//! Map lighting (controls/presentation.js applyLightingEvent / resetLighting /
//! updateLighting) and the DefaultEnvironment light bridge
//! (controls/environment-bridge.js defaultEnvironmentLightingState).

use super::map::Event;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum LightColor {
    Left,
    Right,
    White,
}

const GROUP_DEFAULT_COLORS: [LightColor; 5] = [LightColor::Right, LightColor::Left, LightColor::Right, LightColor::Left, LightColor::Right];

#[derive(Clone, Copy, Debug)]
pub struct LightState {
    pub intensity: f64,
    pub target: f64,
    pub color: LightColor,
    pub last_color: LightColor,
    pub flash_start: f64,
    pub fade_start: f64,
    pub fade_from: f64,
    pub fade_duration: f64,
    pub transition_start: f64,
    pub transition_from: f64,
    pub transition_to: f64,
    pub transition_duration: f64,
}

impl LightState {
    fn new(i: usize) -> Self {
        LightState {
            intensity: 0.0,
            target: 0.0,
            color: GROUP_DEFAULT_COLORS[i],
            last_color: GROUP_DEFAULT_COLORS[i],
            flash_start: -99.0,
            fade_start: -99.0,
            fade_from: 0.0,
            fade_duration: 0.65,
            transition_start: -99.0,
            transition_from: 0.0,
            transition_to: 0.0,
            transition_duration: 0.44,
        }
    }
}

/// `--leftPulse` / `--rightPulse` / `--songPulse` as last pushed to the DOM.
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct Pulses {
    pub left: f64,
    pub right: f64,
    pub song: f64,
}

pub struct Lighting {
    pub states: [LightState; 5],
    event_index: usize,
    last_light_time: f64,
    /// CSS variables (throttled exactly like the DOM writes).
    pub css: Pulses,
    last_css_values: Pulses,
    last_css_update_ms: f64,
}

impl Default for Lighting {
    fn default() -> Self {
        Lighting {
            states: std::array::from_fn(LightState::new),
            event_index: 0,
            last_light_time: 0.0,
            css: Pulses::default(),
            last_css_values: Pulses { left: -1.0, right: -1.0, song: -1.0 },
            last_css_update_ms: 0.0,
        }
    }
}

fn clamp01(v: f64) -> f64 {
    v.clamp(0.0, 1.0)
}

/// JS `x | 0` for the small integers used by events.
fn int32(x: f64) -> i32 {
    if x.is_finite() { (x.trunc() as i64) as i32 } else { 0 }
}

fn event_color_name(value: i32, state: &LightState) -> LightColor {
    match value {
        1..=4 => LightColor::Right,
        5..=8 => LightColor::Left,
        9..=12 => LightColor::White,
        _ => state.last_color,
    }
}

fn apply_event(states: &mut [LightState; 5], e: &Event, event_time: f64) {
    let group = int32(e.t).clamp(0, 4) as usize;
    let state = &mut states[group];
    let value = int32(e.v);
    let f = if e.f == 0.0 || e.f.is_nan() { 1.0 } else { e.f };
    let strength = clamp01(f).max(0.28);
    if value == 0 {
        state.target = 0.0;
        state.intensity = 0.0;
        state.flash_start = -99.0;
        state.fade_start = -99.0;
        state.transition_start = -99.0;
        return;
    }
    let color = event_color_name(value, state);
    state.color = color;
    state.last_color = color;
    // Blocks of four: On / Flash / Fade / Transition (JS remainder semantics).
    let mode = ((value - 1) % 4) + 1;
    let steady = 0.72 + 0.56 * strength;
    if mode == 1 {
        state.target = steady;
        state.intensity = state.intensity.max(state.target * 0.82);
        state.flash_start = -99.0;
        state.fade_start = -99.0;
        state.transition_start = -99.0;
    } else if mode == 2 {
        state.target = 0.3 + 0.3 * strength;
        state.intensity = 1.62 + 0.78 * strength;
        state.flash_start = event_time;
        state.fade_start = -99.0;
        state.transition_start = -99.0;
    } else if mode == 3 {
        state.fade_from = 1.32 + 0.72 * strength;
        state.intensity = state.fade_from;
        state.target = 0.02 + 0.05 * strength;
        state.fade_start = event_time;
        state.flash_start = -99.0;
        state.transition_start = -99.0;
        state.fade_duration = 0.6 + 0.32 * (1.0 - strength);
    } else {
        state.transition_from = state.intensity;
        state.transition_to = steady;
        state.target = steady;
        state.transition_start = event_time;
        state.transition_duration = 0.34 + 0.22 * (1.0 - strength);
        state.flash_start = -99.0;
        state.fade_start = -99.0;
    }
}

impl Lighting {
    pub fn reset(&mut self, time: f64, events: &[Event], bpm: f64, offset: f64) {
        for (i, s) in self.states.iter_mut().enumerate() {
            s.intensity = 0.0;
            s.target = 0.0;
            s.color = GROUP_DEFAULT_COLORS[i];
            s.last_color = GROUP_DEFAULT_COLORS[i];
            s.flash_start = -99.0;
            s.fade_start = -99.0;
            s.transition_start = -99.0;
            s.transition_from = 0.0;
            s.transition_to = 0.0;
        }
        self.event_index = 0;
        let spb = 60.0 / bpm;
        while self.event_index < events.len() {
            let e = &events[self.event_index];
            let et = e.b * spb + offset;
            if et > time {
                break;
            }
            apply_event(&mut self.states, e, et);
            self.event_index += 1;
        }
        self.css = Pulses::default();
        self.last_light_time = time;
    }

    pub fn update(&mut self, time: f64, dt: f64, events: &[Event], bpm: f64, offset: f64, now_ms: f64) {
        if time < self.last_light_time - 0.05 || time - self.last_light_time > 0.75 {
            self.reset(time, events, bpm, offset);
        }
        let spb = 60.0 / bpm;
        while self.event_index < events.len() {
            let e = &events[self.event_index];
            let et = e.b * spb + offset;
            if et > time {
                break;
            }
            apply_event(&mut self.states, e, et);
            self.event_index += 1;
        }
        let (mut left, mut right) = (0.0, 0.0);
        for state in &mut self.states {
            if state.flash_start > -90.0 {
                let age = (time - state.flash_start).max(0.0);
                state.intensity = state.target.max((2.35 - state.target) * (-age * 6.3).exp() + state.target);
                if age > 0.92 {
                    state.flash_start = -99.0;
                }
            } else if state.fade_start > -90.0 {
                let q = clamp01((time - state.fade_start) / state.fade_duration);
                state.intensity = state.target.max(state.fade_from * (1.0 - q) * (1.0 - q) * (1.0 - q));
                if q >= 1.0 {
                    state.fade_start = -99.0;
                    state.intensity = state.target;
                }
            } else if state.transition_start > -90.0 {
                let q = clamp01((time - state.transition_start) / state.transition_duration.max(0.001));
                let eased = q * q * (3.0 - 2.0 * q);
                state.intensity = state.transition_from + (state.transition_to - state.transition_from) * eased;
                if q >= 1.0 {
                    state.transition_start = -99.0;
                    state.intensity = state.target;
                }
            } else {
                let smoothing = 1.0 - 0.00022f64.powf(dt.max(0.001));
                state.intensity += (state.target - state.intensity) * smoothing;
            }
            match state.color {
                LightColor::Left => left += state.intensity,
                LightColor::Right => right += state.intensity,
                LightColor::White => {
                    left += state.intensity * 0.72;
                    right += state.intensity * 0.72;
                }
            }
        }
        let lp = (left / 2.15).min(1.9);
        let rp = (right / 2.15).min(1.9);
        let song = lp.max(rp);
        if now_ms - self.last_css_update_ms > 66.0 || (lp - self.last_css_values.left).abs() > 0.08 || (rp - self.last_css_values.right).abs() > 0.08 {
            self.css = Pulses { left: lp, right: rp, song };
            self.last_css_values = self.css;
            self.last_css_update_ms = now_ms;
        }
        self.last_light_time = time;
    }

    /// The reflLeftPulse / reflRightPulse sums of flush3DFrame (unthrottled).
    pub fn reflection_pulses(&self) -> (f64, f64) {
        let (mut l, mut r) = (0.0, 0.0);
        for s in &self.states {
            let i = s.intensity.max(0.0);
            let i = if i.is_nan() { 0.0 } else { i };
            match s.color {
                LightColor::Left => l += i,
                LightColor::Right => r += i,
                LightColor::White => {
                    l += i * 0.72;
                    r += i * 0.72;
                }
            }
        }
        ((l / 2.15).min(1.9), (r / 2.15).min(1.9))
    }

    /// defaultEnvironmentLightingState()
    pub fn environment_state(&self) -> EnvLight {
        let (mut red, mut blue, mut white) = (0.0f64, 0.0f64, 0.0f64);
        for i in [0, 2, 3, 4] {
            let s = &self.states[i];
            let amount = s.intensity.max(0.0);
            match s.color {
                LightColor::Left => red += amount,
                LightColor::Right => blue += amount,
                LightColor::White => white += amount,
            }
        }
        let (mut scene_mode, mut scene_amt) = (4, 0.0);
        let strongest = red.max(blue).max(white);
        if strongest > 0.015 {
            scene_amt = strongest.min(2.25);
            if white >= 0.8 * red.max(blue) && white > 0.05 {
                scene_mode = 3;
            } else {
                let lo = red.min(blue);
                let hi = red.max(blue);
                scene_mode = if lo > 0.08 && hi / lo.max(0.001) < 2.35 {
                    0
                } else if red > blue {
                    2
                } else {
                    1
                };
            }
        }
        let rs = &self.states[1];
        let (mut ring_mode, mut ring_amt) = (4, 0.0);
        if rs.intensity > 0.012 {
            ring_mode = match rs.color {
                LightColor::Left => 2,
                LightColor::White => 3,
                LightColor::Right => 1,
            };
            ring_amt = rs.intensity.max(0.0).min(2.25);
        }
        EnvLight { scene_mode, scene_amt, ring_mode, ring_amt }
    }
}

#[derive(Clone, Copy, Debug, Default)]
pub struct EnvLight {
    pub scene_mode: i32,
    pub scene_amt: f64,
    pub ring_mode: i32,
    pub ring_amt: f64,
}
