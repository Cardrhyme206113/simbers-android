//! Per-frame scene construction: the port of renderer.js render() (draw list),
//! drawBlock / drawBomb / drawObstacle / drawSlider, the jump timing of
//! drawing-primitives.js and loadDifficulty (controls/map-state.js).

use super::Quality;
use super::geom::{self, Bounds, Caster, Ctx, FrameGeometry, P3, Target};
use super::map::{Beatmap, Embedded, Event, Info, Note, Obstacle, RotationEvent, Slider, css_rgb01};

pub const DEFAULT_ENV_CAMERA_Y: f64 = 1.7 + 0.35;
pub const DEFAULT_ENV_CAMERA_Z: f64 = -2.0;
pub const DEFAULT_ENV_FOV_Y: f64 = (100.0 * std::f64::consts::PI) / 180.0;
pub const DEFAULT_ENV_LANE_WIDTH: f64 = 1.18;
pub const DEFAULT_ENV_ROW_HEIGHT: f64 = 1.12;
pub const DEFAULT_ENV_NOTE_SCALE: f64 = 2.0;
pub const DEFAULT_ENV_NOTE_Y_OFFSET: f64 = 0.7;
pub const DEFAULT_ENV_CUT_WORLD_Z: f64 = 9.1;
pub const DEFAULT_ENV_SPAWN_WORLD_Z: f64 = 99.0;
pub const DEFAULT_ENV_LIFETIME_SCALE: f64 = 0.66;
pub const DEFAULT_ENV_MAX_GAMEPLAY_DPR: f64 = 2.0;
pub const CAMERA_PITCH: f64 = 0.0;
pub const CYBER_HMD_LONG_AXIS_FOV: f64 = (110.0 * std::f64::consts::PI) / 180.0;

pub fn uses_default_environment(mode: &str) -> bool {
    mode != "90Degree" && mode != "360Degree"
}

/// "Note approach" select of the replay dock.
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum Approach {
    Auto,
    Factor(f64),
}

/// updateArcViewerJumpTiming() results.
#[derive(Clone, Copy, Debug)]
pub struct Timing {
    pub njs: f64,
    pub reaction_time: f64,
    pub half_jump_distance: f64,
    pub move_time: f64,
    pub move_z: f64,
    pub world_to_viewer_z: f64,
    pub lead_time: f64,
    pub near_z: f64,
    pub far_z: f64,
    pub eye_y: f64,
    pub fov_y: f64,
}

impl Default for Timing {
    fn default() -> Self {
        Timing {
            njs: 16.0,
            reaction_time: 1.0,
            half_jump_distance: 16.0,
            move_time: 0.5,
            move_z: 8.0,
            world_to_viewer_z: 1.0,
            lead_time: 1.944,
            near_z: 3.15,
            far_z: 42.0,
            eye_y: 1.11,
            fov_y: (105.0 * std::f64::consts::PI) / 180.0,
        }
    }
}

impl Timing {
    pub fn compute(bpm: f64, meta_njs: Option<f64>, difficulty: &str, default_env: bool, approach: Approach) -> Timing {
        let bpm = (if bpm == 0.0 || bpm.is_nan() { 60.0 } else { bpm }).max(0.0001);
        let fallback = match difficulty {
            "ExpertPlus" => 16.0,
            "Expert" => 12.0,
            _ => 10.0,
        };
        let njs = meta_njs.filter(|n| *n != 0.0 && !n.is_nan()).unwrap_or(fallback).max(0.01);
        let mut t = Timing { njs, ..Timing::default() };
        let mut default_hjd = 4.0;
        let jump_distance = |hjd: f64| t.njs * 2.0 * ((60.0 / bpm) * hjd);
        while jump_distance(default_hjd) > 35.998 {
            default_hjd /= 2.0;
        }
        let hjd = (default_hjd + 0.0f64).max(0.25);
        t.reaction_time = (60.0 / bpm) * hjd;
        t.half_jump_distance = t.reaction_time * t.njs;
        if default_env {
            t.reaction_time *= DEFAULT_ENV_LIFETIME_SCALE;
            t.njs /= DEFAULT_ENV_LIFETIME_SCALE;
            t.eye_y = DEFAULT_ENV_CAMERA_Y;
            t.fov_y = DEFAULT_ENV_FOV_Y;
            t.near_z = DEFAULT_ENV_CUT_WORLD_Z - DEFAULT_ENV_CAMERA_Z;
            t.move_time = 0.975 * DEFAULT_ENV_LIFETIME_SCALE;
            let travel = DEFAULT_ENV_SPAWN_WORLD_Z - DEFAULT_ENV_CUT_WORLD_Z;
            t.move_z = (travel - t.half_jump_distance).max(0.0);
            t.far_z = t.near_z + travel;
            t.world_to_viewer_z = 1.0;
        } else {
            t.eye_y = 1.11;
            t.fov_y = (105.0 * std::f64::consts::PI) / 180.0;
            t.near_z = 3.15;
            t.far_z = 42.0;
            t.move_time = 0.5;
            t.move_z = 8.0;
            t.world_to_viewer_z = (t.far_z - t.near_z) / (t.half_jump_distance + t.move_z).max(0.001);
        }
        let factor = match approach {
            Approach::Auto => {
                if difficulty == "ExpertPlus" {
                    1.32
                } else {
                    1.0
                }
            }
            Approach::Factor(f) => (if f == 0.0 || f.is_nan() { 1.0 } else { f }).clamp(0.75, 1.8),
        };
        t.reaction_time /= factor;
        t.njs *= factor;
        t.move_time /= factor;
        t.lead_time = t.reaction_time + t.move_time;
        t
    }

    pub fn world_distance_for_delta(&self, dt: f64) -> f64 {
        if dt <= self.reaction_time {
            return (dt * self.njs).max(0.0);
        }
        let move_progress = (dt - self.reaction_time) / self.move_time.max(0.001);
        self.half_jump_distance + self.move_z * move_progress
    }
    pub fn note_z(&self, dt: f64) -> f64 {
        self.near_z + self.world_distance_for_delta(dt) * self.world_to_viewer_z
    }
    pub fn jump_progress(&self, dt: f64) -> f64 {
        (self.reaction_time - dt) / self.reaction_time.max(0.001)
    }
    pub fn time_to_progress(&self, dt: f64) -> f64 {
        ((self.lead_time - dt) / self.lead_time.max(0.0001)).clamp(0.0, 1.0)
    }
    pub fn progress_to_z(&self, p: f64) -> f64 {
        self.far_z - (self.far_z - self.near_z) * crate::util::jsm::pow(p, 1.72)
    }
    pub fn arc_z(&self, dt: f64, default_env: bool) -> f64 {
        if default_env {
            if dt >= 0.0 {
                return self.near_z + self.world_distance_for_delta(dt);
            }
            return self.near_z + dt * self.njs;
        }
        if dt >= 0.0 {
            return self.progress_to_z(self.time_to_progress(dt));
        }
        let terminal = (self.far_z - self.near_z) / self.lead_time.max(0.0001);
        self.near_z + dt * terminal
    }
    pub fn wall_z(&self, dt: f64, default_env: bool) -> f64 {
        if default_env {
            if dt >= 0.0 {
                return self.near_z + self.world_distance_for_delta(dt);
            }
            return self.near_z;
        }
        if dt >= 0.0 {
            return self.progress_to_z(self.time_to_progress(dt));
        }
        self.near_z
    }
}

/// `Number(v || 0)`
fn or0(v: f64) -> f64 {
    if v == 0.0 || v.is_nan() { 0.0 } else { v }
}
/// `Math.max(1, Number(v) || 1)`
fn at_least1(v: f64) -> f64 {
    (if v == 0.0 || v.is_nan() { 1.0 } else { v }).max(1.0)
}

pub fn lane_position(default_env: bool, column: f64, row: f64) -> (f64, f64) {
    if default_env {
        let x0 = -1.5 * DEFAULT_ENV_LANE_WIDTH;
        return (x0 + or0(column) * DEFAULT_ENV_LANE_WIDTH, or0(row) * DEFAULT_ENV_ROW_HEIGHT + DEFAULT_ENV_NOTE_Y_OFFSET);
    }
    ((column - 1.5) * 1.02, (row - 0.82) * 0.94)
}

pub fn obstacle_bounds(default_env: bool, ob: &Obstacle) -> Bounds {
    if default_env {
        let (w, h) = (DEFAULT_ENV_LANE_WIDTH, DEFAULT_ENV_ROW_HEIGHT);
        let left = -2.0 * w + or0(ob.x) * w;
        let right = left + at_least1(ob.w) * w;
        let bottom = or0(ob.y) * h + DEFAULT_ENV_NOTE_Y_OFFSET - h * 0.5;
        let top = bottom + at_least1(ob.h) * h;
        return Bounds { left, right, bottom, top };
    }
    let (w, h) = (1.02, 0.94);
    let left = (ob.x - 2.0) * w;
    let right = left + at_least1(ob.w) * w;
    let bottom = (ob.y - 0.82) * h - h * 0.5;
    let top = bottom + at_least1(ob.h) * h;
    Bounds { left, right, bottom, top }
}

/// wallPalette(): (fill, edge)
pub fn wall_palette(b: &Bounds) -> ([f32; 3], [f32; 3]) {
    if b.right <= 0.0 {
        (css_rgb01("#8f171b"), css_rgb01("#e83d47"))
    } else if b.left >= 0.0 {
        (css_rgb01("#1d6094"), css_rgb01("#3fa8ef"))
    } else {
        (css_rgb01("#66328f"), css_rgb01("#b86be3"))
    }
}

fn smoothstep(t: f64) -> f64 {
    let t = t.clamp(0.0, 1.0);
    t * t * (3.0 - 2.0 * t)
}

/// The difficulty currently shown (loadDifficulty).
#[derive(Default)]
pub struct ActiveMap {
    pub mode: String,
    pub difficulty: String,
    pub notes: Vec<Note>,
    pub color_notes: Vec<Note>,
    /// arcViewerStartYForNote, precomputed per color note.
    pub color_start_y: Vec<f64>,
    pub bomb_notes: Vec<Note>,
    pub obstacles: Vec<Obstacle>,
    pub sliders: Vec<Slider>,
    pub light_events: Vec<Event>,
    pub ring_events: Vec<Event>,
    pub rotation_events: Vec<RotationEvent>,
    /// (seconds, angle)
    pub rotation_timeline: Vec<(f64, f64)>,
    pub max_obstacle_duration_beats: f64,
    pub max_slider_duration_beats: f64,
}

impl ActiveMap {
    pub fn from_beatmap(mode: &str, difficulty: &str, bm: &Beatmap, info: &Info) -> ActiveMap {
        let default_env = uses_default_environment(mode);
        let notes = bm.notes.clone();
        let color_notes: Vec<Note> = notes.iter().copied().filter(|n| n.c == 0.0 || n.c == 1.0).collect();
        let bomb_notes: Vec<Note> = notes.iter().copied().filter(|n| n.c == 3.0).collect();
        // arcViewerStartYForNote: count same-beat same-column notes below this one.
        let color_start_y = color_notes
            .iter()
            .map(|note| {
                if !default_env {
                    return 0.0;
                }
                let mut below = 0usize;
                let mut skipped_self = false;
                for n in &notes {
                    if !skipped_self && n == note {
                        skipped_self = true;
                        continue;
                    }
                    if (n.b - note.b).abs() > 0.001 {
                        continue;
                    }
                    if n.x != note.x {
                        continue;
                    }
                    if n.y < note.y {
                        below += 1;
                    }
                }
                DEFAULT_ENV_NOTE_Y_OFFSET + below as f64 * DEFAULT_ENV_ROW_HEIGHT
            })
            .collect();
        let max_obstacle_duration_beats = bm.obstacles.iter().fold(0.0f64, |m, o| m.max(or0(o.dur)));
        let max_slider_duration_beats = bm.sliders.iter().fold(0.0f64, |m, s| m.max((or0(s.tb) - or0(s.hb)).abs()));
        // buildRotationTimeline
        let mut angle = 0.0;
        let rotation_timeline = bm
            .rotation_events
            .iter()
            .map(|e| {
                let delta = match e.r.filter(|r| r.is_finite()) {
                    Some(r) => r,
                    None => rotation_delta_from_event_value(e.v),
                };
                angle += delta;
                if mode == "90Degree" {
                    angle = angle.clamp(-45.0, 45.0);
                }
                let bpm = if info.bpm == 0.0 || info.bpm.is_nan() { 60.0 } else { info.bpm };
                ((e.b * 60.0) / bpm + or0(info.offset), angle)
            })
            .collect();
        ActiveMap {
            mode: mode.to_string(),
            difficulty: difficulty.to_string(),
            notes,
            color_notes,
            color_start_y,
            bomb_notes,
            obstacles: bm.obstacles.clone(),
            sliders: bm.sliders.clone(),
            light_events: bm.events.clone(),
            ring_events: bm.ring_events.clone(),
            rotation_events: bm.rotation_events.clone(),
            rotation_timeline,
            max_obstacle_duration_beats,
            max_slider_duration_beats,
        }
    }

    pub fn is_empty_visuals(&self) -> bool {
        self.color_notes.is_empty() && self.bomb_notes.is_empty() && self.obstacles.is_empty() && self.sliders.is_empty()
    }

    pub fn rotation_angle_for_time(&self, seconds: f64) -> f64 {
        if (self.mode != "90Degree" && self.mode != "360Degree") || self.rotation_timeline.is_empty() {
            return 0.0;
        }
        let mut result = 0.0;
        for &(time, angle) in &self.rotation_timeline {
            if time > seconds {
                break;
            }
            result = angle;
        }
        result
    }

    pub fn status_text(&self) -> String {
        format!(
            "{} · {} · {} notes · {} bombs · {} walls · {} arcs",
            super::map::characteristic_label(&self.mode),
            super::map::difficulty_label(&self.difficulty),
            self.color_notes.len(),
            self.bomb_notes.len(),
            self.obstacles.len(),
            self.sliders.len()
        )
    }
}

fn rotation_delta_from_event_value(value: f64) -> f64 {
    let v = (if value.is_nan() { 0.0 } else { value }).clamp(0.0, 7.0);
    match v {
        x if x == 0.0 => -60.0,
        x if x == 1.0 => -45.0,
        x if x == 2.0 => -30.0,
        x if x == 3.0 => -15.0,
        x if x == 4.0 => 15.0,
        x if x == 5.0 => 30.0,
        x if x == 6.0 => 45.0,
        x if x == 7.0 => 60.0,
        _ => 0.0,
    }
}

/// lowerBoundKey(arr, value, key)
fn lower_bound<T>(arr: &[T], value: f64, key: impl Fn(&T) -> f64) -> usize {
    let (mut lo, mut hi) = (0usize, arr.len());
    while lo < hi {
        let mid = (lo + hi) >> 1;
        if key(&arr[mid]) < value {
            lo = mid + 1;
        } else {
            hi = mid;
        }
    }
    lo
}

/// 360° spectator camera (rotation.js update360Camera / target360YawFromUpcomingNotes).
pub fn target_360_yaw(map: &ActiveMap, info: &Info, timing: &Timing, t: f64) -> f64 {
    let bpm = (if info.bpm == 0.0 || info.bpm.is_nan() { 60.0 } else { info.bpm }).max(0.0001);
    let spb = 60.0 / bpm;
    let offset = or0(info.offset);
    let beat_now = (t - offset) / spb;
    let source = if !map.color_notes.is_empty() { &map.color_notes } else { &map.bomb_notes };
    if source.is_empty() {
        return map.rotation_angle_for_time(t);
    }
    let mut i = lower_bound(source, beat_now - 0.001, |n| n.b);
    while i < source.len() {
        let note_time = source[i].b * spb + offset;
        if note_time >= t - 0.02 {
            break;
        }
        i += 1;
    }
    if i >= source.len() {
        return map.rotation_angle_for_time(t);
    }
    let first_time = source[i].b * spb + offset;
    if first_time - t > timing.lead_time {
        return map.rotation_angle_for_time(t);
    }
    let group_window = (spb * 0.18).min(0.12).max(0.045);
    let (mut sx, mut sz, mut count) = (0.0, 0.0, 0);
    for note in &source[i..] {
        if count >= 8 {
            break;
        }
        let note_time = note.b * spb + offset;
        if note_time - first_time > group_window {
            break;
        }
        let (px, _) = lane_position(false, note.x, note.y);
        let map_yaw = map.rotation_angle_for_time(note_time);
        let world = geom::rotate_point_y(P3::new(px, 0.0, 7.5), map_yaw);
        let yaw = crate::util::jsm::atan2(world.x, world.z);
        sx += crate::util::jsm::sin(yaw);
        sz += crate::util::jsm::cos(yaw);
        count += 1;
    }
    if count == 0 {
        return map.rotation_angle_for_time(first_time);
    }
    (crate::util::jsm::atan2(sx / count as f64, sz / count as f64) * 180.0) / std::f64::consts::PI
}

/// Colors resolved once per palette (cssRgb01 of COLORS.*).
#[derive(Clone, Copy, Debug)]
pub struct SceneColors {
    pub left_front: [f32; 3],
    pub left_top: [f32; 3],
    pub right_front: [f32; 3],
    pub right_top: [f32; 3],
}

impl SceneColors {
    pub fn new(left: &super::map::SaberColors, right: &super::map::SaberColors) -> Self {
        SceneColors { left_front: css_rgb01(&left.front), left_top: css_rgb01(&left.top), right_front: css_rgb01(&right.front), right_top: css_rgb01(&right.top) }
    }
}

pub struct SceneInput<'a> {
    pub t: f64,
    pub info: &'a Info,
    pub map: &'a ActiveMap,
    pub timing: &'a Timing,
    pub colors: &'a SceneColors,
    pub quality: Quality,
    pub paused: bool,
    /// cameraYawDeg when in 360° mode.
    pub camera_yaw_deg: f64,
    pub block_meshes: &'a [super::meshes::Mesh],
    pub bomb_unit: &'a super::meshes::BombUnit,
}

enum Item {
    Slider(usize, f64, f64, f64),
    Obstacle(usize, f64, f64, f64),
    Bomb(usize, f64, f64, f64),
    Note(usize, f64, f64, f64, f64, f64),
}

/// render(): build every gameplay command buffer for time `t`.
pub fn build(g: &mut FrameGeometry, s: &SceneInput) {
    let map = s.map;
    let timing = s.timing;
    let default_env = uses_default_environment(&map.mode);
    let ctx = Ctx {
        yaw_offset: if map.mode == "360Degree" { s.camera_yaw_deg } else { 0.0 },
        near_z: timing.near_z,
        eye_y: timing.eye_y,
        default_env,
        quality: s.quality,
        bpm: s.info.bpm,
    };
    let t = s.t;
    let bpm = s.info.bpm;
    let spb = 60.0 / bpm;
    let offset = s.info.offset;
    let beat_now = (t - offset) / spb;
    let lead_beats = timing.lead_time / spb;
    let lead = timing.lead_time;
    let mut list: Vec<(f64, Item)> = vec![];

    let slider_start = lower_bound(&map.sliders, beat_now - map.max_slider_duration_beats, |x| x.hb);
    for (i, slider) in map.sliders.iter().enumerate().skip(slider_start) {
        if slider.hb > beat_now + lead_beats {
            break;
        }
        let raw_head = slider.hb * spb + offset;
        let raw_tail = slider.tb * spb + offset;
        let first_time = raw_head.min(raw_tail);
        let last_time = raw_head.max(raw_tail);
        if first_time - t > lead {
            continue;
        }
        if last_time <= t {
            continue;
        }
        let z_head = timing.arc_z(raw_head - t, default_env);
        let z_tail = timing.arc_z(raw_tail - t, default_env);
        let angle = map.rotation_angle_for_time(raw_head);
        let (sx, sy) = lane_position(default_env, slider.hx, slider.hy);
        let (ex, ey) = lane_position(default_env, slider.tx, slider.ty);
        let rz_head = ctx.rot(P3::new(sx, sy, z_head), angle).z;
        let rz_tail = ctx.rot(P3::new(ex, ey, z_tail), angle).z;
        list.push(((rz_head + rz_tail) * 0.5, Item::Slider(i, z_head, z_tail, angle)));
    }

    let wall_post = if default_env { 0.08 } else { 0.52 };
    let wall_start_beat = beat_now - map.max_obstacle_duration_beats - wall_post / spb;
    let obstacle_start = lower_bound(&map.obstacles, wall_start_beat, |o| o.b);
    for (i, ob) in map.obstacles.iter().enumerate().skip(obstacle_start) {
        if ob.b > beat_now + lead_beats {
            break;
        }
        let start_time = ob.b * spb + offset;
        let end_time = (ob.b + ob.dur) * spb + offset;
        let (dt_front, dt_back) = (start_time - t, end_time - t);
        if dt_back < -wall_post || dt_front > lead {
            continue;
        }
        let z_front = timing.wall_z(dt_front, default_env);
        let z_back = timing.wall_z(dt_back, default_env);
        let angle = map.rotation_angle_for_time(start_time);
        let b = obstacle_bounds(default_env, ob);
        let center = P3::new((b.left + b.right) * 0.5, (b.bottom + b.top) * 0.5, (z_front + z_back) * 0.5);
        list.push((ctx.rot(center, angle).z, Item::Obstacle(i, z_front, z_back, angle)));
    }

    let bomb_start = lower_bound(&map.bomb_notes, beat_now, |n| n.b);
    for (i, note) in map.bomb_notes.iter().enumerate().skip(bomb_start) {
        if note.b > beat_now + lead_beats {
            break;
        }
        let note_time = note.b * spb + offset;
        let dt = note_time - t;
        if dt < 0.0 || dt > lead {
            continue;
        }
        let progress = timing.time_to_progress(dt);
        let z = if default_env { timing.note_z(dt) } else { timing.progress_to_z(progress) };
        let grow = if default_env { 1.0 } else { smoothstep((progress / 0.16).min(1.0)) };
        let angle = map.rotation_angle_for_time(note_time);
        let (px, py) = lane_position(default_env, note.x, note.y);
        list.push((ctx.rot(P3::new(px, py, z), angle).z, Item::Bomb(i, z, grow, angle)));
    }

    let note_start = lower_bound(&map.color_notes, beat_now, |n| n.b);
    for (i, note) in map.color_notes.iter().enumerate().skip(note_start) {
        if note.b > beat_now + lead_beats {
            break;
        }
        let note_time = note.b * spb + offset;
        let dt = note_time - t;
        if dt < 0.0 || dt > lead {
            continue;
        }
        let z = timing.note_z(dt);
        let jump = timing.jump_progress(dt);
        let y = note_y(default_env, note, map.color_start_y[i], timing, dt);
        let spawn = 1.0 - (dt - timing.reaction_time).max(0.0) / timing.move_time.max(0.001);
        let grow = if default_env { 1.0 } else { smoothstep(spawn.clamp(0.0, 1.0)) };
        let angle = map.rotation_angle_for_time(note_time);
        let (px, _) = lane_position(default_env, note.x, note.y);
        list.push((ctx.rot(P3::new(px, y, z), angle).z, Item::Note(i, z, y, grow, angle, jump)));
    }

    // drawList.sort((a, b) => b.z - a.z), stable.
    list.sort_by(|a, b| b.0.partial_cmp(&a.0).unwrap_or(std::cmp::Ordering::Equal));
    let trail = if s.paused { 0.0 } else { s.quality.sim_motion_trail() };
    for (_, item) in &list {
        match *item {
            Item::Slider(i, zh, zt, angle) => draw_slider(g, &ctx, s.colors, &map.sliders[i], zh, zt, angle, default_env),
            Item::Obstacle(i, zf, zb, angle) => draw_obstacle(g, &ctx, &map.obstacles[i], zf, zb, angle),
            Item::Bomb(i, z, grow, angle) => draw_bomb(g, &ctx, &map.bomb_notes[i], z, grow, angle, s.block_meshes.len(), s.bomb_unit),
            Item::Note(i, z, y, grow, angle, jump) => draw_block(g, &ctx, s.colors, &map.color_notes[i], z, y, grow, angle, jump, s.block_meshes, trail),
        }
    }
}

fn note_y(default_env: bool, note: &Note, start: f64, timing: &Timing, dt: f64) -> f64 {
    let target = lane_position(default_env, note.x, note.y).1;
    if dt > timing.reaction_time {
        return start;
    }
    let world = timing.world_distance_for_delta(dt);
    let ratio = world / timing.half_jump_distance.max(0.001);
    target - (target - start) * ratio * ratio
}

/// The original's instanced note program fails to link in every WebGL1
/// browser ("Precisions of uniform 'uEyeX' differ between VERTEX and FRAGMENT
/// shaders"), so NOTE_INSTANCING_ACTIVE is always false there: notes are CPU
/// triangles in the opaque buffer, bombs use the procedural model and the
/// planar mirror pass never runs. Kept switchable; false matches the original.
pub const NOTE_INSTANCING: bool = false;

/// addImportedMesh3D (non-instanced path). Mirrors the original's per-corner
/// near-plane skip exactly, including its triangle misalignment quirk.
#[allow(clippy::too_many_arguments)]
fn add_imported_mesh(g: &mut FrameGeometry, ctx: &Ctx, mesh: &super::meshes::Mesh, tx: f64, ty: f64, tz: f64, scale: f64, z_rot: f64, map_angle: f64, col: [f32; 3], alpha: f64) {
    let target = FrameGeometry::target_for(alpha);
    let (p, n) = (&mesh.positions, &mesh.normals);
    let view = ctx.view_angle(map_angle);
    let buf = g.buf(target);
    for &i in &mesh.indices {
        let i = i as usize;
        let q = P3::new(p[i * 3] as f64 * scale, p[i * 3 + 1] as f64 * scale, p[i * 3 + 2] as f64 * scale);
        let q = geom::rotate_point_z_local(q, z_rot);
        let point = ctx.rot(P3::new(q.x + tx, q.y + ty, q.z + tz), map_angle);
        if point.z < 0.06 {
            continue;
        }
        let nn = geom::rotate_point_z_local(P3::new(n[i * 3] as f64, n[i * 3 + 1] as f64, n[i * 3 + 2] as f64), z_rot);
        let nn = geom::rotate_point_y(nn, view);
        let l = geom::hypot(&[nn.x, nn.y, nn.z]);
        let l = if l == 0.0 || l.is_nan() { 1.0 } else { l };
        buf.extend_from_slice(&[point.x as f32, point.y as f32, point.z as f32, (nn.x / l) as f32, (nn.y / l) as f32, (nn.z / l) as f32, col[0], col[1], col[2], alpha as f32]);
    }
}

/// submitNoteInstance
fn submit_instance(g: &mut FrameGeometry, ctx: &Ctx, group: usize, x: f64, y: f64, z: f64, scale: f64, z_rot_deg: f64, map_angle_deg: f64, col: [f32; 3], alpha: f64) {
    let pi = std::f64::consts::PI;
    g.note_instances[group].extend_from_slice(&[
        x as f32,
        y as f32,
        z as f32,
        scale as f32,
        ((z_rot_deg * pi) / 180.0) as f32,
        ((ctx.view_angle(map_angle_deg) * pi) / 180.0) as f32,
        col[0],
        col[1],
        col[2],
        alpha as f32,
    ]);
}

fn draw_sim_note_trails(g: &mut FrameGeometry, ctx: &Ctx, center: P3, half: f64, color: [f32; 3], angle: f64, strength: f64) {
    if strength == 0.0 {
        return;
    }
    for n in 1..=2 {
        let fade = if n == 1 { 1.0 } else { 0.44 };
        let spread = half * if n == 1 { 1.04 } else { 0.9 };
        let d = if n == 1 { 0.52 } else { 1.04 };
        let z = center.z + d;
        let p0 = ctx.rot(P3::new(center.x - spread, center.y - spread, z), angle);
        let p1 = ctx.rot(P3::new(center.x + spread, center.y - spread, z), angle);
        let p2 = ctx.rot(P3::new(center.x + spread, center.y + spread, z), angle);
        let p3 = ctx.rot(P3::new(center.x - spread, center.y + spread, z), angle);
        g.quad(Target::Transparent, p0, p1, p2, p3, color, strength * fade);
    }
}

#[allow(clippy::too_many_arguments)]
fn draw_block(g: &mut FrameGeometry, ctx: &Ctx, colors: &SceneColors, note: &Note, z: f64, y: f64, scale: f64, angle: f64, jump: f64, block_meshes: &[super::meshes::Mesh], trail: f64) {
    let (lx, ly) = lane_position(ctx.default_env, note.x, note.y);
    let y = if y.is_finite() { y } else { ly };
    let tint = if note.c == 0.0 { colors.left_front } else { colors.right_front };
    let object_angle = geom::object_angle(note.d, jump);
    if ctx.default_env {
        let c = ctx.rot(P3::new(lx, y, z), angle);
        let half = (0.1715 * DEFAULT_ENV_NOTE_SCALE * scale).max(0.154);
        let reflect_half = half * 0.8;
        g.casters.push(Caster {
            kind: if note.d == 8.0 { 3.0 } else { 0.0 },
            x: c.x,
            y: c.y,
            z: c.z,
            hx: reflect_half,
            hy: reflect_half,
            hz: reflect_half,
            angle: (object_angle * std::f64::consts::PI) / 180.0,
            r: tint[0] as f64,
            g: tint[1] as f64,
            b: tint[2] as f64,
            opacity: 0.91,
        });
        draw_sim_note_trails(g, ctx, P3::new(lx, y, z), half, tint, angle, trail);
    }
    // addArcViewerBlock3D
    let physical = ctx.default_env;
    let mesh_scale = (if physical { DEFAULT_ENV_NOTE_SCALE } else { 1.74 }) * scale;
    let material = if physical { 1.1 } else { 1.0 };
    for (m, mesh) in block_meshes.iter().enumerate() {
        if NOTE_INSTANCING && material >= 0.985 {
            submit_instance(g, ctx, m, lx, y, z, mesh_scale, object_angle, angle, tint, material);
        } else {
            add_imported_mesh(g, ctx, mesh, lx, y, z, mesh_scale, object_angle, angle, tint, material);
        }
    }
    let arrow_scale = (if physical { 0.5 * DEFAULT_ENV_NOTE_SCALE } else { 0.87 }) * scale;
    let arrow_front = (if physical { 0.255 * DEFAULT_ENV_NOTE_SCALE } else { 0.445 }) * scale;
    geom::cut_mark(g, ctx, note.d, lx, y, z - arrow_front, arrow_scale, object_angle, angle);
}

fn draw_bomb(g: &mut FrameGeometry, ctx: &Ctx, note: &Note, z: f64, scale: f64, angle: f64, block_meshes: usize, unit: &super::meshes::BombUnit) {
    let (px, py) = lane_position(ctx.default_env, note.x, note.y);
    if ctx.default_env {
        let c = ctx.rot(P3::new(px, py, z), angle);
        let radius = (0.1624 * DEFAULT_ENV_NOTE_SCALE * scale * 1.255).max(0.098) * 0.8;
        g.casters.push(Caster { kind: 1.0, x: c.x, y: c.y, z: c.z, hx: radius, hy: radius, hz: radius, angle: 0.0, r: 0.52, g: 0.63, b: 0.8, opacity: 0.85 });
    }
    let body = (if ctx.default_env { 0.232 * DEFAULT_ENV_NOTE_SCALE } else { 0.395 }) * scale;
    if NOTE_INSTANCING {
        let cols = [[0.063, 0.071, 0.086], [0.09, 0.102, 0.125], [0.043, 0.051, 0.063]];
        for (k, col) in cols.iter().enumerate() {
            submit_instance(g, ctx, block_meshes + k, px, py, z, body, 0.0, angle, *col, 1.2);
        }
        return;
    }
    // Legacy procedural bomb (BOMB_INSTANCE_MESHES is null in the original).
    let spike_base = body * 0.91;
    let spike_tip = body * 1.255;
    let spike_r = body * 0.135;
    let body_a = css_rgb01("#101216");
    let body_b = css_rgb01("#171a20");
    let spike_col = css_rgb01("#0b0d10");
    let material = if ctx.default_env { 1.2 } else { 1.0 };
    for (i, tri) in unit.tris.iter().enumerate() {
        let pts = tri.map(|q| ctx.rot(P3::new(px + q.x * body, py + q.y * body, z + q.z * body), angle));
        g.tri(Target::Opaque, pts[0], pts[1], pts[2], if i % 3 == 0 { body_b } else { body_a }, material, None);
    }
    for dir in &unit.spikes {
        let (u, v) = super::meshes::bomb_basis(*dir);
        let ring: Vec<P3> = (0..6)
            .map(|k| {
                let a = (k as f64 / 6.0) * std::f64::consts::PI * 2.0;
                let (ca, sa) = (a.cos(), a.sin());
                ctx.rot(
                    P3::new(
                        px + dir.x * spike_base + (u.x * ca + v.x * sa) * spike_r,
                        py + dir.y * spike_base + (u.y * ca + v.y * sa) * spike_r,
                        z + dir.z * spike_base + (u.z * ca + v.z * sa) * spike_r,
                    ),
                    angle,
                )
            })
            .collect();
        let tip = ctx.rot(P3::new(px + dir.x * spike_tip, py + dir.y * spike_tip, z + dir.z * spike_tip), angle);
        for k in 0..6 {
            g.tri(Target::Opaque, ring[k], ring[(k + 1) % 6], tip, spike_col, material, None);
        }
    }
}

fn draw_obstacle(g: &mut FrameGeometry, ctx: &Ctx, ob: &Obstacle, z_front: f64, z_back: f64, angle: f64) {
    let b = obstacle_bounds(ctx.default_env, ob);
    let (fill, edge) = wall_palette(&b);
    let nearest = z_front.min(z_back);
    let z0 = ctx.near_z.max(nearest);
    let z1 = z_front.max(z_back);
    if z1 <= z0 + 0.01 {
        return;
    }
    let proximity = ((nearest - ctx.near_z) / 6.0).clamp(0.0, 1.0);
    let fade = proximity * proximity * (3.0 - 2.0 * proximity);
    if fade <= 0.003 {
        return;
    }
    if ctx.default_env {
        let center = ctx.rot(P3::new((b.left + b.right) * 0.5, (b.bottom + b.top) * 0.5, (z0 + z1) * 0.5), angle);
        g.casters.push(Caster {
            kind: 2.0,
            x: center.x,
            y: center.y,
            z: center.z,
            hx: ((b.right - b.left) * 0.5).max(0.08),
            hy: ((b.top - b.bottom) * 0.5).max(0.08),
            hz: ((z1 - z0) * 0.5).max(0.12),
            angle: 0.0,
            r: edge[0] as f64,
            g: edge[1] as f64,
            b: edge[2] as f64,
            opacity: 0.5 * fade,
        });
        g.wall_instances.extend_from_slice(&[
            b.left as f32,
            b.bottom as f32,
            z0 as f32,
            fade as f32,
            (b.right - b.left) as f32,
            (b.top - b.bottom) as f32,
            (z1 - z0) as f32,
            ((ctx.view_angle(angle) * std::f64::consts::PI) / 180.0) as f32,
            fill[0],
            fill[1],
            fill[2],
            edge[0],
            edge[1],
            edge[2],
        ]);
        return;
    }
    geom::add_box(g, ctx, b.left, b.right, b.bottom, b.top, z0, z1, fill, 0.082 * fade, angle, None);
    if fade > 0.025 {
        geom::add_box(g, ctx, b.left, b.right, b.bottom, b.top, z0, z1, fill, 1.0, angle, Some(Target::WallOccluders));
    }
    geom::wavy_outline(g, ctx, b, z0, z1, 0.38 * fade, angle, edge);
}

#[allow(clippy::too_many_arguments)]
fn draw_slider(g: &mut FrameGeometry, ctx: &Ctx, colors: &SceneColors, slider: &Slider, z_head: f64, z_tail: f64, angle: f64, default_env: bool) {
    let pts = geom::arc_curve_points(slider, z_head, z_tail, ctx, |c, r| lane_position(default_env, c, r));
    let (front, top) = if slider.c == 0.0 { (colors.left_front, colors.left_top) } else { (colors.right_front, colors.right_top) };
    geom::camera_facing_ribbon(g, ctx, &pts, 0.245, front, 0.18f64.max(0.08), angle);
    geom::camera_facing_ribbon(g, ctx, &pts, 0.155, top, 0.82f64.max(0.12), angle);
}

/// loadDifficulty's fallback chain: the requested difficulty, otherwise the
/// first of ExpertPlus..Easy present, otherwise the first key.
pub fn resolve_difficulty<'a>(embedded: &'a Embedded, mode: &str, wanted: &str) -> Option<(&'a str, &'a Beatmap)> {
    let maps = embedded.mode_maps(mode)?;
    if let Some((d, bm)) = maps.iter().find(|(d, _)| d == wanted) {
        return Some((d.as_str(), bm));
    }
    for key in ["ExpertPlus", "Expert", "Hard", "Normal", "Easy"] {
        if let Some((d, bm)) = maps.iter().find(|(d, _)| d == key) {
            return Some((d.as_str(), bm));
        }
    }
    maps.first().map(|(d, bm)| (d.as_str(), bm))
}
