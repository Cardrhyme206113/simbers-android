//! Native port of the WebGL map viewer (ref/viewer_mod/viewer): map data, scene
//! geometry, lighting, DefaultEnvironment, the wgpu passes, audio playback, the
//! simulated/recorded replay (HMD POV) and BSOR export/import.

pub mod audio;
pub mod bsor;
pub mod env;
pub mod geom;
pub mod gpu;
pub mod lighting;
pub mod map;
pub mod meshes;
pub mod replay;
pub mod replay_sim;
pub mod scene;
pub mod state;

/// QUALITY_PROFILES keys (app.js) and the per-quality tables used around the viewer.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Default)]
pub enum Quality {
    Low,
    Medium,
    High,
    VeryHigh,
    Ultra,
    #[default]
    Native,
}

impl Quality {
    pub fn render_scale(self) -> f64 {
        match self {
            Quality::Low => 0.46,
            Quality::Medium => 0.66,
            Quality::High => 0.82,
            Quality::VeryHigh | Quality::Native => 1.0,
            Quality::Ultra => 1.15,
        }
    }
    pub fn native(self) -> bool {
        self == Quality::Native
    }
    pub fn arc_density(self) -> u32 {
        match self {
            Quality::Low => 30,
            Quality::Medium => 45,
            Quality::High => 60,
            Quality::VeryHigh | Quality::Native => 75,
            Quality::Ultra => 90,
        }
    }
    pub fn matcap_strength(self) -> f64 {
        let v: f64 = match self {
            Quality::Low => 0.0,
            Quality::Medium => 0.3,
            Quality::High => 0.8,
            Quality::VeryHigh => 1.3,
            Quality::Ultra => 1.85,
            Quality::Native => 2.65,
        };
        v.min(1.4)
    }
    pub fn floor_mirror_strength(self) -> f64 {
        match self {
            Quality::Native => 0.91,
            Quality::Ultra => 0.68,
            Quality::VeryHigh => 0.38,
            _ => 0.0,
        }
    }
    /// simMotionTrailAmount() while playing.
    pub fn sim_motion_trail(self) -> f64 {
        match self {
            Quality::High => 0.08,
            Quality::VeryHigh => 0.12,
            Quality::Ultra => 0.16,
            Quality::Native => 0.22,
            _ => 0.0,
        }
    }
    pub fn env_quality_fx(self) -> f64 {
        match self {
            Quality::Low | Quality::Medium => 0.0,
            Quality::High => 0.8,
            Quality::VeryHigh => 1.3,
            Quality::Ultra => 2.0,
            Quality::Native => 2.8,
        }
    }
    pub fn mirror_budget(self) -> usize {
        match self {
            Quality::Native => 8,
            Quality::Ultra => 6,
            Quality::VeryHigh => 4,
            _ => 0,
        }
    }
}
