//! CPU-side geometry emitted every frame: the port of webgl-init.js push
//! helpers, webgl-geometry.js (cut marks, boxes, wall outlines, ribbons) and
//! arc-geometry.js (ArcViewer curves and camera-facing ribbons).

use crate::util::jsm;

#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct P3 {
    pub x: f64,
    pub y: f64,
    pub z: f64,
}

impl P3 {
    pub const fn new(x: f64, y: f64, z: f64) -> Self {
        P3 { x, y, z }
    }
    pub fn add(self, o: P3) -> P3 {
        P3::new(self.x + o.x, self.y + o.y, self.z + o.z)
    }
    pub fn sub(self, o: P3) -> P3 {
        P3::new(self.x - o.x, self.y - o.y, self.z - o.z)
    }
    pub fn scale(self, k: f64) -> P3 {
        P3::new(self.x * k, self.y * k, self.z * k)
    }
}

/// V8 Math.hypot for any number of arguments.
pub fn hypot(v: &[f64]) -> f64 {
    let mut max = 0.0f64;
    for &x in v {
        let a = x.abs();
        if a.is_infinite() {
            return f64::INFINITY;
        }
        if a.is_nan() {
            return f64::NAN;
        }
        if a > max {
            max = a;
        }
    }
    if max == 0.0 {
        return 0.0;
    }
    let (mut sum, mut comp) = (0.0f64, 0.0f64);
    for &x in v {
        let n = x.abs() / max;
        let summand = n * n - comp;
        let prelim = sum + summand;
        comp = (prelim - sum) - summand;
        sum = prelim;
    }
    sum.sqrt() * max
}

pub fn normalize3(v: P3) -> P3 {
    let l = hypot(&[v.x, v.y, v.z]);
    let l = if l == 0.0 || l.is_nan() { 1.0 } else { l };
    P3::new(v.x / l, v.y / l, v.z / l)
}

/// faceNormal(a, b, c)
pub fn face_normal(a: P3, b: P3, c: P3) -> P3 {
    let (ux, uy, uz) = (b.x - a.x, b.y - a.y, b.z - a.z);
    let (vx, vy, vz) = (c.x - a.x, c.y - a.y, c.z - a.z);
    let (nx, ny, nz) = (uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx);
    let l = hypot(&[nx, ny, nz]);
    let l = if l == 0.0 || l.is_nan() { 1.0 } else { l };
    P3::new(nx / l, ny / l, nz / l)
}

/// rotatePointY(point, angleDeg)
pub fn rotate_point_y(p: P3, angle_deg: f64) -> P3 {
    if angle_deg == 0.0 || angle_deg.is_nan() {
        return p;
    }
    let rad = (angle_deg * std::f64::consts::PI) / 180.0;
    let (c, s) = (jsm::cos(rad), jsm::sin(rad));
    P3::new(p.x * c + p.z * s, p.y, p.z * c - p.x * s)
}

/// rotatePointZLocal(p, angleDeg)
pub fn rotate_point_z_local(p: P3, angle_deg: f64) -> P3 {
    if angle_deg == 0.0 || angle_deg.is_nan() {
        return p;
    }
    let r = (angle_deg * std::f64::consts::PI) / 180.0;
    let (c, s) = (jsm::cos(r), jsm::sin(r));
    P3::new(p.x * c - p.y * s, p.x * s + p.y * c, p.z)
}

pub fn wrap_degrees(mut deg: f64) -> f64 {
    while deg <= -180.0 {
        deg += 360.0;
    }
    while deg > 180.0 {
        deg -= 360.0;
    }
    deg
}

/// One floorReflectionNotes entry (environment mirror caster).
#[derive(Clone, Copy, Debug, Default)]
pub struct Caster {
    pub kind: f64,
    pub x: f64,
    pub y: f64,
    pub z: f64,
    pub hx: f64,
    pub hy: f64,
    pub hz: f64,
    pub angle: f64,
    pub r: f64,
    pub g: f64,
    pub b: f64,
    pub opacity: f64,
}

/// Per-frame command buffers (begin3DFrame resets them).
#[derive(Default)]
pub struct FrameGeometry {
    pub opaque: Vec<f32>,
    pub transparent: Vec<f32>,
    pub arc_transparent: Vec<f32>,
    pub replay_opaque: Vec<f32>,
    pub replay_transparent: Vec<f32>,
    pub wall_occluders: Vec<f32>,
    /// noteInstanceGroups: block meshes first, then the three bomb meshes.
    pub note_instances: Vec<Vec<f32>>,
    pub wall_instances: Vec<f32>,
    pub casters: Vec<Caster>,
}

#[derive(Clone, Copy, PartialEq, Eq)]
pub enum Target {
    Opaque,
    Transparent,
    Arc,
    ReplayOpaque,
    ReplayTransparent,
    WallOccluders,
}

impl FrameGeometry {
    pub fn begin(&mut self, groups: usize) {
        self.opaque.clear();
        self.transparent.clear();
        self.arc_transparent.clear();
        self.replay_opaque.clear();
        self.replay_transparent.clear();
        self.wall_occluders.clear();
        self.note_instances.resize_with(groups, Vec::new);
        for g in &mut self.note_instances {
            g.clear();
        }
        self.wall_instances.clear();
        self.casters.clear();
    }

    pub fn buf(&mut self, t: Target) -> &mut Vec<f32> {
        match t {
            Target::Opaque => &mut self.opaque,
            Target::Transparent => &mut self.transparent,
            Target::Arc => &mut self.arc_transparent,
            Target::ReplayOpaque => &mut self.replay_opaque,
            Target::ReplayTransparent => &mut self.replay_transparent,
            Target::WallOccluders => &mut self.wall_occluders,
        }
    }

    /// glTarget(alpha)
    pub fn target_for(alpha: f64) -> Target {
        if alpha < 0.985 { Target::Transparent } else { Target::Opaque }
    }

    /// glPushVertex
    fn vertex(buf: &mut Vec<f32>, p: P3, n: P3, color: [f32; 3], alpha: f64) {
        buf.extend_from_slice(&[p.x as f32, p.y as f32, p.z as f32, n.x as f32, n.y as f32, n.z as f32, color[0], color[1], color[2], alpha as f32]);
    }

    /// glPushTri
    pub fn tri(&mut self, t: Target, a: P3, b: P3, c: P3, color: [f32; 3], alpha: f64, normal: Option<P3>) {
        if a.z.min(b.z).min(c.z) < 0.06 {
            return;
        }
        let n = normal.unwrap_or_else(|| face_normal(a, b, c));
        let buf = self.buf(t);
        Self::vertex(buf, a, n, color, alpha);
        Self::vertex(buf, b, n, color, alpha);
        Self::vertex(buf, c, n, color, alpha);
    }

    /// glPushQuad
    pub fn quad(&mut self, t: Target, a: P3, b: P3, c: P3, d: P3, color: [f32; 3], alpha: f64) {
        let n = face_normal(a, b, c);
        self.tri(t, a, b, c, color, alpha, Some(n));
        self.tri(t, a, c, d, color, alpha, Some(n));
    }
}

/// Per-frame drawing context shared by the geometry helpers.
pub struct Ctx {
    /// cameraYawDeg in 360° mode, otherwise 0 (viewRotationAngle offset).
    pub yaw_offset: f64,
    pub near_z: f64,
    pub eye_y: f64,
    pub default_env: bool,
    pub quality: super::Quality,
    pub bpm: f64,
}

impl Ctx {
    /// viewRotationAngle(angleDeg)
    pub fn view_angle(&self, angle_deg: f64) -> f64 {
        angle_deg - self.yaw_offset
    }
    /// rotateWorldPoint(p, angleDeg)
    pub fn rot(&self, p: P3, angle_deg: f64) -> P3 {
        rotate_point_y(p, self.view_angle(angle_deg))
    }
}

/// roundedRing3D
pub fn rounded_ring(ctx: &Ctx, cx: f64, cy: f64, z: f64, half: f64, radius: f64, segments: usize, angle_deg: f64) -> Vec<P3> {
    let r = radius.min(half * 0.98).max(0.001);
    let pi = std::f64::consts::PI;
    let centers = [(cx + half - r, cy + half - r, 0.0), (cx - half + r, cy + half - r, pi / 2.0), (cx - half + r, cy - half + r, pi), (cx + half - r, cy - half + r, pi * 1.5)];
    let mut pts = Vec::with_capacity(segments * 4);
    for (ccx, ccy, start) in centers {
        for i in 0..segments {
            let a = start + (i as f64 / (segments - 1) as f64) * (pi / 2.0);
            pts.push(ctx.rot(P3::new(ccx + jsm::cos(a) * r, ccy + jsm::sin(a) * r, z), angle_deg));
        }
    }
    pts
}

/// addRingBand
pub fn ring_band(g: &mut FrameGeometry, a: &[P3], b: &[P3], color: [f32; 3], alpha: f64) {
    let t = FrameGeometry::target_for(alpha);
    let n = a.len().min(b.len());
    for i in 0..n {
        let j = (i + 1) % n;
        g.quad(t, a[i], a[j], b[j], b[i], color, alpha);
    }
}

/// addFlatSegment3D
pub fn flat_segment(g: &mut FrameGeometry, ctx: &Ctx, ax: f64, ay: f64, bx: f64, by: f64, z: f64, width: f64, color: [f32; 3], angle_deg: f64) {
    let (dx, dy) = (bx - ax, by - ay);
    let l = jsm::hypot(dx, dy);
    let l = if l == 0.0 || l.is_nan() { 1.0 } else { l };
    let (nx, ny) = ((-dy / l) * width * 0.5, (dx / l) * width * 0.5);
    let a = ctx.rot(P3::new(ax + nx, ay + ny, z), angle_deg);
    let b = ctx.rot(P3::new(bx + nx, by + ny, z), angle_deg);
    let c = ctx.rot(P3::new(bx - nx, by - ny, z), angle_deg);
    let d = ctx.rot(P3::new(ax - nx, ay - ny, z), angle_deg);
    g.quad(Target::Opaque, a, b, c, d, color, 1.0);
}

const ARCV_DIRECTION_ANGLES: [f64; 9] = [180.0, 0.0, -90.0, 90.0, -135.0, 135.0, -45.0, 45.0, 0.0];

/// arcViewerFinalNoteAngle
pub fn final_note_angle(d: f64) -> f64 {
    // ARCV_DIRECTION_ANGLES[clamp(Number(d) || 0)] || 0: a fractional index reads undefined -> 0.
    let i = if d.is_nan() { 0.0 } else { d }.clamp(0.0, 8.0);
    let base = if i.fract() == 0.0 { ARCV_DIRECTION_ANGLES[i as usize] } else { 0.0 };
    let mut angle = base % 360.0;
    if angle > 180.0 {
        angle -= 360.0;
    }
    if angle < -180.0 {
        angle += 360.0;
    }
    angle
}

/// arcViewerObjectAngle
pub fn object_angle(d: f64, jump_progress: f64) -> f64 {
    let fin = final_note_angle(d);
    if jump_progress <= 0.0 {
        return 0.0;
    }
    if jump_progress < 0.5 {
        return fin * jsm::sin((jump_progress / 0.5).clamp(0.0, 1.0) * std::f64::consts::PI * 0.5);
    }
    fin
}

/// addArcViewerCutMark3D
pub fn cut_mark(g: &mut FrameGeometry, ctx: &Ctx, d: f64, cx: f64, cy: f64, z: f64, size: f64, object_angle: f64, map_angle: f64) {
    let white = [1.0, 1.0, 1.0];
    let arrow = size * 0.9;
    if d == 8.0 {
        let outer = rounded_ring(ctx, cx, cy, z, arrow * 0.155, arrow * 0.055, 4, map_angle);
        let inner = rounded_ring(ctx, cx, cy, z - 0.002, arrow * 0.06, arrow * 0.025, 4, map_angle);
        ring_band(g, &inner, &outer, white, 1.0);
        return;
    }
    let r = (object_angle * std::f64::consts::PI) / 180.0;
    let (dx, dy) = (jsm::sin(r), -jsm::cos(r));
    let (px, py) = (-dy, dx);
    let diagonal = (4.0..=7.0).contains(&d);
    let tip_radius = arrow * if diagonal { 0.255 } else { 0.315 };
    let arm = arrow * if diagonal { 0.185 } else { 0.225 };
    let slant = (15.0 * std::f64::consts::PI) / 180.0;
    let back = arm * jsm::sin(slant);
    let spread = arm * jsm::cos(slant);
    let line_width = (arrow * 0.072).max(0.018);
    let (tip_x, tip_y) = (cx + dx * tip_radius, cy + dy * tip_radius);
    let (base_x, base_y) = (tip_x - dx * back, tip_y - dy * back);
    flat_segment(g, ctx, base_x + px * spread, base_y + py * spread, tip_x, tip_y, z, line_width, white, map_angle);
    flat_segment(g, ctx, base_x - px * spread, base_y - py * spread, tip_x, tip_y, z, line_width, white, map_angle);
}

/// addBox3D
pub fn add_box(g: &mut FrameGeometry, ctx: &Ctx, x0: f64, x1: f64, y0: f64, y1: f64, z0: f64, z1: f64, color: [f32; 3], alpha: f64, angle_deg: f64, forced: Option<Target>) {
    let raw = [P3::new(x0, y1, z0), P3::new(x1, y1, z0), P3::new(x1, y0, z0), P3::new(x0, y0, z0), P3::new(x0, y1, z1), P3::new(x1, y1, z1), P3::new(x1, y0, z1), P3::new(x0, y0, z1)];
    let v: Vec<P3> = raw.iter().map(|p| ctx.rot(*p, angle_deg)).collect();
    let t = forced.unwrap_or(FrameGeometry::target_for(alpha));
    for f in [[0, 1, 2, 3], [4, 7, 6, 5], [0, 4, 5, 1], [3, 2, 6, 7], [1, 5, 6, 2], [0, 3, 7, 4]] {
        g.quad(t, v[f[0]], v[f[1]], v[f[2]], v[f[3]], color, alpha);
    }
}

/// addRibbonSegment3D
fn ribbon_segment(g: &mut FrameGeometry, ctx: &Ctx, a: P3, b: P3, width: f64, color: [f32; 3], alpha: f64, angle_deg: f64) {
    let (dx, dy) = (b.x - a.x, b.y - a.y);
    let l = jsm::hypot(dx, dy);
    let (px, py) = if l > 0.0001 { ((-dy / l) * width * 0.5, (dx / l) * width * 0.5) } else { (width * 0.5, 0.0) };
    let p0 = ctx.rot(P3::new(a.x + px, a.y + py, a.z), angle_deg);
    let p1 = ctx.rot(P3::new(b.x + px, b.y + py, b.z), angle_deg);
    let p2 = ctx.rot(P3::new(b.x - px, b.y - py, b.z), angle_deg);
    let p3 = ctx.rot(P3::new(a.x - px, a.y - py, a.z), angle_deg);
    g.quad(Target::Transparent, p0, p1, p2, p3, color, alpha);
}

/// addWavyWallEdge3D
fn wavy_edge(g: &mut FrameGeometry, ctx: &Ctx, a: P3, b: P3, color: [f32; 3], alpha: f64, phase: f64, angle_deg: f64) {
    let (steps, amp) = (8, 0.026);
    let mut prev: Option<P3> = None;
    for i in 0..=steps {
        let t = i as f64 / steps as f64;
        let wave = jsm::sin((t * 2.15 + phase) * std::f64::consts::PI * 2.0) * amp;
        let wave2 = jsm::cos((t * 1.37 + phase * 0.71) * std::f64::consts::PI * 2.0) * amp * 0.55;
        let p = P3::new(a.x + (b.x - a.x) * t + wave, a.y + (b.y - a.y) * t + wave2, a.z + (b.z - a.z) * t);
        if let Some(pv) = prev {
            ribbon_segment(g, ctx, pv, p, 0.07, color, alpha * 0.12, angle_deg);
            ribbon_segment(g, ctx, pv, p, 0.022, color, alpha * 0.82, angle_deg);
        }
        prev = Some(p);
    }
}

/// Wall bounds (obstacleBounds).
#[derive(Clone, Copy, Debug)]
pub struct Bounds {
    pub left: f64,
    pub right: f64,
    pub bottom: f64,
    pub top: f64,
}

/// addWavyWallOutline3D
pub fn wavy_outline(g: &mut FrameGeometry, ctx: &Ctx, b: Bounds, z0: f64, z1: f64, alpha: f64, angle_deg: f64, color: [f32; 3]) {
    if alpha <= 0.002 {
        return;
    }
    let front = [P3::new(b.left, b.bottom, z0), P3::new(b.right, b.bottom, z0), P3::new(b.right, b.top, z0), P3::new(b.left, b.top, z0)];
    let back = [P3::new(b.left, b.bottom, z1), P3::new(b.right, b.bottom, z1), P3::new(b.right, b.top, z1), P3::new(b.left, b.top, z1)];
    for i in 0..4 {
        wavy_edge(g, ctx, front[i], front[(i + 1) % 4], color, alpha, i as f64 * 0.17, angle_deg);
        wavy_edge(g, ctx, back[i], back[(i + 1) % 4], color, alpha * 0.46, 0.41 + i as f64 * 0.17, angle_deg);
    }
    for i in 0..4 {
        wavy_edge(g, ctx, front[i], back[i], color, alpha * 0.58, 0.23 + i as f64 * 0.19, angle_deg);
    }
}

// ------------------------------------------------------------------ arcs

fn quad_in_out(t: f64) -> f64 {
    if t < 0.5 { 2.0 * t * t } else { 1.0 - jsm::pow(-2.0 * t + 2.0, 2.0) / 2.0 }
}

fn cut_angle_for_arc(direction: f64) -> f64 {
    let i = if direction.is_nan() { 0.0 } else { direction }.clamp(0.0, 8.0);
    if i.fract() != 0.0 {
        return f64::NAN; // array[fraction] is undefined in JS
    }
    [180.0, 0.0, -90.0, 90.0, -135.0, 135.0, -45.0, 45.0, 0.0][i as usize]
}

fn arc_direction_from_angle(deg: f64) -> (f64, f64) {
    let r = (deg * std::f64::consts::PI) / 180.0;
    (jsm::sin(r), -jsm::cos(r))
}

fn arc_direction(d: f64) -> (f64, f64) {
    if d == 8.0 { (0.0, 0.0) } else { arc_direction_from_angle(cut_angle_for_arc(d)) }
}

fn same_arc_cut_plane(a: f64, b: f64) -> bool {
    if a == 8.0 || b == 8.0 {
        return false;
    }
    let (va, vb) = (arc_direction(a), arc_direction(b));
    (va.0 * vb.0 + va.1 * vb.1).abs() > 0.999
}

fn arc_scaled_offset(dir: (f64, f64), mult: f64) -> (f64, f64) {
    let xs = 1.02 / 0.6;
    let ys = 0.94 / 0.55;
    (dir.0 * 2.5 * xs * mult, dir.1 * 2.5 * ys * mult)
}

fn arc_point_count(slider: &super::map::Slider, ctx: &Ctx) -> i64 {
    let bpm = if ctx.bpm == 0.0 || ctx.bpm.is_nan() { 60.0 } else { ctx.bpm }.max(0.001);
    let duration = ((slider.tb - slider.hb).abs() * 60.0) / bpm;
    let density = ctx.quality.arc_density() as f64;
    ((density / 2.0).floor() as i64).max(((density * 5.0) as i64).min((density * duration).floor() as i64 + 1))
}

fn cubic3(p0: P3, p1: P3, p2: P3, p3: P3, t: f64) -> P3 {
    let m = 1.0 - t;
    let (m2, t2) = (m * m, t * t);
    P3::new(
        p0.x * m2 * m + 3.0 * p1.x * m2 * t + 3.0 * p2.x * m * t2 + p3.x * t2 * t,
        p0.y * m2 * m + 3.0 * p1.y * m2 * t + 3.0 * p2.y * m * t2 + p3.y * t2 * t,
        p0.z * m2 * m + 3.0 * p1.z * m2 * t + 3.0 * p2.z * m * t2 + p3.z * t2 * t,
    )
}

/// arcViewerCurvePoints
pub fn arc_curve_points(s: &super::map::Slider, z_head: f64, z_tail: f64, ctx: &Ctx, lane: impl Fn(f64, f64) -> (f64, f64)) -> Vec<P3> {
    let hp = lane(s.hx, s.hy);
    let tp = lane(s.tx, s.ty);
    let (mut hd, mut td) = (s.hd, s.td);
    let mu = if s.mu.is_finite() { s.mu } else { 1.0 };
    let tmu = if s.tmu.is_finite() { s.tmu } else { 1.0 };
    let (hb, tb) = (s.hb, s.tb);
    let ho = arc_scaled_offset(arc_direction(hd), mu);
    let to = arc_scaled_offset(arc_direction(td), tmu);
    let mut p0 = P3::new(hp.0, hp.1, z_head);
    let mut p1 = P3::new(hp.0 + ho.0, hp.1 + ho.1, z_head);
    let mut p2 = P3::new(tp.0 - to.0, tp.1 - to.1, z_tail);
    let mut p3 = P3::new(tp.0, tp.1, z_tail);
    if tb < hb {
        std::mem::swap(&mut p0, &mut p3);
        std::mem::swap(&mut p1, &mut p2);
        std::mem::swap(&mut hd, &mut td);
    }
    let mut count = arc_point_count(s, ctx);
    let mid_mode = if s.mid.is_nan() { 0.0 } else { s.mid }.clamp(0.0, 2.0);
    let use_mid = mid_mode != 0.0 && same_arc_cut_plane(hd, td) && s.hx == s.tx;
    if !use_mid {
        let count = count.max(2);
        return (0..count).map(|i| cubic3(p0, p1, p2, p3, quad_in_out(i as f64 / (count - 1) as f64))).collect();
    }
    let mid_rotation = if mid_mode == 1.0 { -90.0 } else { 90.0 };
    let mut mid = P3::new((p0.x + p3.x) * 0.5, (p0.y + p3.y) * 0.5, (p0.z + p3.z) * 0.5);
    if hd != 8.0 {
        let mo = arc_scaled_offset(arc_direction_from_angle(cut_angle_for_arc(hd) + mid_rotation), 1.0);
        mid.x += mo.0;
        mid.y += mo.1;
    }
    let p1d = P3::new((p1.x - mid.x).abs(), (p1.y - mid.y).abs(), (p1.z - mid.z).abs());
    let p2d = P3::new((p2.x - mid.x).abs(), (p2.y - mid.y).abs(), (p2.z - mid.z).abs());
    let (p1ox, p1oy) = (p1.x - p0.x, p1.y - p0.y);
    let (p2ox, p2oy) = (p2.x - p3.x, p2.y - p3.y);
    let eq = |a: f64, b: f64| (a - b).abs() < 1e-5;
    let mut cx = if eq(p1ox, p2ox) { 0.0 } else { (p1d.x + p2d.x) * 0.25 };
    let mut cy = if eq(p1oy, p2oy) { 0.0 } else { (p1d.y + p2d.y) * 0.25 };
    let cz = (p1d.z + p2d.z) * 0.15;
    if p1.x < p2.x {
        cx = -cx;
    }
    if p1.y < p2.y {
        cy = -cy;
    }
    let hmc = P3::new(mid.x + cx, mid.y + cy, mid.z - cz);
    let mtc = P3::new(mid.x - cx, mid.y - cy, mid.z + cz);
    if count % 2 == 0 {
        count += 1;
    }
    let count = count.max(3) as usize;
    let mid_index = count / 2 + 1;
    let mut pts = Vec::with_capacity(count);
    for i in 0..mid_index.min(count) {
        pts.push(cubic3(p0, p1, hmc, mid, quad_in_out(i as f64 / mid_index as f64)));
    }
    for i in mid_index..count {
        let denom = (count - mid_index - 1).max(1) as f64;
        pts.push(cubic3(mid, mtc, p2, p3, quad_in_out((i - mid_index) as f64 / denom)));
    }
    pts
}

/// cameraFacingRibbon (into glArcTransparent)
pub fn camera_facing_ribbon(g: &mut FrameGeometry, ctx: &Ctx, points: &[P3], width: f64, color: [f32; 3], alpha: f64, angle_deg: f64) {
    if points.len() < 2 {
        return;
    }
    let rp: Vec<P3> = points.iter().map(|p| ctx.rot(*p, angle_deg)).collect();
    let mut total = 0.0;
    let mut cumulative = vec![0.0];
    for i in 1..rp.len() {
        total += hypot(&[rp[i].x - rp[i - 1].x, rp[i].y - rp[i - 1].y, rp[i].z - rp[i - 1].z]);
        cumulative.push(total);
    }
    let half = width * 0.5;
    let mut edges = Vec::with_capacity(rp.len());
    for i in 0..rp.len() {
        let prev = rp[i.saturating_sub(1)];
        let next = rp[(i + 1).min(rp.len() - 1)];
        let p = rp[i];
        let tangent = normalize3(next.sub(prev));
        let view = normalize3(P3::new(-p.x, ctx.eye_y - p.y, -p.z));
        let side = normalize3(P3::new(tangent.y * view.z - tangent.z * view.y, tangent.z * view.x - tangent.x * view.z, tangent.x * view.y - tangent.y * view.x));
        edges.push((p.add(side.scale(half)), p.sub(side.scale(half))));
    }
    let fade_dist = (total * 0.1).max(0.16).min(0.42);
    let end_alpha = |distance: f64| -> f64 {
        if total <= 1e-5 {
            return 0.0;
        }
        let d = distance.min(total - distance);
        (d / fade_dist).clamp(0.0, 1.0)
    };
    for i in 0..edges.len() - 1 {
        let (a0, a1) = (end_alpha(cumulative[i]), end_alpha(cumulative[i + 1]));
        let z_mid = (rp[i].z + rp[i + 1].z) * 0.5;
        let near_fade = ((z_mid - (ctx.near_z - 0.1)) / 2.25).clamp(0.0, 1.0);
        let camera_alpha = near_fade * near_fade * (3.0 - 2.0 * near_fade);
        let seg_alpha = alpha * (a0 + a1) * 0.5 * camera_alpha;
        if seg_alpha <= 0.002 {
            continue;
        }
        g.quad(Target::Arc, edges[i].0, edges[i + 1].0, edges[i + 1].1, edges[i].1, color, seg_alpha);
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn hypot_matches_v8_cases() {
        assert_eq!(hypot(&[3.0, 4.0]), 5.0);
        assert_eq!(hypot(&[0.0, 0.0, 0.0]), 0.0);
        assert_eq!(hypot(&[1.0, 2.0, 2.0]), 3.0);
        assert_eq!(final_note_angle(0.0), 180.0);
        assert_eq!(final_note_angle(5.0), 135.0);
        assert_eq!(wrap_degrees(190.0), -170.0);
    }
}
