//! Static meshes and textures of the viewer: ArcViewer SSM2 note blocks
//! (webgl-init.js decodeSSM2), the faceted bomb (renderer.js), the wall unit
//! mesh (makeWallUnitMesh), the studio matcap (initStudioMatcap) and the
//! DefaultEnvironment tunnel (assets/environment-mesh.js).

use super::geom::{P3, face_normal, normalize3};
use crate::util::jsm;

static ARCV_BLOCK_SSM2: &[u8] = include_bytes!("../../assets/viewer/arcv_block.ssm2");

pub struct Mesh {
    pub name: String,
    pub positions: Vec<f32>,
    pub normals: Vec<f32>,
    pub indices: Vec<u32>,
}

/// decodeSSM2(decodeBase64Bytes(ARCV_BLOCK_SSM2_B64))
pub fn arcv_block_meshes() -> Vec<Mesh> {
    decode_ssm2(ARCV_BLOCK_SSM2).expect("embedded SSM2 note mesh")
}

fn decode_ssm2(b: &[u8]) -> anyhow::Result<Vec<Mesh>> {
    let mut p = 0usize;
    let mut take = |n: usize| -> anyhow::Result<&[u8]> {
        let s = b.get(p..p + n).ok_or_else(|| anyhow::anyhow!("truncated SSM2"))?;
        p += n;
        Ok(s)
    };
    if take(4)? != b"SSM2" {
        anyhow::bail!("Invalid SSM2 model");
    }
    let u16v = |s: &[u8]| u16::from_le_bytes([s[0], s[1]]);
    let u32v = |s: &[u8]| u32::from_le_bytes([s[0], s[1], s[2], s[3]]);
    let f32v = |s: &[u8]| f32::from_le_bytes([s[0], s[1], s[2], s[3]]);
    let count = u16v(take(2)?);
    let mut meshes = vec![];
    for _ in 0..count {
        let n = u16v(take(2)?) as usize;
        let _source = String::from_utf8_lossy(take(n)?).to_string();
        let n = u16v(take(2)?) as usize;
        let name = String::from_utf8_lossy(take(n)?).to_string();
        let vc = u32v(take(4)?) as usize;
        let ic = u32v(take(4)?) as usize;
        let iw = take(1)?[0];
        let _flags = take(1)?[0];
        let mut min = [0f32; 3];
        let mut ext = [0f32; 3];
        for m in &mut min {
            *m = f32v(take(4)?);
        }
        for e in &mut ext {
            *e = f32v(take(4)?);
        }
        let mut positions = Vec::with_capacity(vc * 3);
        let mut normals = Vec::with_capacity(vc * 3);
        for _ in 0..vc {
            // Float32Array stores (min + u16/65535 * ext) computed in double precision.
            for a in 0..3 {
                let q = u16v(take(2)?) as f64;
                positions.push((min[a] as f64 + (q / 65535.0) * ext[a] as f64) as f32);
            }
            for _ in 0..3 {
                normals.push(((take(1)?[0] as i8) as f64 / 127.0) as f32);
            }
            take(4)?; // uv
        }
        let mut indices = Vec::with_capacity(ic);
        for _ in 0..ic {
            indices.push(if iw == 2 { u16v(take(2)?) as u32 } else { u32v(take(4)?) });
        }
        meshes.push(Mesh { name, positions, normals, indices });
    }
    Ok(meshes)
}

/// makeBombUnitGeometry()
pub struct BombUnit {
    pub tris: Vec<[P3; 3]>,
    pub spikes: Vec<P3>,
}

pub fn bomb_unit_geometry() -> BombUnit {
    let g = (1.0 + 5f64.sqrt()) / 2.0;
    let base: Vec<P3> = [
        [-1.0, g, 0.0],
        [1.0, g, 0.0],
        [-1.0, -g, 0.0],
        [1.0, -g, 0.0],
        [0.0, -1.0, g],
        [0.0, 1.0, g],
        [0.0, -1.0, -g],
        [0.0, 1.0, -g],
        [g, 0.0, -1.0],
        [g, 0.0, 1.0],
        [-g, 0.0, -1.0],
        [-g, 0.0, 1.0],
    ]
    .iter()
    .map(|v| normalize3(P3::new(v[0], v[1], v[2])))
    .collect();
    let faces = [
        [0, 11, 5],
        [0, 5, 1],
        [0, 1, 7],
        [0, 7, 10],
        [0, 10, 11],
        [1, 5, 9],
        [5, 11, 4],
        [11, 10, 2],
        [10, 7, 6],
        [7, 1, 8],
        [3, 9, 4],
        [3, 4, 2],
        [3, 2, 6],
        [3, 6, 8],
        [3, 8, 9],
        [4, 9, 5],
        [2, 4, 11],
        [6, 2, 10],
        [8, 6, 7],
        [9, 8, 1],
    ];
    let mut tris = vec![];
    for f in faces {
        let (a, b, c) = (base[f[0]], base[f[1]], base[f[2]]);
        let ab = normalize3(a.add(b));
        let bc = normalize3(b.add(c));
        let ca = normalize3(c.add(a));
        tris.push([a, ab, ca]);
        tris.push([b, bc, ab]);
        tris.push([c, ca, bc]);
        tris.push([ab, bc, ca]);
    }
    BombUnit { tris, spikes: base }
}

/// bombBasis(dir)
pub fn bomb_basis(dir: P3) -> (P3, P3) {
    let helper = if dir.y.abs() > 0.82 { P3::new(1.0, 0.0, 0.0) } else { P3::new(0.0, 1.0, 0.0) };
    let u = normalize3(P3::new(helper.y * dir.z - helper.z * dir.y, helper.z * dir.x - helper.x * dir.z, helper.x * dir.y - helper.y * dir.x));
    let v = P3::new(dir.y * u.z - dir.z * u.y, dir.z * u.x - dir.x * u.z, dir.x * u.y - dir.y * u.x);
    (u, v)
}

/// buildStaticBombMeshes()
pub fn static_bomb_meshes(unit: &BombUnit) -> Vec<Mesh> {
    let mut groups: Vec<(Vec<f32>, Vec<f32>, Vec<u32>)> = vec![Default::default(), Default::default(), Default::default()];
    fn tri(g: &mut (Vec<f32>, Vec<f32>, Vec<u32>), a: P3, b: P3, c: P3) {
        let n = face_normal(a, b, c);
        let i = (g.0.len() / 3) as u32;
        for v in [a, b, c] {
            g.0.extend([v.x as f32, v.y as f32, v.z as f32]);
            g.1.extend([n.x as f32, n.y as f32, n.z as f32]);
        }
        g.2.extend([i, i + 1, i + 2]);
    }
    for (i, t) in unit.tris.iter().enumerate() {
        tri(&mut groups[if i % 3 == 0 { 1 } else { 0 }], t[0], t[1], t[2]);
    }
    for &dir in &unit.spikes {
        let (u, v) = bomb_basis(dir);
        let ring: Vec<P3> = (0..6)
            .map(|k| {
                let a = k as f64 * std::f64::consts::PI / 3.0;
                let (ca, sa) = (jsm::cos(a), jsm::sin(a));
                P3::new(dir.x * 0.91 + (u.x * ca + v.x * sa) * 0.135, dir.y * 0.91 + (u.y * ca + v.y * sa) * 0.135, dir.z * 0.91 + (u.z * ca + v.z * sa) * 0.135)
            })
            .collect();
        let tip = dir.scale(1.255);
        for k in 0..6 {
            tri(&mut groups[2], ring[k], ring[(k + 1) % 6], tip);
        }
    }
    groups.into_iter().enumerate().map(|(i, g)| Mesh { name: format!("bomb-static-{i}"), positions: g.0, normals: g.1, indices: g.2 }).collect()
}

/// makeWallUnitMesh(): [x, y, z, alpha, kind] per vertex.
pub fn wall_unit_mesh() -> Vec<f32> {
    let mut p: Vec<f32> = vec![];
    let tri = |p: &mut Vec<f32>, a: P3, b: P3, c: P3, alpha: f64, kind: f64| {
        for v in [a, b, c] {
            p.extend([v.x as f32, v.y as f32, v.z as f32, alpha as f32, kind as f32]);
        }
    };
    let quad = |p: &mut Vec<f32>, a: P3, b: P3, c: P3, d: P3, alpha: f64, kind: f64| {
        tri(p, a, b, c, alpha, kind);
        tri(p, a, c, d, alpha, kind);
    };
    let c = [
        P3::new(0.0, 0.0, 0.0),
        P3::new(1.0, 0.0, 0.0),
        P3::new(1.0, 1.0, 0.0),
        P3::new(0.0, 1.0, 0.0),
        P3::new(0.0, 0.0, 1.0),
        P3::new(1.0, 0.0, 1.0),
        P3::new(1.0, 1.0, 1.0),
        P3::new(0.0, 1.0, 1.0),
    ];
    for f in [[0, 3, 2, 1], [4, 5, 6, 7], [0, 4, 7, 3], [1, 2, 6, 5], [0, 1, 5, 4], [3, 7, 6, 2]] {
        quad(&mut p, c[f[0]], c[f[1]], c[f[2]], c[f[3]], 0.082, 0.0);
    }
    let edge = |p: &mut Vec<f32>, a: P3, b: P3, phase: f64, weight: f64| {
        let mut prev: Option<P3> = None;
        for i in 0..=8 {
            let t = i as f64 / 8.0;
            let wav = jsm::sin((t * 2.15 + phase) * std::f64::consts::PI * 2.0) * 0.026;
            let wav2 = jsm::cos((t * 1.37 + phase * 0.71) * std::f64::consts::PI * 2.0) * 0.0143;
            let q = P3::new(a.x + (b.x - a.x) * t + wav, a.y + (b.y - a.y) * t + wav2, a.z + (b.z - a.z) * t);
            if let Some(pv) = prev {
                let (dx, dy) = (q.x - pv.x, q.y - pv.y);
                let l = jsm::hypot(dx, dy);
                for (width, alpha) in [(0.07, 0.38 * weight * 0.12), (0.022, 0.38 * weight * 0.82)] {
                    let nx = if l > 0.0001 { (-dy / l) * width * 0.5 } else { width * 0.5 };
                    let ny = if l > 0.0001 { (dx / l) * width * 0.5 } else { 0.0 };
                    quad(p, P3::new(pv.x + nx, pv.y + ny, pv.z), P3::new(q.x + nx, q.y + ny, q.z), P3::new(q.x - nx, q.y - ny, q.z), P3::new(pv.x - nx, pv.y - ny, pv.z), alpha, 1.0);
                }
            }
            prev = Some(q);
        }
    };
    for i in 0..4 {
        edge(&mut p, c[i], c[(i + 1) % 4], i as f64 * 0.17, 1.0);
        edge(&mut p, c[i + 4], c[(i + 1) % 4 + 4], 0.41 + i as f64 * 0.17, 0.46);
        edge(&mut p, c[i], c[i + 4], 0.23 + i as f64 * 0.19, 0.58);
    }
    p
}

/// initStudioMatcap(): 256x256 RGBA.
pub fn studio_matcap() -> Vec<u8> {
    const N: usize = 256;
    let mut pix = vec![0u8; N * N * 4];
    for y in 0..N {
        for x in 0..N {
            let u = ((x as f64 + 0.5) / N as f64) * 2.0 - 1.0;
            let v = ((y as f64 + 0.5) / N as f64) * 2.0 - 1.0;
            let r2 = u * u + v * v;
            let stripe = jsm::exp(-jsm::pow((u + v * 0.23 - 0.19) * 7.8, 2.0));
            let stripe2 = jsm::exp(-jsm::pow((u - v * 0.32 + 0.54) * 15.0, 2.0));
            let ceiling = (1.0 - (v + 0.64).abs() * 2.4).max(0.0);
            let soft = 1.0 / (1.0 + jsm::pow((u + 0.15) * 3.0, 2.0) + jsm::pow((v + 0.1) * 3.4, 2.0));
            let fade = (1.0 - r2 * 0.25).max(0.0);
            let a = (0.045 + 0.9 * stripe + 0.48 * stripe2 + 0.34 * ceiling + 0.26 * soft) * fade;
            let i = (y * N + x) * 4;
            pix[i] = crate::util::js_round((255.0 * a).min(255.0)) as u8;
            pix[i + 1] = crate::util::js_round((255.0 * a * 1.08).min(255.0)) as u8;
            pix[i + 2] = crate::util::js_round((255.0 * a * 1.25).min(255.0)) as u8;
            pix[i + 3] = 255;
        }
    }
    pix
}

// ------------------------------------------------------------ environment

static ENV_P: &[u8] = include_bytes!("../../assets/viewer/env_p.bin");
static ENV_N: &[u8] = include_bytes!("../../assets/viewer/env_n.bin");
static ENV_V: &[u8] = include_bytes!("../../assets/viewer/env_v.bin");
static ENV_W: &[u8] = include_bytes!("../../assets/viewer/env_w.bin");
static ENV_A: &[u8] = include_bytes!("../../assets/viewer/env_a.bin");
static ENV_E: &[u8] = include_bytes!("../../assets/viewer/env_e.bin");
pub const ENV_INDEX_COUNT: usize = 22404;
pub const ENV_VERTEX_COUNT: usize = 16032;

/// One tunnel vertex as uploaded to the GPU.
#[repr(C)]
#[derive(Clone, Copy, Default)]
pub struct EnvVertex {
    pub p: [f32; 3],
    /// Signed normal bytes + padding (Snorm8x4).
    pub n: [i8; 4],
    /// K, S, R, RI (Sint8x4).
    pub ksri: [i8; 4],
}

pub struct EnvMesh {
    pub vertices: Vec<EnvVertex>,
    pub indices: Vec<u16>,
    /// R and RI per vertex (ring animation).
    pub ring: Vec<(u8, u8)>,
}

/// __simbersDecodeEnvironmentMesh()
pub fn environment_mesh() -> EnvMesh {
    let u16s = |b: &[u8]| b.chunks_exact(2).map(|c| u16::from_le_bytes([c[0], c[1]])).collect::<Vec<_>>();
    let p_bits: Vec<u32> = ENV_P.chunks_exact(4).map(|c| u32::from_le_bytes([c[0], c[1], c[2], c[3]])).collect();
    let n_base: Vec<i8> = ENV_N.iter().map(|&b| b as i8).collect();
    let (pos_ref, norm_ref, meta, indices) = (u16s(ENV_V), u16s(ENV_W), u16s(ENV_A), u16s(ENV_E));
    assert!(indices.len() == ENV_INDEX_COUNT && pos_ref.len() == ENV_VERTEX_COUNT && norm_ref.len() == ENV_VERTEX_COUNT && meta.len() == ENV_VERTEX_COUNT, "Environment mesh index integrity failure");
    let mut vertices = Vec::with_capacity(ENV_VERTEX_COUNT);
    let mut ring = Vec::with_capacity(ENV_VERTEX_COUNT);
    for i in 0..ENV_VERTEX_COUNT {
        let ps = pos_ref[i] as usize * 3;
        let ns = norm_ref[i] as usize * 3;
        let a = meta[i] as u32;
        let k = (a & 7) as i8;
        let s = (((a >> 3) & 3) as i32 - 1) as i8;
        let r = ((a >> 5) & 3) as u8;
        let ri = ((a >> 7) & 63) as u8;
        vertices.push(EnvVertex {
            p: [f32::from_bits(p_bits[ps]), f32::from_bits(p_bits[ps + 1]), f32::from_bits(p_bits[ps + 2])],
            n: [n_base[ns], n_base[ns + 1], n_base[ns + 2], 0],
            ksri: [k, s, r as i8, ri as i8],
        });
        ring.push((r, ri));
    }
    EnvMesh { vertices, indices, ring }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn static_meshes_decode() {
        let blocks = arcv_block_meshes();
        assert!(!blocks.is_empty());
        for m in &blocks {
            assert_eq!(m.positions.len(), m.normals.len());
            assert!(m.indices.iter().all(|&i| (i as usize) < m.positions.len() / 3));
        }
        let env = environment_mesh();
        assert_eq!(env.vertices.len(), ENV_VERTEX_COUNT);
        assert!(env.indices.iter().all(|&i| (i as usize) < ENV_VERTEX_COUNT));
        let bombs = static_bomb_meshes(&bomb_unit_geometry());
        assert_eq!(bombs.len(), 3);
        assert_eq!(wall_unit_mesh().len() % 15, 0);
        assert_eq!(studio_matcap().len(), 256 * 256 * 4);
    }
}
