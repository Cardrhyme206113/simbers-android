//! replay-math.js + replay-simulator.js + the wall helpers of replay.js
//! (cyberMapWalls / cyberCountWallIntersections / cyberDodgeWalls).
//!
//! Number model follows the JS exactly: Float32Array storage is `Vec<f32>`
//! (every store rounds), everything else is f64.

use super::geom::hypot;
use super::scene::{DEFAULT_ENV_LANE_WIDTH, DEFAULT_ENV_NOTE_Y_OFFSET, DEFAULT_ENV_ROW_HEIGHT};
use serde_json::Value;

pub const HZ: f64 = 108.0;
pub const CYBER_PLAYER_HEAD_HEIGHT: f64 = 2.165;
pub const CYBER_SCENE_Y_SCALE: f64 = 1.15;

static MODEL_Z: &[u8] = include_bytes!("../../assets/viewer/replay-model.json.z");

// ------------------------------------------------------------------ math

pub fn clamp(v: f64, a: f64, b: f64) -> f64 {
    b.min(a.max(v))
}

fn dot(a: &[f64], b: &[f64]) -> f64 {
    a.iter().zip(b).fold(0.0, |s, (x, y)| s + x * y)
}

pub fn norm(a: &[f64]) -> Vec<f64> {
    let n = hypot(a);
    if n > 1e-10 {
        a.iter().map(|x| x / n).collect()
    } else {
        [0.0, 0.0, 0.0, 1.0][..a.len().min(4)].to_vec()
    }
}

pub fn norm4(a: [f64; 4]) -> [f64; 4] {
    let v = norm(&a);
    [v[0], v[1], v[2], v[3]]
}

pub fn quat_slerp(a: [f64; 4], b: [f64; 4], t: f64) -> [f64; 4] {
    let mut b = b;
    let mut cos = dot(&a, &b);
    if cos < 0.0 {
        b = b.map(|x| -x);
        cos = -cos;
    }
    if cos > 0.9995 {
        return norm4([0, 1, 2, 3].map(|i| a[i] + (b[i] - a[i]) * t));
    }
    let th = libm::acos(clamp(cos, -1.0, 1.0));
    let s = libm::sin(th);
    [0, 1, 2, 3].map(|i| (libm::sin((1.0 - t) * th) * a[i] + libm::sin(t * th) * b[i]) / s)
}

pub fn qmul(a: [f64; 4], b: [f64; 4]) -> [f64; 4] {
    [
        a[3] * b[0] + a[0] * b[3] + a[1] * b[2] - a[2] * b[1],
        a[3] * b[1] - a[0] * b[2] + a[1] * b[3] + a[2] * b[0],
        a[3] * b[2] + a[0] * b[1] - a[1] * b[0] + a[2] * b[3],
        a[3] * b[3] - a[0] * b[0] - a[1] * b[1] - a[2] * b[2],
    ]
}

fn rvquat(v: [f64; 3]) -> [f64; 4] {
    let a = hypot(&v);
    let s = if a < 1e-6 { 0.5 } else { libm::sin(a / 2.0) / a };
    norm4([v[0] * s, v[1] * s, v[2] * s, libm::cos(a / 2.0)])
}

fn eulerquat(x: f64, y: f64, z: f64) -> [f64; 4] {
    let (a, b, c, d, e, f) = (libm::sin(x / 2.0), libm::cos(x / 2.0), libm::sin(y / 2.0), libm::cos(y / 2.0), libm::sin(z / 2.0), libm::cos(z / 2.0));
    [a * d * f - b * c * e, b * c * f + a * d * e, b * d * e - a * c * f, b * d * f + a * c * e]
}

pub fn qrot(q: [f64; 4], v: [f64; 3]) -> [f64; 3] {
    let u = [q[0], q[1], q[2]];
    let uv = [u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]];
    let uu = [u[1] * uv[2] - u[2] * uv[1], u[2] * uv[0] - u[0] * uv[2], u[0] * uv[1] - u[1] * uv[0]];
    [0, 1, 2].map(|i| v[i] + 2.0 * (q[3] * uv[i] + uu[i]))
}

/// gaussianBlur(v, width, sigma) with its Float32Array kernel and output.
pub fn gaussian_blur(v: &[f32], width: usize, sigma: f64) -> Vec<f32> {
    if sigma < 0.4 {
        return v.to_vec();
    }
    let radius = (3.0 * sigma).ceil() as usize;
    let mut kernel = vec![0f32; radius + 1];
    let mut sum = 0.0f64;
    for (j, k) in kernel.iter_mut().enumerate() {
        *k = libm::exp(-((j * j) as f64) / (2.0 * sigma * sigma)) as f32;
        sum += *k as f64 * if j == 0 { 1.0 } else { 2.0 };
    }
    for k in kernel.iter_mut() {
        *k = (*k as f64 / sum) as f32;
    }
    let n = v.len() / width;
    let mut out = vec![0f32; v.len()];
    if n == 0 {
        return out;
    }
    for i in 0..n {
        for c in 0..width {
            let mut a = kernel[0] as f64 * v[i * width + c] as f64;
            for (k, kv) in kernel.iter().enumerate().skip(1) {
                let lo = i.saturating_sub(k);
                let hi = (i + k).min(n - 1);
                a += *kv as f64 * (v[lo * width + c] as f64 + v[hi * width + c] as f64);
            }
            out[i * width + c] = a as f32;
        }
    }
    out
}

pub fn dir(d: f64) -> [f64; 2] {
    let s = std::f64::consts::FRAC_1_SQRT_2;
    match d {
        x if x == 0.0 => [0.0, 1.0],
        x if x == 1.0 => [0.0, -1.0],
        x if x == 2.0 => [-1.0, 0.0],
        x if x == 3.0 => [1.0, 0.0],
        x if x == 4.0 => [-s, s],
        x if x == 5.0 => [s, s],
        x if x == 6.0 => [-s, -s],
        x if x == 7.0 => [s, -s],
        _ => [0.0, 0.0],
    }
}

// ------------------------------------------------------------------ model

pub struct BankEntry {
    pub key: Vec<f64>,
    pub dur: f64,
    pub p: Vec<[f64; 3]>,
    pub r: Vec<[f64; 3]>,
}

pub struct Track {
    pub features: Vec<Vec<f64>>,
    pub pos: Vec<[f64; 3]>,
    pub rot: Vec<[f64; 4]>,
    pub offset: Vec<f64>,
    pub lanes: Vec<f64>,
    pub layers: Vec<f64>,
    pub cut: Vec<String>,
    pub bank: Vec<BankEntry>,
}

pub struct Head {
    pub mu: Vec<f64>,
    pub sd: Vec<f64>,
    pub coef: Vec<Vec<f64>>,
    pub lo: Vec<f64>,
    pub hi: Vec<f64>,
    pub tail: Vec<f64>,
    pub res: Vec<Vec<f64>>,
    pub src_start: f64,
    pub src_end: f64,
}

pub struct Model {
    pub tracks: [Track; 2],
    pub head: Head,
    pub info: Value,
}

fn nums(v: &Value) -> Vec<f64> {
    v.as_array().map(|a| a.iter().map(|x| x.as_f64().unwrap_or(f64::NAN)).collect()).unwrap_or_default()
}

fn rows(v: &Value) -> Vec<Vec<f64>> {
    v.as_array().map(|a| a.iter().map(nums).collect()).unwrap_or_default()
}

fn arr3(v: &Value) -> Vec<[f64; 3]> {
    rows(v).into_iter().map(|r| [r[0], r[1], r[2]]).collect()
}

impl Model {
    /// Lazily inflated shared instance (ensureReplayModelLoaded).
    pub fn shared() -> anyhow::Result<&'static Model> {
        static M: std::sync::OnceLock<Result<Model, String>> = std::sync::OnceLock::new();
        M.get_or_init(|| Model::load().map_err(|e| e.to_string())).as_ref().map_err(|e| anyhow::anyhow!("{e}"))
    }

    pub fn load() -> anyhow::Result<Model> {
        let json = miniz_oxide::inflate::decompress_to_vec_zlib(MODEL_Z).map_err(|e| anyhow::anyhow!("replay model inflate: {e:?}"))?;
        let v: Value = serde_json::from_slice(&json)?;
        let track = |k: &str| -> Track {
            let t = &v["tracks"][k];
            Track {
                features: rows(&t["features"]),
                pos: arr3(&t["pos"]),
                rot: rows(&t["rot"]).into_iter().map(|r| [r[0], r[1], r[2], r[3]]).collect(),
                offset: nums(&t["offset"]),
                lanes: nums(&t["lanes"]),
                layers: nums(&t["layers"]),
                cut: t["cut"].as_array().map(|a| a.iter().map(|s| s.as_str().unwrap_or("").to_string()).collect()).unwrap_or_default(),
                bank: t["bank"]
                    .as_array()
                    .map(|a| a.iter().map(|b| BankEntry { key: nums(&b["key"]), dur: b["dur"].as_f64().unwrap_or(1.0), p: arr3(&b["p"]), r: arr3(&b["r"]) }).collect())
                    .unwrap_or_default(),
            }
        };
        let h = &v["head"];
        let head = Head {
            mu: nums(&h["mu"]),
            sd: nums(&h["sd"]),
            coef: rows(&h["coef"]),
            lo: nums(&h["lo"]),
            hi: nums(&h["hi"]),
            tail: nums(&h["res"][0]),
            res: rows(&h["res"][1]),
            src_start: h["srcStart"].as_f64().unwrap_or(0.0),
            src_end: h["srcEnd"].as_f64().unwrap_or(1.0),
        };
        Ok(Model { tracks: [track("0"), track("1")], head, info: v["info"].clone() })
    }
}

// ------------------------------------------------------------------ notes / walls

#[derive(Clone, Copy, Debug)]
pub struct RNote {
    pub b: f64,
    pub x: f64,
    pub y: f64,
    pub c: f64,
    pub d: f64,
    pub t: f64,
    pub idx: usize,
}

/// JS unary plus on a JSON value (`+undefined` = NaN).
fn plus(v: Option<&Value>) -> f64 {
    match v {
        Some(Value::Number(n)) => n.as_f64().unwrap_or(f64::NAN),
        Some(Value::String(s)) => {
            let t = s.trim();
            if t.is_empty() { 0.0 } else { t.parse().unwrap_or(f64::NAN) }
        }
        Some(Value::Bool(b)) => *b as u8 as f64,
        Some(Value::Null) => 0.0,
        _ => f64::NAN,
    }
}

fn truthy(v: &Value) -> bool {
    match v {
        Value::Null => false,
        Value::Bool(b) => *b,
        Value::Number(n) => n.as_f64().is_some_and(|x| x != 0.0 && !x.is_nan()),
        Value::String(s) => !s.is_empty(),
        _ => true,
    }
}

/// `raw[a] || raw[b]`
fn js_or<'a>(o: &'a Value, a: &str, b: &str) -> Option<&'a Value> {
    o.get(a).filter(|v| truthy(v)).or_else(|| o.get(b).filter(|v| truthy(v)))
}

/// `a ?? b` over JSON keys (null and missing both fall through).
fn nn<'a>(o: &'a Value, keys: &[&str]) -> Option<&'a Value> {
    keys.iter().find_map(|k| o.get(*k).filter(|v| !v.is_null()))
}

/// mapNotes(raw, bpm, offset)
pub fn map_notes(raw: &Value, bpm: f64, offset: f64) -> Vec<RNote> {
    let empty = vec![];
    // raw._notes || raw.notes || []  (an empty array is truthy)
    let xs = js_or(raw, "_notes", "notes").and_then(|v| v.as_array()).unwrap_or(&empty);
    let mut out: Vec<RNote> = xs
        .iter()
        .map(|n| RNote {
            b: plus(nn(n, &["_time", "b"])),
            x: plus(nn(n, &["_lineIndex", "x"])),
            y: plus(nn(n, &["_lineLayer", "y"])),
            c: plus(nn(n, &["_type", "c"])),
            d: plus(nn(n, &["_cutDirection", "d"])),
            t: 0.0,
            idx: 0,
        })
        .collect();
    for n in raw.get("colorNotes").and_then(|v| v.as_array()).unwrap_or(&empty) {
        out.push(RNote { b: plus(n.get("b")), x: plus(n.get("x")), y: plus(n.get("y")), c: plus(n.get("c")), d: plus(n.get("d")), t: 0.0, idx: 0 });
    }
    for n in raw.get("bombNotes").and_then(|v| v.as_array()).unwrap_or(&empty) {
        out.push(RNote { b: plus(n.get("b")), x: plus(n.get("x")), y: plus(n.get("y")), c: 3.0, d: 0.0, t: 0.0, idx: 0 });
    }
    for (i, n) in out.iter_mut().enumerate() {
        n.t = (n.b * 60.0) / bpm + offset;
        n.idx = i;
    }
    out.sort_by(|a, b| js_cmp(a.t - b.t).then((a.idx as i64 - b.idx as i64).cmp(&0)));
    out
}

/// Array.prototype.sort comparator result (NaN compares as equal).
fn js_cmp(v: f64) -> std::cmp::Ordering {
    if v < 0.0 {
        std::cmp::Ordering::Less
    } else if v > 0.0 {
        std::cmp::Ordering::Greater
    } else {
        std::cmp::Ordering::Equal
    }
}

#[derive(Clone, Copy, Debug)]
pub struct Wall {
    pub start: f64,
    pub end: f64,
    pub left: f64,
    pub right: f64,
    pub bottom: f64,
    pub top: f64,
}

fn num_or(o: &Value, keys: &[&str], fallback: f64) -> f64 {
    match nn(o, keys) {
        Some(v) => match v {
            Value::Number(n) => n.as_f64().unwrap_or(f64::NAN),
            Value::String(s) => {
                let t = s.trim();
                if t.is_empty() { 0.0 } else { t.parse().unwrap_or(f64::NAN) }
            }
            Value::Bool(b) => *b as u8 as f64,
            _ => f64::NAN,
        },
        None => fallback,
    }
}

/// cyberMapWalls(raw, bpm, offset)
pub fn map_walls(raw: &Value, bpm: f64, offset: f64) -> Vec<Wall> {
    let empty = vec![];
    let arr = js_or(raw, "_obstacles", "obstacles").and_then(|v| v.as_array()).unwrap_or(&empty);
    let secs = 60.0 / bpm.max(0.01);
    let mut out = vec![];
    for ob in arr {
        let legacy = ob.get("_time").is_some();
        let typ = num_or(ob, &["_type", "type"], 0.0);
        let y = num_or(ob, &["_lineLayer", "y"], if legacy && typ == 1.0 { 2.0 } else { 0.0 });
        let h = num_or(ob, &["_height", "h"], if legacy && typ == 1.0 { 3.0 } else { 5.0 });
        let x = num_or(ob, &["_lineIndex", "x"], 0.0);
        let w = num_or(ob, &["_width", "w"], 1.0);
        let beat = num_or(ob, &["_time", "b"], 0.0);
        let dur = num_or(ob, &["_duration", "d"], 0.0);
        if !(beat + dur + x + y + w + h).is_finite() || dur <= 0.0 || w <= 0.0 || h <= 0.0 {
            continue;
        }
        let left = (-2.0 + x) * DEFAULT_ENV_LANE_WIDTH;
        let bottom = y * DEFAULT_ENV_ROW_HEIGHT + DEFAULT_ENV_NOTE_Y_OFFSET - DEFAULT_ENV_ROW_HEIGHT * 0.5;
        out.push(Wall { start: (beat * secs + offset).max(0.0), end: (beat + dur) * secs + offset, left, right: left + w * DEFAULT_ENV_LANE_WIDTH, bottom, top: bottom + h * DEFAULT_ENV_ROW_HEIGHT });
    }
    out
}

/// cyberCountWallIntersections(head, times, walls).hits
pub fn count_wall_hits(head_pos: &[f32], n_times: usize, walls: &[Wall], eye_y: f64) -> usize {
    let mut hits = 0;
    for w in walls {
        let start = (w.start * HZ - 1e-3).ceil().max(0.0) as usize;
        let end = (w.end * HZ + 1e-3).floor().min(n_times as f64 - 1.0);
        if end < 0.0 {
            continue;
        }
        let end = end as usize;
        let mut hit = false;
        let mut i = start;
        while i <= end {
            let x = head_pos[3 * i] as f64 * 2.25;
            let y = (head_pos[3 * i + 1] as f64 - CYBER_PLAYER_HEAD_HEIGHT) * CYBER_SCENE_Y_SCALE + eye_y;
            let r = 0.19;
            let dx = (w.left - x).max(0.0).max(x - w.right);
            let dy = (w.bottom - y).max(0.0).max(y - w.top);
            if dx * dx + dy * dy < r * r {
                hit = true;
                break;
            }
            i += 1;
        }
        if hit {
            hits += 1;
        }
    }
    hits
}

#[derive(Clone, Copy, Debug, Default)]
pub struct WallStats {
    pub before: usize,
    pub after: usize,
    pub wall_count: usize,
    pub adjusted: usize,
}

/// cyberDodgeWalls(head, times, walls)
pub fn dodge_walls(head_pos: &mut [f32], times: &[f32], walls: &[Wall], eye_y: f64, enabled: bool) -> WallStats {
    if walls.is_empty() {
        return WallStats::default();
    }
    let n = times.len();
    let before = count_wall_hits(head_pos, n, walls, eye_y);
    if !enabled {
        return WallStats { before, after: before, wall_count: walls.len(), adjusted: 0 };
    }
    let base = head_pos.to_vec();
    let mut shift_x = vec![0f32; n];
    let mut shift_y = vec![0f32; n];
    let mut adjusted = 0;
    for w in walls {
        let mid = (w.start + w.end) * 0.5;
        let index = ((mid * HZ).round().max(0.0) as usize).min(n - 1);
        let sx = base[index * 3] as f64 * 2.25;
        let sy = (base[index * 3 + 1] as f64 - CYBER_PLAYER_HEAD_HEIGHT) * CYBER_SCENE_Y_SCALE + eye_y;
        let r = 0.24;
        let dist_x = (w.left - sx).max(0.0).max(sx - w.right);
        let dist_y = (w.bottom - sy).max(0.0).max(sy - w.top);
        if dist_x * dist_x + dist_y * dist_y >= r * r && count_wall_hits(&base, n, std::slice::from_ref(w), eye_y) == 0 {
            continue;
        }
        let mut cands: Vec<[f64; 2]> = [[w.left - r, sy], [w.right + r, sy], [sx, w.bottom - r], [sx, w.top + r]].into_iter().filter(|[x, y]| x.abs() <= 2.0 && *y >= 0.85 && *y <= 2.65).collect();
        let cost = |a: &[f64; 2]| (a[0] - sx).powi(2) + (a[1] - sy).powi(2) * 1.22;
        cands.sort_by(|a, b| js_cmp(cost(a) - cost(b)));
        let Some(target) = cands.first() else { continue };
        let (dx, dy) = (target[0] - sx, target[1] - sy);
        let from = ((w.start - 0.42) * HZ).floor().max(0.0) as usize;
        let to = ((w.end + 0.39) * HZ).ceil().min(n as f64 - 1.0);
        if to >= 0.0 {
            for i in from..=(to as usize) {
                let t = times[i] as f64;
                let rise = clamp((t - (w.start - 0.42)) / 0.42, 0.0, 1.0);
                let fall = clamp((w.end + 0.39 - t) / 0.39, 0.0, 1.0);
                let smooth = |z: f64| z * z * (3.0 - 2.0 * z);
                let weight = smooth(rise).min(smooth(fall));
                if weight < 0.0001 {
                    continue;
                }
                if (dx * weight).abs() > (shift_x[i] as f64).abs() {
                    shift_x[i] = (dx * weight) as f32;
                }
                if (dy * weight).abs() > (shift_y[i] as f64).abs() {
                    shift_y[i] = (dy * weight) as f32;
                }
            }
        }
        adjusted += 1;
    }
    for i in 0..n {
        head_pos[3 * i] = (head_pos[3 * i] as f64 + shift_x[i] as f64 / 2.25) as f32;
        head_pos[3 * i + 1] = (head_pos[3 * i + 1] as f64 + shift_y[i] as f64 / CYBER_SCENE_Y_SCALE) as f32;
    }
    let after = count_wall_hits(head_pos, n, walls, eye_y);
    WallStats { before, after, wall_count: walls.len(), adjusted }
}

// ------------------------------------------------------------------ simulator

pub struct Motion {
    pub pos: Vec<f32>,
    pub rot: Vec<f32>,
}

struct HandTrack {
    notes: Vec<RNote>,
    feats: Vec<Vec<f64>>,
    anchor_times: Vec<f64>,
    nearest: Vec<usize>,
}

pub struct Event {
    pub id: i32,
    pub t: f64,
    pub spawn: f64,
    pub kind: i32,
    pub cut: Vec<u8>,
    pub points: i64,
    pub cumulative: i64,
    pub combo: i64,
    pub mult: i64,
}

pub struct Replay {
    pub times: Vec<f32>,
    pub left: Motion,
    pub right: Motion,
    pub head: Motion,
    pub wall_stats: WallStats,
    pub events: Vec<Event>,
    pub score: i64,
    pub hit: usize,
    pub miss: usize,
    pub max_combo: i64,
}

fn features(notes: &[RNote]) -> Vec<Vec<f64>> {
    (0..notes.len())
        .map(|i| {
            let n = &notes[i];
            let [x, y] = dir(n.d);
            let mut z = vec![0.75 * n.x, 0.8 * n.y, 1.4 * x, 1.4 * y, if n.d == 8.0 { 0.3 } else { 0.0 }];
            for (j, prev) in [(i as i64 - 1, true), (i as i64 + 1, false)] {
                let b = if j >= 0 { notes.get(j as usize) } else { None };
                let Some(b) = b else {
                    z.extend_from_slice(&[0.0, 0.0, 0.0, 0.0, 2.6]);
                    continue;
                };
                let [xx, yy] = dir(b.d);
                let dt = (if prev { n.t - b.t } else { b.t - n.t }).max(0.0);
                z.extend_from_slice(&[0.28 * (b.x - n.x), 0.28 * (b.y - n.y), 0.32 * xx, 0.32 * yy, 0.55 * libm::log1p(dt / 0.22)]);
            }
            z
        })
        .collect()
}

#[derive(Clone, Copy)]
struct Nb {
    i: usize,
    d: f64,
}

fn nearest<'a>(source: impl Iterator<Item = &'a [f64]>, query: &[f64], k: usize) -> Vec<Nb> {
    let mut best: Vec<Nb> = Vec::with_capacity(k + 1);
    for (i, a) in source.enumerate() {
        let mut d = 0.0;
        for j in 0..query.len() {
            let e = a.get(j).copied().unwrap_or(f64::NAN) - query[j];
            d += e * e;
        }
        if best.len() < k || d < best[best.len() - 1].d {
            let p = best.iter().position(|x| x.d > d).unwrap_or(best.len());
            best.insert(p, Nb { i, d });
            if best.len() > k {
                best.pop();
            }
        }
    }
    best
}

fn weights(nb: &[Nb], temp: f64) -> Vec<f64> {
    let m = nb[0].d;
    let z: Vec<f64> = nb.iter().map(|v| libm::exp(-(60f64.min(v.d - m)) / temp)).collect();
    let s: f64 = z.iter().fold(0.0, |a, b| a + b);
    z.iter().map(|v| v / s).collect()
}

fn get_track(notes: &[RNote], hand: f64) -> HandTrack {
    let mut x: Vec<RNote> = notes.iter().filter(|n| n.c == hand).copied().collect();
    x.sort_by(|a, b| js_cmp(a.t - b.t).then((a.idx as i64 - b.idx as i64).cmp(&0)));
    let feats = features(&x);
    HandTrack { notes: x, feats, anchor_times: vec![], nearest: vec![] }
}

fn set3(dst: &mut [f32], at: usize, v: &[f64]) {
    for (j, x) in v.iter().enumerate() {
        dst[at + j] = *x as f32;
    }
}

fn generate_hand(model: &Model, track: &mut HandTrack, hand: usize, time: &[f32]) -> Motion {
    let n = time.len();
    let src = &model.tracks[hand];
    let notes = track.notes.clone();
    let mut pos = vec![0f32; n * 3];
    let mut rot = vec![0f32; n * 4];
    let idle = [if hand == 0 { -0.45 } else { 0.45 }, 1.0, 0.0];
    let idleq = norm4([0.0, 0.0, 0.4, -0.8]);
    if notes.is_empty() {
        for i in 0..n {
            set3(&mut pos, i * 3, &idle);
            set3(&mut rot, i * 4, &idleq);
        }
        return Motion { pos, rot };
    }
    let nsrc = src.features.len();
    // Lane / layer regression slopes.
    let mut slopes = [0.0; 2];
    for (ax, slope) in slopes.iter_mut().enumerate() {
        let la = if ax == 1 { &src.layers } else { &src.lanes };
        let avg = la.iter().fold(0.0, |a, b| a + b) / la.len() as f64;
        let pavg = src.pos.iter().map(|p| p[ax]).fold(0.0, |a, b| a + b) / src.pos.len() as f64;
        let (mut num, mut den) = (0.0, 0.0);
        for j in 0..la.len() {
            num += (la[j] - avg) * (src.pos[j][ax] - pavg);
            den += (la[j] - avg).powi(2);
        }
        *slope = num / den.max(1e-9);
    }
    struct Node {
        p: [f64; 3],
        q: [f64; 4],
        t: f64,
    }
    let mut nodes: Vec<Node> = vec![];
    let mut nearest_idx = vec![];
    for (i, note) in notes.iter().enumerate() {
        let nb = nearest(src.features.iter().map(|v| v.as_slice()), &track.feats[i], 10.min(nsrc));
        let w = weights(&nb, 0.95);
        let mut p = [0.0; 3];
        let mut q = [0.0; 4];
        let mut near = [0.0; 2];
        let mut off = 0.0;
        let q0 = src.rot[nb[0].i];
        for (j, b) in nb.iter().enumerate() {
            let (k, wt) = (b.i, w[j]);
            for a in 0..3 {
                p[a] += src.pos[k][a] * wt;
            }
            let sign = if dot(&src.rot[k], &q0) < 0.0 { -1.0 } else { 1.0 };
            for a in 0..4 {
                q[a] += src.rot[k][a] * wt * sign;
            }
            near[0] += src.lanes[k] * wt;
            near[1] += src.layers[k] * wt;
            off += src.offset[k] * wt;
        }
        p[0] += slopes[0] * (note.x - near[0]);
        p[1] += slopes[1] * (note.y - near[1]);
        let off = clamp(off, -0.055, 0.025);
        nodes.push(Node { p, q: norm4(q), t: note.t + off });
        nearest_idx.push(nb[0].i);
    }
    track.anchor_times = nodes.iter().map(|n| n.t).collect();
    track.nearest = nearest_idx;
    let mut pnodes: Vec<[f64; 3]> = vec![idle];
    pnodes.extend(nodes.iter().map(|n| n.p));
    pnodes.push(idle);
    let mut qnodes: Vec<[f64; 4]> = vec![idleq];
    qnodes.extend(nodes.iter().map(|n| n.q));
    qnodes.push(idleq);
    let mut tnodes: Vec<f64> = vec![0.0];
    tnodes.extend(track.anchor_times.iter().copied());
    tnodes.push(time[n - 1] as f64);
    for i in 1..tnodes.len() {
        tnodes[i] = tnodes[i].max(tnodes[i - 1] + 1e-6);
    }
    struct Motif {
        pr: Vec<f32>,
        rr: Vec<f32>,
    }
    let mut motifs: Vec<Motif> = vec![];
    for i in 0..notes.len().saturating_sub(1) {
        let dur = tnodes[i + 2] - tnodes[i + 1];
        let mut key: Vec<f64> = track.feats[i][..5].to_vec();
        key.extend_from_slice(&track.feats[i + 1][..5]);
        key.push(0.55 * libm::log1p(dur.max(0.001) / 0.22));
        key.push(0.15 * (notes[i + 1].x - notes[i].x));
        key.push(0.15 * (notes[i + 1].y - notes[i].y));
        let nb = nearest(src.bank.iter().map(|b| b.key.as_slice()), &key, 6.min(src.bank.len()));
        let w = weights(&nb, 0.85);
        let mut pr = vec![0f32; 75];
        let mut rr = vec![0f32; 75];
        let mut factor = 0.0;
        for (j, b) in nb.iter().enumerate() {
            factor += w[j] * clamp(dur / src.bank[b.i].dur, 1.12, 1.52);
        }
        for (j, b) in nb.iter().enumerate() {
            let be = &src.bank[b.i];
            let wt = w[j] * factor;
            for k in 0..25 {
                for c in 0..3 {
                    pr[k * 3 + c] = (pr[k * 3 + c] as f64 + wt * be.p[k][c]) as f32;
                    rr[k * 3 + c] = (rr[k * 3 + c] as f64 + wt * be.r[k][c]) as f32;
                }
            }
        }
        motifs.push(Motif { pr, rr });
    }
    let mut seg = 0usize;
    let last = tnodes.len() - 2;
    for k in 0..n {
        let t = time[k] as f64;
        while seg < last && t >= tnodes[seg + 1] {
            seg += 1;
        }
        let (s0, s1) = (tnodes[seg], tnodes[seg + 1]);
        let sdur = s1 - s0;
        let late = seg == 0 || (seg < notes.len() && sdur > 3.0);
        let mstart = if late { s0.max(s1 - 1.0) } else { s0 };
        let raw = clamp((t - mstart) / (s1 - mstart).max(1e-8), 0.0, 1.0);
        let idle_phase = seg == 0 || seg == last;
        let u = if idle_phase || late { raw * raw * (3.0 - 2.0 * raw) } else { raw };
        let (a, b) = (pnodes[seg], pnodes[seg + 1]);
        let mut p = [0, 1, 2].map(|j| a[j] + (b[j] - a[j]) * u);
        let mut q = quat_slerp(qnodes[seg], qnodes[seg + 1], u);
        if !idle_phase {
            let m = &motifs[seg - 1];
            let x = raw * 24.0;
            let j = 23usize.min(x.floor() as usize);
            let f = x - j as f64;
            let mut rv = [0.0; 3];
            for c in 0..3 {
                p[c] += m.pr[j * 3 + c] as f64 * (1.0 - f) + m.pr[(j + 1) * 3 + c] as f64 * f;
                rv[c] = m.rr[j * 3 + c] as f64 * (1.0 - f) + m.rr[(j + 1) * 3 + c] as f64 * f;
            }
            q = qmul(rvquat(rv), q);
        }
        set3(&mut pos, k * 3, &p);
        set3(&mut rot, k * 4, &q);
    }
    let mut ps = gaussian_blur(&pos, 3, 1.2);
    for k in 1..n {
        let mut d = 0.0f64;
        for j in 0..4 {
            d += rot[k * 4 + j] as f64 * rot[(k - 1) * 4 + j] as f64;
        }
        if d < 0.0 {
            for j in 0..4 {
                rot[k * 4 + j] = -rot[k * 4 + j];
            }
        }
    }
    let sm = gaussian_blur(&rot, 4, 1.1);
    let mut qs = vec![0f32; n * 4];
    for k in 0..n {
        let q = norm(&sm[k * 4..k * 4 + 4].iter().map(|v| *v as f64).collect::<Vec<_>>());
        set3(&mut qs, k * 4, &q);
    }
    // Follow-through after smoothing.
    let mut fseg = 0usize;
    for k in 0..n {
        let t = time[k] as f64;
        while fseg < last && t >= tnodes[fseg + 1] {
            fseg += 1;
        }
        if fseg == 0 || fseg >= notes.len() {
            continue;
        }
        let (start, end) = (tnodes[fseg], tnodes[fseg + 1]);
        let fdur = if end - start > 3.0 { 1.0 } else { end - start };
        if t >= start + fdur {
            continue;
        }
        let u = clamp((t - start) / fdur.max(1e-8), 0.0, 1.0);
        let apex = 0.445;
        let mut phase = u;
        if u > apex {
            let rec = (u - apex) / (1.0 - apex);
            let eased = rec - 0.18 * rec * (1.0 - rec);
            phase = apex + (1.0 - apex) * eased;
        }
        let ft = libm::sin(std::f64::consts::PI * phase) * (1.0 - 0.35 * phase);
        let [cx, cy] = dir(notes[fseg - 1].d);
        ps[k * 3] = (ps[k * 3] as f64 + cx * 0.22 * ft) as f32;
        ps[k * 3 + 1] = (ps[k * 3 + 1] as f64 + cy * 0.22 * ft) as f32;
    }
    Motion { pos: ps, rot: qs }
}

fn generate_headset(model: &Model, notes: &[RNote], times: &[f32], left: &Motion, right: &Motion) -> Motion {
    let n = times.len();
    let hz = HZ;
    let mut a = vec![0f32; n * 6];
    for i in 0..n {
        a[i * 6..i * 6 + 3].copy_from_slice(&left.pos[i * 3..i * 3 + 3]);
        a[i * 6 + 3..i * 6 + 6].copy_from_slice(&right.pos[i * 3..i * 3 + 3]);
    }
    let aa = gaussian_blur(&a, 6, hz * 0.18);
    let bb = gaussian_blur(&a, 6, hz * 0.48);
    let mut vv = vec![0f32; n * 6];
    let mut sp = vec![0f32; n];
    let mut nf = vec![0f32; n * 7];
    let dt = 1.0 / hz;
    for i in 0..n {
        let mut speed = 0.0;
        for c in 0..6 {
            let hi = (i + 1).min(n - 1);
            let lo = i.saturating_sub(1);
            let d = (bb[hi * 6 + c] as f64 - bb[lo * 6 + c] as f64) / if i == 0 || i == n - 1 { dt } else { 2.0 * dt };
            vv[i * 6 + c] = d as f32;
            speed += d * d;
        }
        sp[i] = libm::sqrt(speed) as f32;
    }
    let ss = gaussian_blur(&sp, 1, hz * 0.25);
    for note in notes {
        let i = ((note.t * hz).round().max(0.0) as usize).min(n - 1);
        let p = i * 7;
        let x = (note.x - 1.5) / 1.5;
        let y = note.y - 1.0;
        let add = |nf: &mut Vec<f32>, k: usize, v: f64| nf[k] = (nf[k] as f64 + v) as f32;
        if note.c == 3.0 {
            add(&mut nf, p + 4, x);
            add(&mut nf, p + 5, y);
            add(&mut nf, p + 6, 1.0);
        } else if note.c < 2.0 {
            add(&mut nf, p, x);
            add(&mut nf, p + 1, y);
            add(&mut nf, p + 2, 1.0);
            add(&mut nf, p + 3, if note.c == 1.0 { 1.0 } else { -1.0 });
        }
    }
    let note_blur = gaussian_blur(&nf, 7, hz * 0.26);
    let hh = &model.head;
    let mut out = vec![0f32; n * 6];
    let mut f = Vec::with_capacity(32);
    for k in 0..n {
        f.clear();
        let base = k * 6;
        for i in 0..6 {
            f.push(aa[base + i] as f64);
        }
        for i in 0..6 {
            f.push(bb[base + i] as f64);
        }
        for i in 0..6 {
            f.push(vv[base + i] as f64);
        }
        for i in 0..3 {
            f.push((aa[base + i] as f64 + aa[base + 3 + i] as f64) * 0.5);
        }
        for i in 0..3 {
            f.push(aa[base + 3 + i] as f64 - aa[base + i] as f64);
        }
        f.push(ss[k] as f64);
        for i in 0..7 {
            f.push(note_blur[k * 7 + i] as f64 * hz * 0.65);
        }
        for j in 0..6 {
            let mut value = hh.coef[32][j];
            for i in 0..32 {
                value += ((f[i] - hh.mu[i]) / hh.sd[i]) * hh.coef[i][j];
            }
            out[k * 6 + j] = clamp(value, hh.lo[j], hh.hi[j]) as f32;
        }
    }
    let mut sm = gaussian_blur(&out, 6, hz * 0.19);
    let (tail, res) = (&hh.tail, &hh.res);
    let mut rptr = 0usize;
    let tlast = (times[n - 1] as f64).max(0.01);
    for k in 0..n {
        let target = hh.src_start + (hh.src_end - hh.src_start) * (times[k] as f64 / tlast);
        while rptr < tail.len() - 2 && tail[rptr + 1] < target {
            rptr += 1;
        }
        let u = clamp((target - tail[rptr]) / (tail[rptr + 1] - tail[rptr]).max(0.00001), 0.0, 1.0);
        for j in 0..6 {
            sm[k * 6 + j] = clamp(sm[k * 6 + j] as f64 + 0.23 * (res[rptr][j] * (1.0 - u) + res[rptr + 1][j] * u), hh.lo[j], hh.hi[j]) as f32;
        }
    }
    let sm = gaussian_blur(&sm, 6, hz * 0.1);
    let mut pos = vec![0f32; n * 3];
    let mut rot = vec![0f32; n * 4];
    for k in 0..n {
        pos[k * 3..k * 3 + 3].copy_from_slice(&sm[k * 6..k * 6 + 3]);
        let q = eulerquat(sm[k * 6 + 3] as f64, sm[k * 6 + 4] as f64, sm[k * 6 + 5] as f64);
        set3(&mut rot, k * 4, &q);
    }
    Motion { pos, rot }
}

pub fn b64decode(s: &str) -> Vec<u8> {
    fn val(c: u8) -> Option<u32> {
        match c {
            b'A'..=b'Z' => Some((c - b'A') as u32),
            b'a'..=b'z' => Some((c - b'a' + 26) as u32),
            b'0'..=b'9' => Some((c - b'0' + 52) as u32),
            b'+' => Some(62),
            b'/' => Some(63),
            _ => None,
        }
    }
    let mut out = vec![];
    let (mut acc, mut bits) = (0u32, 0);
    for c in s.bytes() {
        let Some(v) = val(c) else { continue };
        acc = (acc << 6) | v;
        bits += 6;
        if bits >= 8 {
            bits -= 8;
            out.push((acc >> bits) as u8);
            acc &= (1 << bits) - 1;
        }
    }
    out
}

fn f32_at(b: &[u8], o: usize) -> f64 {
    f32::from_le_bytes([b[o], b[o + 1], b[o + 2], b[o + 3]]) as f64
}

/// Shared scoring loop of extractEvents / parseBSOR.
pub fn score_events(events: &mut [Event]) -> (i64, usize, usize, i64) {
    let (mut mult, mut progress, mut score, mut hit, mut miss, mut max_combo, mut combo) = (1i64, 0i64, 0i64, 0usize, 0usize, 0i64, 0i64);
    for e in events.iter_mut() {
        if e.kind == 0 && e.cut.len() >= 72 {
            let (dist, pre, post) = (f32_at(&e.cut, 56), f32_at(&e.cut, 64), f32_at(&e.cut, 68));
            let raw = 70.0 * clamp(pre, 0.0, 1.0) + 30.0 * clamp(post, 0.0, 1.0) + 15.0 * (1.0 - clamp(dist / 0.3, 0.0, 1.0));
            let pts = clamp((raw + 0.5).floor(), 0.0, 115.0) as i64;
            e.points = pts;
            score += pts * mult;
            hit += 1;
            combo += 1;
            max_combo = max_combo.max(combo);
            progress += 1;
            if mult < 8 && progress >= mult * 2 {
                mult *= 2;
                progress = 0;
            }
        } else {
            e.points = 0;
            miss += 1;
            combo = 0;
            mult = (mult / 2).max(1);
            progress = 0;
        }
        e.cumulative = score;
        e.combo = combo;
        e.mult = mult;
    }
    (score, hit, miss, max_combo)
}

fn extract_events(model: &Model, times: &[f32], hands: [(&HandTrack, &Motion); 2]) -> Vec<Event> {
    let mut records: Vec<Event> = vec![];
    let n = times.len() as f64;
    for (hand, (track, motion)) in hands.iter().enumerate() {
        let src = &model.tracks[hand];
        for (i, no) in track.notes.iter().enumerate() {
            let at = track.anchor_times[i];
            let fi = clamp((at * HZ + 0.5).floor(), 4.0, n - 5.0) as usize;
            let bi = clamp((no.t * HZ + 0.5).floor(), 4.0, n - 5.0) as usize;
            let mut v = [0.0; 2];
            let mut w = [0.0; 2];
            for c in 0..2 {
                v[c] = motion.pos[(fi + 2) * 3 + c] as f64 - motion.pos[(fi - 2) * 3 + c] as f64;
                w[c] = motion.pos[(bi + 2) * 3 + c] as f64 - motion.pos[(bi - 2) * 3 + c] as f64;
            }
            let d = dir(no.d);
            let cos = |v: [f64; 2]| dot(&v, &d) / (hypot(&v) * hypot(&d) + 1e-10);
            let plausible = if no.d == 8.0 { hypot(&v) > 0.004 } else { cos(v) >= 0.5 && cos(w) >= 0.5 };
            let mut cut = if plausible { b64decode(&src.cut[track.nearest[i]]) } else { vec![] };
            if plausible && cut.len() == 72 {
                cut[20..24].copy_from_slice(&(hand as i32).to_le_bytes());
                cut[24..28].copy_from_slice(&((at - no.t) as f32).to_le_bytes());
            }
            records.push(Event {
                id: (30000.0 + 1000.0 * no.x + 100.0 * no.y + 10.0 * no.c + no.d) as i32,
                t: at,
                spawn: no.t,
                kind: if plausible { 0 } else { 2 },
                cut,
                points: 0,
                cumulative: 0,
                combo: 0,
                mult: 1,
            });
        }
    }
    records.sort_by(|a, b| js_cmp(a.t - b.t).then(a.id.cmp(&b.id)));
    records
}

/// SimbersReplaySimulator.generate(model, notes, duration, walls, dodgeWalls)
pub fn generate(model: &Model, notes: &[RNote], duration: f64, walls: &[Wall], eye_y: f64, dodge: bool) -> Replay {
    let end = 1800f64.min(duration.max(2.0));
    let n = (end * HZ).ceil() as usize + 1;
    let times: Vec<f32> = (0..n).map(|i| end.min(i as f64 / HZ) as f32).collect();
    let mut lt = get_track(notes, 0.0);
    let mut rt = get_track(notes, 1.0);
    let left = generate_hand(model, &mut lt, 0, &times);
    let right = generate_hand(model, &mut rt, 1, &times);
    let mut head = generate_headset(model, notes, &times, &left, &right);
    let wall_stats = dodge_walls(&mut head.pos, &times, walls, eye_y, dodge);
    let mut events = extract_events(model, &times, [(&lt, &left), (&rt, &right)]);
    let (score, hit, miss, max_combo) = score_events(&mut events);
    Replay { times, left, right, head, wall_stats, events, score, hit, miss, max_combo }
}
