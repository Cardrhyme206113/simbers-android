//! replay-bsor.js (packBSOR / parseBSOR) plus cyberAttachMapZip's map hash.

use super::replay_sim::{score_events, Event, Motion, Replay, WallStats};
use anyhow::{anyhow, bail, Result};
use serde_json::Value;

const MAGIC: i32 = 0x442d3d69;
const STR_KEYS: [&str; 13] = ["version", "gameVersion", "timestamp", "playerID", "playerName", "platform", "trackingSystem", "hmd", "controller", "hash", "songName", "mapper", "difficulty"];

struct W(Vec<u8>);

impl W {
    fn i32(&mut self, n: i32) {
        self.0.extend_from_slice(&n.to_le_bytes());
    }
    fn u8(&mut self, n: u8) {
        self.0.push(n);
    }
    fn f32(&mut self, x: f64) {
        self.0.extend_from_slice(&(x as f32).to_le_bytes());
    }
    fn utf8(&mut self, s: &str) {
        self.i32(s.len() as i32);
        self.0.extend_from_slice(s.as_bytes());
    }
}

/// `String(v ?? "")`
fn js_string(v: Option<&Value>) -> String {
    match v {
        None | Some(Value::Null) => String::new(),
        Some(Value::String(s)) => s.clone(),
        Some(Value::Bool(b)) => b.to_string(),
        Some(Value::Number(n)) => crate::util::js_num_to_string(n.as_f64().unwrap_or(f64::NAN)),
        Some(other) => other.to_string(),
    }
}

/// `Number(v || 0)`
fn js_num0(v: Option<&Value>) -> f64 {
    match v {
        Some(Value::Number(n)) => n.as_f64().unwrap_or(0.0),
        Some(Value::String(s)) if !s.is_empty() => s.trim().parse().unwrap_or(f64::NAN),
        Some(Value::Bool(true)) => 1.0,
        _ => 0.0,
    }
}

/// First truthy string among keys, else `fallback`.
fn first_text(info: &Value, keys: &[&str], fallback: &str) -> String {
    keys.iter().find_map(|k| info.get(*k).and_then(|v| v.as_str()).filter(|s| !s.is_empty()).map(str::to_string)).unwrap_or_else(|| fallback.to_string())
}

pub struct Meta<'a> {
    pub info: &'a Value,
    pub difficulty: &'a str,
    pub characteristic: &'a str,
}

/// packBSOR(meta, rep, hash, info)
pub fn pack(meta: &Meta, rep: &Replay, hash: &str, model_info: &Value) -> Result<Vec<u8>> {
    let mut fields = model_info.as_object().cloned().unwrap_or_default();
    let set = |f: &mut serde_json::Map<String, Value>, k: &str, v: Value| {
        f.insert(k.into(), v);
    };
    set(&mut fields, "version", "CyberStyle-Web-0.1-simulated".into());
    set(&mut fields, "timestamp", "0".into());
    set(&mut fields, "playerName", "CyberStyle SIMULATED preview".into());
    set(&mut fields, "playerID", "SIMULATED-DIRECTIONAL-PROXY-NO-LEADERBOARD".into());
    set(&mut fields, "hash", hash.into());
    set(&mut fields, "songName", first_text(meta.info, &["_songName", "songName"], "Unknown").into());
    set(&mut fields, "mapper", first_text(meta.info, &["_levelAuthorName", "levelAuthor"], "Unknown").into());
    set(&mut fields, "difficulty", meta.difficulty.into());
    set(&mut fields, "mode", meta.characteristic.into());
    let mut w = W(Vec::with_capacity(256 + rep.times.len() * 92 + rep.events.len() * 88));
    w.i32(MAGIC);
    w.u8(1);
    w.u8(0);
    for k in STR_KEYS {
        w.utf8(&js_string(fields.get(k)));
    }
    w.i32(rep.score as i32);
    for k in ["mode", "environment", "modifiers"] {
        w.utf8(&js_string(fields.get(k)));
    }
    let jd = js_num0(model_info.get("jumpDistance"));
    w.f32(if jd == 0.0 || jd.is_nan() { 12.0 } else { jd });
    w.u8(0);
    for k in ["height", "startTime", "failTime", "speed"] {
        w.f32(js_num0(model_info.get(k)));
    }
    let n = rep.times.len();
    w.u8(1);
    w.i32(n as i32);
    for i in 0..n {
        w.0.extend_from_slice(&rep.times[i].to_le_bytes());
        w.i32(108);
        for (arr, width) in [(&rep.head.pos, 3), (&rep.head.rot, 4), (&rep.left.pos, 3), (&rep.left.rot, 4), (&rep.right.pos, 3), (&rep.right.rot, 4)] {
            for j in 0..width {
                w.0.extend_from_slice(&arr[i * width + j].to_le_bytes());
            }
        }
    }
    w.u8(2);
    w.i32(rep.events.len() as i32);
    for e in &rep.events {
        w.i32(e.id);
        w.f32(e.t);
        w.f32(e.spawn);
        w.i32(e.kind);
        if e.kind == 0 {
            if e.cut.len() != 72 {
                bail!("Invalid cut metadata");
            }
            w.0.extend_from_slice(&e.cut);
        }
    }
    for tag in [3u8, 4, 5] {
        w.u8(tag);
        w.i32(0);
    }
    Ok(w.0)
}

pub struct External {
    pub replay: Replay,
    pub info: serde_json::Map<String, Value>,
}

impl External {
    pub fn text(&self, k: &str) -> String {
        js_string(self.info.get(k))
    }
}

/// parseBSOR(bytes)
pub fn parse(bytes: &[u8]) -> Result<External> {
    let mut o = 0usize;
    let need = |o: usize, n: usize| -> Result<()> {
        if o + n > bytes.len() {
            bail!("Truncated BSOR replay");
        }
        Ok(())
    };
    macro_rules! i32_ {
        () => {{
            need(o, 4)?;
            let v = i32::from_le_bytes(bytes[o..o + 4].try_into().unwrap());
            o += 4;
            v
        }};
    }
    macro_rules! f32_ {
        () => {{
            need(o, 4)?;
            let v = f32::from_le_bytes(bytes[o..o + 4].try_into().unwrap());
            o += 4;
            v
        }};
    }
    macro_rules! byte {
        () => {{
            need(o, 1)?;
            let v = bytes[o];
            o += 1;
            v
        }};
    }
    macro_rules! str_ {
        () => {{
            let n = i32_!();
            if !(0..=100000).contains(&n) {
                bail!("Invalid string");
            }
            let n = n as usize;
            need(o, n)?;
            let v = String::from_utf8_lossy(&bytes[o..o + n]).into_owned();
            o += n;
            v
        }};
    }
    if i32_!() != MAGIC || byte!() != 1 || byte!() != 0 {
        bail!("Unsupported BSOR header");
    }
    let mut info = serde_json::Map::new();
    for k in STR_KEYS {
        info.insert(k.into(), str_!().into());
    }
    let score = i32_!();
    info.insert("score".into(), score.into());
    for k in ["mode", "environment", "modifiers"] {
        info.insert(k.into(), str_!().into());
    }
    info.insert("jumpDistance".into(), (f32_!() as f64).into());
    info.insert("leftHanded".into(), byte!().into());
    for k in ["height", "startTime", "failTime", "speed"] {
        info.insert(k.into(), (f32_!() as f64).into());
    }
    if byte!() != 1 {
        bail!("Missing BSOR frames");
    }
    let n = i32_!();
    if !(1..=1_000_000).contains(&n) {
        bail!("Invalid BSOR frame count");
    }
    let n = n as usize;
    need(o, n * 92)?;
    let mk = || Motion { pos: vec![0f32; n * 3], rot: vec![0f32; n * 4] };
    let (mut head, mut left, mut right) = (mk(), mk(), mk());
    let mut times = vec![0f32; n];
    let rd = |at: usize| f32::from_le_bytes(bytes[at..at + 4].try_into().unwrap());
    for k in 0..n {
        times[k] = rd(o);
        for (dst, off, width) in [(&mut head.pos, 8, 3), (&mut head.rot, 20, 4), (&mut left.pos, 36, 3), (&mut left.rot, 48, 4), (&mut right.pos, 64, 3), (&mut right.rot, 76, 4)] {
            for c in 0..width {
                dst[k * width + c] = rd(o + off + c * 4);
            }
        }
        o += 92;
    }
    if byte!() != 2 {
        bail!("Missing note events");
    }
    let ne = i32_!();
    if !(0..=1_000_000).contains(&ne) {
        bail!("Invalid event count");
    }
    let mut events = Vec::with_capacity(ne as usize);
    for _ in 0..ne {
        let id = i32_!();
        let t = f32_!() as f64;
        let spawn = f32_!() as f64;
        let kind = i32_!();
        let mut cut = vec![];
        if kind == 0 || kind == 1 {
            need(o, 72)?;
            cut = bytes[o..o + 72].to_vec();
            o += 72;
        }
        events.push(Event { id, t, spawn, kind, cut, points: 0, cumulative: 0, combo: 0, mult: 1 });
    }
    let (sum, hit, miss, max_combo) = score_events(&mut events);
    let replay = Replay { times, left, right, head, wall_stats: WallStats::default(), events, score: if score != 0 { score as i64 } else { sum }, hit, miss, max_combo };
    Ok(External { replay, info })
}

/// cyberAttachMapZip: SHA-1 over Info.dat followed by every listed difficulty file.
pub fn map_hash(zip: &[u8]) -> Result<String> {
    let z = crate::storage::zip_reader::ZipReader::new(zip, crate::storage::zip_reader::Limits::default())?;
    let info_bytes = z.get("Info.dat")?.ok_or_else(|| anyhow!("Info.dat missing from ZIP"))?;
    let info: Value = serde_json::from_slice(&info_bytes)?;
    let mut all = info_bytes.clone();
    let (sets, legacy) = match info.get("_difficultyBeatmapSets").filter(|v| !v.is_null()) {
        Some(v) => (v.as_array().cloned().unwrap_or_default(), true),
        None => (info.get("difficultyBeatmapSets").and_then(|v| v.as_array()).cloned().unwrap_or_default(), false),
    };
    for s in &sets {
        let diffs = s.get(if legacy { "_difficultyBeatmaps" } else { "difficultyBeatmaps" }).and_then(|v| v.as_array()).cloned().unwrap_or_default();
        for d in diffs {
            let file = if legacy {
                d.get("_beatmapFilename").and_then(|v| v.as_str()).map(str::to_string)
            } else {
                d.get("beatmapDataFilename").and_then(|v| v.as_str()).filter(|s| !s.is_empty()).or_else(|| d.get("beatmapFilename").and_then(|v| v.as_str())).map(str::to_string)
            };
            let Some(file) = file.filter(|f| !f.is_empty()) else { continue };
            if let Some(bytes) = z.get(&file)? {
                all.extend_from_slice(&bytes);
            }
        }
    }
    Ok(sha1_hex_upper(&all))
}

pub fn sha1_hex_upper(data: &[u8]) -> String {
    let mut h: [u32; 5] = [0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476, 0xc3d2e1f0];
    let mut msg = data.to_vec();
    let bits = (data.len() as u64).wrapping_mul(8);
    msg.push(0x80);
    while msg.len() % 64 != 56 {
        msg.push(0);
    }
    msg.extend_from_slice(&bits.to_be_bytes());
    let mut w = [0u32; 80];
    for chunk in msg.chunks(64) {
        for i in 0..16 {
            w[i] = u32::from_be_bytes(chunk[i * 4..i * 4 + 4].try_into().unwrap());
        }
        for i in 16..80 {
            w[i] = (w[i - 3] ^ w[i - 8] ^ w[i - 14] ^ w[i - 16]).rotate_left(1);
        }
        let [mut a, mut b, mut c, mut d, mut e] = h;
        for (i, wi) in w.iter().enumerate() {
            let (f, k) = match i {
                0..=19 => ((b & c) | (!b & d), 0x5a827999),
                20..=39 => (b ^ c ^ d, 0x6ed9eba1),
                40..=59 => ((b & c) | (b & d) | (c & d), 0x8f1bbcdc),
                _ => (b ^ c ^ d, 0xca62c1d6u32),
            };
            let t = a.rotate_left(5).wrapping_add(f).wrapping_add(e).wrapping_add(k).wrapping_add(*wi);
            e = d;
            d = c;
            c = b.rotate_left(30);
            b = a;
            a = t;
        }
        for (x, y) in h.iter_mut().zip([a, b, c, d, e]) {
            *x = x.wrapping_add(y);
        }
    }
    h.iter().map(|v| format!("{v:08X}")).collect()
}

/// `${songName}_${difficulty}_CyberStyle_SIMULATED.bsor`
pub fn export_name(info: &Value, difficulty: &str) -> String {
    let song = first_text(info, &["_songName", "songName"], "Map");
    let clean: String = song.chars().filter(|c| c.is_ascii_alphanumeric() || matches!(c, '_' | ' ' | '.' | '-')).take(56).collect();
    format!("{}_{}_CyberStyle_SIMULATED.bsor", if clean.is_empty() { "Map" } else { &clean }, difficulty)
}

#[cfg(test)]
mod tests {
    #[test]
    fn sha1_vectors() {
        assert_eq!(super::sha1_hex_upper(b"abc"), "A9993E364706816ABA3E25717850C26C9CD0D89D");
        assert_eq!(super::sha1_hex_upper(b""), "DA39A3EE5E6B4B0D3255BFEF95601890AFD80709");
    }
}
