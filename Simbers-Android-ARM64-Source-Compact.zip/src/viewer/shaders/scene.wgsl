// WGSL port of the WebGL 1 gameplay programs:
//   vs_main/fs_main  - buffered geometry (controls/webgl-init.js init3D)
//   vs_note/fs_note  - instanced ArcViewer notes + planar floor mirror pass
//                      (controls/webgl-init.js initNoteInstancing)
//   vs_wall/fs_wall  - instanced translucent walls (controls/webgl-geometry.js)
// The math is kept 1:1. Only two things differ from GL: clip-space depth is
// remapped from [-w, w] to wgpu's [0, w] (same ordering and clipping), and
// the fragment position has a top-left origin, which the mirror pass undoes.

struct Globals {
  // tan(fov/2), aspect, near, far
  proj: vec4<f32>,
  // eye x, eye y, eye z (map Z), yaw
  eye: vec4<f32>,
  // pitch, roll, studio matcap strength, shine time (song seconds)
  cam: vec4<f32>,
  // uEnvLeft rgb, mirror pass flag
  env_left: vec4<f32>,
  // uEnvRight rgb, mirror opacity
  env_right: vec4<f32>,
  // uEnvPulse xy, mirror viewport (drawing buffer px)
  env_pulse: vec4<f32>,
};

@group(0) @binding(0) var<uniform> g: Globals;
@group(0) @binding(1) var matcap_tex: texture_2d<f32>;
@group(0) @binding(2) var matcap_samp: sampler;

struct View {
  v: vec3<f32>,
  rel: vec3<f32>,
};

fn to_view(p: vec3<f32>) -> View {
  let rel = vec3<f32>(p.x - g.eye.x, p.y - g.eye.y, p.z - g.eye.z);
  let cy = cos(g.eye.w);
  let sy = sin(g.eye.w);
  let vx = cy * rel.x - sy * rel.z;
  let forward = sy * rel.x + cy * rel.z;
  let cp = cos(g.cam.x);
  let sp = sin(g.cam.x);
  let vy0 = cp * rel.y - sp * forward;
  let vz = sp * rel.y + cp * forward;
  let cr = cos(g.cam.y);
  let sr = sin(g.cam.y);
  let rolled_x = cr * vx + sr * vy0;
  let vy = -sr * vx + cr * vy0;
  return View(vec3<f32>(rolled_x, vy, vz), rel);
}

fn clip_of(v: vec3<f32>) -> vec4<f32> {
  let z = max(v.z, 0.055);
  let n = g.proj.z;
  let f = g.proj.w;
  let a = (f + n) / (f - n);
  let b = (-2.0 * f * n) / (f - n);
  let cz = a * z + b;
  return vec4<f32>(v.x / (g.proj.y * g.proj.x), v.y / g.proj.x, (cz + z) * 0.5, z);
}

fn shade(normal: vec3<f32>, view_ray: vec3<f32>, surface: vec3<f32>, color: vec4<f32>) -> vec3<f32> {
  let N = normalize(normal);
  let L = normalize(vec3<f32>(-0.42, 0.72, -1.0));
  let V = vec3<f32>(0.0, 0.0, -1.0);
  let diffuse = max(dot(N, L), 0.0);
  let H = normalize(L + V);
  let front = max(dot(N, V), 0.0);

  // color.a > 1 is an internal opaque-material tag. 1.10 = note, 1.20 = bomb.
  let reflective = step(1.05, color.a);
  let bomb = step(1.18, color.a);
  var rgb: vec3<f32>;

  if (reflective > 0.5) {
    let ndv = clamp(abs(dot(N, V)), 0.0, 1.0);
    let f = 1.0 - ndv;
    let fres = f * f;
    let side_mix = clamp(0.5 + 0.5 * N.x, 0.0, 1.0);

    let lp = 0.18 + 0.52 * clamp(g.env_pulse.x, 0.0, 1.7);
    let rp = 0.18 + 0.52 * clamp(g.env_pulse.y, 0.0, 1.7);
    var env = mix(g.env_left.rgb * lp, g.env_right.rgb * rp, side_mix);
    env += vec3<f32>(0.050, 0.080, 0.130) * (1.0 + bomb * 0.18);
    env += vec3<f32>(0.035, 0.055, 0.075) * max(N.y, 0.0);

    var h0 = max(abs(dot(N, H)), 0.0);
    h0 = h0 * h0;
    var sr = max(dot(N, vec3<f32>(0.69, 0.27, -0.67)), 0.0);
    sr = sr * sr;
    var sl = max(dot(N, vec3<f32>(-0.69, 0.27, -0.67)), 0.0);
    sl = sl * sl;
    let colored_spec = g.env_right.rgb * sr * (0.035 + 0.13 * g.env_pulse.y) + g.env_left.rgb * sl * (0.035 + 0.13 * g.env_pulse.x);

    let metallic = mix(0.43, 0.60, bomb);
    let diffuse_base = color.rgb * (0.48 + 0.36 * diffuse) * (1.0 - 0.34 * metallic);
    let reflection = env * (0.20 + 0.48 * fres) + colored_spec;
    let highlight = mix(vec3<f32>(0.040), color.rgb * 0.30, metallic) * h0 * (0.34 + 0.28 * fres);

    var rim = 1.0 - ndv;
    rim = rim * rim;
    rgb = diffuse_base + reflection + highlight;
    let strength = g.cam.z;
    if (strength > 0.01) {
      let vr = normalize(view_ray);
      let reflected = reflect(-vr, N);
      let mat_uv = clamp(vec2<f32>(0.5) + reflected.xy * 0.46, vec2<f32>(0.005), vec2<f32>(0.995));
      // No mipmaps (GL LINEAR min filter): level 0 is the exact equivalent and
      // is legal in non-uniform control flow.
      let studio = textureSampleLevel(matcap_tex, matcap_samp, mat_uv, 0.0).rgb;
      let cinematic = smoothstep(0.70, 2.60, strength);
      let chrome = strength * (0.15 + 0.38 * rim);
      rgb += studio * mix(color.rgb, vec3<f32>(1.0), 0.48) * (0.18 + 0.62 * cinematic) * chrome;

      let front_face = smoothstep(0.62, 0.93, abs(N.z));
      let gloss = surface.x * 0.83 + surface.y * 0.34;
      let sweep = 0.18 * sin(g.cam.w * 0.58);
      let long_band = 1.0 - smoothstep(0.012, 0.16, abs(gloss - 0.06 - sweep));
      let short_band = 1.0 - smoothstep(0.012, 0.065, abs(gloss + 0.36 - sweep * 0.5));
      let glint = front_face * (0.66 * long_band + 0.32 * short_band);
      let bright = mix(color.rgb, vec3<f32>(0.93, 0.97, 1.0), 0.42);
      rgb += bright * glint * (0.10 + 0.38 * cinematic);

      let face_edge = max(abs(surface.x), abs(surface.y));
      let edge_line = smoothstep(0.32, 0.47, face_edge) * front_face;
      rgb += mix(color.rgb, vec3<f32>(1.0), 0.48) * edge_line * (0.02 + 0.23 * cinematic);
      rgb += mix(color.rgb, vec3<f32>(0.63, 0.84, 1.0), 0.48) * rim * (0.04 + 0.20 * cinematic);
    }

    if (bomb > 0.5) {
      rgb *= 0.76;
      rgb += env * (0.16 + 0.22 * fres);
    }
  } else {
    let s = max(dot(N, H), 0.0);
    let s2 = s * s;
    let s4 = s2 * s2;
    let s8 = s4 * s4;
    let spec = s8 * s8 * s2;
    let light = 0.50 + 0.48 * diffuse + 0.10 * front;
    rgb = color.rgb * light + vec3<f32>(spec * 0.20);
  }
  return rgb;
}

// ---------------------------------------------------------------- buffered

struct MainIn {
  @location(0) pos: vec3<f32>,
  @location(1) normal: vec3<f32>,
  @location(2) color: vec4<f32>,
};

struct MainOut {
  @builtin(position) clip: vec4<f32>,
  @location(0) normal: vec3<f32>,
  @location(1) view_ray: vec3<f32>,
  @location(2) surface: vec3<f32>,
  @location(3) color: vec4<f32>,
};

@vertex
fn vs_main(in: MainIn) -> MainOut {
  let v = to_view(in.pos);
  var out: MainOut;
  out.clip = clip_of(v.v);
  out.normal = in.normal;
  out.view_ray = normalize(vec3<f32>(-v.rel.x, -v.v.y, -v.v.z));
  out.surface = in.pos;
  out.color = in.color;
  return out;
}

@fragment
fn fs_main(in: MainOut) -> @location(0) vec4<f32> {
  let rgb = shade(in.normal, in.view_ray, in.surface, in.color);
  return vec4<f32>(rgb, min(in.color.a, 1.0));
}

// ---------------------------------------------------------------- notes

struct NoteIn {
  @location(0) local_pos: vec3<f32>,
  @location(1) local_normal: vec3<f32>,
  @location(2) translate_scale: vec4<f32>,
  @location(3) rotation: vec2<f32>,
  @location(4) tint: vec4<f32>,
};

struct NoteOut {
  @builtin(position) clip: vec4<f32>,
  @location(0) normal: vec3<f32>,
  @location(1) view_ray: vec3<f32>,
  @location(2) surface: vec3<f32>,
  @location(3) color: vec4<f32>,
  @location(4) mirrored_y: f32,
};

@vertex
fn vs_note(in: NoteIn) -> NoteOut {
  let zr = in.rotation.x;
  let yr = in.rotation.y;
  let cz = cos(zr);
  let sz = sin(zr);
  let cy = cos(yr);
  let sy = sin(yr);
  let q = in.local_pos * in.translate_scale.w;
  let world = vec3<f32>(q.x * cz - q.y * sz, q.x * sz + q.y * cz, q.z) + in.translate_scale.xyz;
  var rotated = vec3<f32>(world.x * cy + world.z * sy, world.y, world.z * cy - world.x * sy);
  var out: NoteOut;
  out.mirrored_y = abs(rotated.y);
  let mirror = g.env_left.w;
  if (mirror > 0.5) {
    rotated.y = -rotated.y;
  }
  let n = vec3<f32>(in.local_normal.x * cz - in.local_normal.y * sz, in.local_normal.x * sz + in.local_normal.y * cz, in.local_normal.z);
  out.normal = vec3<f32>(n.x * cy + n.z * sy, n.y * (1.0 - 2.0 * step(0.5, mirror)), n.z * cy - n.x * sy);
  let v = to_view(rotated);
  out.clip = clip_of(v.v);
  out.view_ray = normalize(vec3<f32>(-v.rel.x, -v.v.y, -v.v.z));
  out.surface = in.local_pos;
  out.color = in.tint;
  return out;
}

@fragment
fn fs_note(in: NoteOut) -> @location(0) vec4<f32> {
  let rgb = shade(in.normal, in.view_ray, in.surface, in.color);
  if (g.env_left.w > 0.5) {
    // Real mirrored note geometry, clipped to where the camera ray meets the
    // environment floor (Y=0, X=-3..3, Z=6..306). gl_FragCoord is
    // bottom-left based; @builtin(position) is top-left based.
    let vp = max(g.env_pulse.zw, vec2<f32>(1.0));
    let ndc = vec2<f32>((in.clip.x / vp.x) * 2.0 - 1.0, 1.0 - (in.clip.y / vp.y) * 2.0);
    let camera_ray = vec3<f32>(ndc.x * g.proj.y * g.proj.x, ndc.y * g.proj.x, 1.0);
    let cr = cos(g.cam.y);
    let sr = sin(g.cam.y);
    let rx = cr * camera_ray.x - sr * camera_ray.y;
    let py = sr * camera_ray.x + cr * camera_ray.y;
    let cp = cos(g.cam.x);
    let sp = sin(g.cam.x);
    let ry = cp * py + sp * camera_ray.z;
    let forward = -sp * py + cp * camera_ray.z;
    let cy = cos(g.eye.w);
    let sy = sin(g.eye.w);
    let floor_ray = vec3<f32>(cy * rx + sy * forward, ry, -sy * rx + cy * forward);
    if (floor_ray.y >= -0.00001) {
      discard;
    }
    let t = -g.eye.y / floor_ray.y;
    let floor_world = vec3<f32>(g.eye.x, g.eye.y, g.eye.z) + floor_ray * t;
    let near_edge = smoothstep(7.99, 10.30, floor_world.z);
    let far_edge = 1.0 - smoothstep(304.0, 307.99, floor_world.z);
    let side_edge = 1.0 - smoothstep(2.35, 2.995, abs(floor_world.x));
    let fade = 1.0 - smoothstep(0.45, 3.50, in.mirrored_y);
    let alpha = clamp(g.env_right.w * fade * near_edge * far_edge * side_edge, 0.0, 0.88);
    if (alpha < 0.001) {
      discard;
    }
    return vec4<f32>(rgb * 0.68 + in.color.rgb * 0.14, alpha);
  }
  return vec4<f32>(rgb, min(in.color.a, 1.0));
}

// ---------------------------------------------------------------- walls

struct WallIn {
  @location(0) local: vec3<f32>,
  @location(1) tag: vec2<f32>,
  @location(2) wall_min: vec4<f32>,
  @location(3) wall_size: vec4<f32>,
  @location(4) wall_fill: vec3<f32>,
  @location(5) wall_edge: vec3<f32>,
};

struct WallOut {
  @builtin(position) clip: vec4<f32>,
  @location(0) color: vec4<f32>,
};

@vertex
fn vs_wall(in: WallIn) -> WallOut {
  var xyz = in.wall_min.xyz + in.local * in.wall_size.xyz;
  let c = cos(in.wall_size.w);
  let s = sin(in.wall_size.w);
  xyz = vec3<f32>(xyz.x * c + xyz.z * s, xyz.y, xyz.z * c - xyz.x * s);
  let v = to_view(xyz);
  var out: WallOut;
  out.clip = clip_of(v.v);
  let edge = step(0.5, in.tag.y);
  let color = mix(in.wall_fill, in.wall_edge, edge);
  out.color = vec4<f32>(color * (0.87 + 0.13 * edge), in.tag.x * in.wall_min.w);
  return out;
}

@fragment
fn fs_wall(in: WallOut) -> @location(0) vec4<f32> {
  return in.color;
}
