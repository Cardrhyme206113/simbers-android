// WGSL port of the unified DefaultEnvironment program
// (js/environment-renderer.js). Kept 1:1 except:
//  * clip-space depth is remapped from GL [-w, w] to wgpu [0, w];
//  * per-vertex ring angles come from two small uniform tables instead of a
//    re-uploaded per-vertex buffer (same f32 values, same staleness rule);
//  * pow(x, 2.0) with a possibly negative base is written as x * x. Chrome on
//    Windows (ANGLE -> HLSL) compiles that pow into a multiply, which is the
//    rendering this port matches; a literal exp2/log2 pow would turn the left
//    floor lane into NaN.

struct EnvU {
  vp: mat4x4<f32>,
  // camera position, glow size
  cam: vec4<f32>,
  // view direction, ring zoom
  view_dir: vec4<f32>,
  // scene mode, ring mode, mirror count, unused
  modes: vec4<i32>,
  // bright, rings, glow pass, glow strength
  p0: vec4<f32>,
  // scene amount, ring amount, quality fx, env time
  p1: vec4<f32>,
  // preview idle, unused...
  p2: vec4<f32>,
  mirror_pos: array<vec4<f32>, 8>,
  mirror_ext: array<vec4<f32>, 8>,
  mirror_col: array<vec4<f32>, 8>,
  // cos, sin, unused, unused
  mirror_rot: array<vec4<f32>, 8>,
  small_angles: array<vec4<f32>, 8>,
  big_angles: array<vec4<f32>, 16>,
};

@group(0) @binding(0) var<uniform> u: EnvU;

struct EnvIn {
  @location(0) p: vec3<f32>,
  @location(1) n: vec4<f32>,
  @location(2) ksri: vec4<i32>,
};

struct EnvOut {
  @builtin(position) clip: vec4<f32>,
  @location(0) n: vec3<f32>,
  @location(1) p: vec3<f32>,
  @location(2) k: f32,
  @location(3) s: f32,
  @location(4) r: f32,
  @location(5) d: f32,
  @location(6) c: f32,
};

fn ring_angle(r: i32, id: i32) -> f32 {
  if (r == 1) {
    if (id >= 30) {
      return 0.0;
    }
    return u.small_angles[id / 4][id % 4];
  }
  if (id >= 59) {
    return 0.0;
  }
  return u.big_angles[id / 4][id % 4];
}

@vertex
fn vs_env(in: EnvIn) -> EnvOut {
  var p = in.p;
  var n = in.n.xyz;
  let k = f32(in.ksri.x);
  let s = f32(in.ksri.y);
  let r = f32(in.ksri.z);
  let ri = f32(in.ksri.w);
  if (r > 0.5) {
    let a = ring_angle(in.ksri.z, in.ksri.w);
    let c = cos(a);
    let sn = sin(a);
    let offset = vec2<f32>(in.p.x, in.p.y - 3.0);
    p = vec3<f32>(offset.x * c - offset.y * sn, 3.0 + offset.x * sn + offset.y * c, p.z);
    n = vec3<f32>(in.n.x * c - in.n.y * sn, in.n.x * sn + in.n.y * c, n.z);
    if (r < 1.5) {
      p.z += ri * (u.view_dir.w - 5.0);
    }
  }
  let lit = step(1.5, k) * (1.0 - step(3.5, k));
  p += normalize(n) * u.cam.w * lit;
  var out: EnvOut;
  out.n = n;
  out.p = p;
  out.k = k;
  out.s = s;
  out.r = r;
  out.d = distance(p, u.cam.xyz);
  out.c = select(0.0, 1.0, lit > 0.5 && abs(p.z - 65.0) < 0.72 && abs(p.x) < 3.6 && p.y > 3.2 && p.y < 6.8);
  let clip = u.vp * vec4<f32>(p, 1.0);
  out.clip = vec4<f32>(clip.x, clip.y, (clip.z + clip.w) * 0.5, clip.w);
  return out;
}

fn sdf_box(p: vec3<f32>, h: vec3<f32>) -> f32 {
  let d = abs(p) - h;
  return length(max(d, vec3<f32>(0.0))) + min(max(d.x, max(d.y, d.z)), 0.0);
}

fn seg_dist(p: vec2<f32>, a: vec2<f32>, b: vec2<f32>) -> f32 {
  let v = b - a;
  let t = clamp(dot(p - a, v) / max(dot(v, v), 0.0001), 0.0, 1.0);
  return length(p - (a + t * v));
}

fn col(m: i32, vs: f32) -> vec3<f32> {
  if (m == 4) {
    return vec3<f32>(0.0);
  }
  if (m == 1) {
    return vec3<f32>(0.045, 0.39, 1.0);
  }
  if (m == 2) {
    return vec3<f32>(1.0, 0.035, 0.055);
  }
  if (m == 3) {
    return vec3<f32>(0.82, 0.92, 1.0);
  }
  if (vs < -0.1) {
    return vec3<f32>(1.0, 0.03, 0.05);
  }
  if (vs > 0.1) {
    return vec3<f32>(0.025, 0.32, 1.0);
  }
  return vec3<f32>(0.13, 0.46, 1.0);
}

@fragment
fn fs_env(in: EnvOut) -> @location(0) vec4<f32> {
  let bright = u.p0.x;
  let rings = u.p0.y;
  let glow_pass = u.p0.z;
  let glow_strength = u.p0.w;
  let scene_amt = u.p1.x;
  let ring_amt = u.p1.y;
  let quality_fx = u.p1.z;
  let preview_idle = u.p2.x;
  let scene_mode = u.modes.x;
  let ring_mode = u.modes.y;
  let mirror_count = u.modes.z;

  if (in.r > 0.5 && rings < 0.5) {
    discard;
  }
  let lit = step(1.5, in.k) * (1.0 - step(3.5, in.k));
  let is_ring = step(0.5, in.r);
  var C: vec3<f32>;
  if (in.c > 0.5) {
    C = vec3<f32>(1.0, 0.025, 0.045);
  } else if (is_ring > 0.5) {
    C = col(ring_mode, in.s);
  } else {
    C = col(scene_mode, in.s);
  }
  var amt: f32;
  if (in.c > 0.5) {
    amt = 0.92;
  } else if (is_ring > 0.5) {
    amt = ring_amt;
  } else {
    amt = scene_amt;
  }
  if (glow_pass > 0.5) {
    let a = max(amt, 0.24 * preview_idle);
    if (lit < 0.5 || a < 0.012) {
      return vec4<f32>(0.0, 0.0, 0.0, 1.0);
    }
    let gc = mix(C, mix(vec3<f32>(0.12, 0.65, 1.0), vec3<f32>(0.70, 0.20, 0.95), clamp(0.5 + in.s * 0.30, 0.0, 1.0)), preview_idle);
    let gg = (0.35 + 1.35 * min(a, 2.25)) * glow_strength;
    return vec4<f32>(min(gc * gg, vec3<f32>(1.0)), 1.0);
  }

  let nn = normalize(in.n);
  let V = normalize(-u.view_dir.xyz);
  let L = normalize(vec3<f32>(-0.24, 0.80, -0.42));
  let nd = 0.34 + 0.66 * abs(dot(nn, L));
  var base: vec3<f32>;
  if (in.k < 0.5) {
    base = vec3<f32>(0.205, 0.245, 0.305) * nd;
  } else if (in.k < 1.5) {
    base = vec3<f32>(0.115, 0.145, 0.19) * nd;
  } else if (in.k < 3.5) {
    let idle = preview_idle;
    var idle_color = mix(vec3<f32>(0.09, 0.59, 0.94), vec3<f32>(0.66, 0.18, 0.92), clamp(0.5 + in.s * 0.34, 0.0, 1.0));
    idle_color = mix(idle_color, vec3<f32>(1.0, 0.43, 0.12), 0.09);
    base = C * (0.07 + 1.58 * amt) + idle * idle_color * (0.28 * clamp((quality_fx - 0.5) / 2.3, 0.0, 1.0));
  } else {
    base = vec3<f32>(0.145, 0.18, 0.235) * nd;
  }
  if (lit < 0.5) {
    let vis = select(0.30, 1.0, bright > 0.5);
    base *= vis;
    let floor_col = select(vec3<f32>(0.018, 0.024, 0.035), vec3<f32>(0.058, 0.072, 0.096), bright > 0.5);
    base = max(base, floor_col);
    let nv = clamp(abs(dot(nn, V)), 0.0, 1.0);
    let fres0 = (1.0 - nv) * (1.0 - nv) * (1.0 - nv);
    let H = normalize(L + V);
    let spec = pow(max(abs(dot(nn, H)), 0.0), 24.0);
    let side = max(0.0, 1.0 - abs(nn.x));
    var env = vec3<f32>(0.018, 0.028, 0.052) + vec3<f32>(0.030, 0.050, 0.095) * fres0;
    env += C * (0.012 + 0.035 * fres0) * min(amt, 1.8);
    base += env * (select(0.34, 0.55, bright > 0.5) + 0.55 * fres0);
    base += vec3<f32>(0.20, 0.25, 0.34) * spec * select(0.13, 0.22, bright > 0.5);
    base += vec3<f32>(0.018, 0.025, 0.045) * side;
    if (quality_fx > 0.5) {
      let q = clamp((quality_fx - 0.5) / 2.3, 0.0, 1.0);
      let lit_amount = clamp(max(scene_amt, ring_amt), 0.0, 1.8);
      let idle = preview_idle;
      let cool = vec3<f32>(0.045, 0.55, 0.92);
      let violet = vec3<f32>(0.53, 0.16, 0.96);
      let warm = vec3<f32>(1.0, 0.26, 0.36);
      let smf = f32(scene_mode);
      let rmf = f32(ring_mode);
      var light_a = mix(cool, warm, step(1.5, smf) * (1.0 - step(2.5, smf)));
      var light_b = mix(violet, vec3<f32>(0.10, 0.44, 1.0), step(0.5, rmf) * (1.0 - step(1.5, rmf)));
      if (scene_mode == 1) {
        light_a = vec3<f32>(0.07, 0.42, 1.0);
        light_b = vec3<f32>(0.39, 0.23, 0.91);
      }
      if (scene_mode == 2) {
        light_a = vec3<f32>(1.0, 0.13, 0.25);
        light_b = vec3<f32>(0.90, 0.21, 0.52);
      }
      if (scene_mode == 3) {
        light_a = vec3<f32>(0.55, 0.80, 1.0);
        light_b = vec3<f32>(0.54, 0.37, 0.83);
      }
      if (scene_mode == 0) {
        light_a = vec3<f32>(1.0, 0.13, 0.27);
        light_b = vec3<f32>(0.08, 0.48, 1.0);
      }
      if (idle > 0.5) {
        light_a = cool;
        light_b = violet;
      }
      let e = 0.24 * idle + 0.18 + min(1.5, lit_amount) * 0.33;
      let ground = step(0.58, abs(nn.y)) * (1.0 - smoothstep(0.18, 1.25, abs(in.p.y))) * (1.0 - step(1.5, in.k));
      let lane_blend = clamp(0.5 + 0.23 * in.p.x, 0.0, 1.0);
      var reflected = mix(light_a, light_b, lane_blend);
      let gold = 0.08 * idle;
      reflected = mix(reflected, vec3<f32>(1.0, 0.48, 0.10), gold);
      if (ground > 0.01) {
        let l1 = in.p.x + 1.75;
        let l2 = in.p.x - 1.75;
        let lane1 = 1.0 / (1.0 + (l1 * l1) * 2.6);
        let lane2 = 1.0 / (1.0 + (l2 * l2) * 2.6);
        let d = 1.0 / (1.0 + max(0.0, in.p.z - 10.0) * 0.012);
        let ff = 1.0 - clamp(abs(dot(nn, V)), 0.0, 1.0);
        let floor_fres = ff * ff;
        var pool = light_a * lane1 + light_b * lane2;
        pool = mix(pool, reflected * 0.72, 0.32);
        base += pool * ground * d * e * (0.22 + 0.55 * q) * (0.78 + 0.22 * floor_fres);
        base += vec3<f32>(0.72, 0.88, 1.0) * ground * d * q * (0.026 + 0.09 * floor_fres) / (1.0 + in.p.x * in.p.x * 0.9);
      }
      let metal = (1.0 - ground) * (1.0 - step(1.5, in.k));
      let mf = 1.0 - clamp(abs(dot(nn, V)), 0.0, 1.0);
      let fres = mf * mf;
      let metal_spec = pow(max(abs(dot(nn, normalize(L + V))), 0.0), 10.0);
      let studio = vec3<f32>(0.35, 0.49, 0.73) * (0.055 + 0.12 * q * metal_spec);
      base += metal * (reflected * e * (0.11 + 0.32 * q) * fres + studio * (0.5 + 0.5 * fres));
    }
  }
  // Blurred object reflections, floor only.
  if (quality_fx > 1.18 && mirror_count > 0 && in.k < 1.5 && abs(in.p.y) < 0.30 && abs(nn.y) > 0.80) {
    let incident = normalize(in.p - u.cam.xyz);
    let bounce = normalize(reflect(incident, nn));
    let gloss = pow(1.0 - clamp(abs(dot(nn, incident)), 0.0, 1.0), 1.35);
    let roughness = mix(0.496, 0.368, clamp((quality_fx - 1.3) / 1.5, 0.0, 1.0));
    let strength = mix(0.25, 0.64, clamp((quality_fx - 1.3) / 1.5, 0.0, 1.0));
    var near_color = vec3<f32>(0.0);
    var next_color = vec3<f32>(0.0);
    var near_alpha = 0.0;
    var next_alpha = 0.0;
    var near_depth = 100000.0;
    var next_depth = 100000.0;
    var nearby_bounce = vec3<f32>(0.0);
    for (var ri = 0; ri < 8; ri++) {
      if (ri >= mirror_count) {
        break;
      }
      let center = u.mirror_pos[ri].xyz;
      let typ = u.mirror_pos[ri].w;
      let half_dim = u.mirror_ext[ri].xyz;
      let delta = center - in.p;
      let reflection_range = 1.0 - smoothstep(88.0, 110.0, abs(delta.z));
      if (reflection_range < 0.001) {
        continue;
      }
      let proximity = (1.0 - smoothstep(2.5, 15.0, abs(delta.z))) / (1.0 + 0.14 * delta.x * delta.x + 0.12 * delta.y * delta.y);
      nearby_bounce += u.mirror_col[ri].rgb * proximity * u.mirror_col[ri].a * reflection_range;
      let raw_t = dot(delta, bounce);
      if (raw_t < -6.0 || raw_t > 145.0) {
        continue;
      }
      let forward_fade = smoothstep(-6.0, 2.0, raw_t);
      let t = max(0.0, raw_t);
      let hit = in.p + bounce * t - center;
      let cs = u.mirror_rot[ri].x;
      let sn = u.mirror_rot[ri].y;
      let local_hit = vec3<f32>(cs * hit.x + sn * hit.y, -sn * hit.x + cs * hit.y, hit.z);
      var d: f32;
      if (typ > 0.5 && typ < 1.5) {
        d = length(hit) - half_dim.x;
      } else {
        d = sdf_box(local_hit, half_dim);
      }
      var alpha = 1.0 - smoothstep(-roughness * 0.28, roughness * 1.85, d);
      alpha = alpha * alpha * (3.0 - 2.0 * alpha);
      if (alpha <= 0.001) {
        continue;
      }
      let fade = forward_fade * (1.0 - smoothstep(28.0, 145.0, t));
      var tint = u.mirror_col[ri].rgb;
      var marker_ink = 0.0;
      if (typ < 0.5 || (typ > 2.5 && typ < 3.5)) {
        let face_t = t + (-half_dim.z - hit.z) / max(bounce.z, 0.001);
        if (bounce.z > 0.015 && face_t > 0.0 && face_t < 145.0) {
          let face_world = hit.xy + bounce.xy * (face_t - t);
          let local_face = vec2<f32>(cs * face_world.x + sn * face_world.y, -sn * face_world.x + cs * face_world.y);
          let uv = local_face / max(half_dim.xy, vec2<f32>(0.001));
          let face_mask = 1.0 - smoothstep(0.62, 1.30, max(abs(uv.x), abs(uv.y)));
          if (typ < 0.5) {
            let tip = vec2<f32>(0.0, -0.83);
            let stroke = min(seg_dist(uv, vec2<f32>(-0.56, -0.67), tip), seg_dist(uv, vec2<f32>(0.56, -0.67), tip));
            let marker_soft = 1.0 - smoothstep(0.015, 0.52, stroke);
            marker_ink = marker_soft * 0.55 * face_mask;
          } else {
            let ring_dist = abs(length(uv) - 0.30);
            let marker_soft = 1.0 - smoothstep(0.015, 0.50, ring_dist);
            marker_ink = marker_soft * 0.55 * face_mask;
          }
          tint = mix(tint, vec3<f32>(0.96, 0.98, 1.0), marker_ink * 0.70);
        }
      }
      let a = alpha * fade * u.mirror_col[ri].a * reflection_range;
      if (a < 0.025) {
        continue;
      }
      let depth = t - min(half_dim.z, 1.0) * 0.30 + max(d, 0.0) * 0.55 + (1.0 - alpha) * 0.85;
      let candidate = tint * (0.58 + 0.42 * gloss) * (1.0 + marker_ink * 0.22);
      if (depth < near_depth) {
        next_depth = near_depth;
        next_color = near_color;
        next_alpha = near_alpha;
        near_depth = depth;
        near_color = candidate;
        near_alpha = a;
      } else if (depth < next_depth) {
        next_depth = depth;
        next_color = candidate;
        next_alpha = a;
      }
    }
    let surface = select(1.0, 0.22, lit > 0.5);
    let overlap = 1.0 - smoothstep(0.0, 1.8, next_depth - near_depth);
    let next_weight = overlap * next_alpha / max(0.0001, near_alpha + next_alpha);
    let mirrored_light = mix(near_color, next_color, next_weight);
    let mirror_amount = mix(near_alpha, next_alpha, next_weight);
    base += mirrored_light * mirror_amount * clamp(mirror_amount, 0.0, 1.0) * strength * (0.64 + 0.36 * gloss) * surface;
    let side_spec = clamp(0.15 + 0.7 * abs(nn.x) + 0.25 * abs(nn.z), 0.0, 1.0);
    base += min(nearby_bounce, vec3<f32>(1.4)) * side_spec * surface * (0.035 + 0.095 * strength);
  }
  let fog = 1.0 - exp(-in.d * select(0.0062, 0.0025, bright > 0.5));
  let fogc = vec3<f32>(0.002, 0.008, 0.022) + C * (0.010 + 0.022 * min(amt, 1.5));
  let fog_amt = clamp(fog * select(0.82, 0.34, bright > 0.5), 0.0, 0.90);
  base = mix(base, fogc, fog_amt);
  base = base / (vec3<f32>(1.0) + base * 0.16);
  return vec4<f32>(base, 1.0);
}
