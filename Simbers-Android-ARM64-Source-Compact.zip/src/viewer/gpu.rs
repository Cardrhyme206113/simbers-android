//! wgpu side of the viewer: the WebGL canvas equivalent. Renders the frame
//! into an offscreen MSAA target (WebGL `antialias: true`, depth24/stencil8),
//! resolves it into an Rgba8Unorm texture registered with egui, and keeps the
//! exact pass order and GL state of flush3DFrame().
//!
//! egui samples Rgba8Unorm textures as gamma-space, premultiplied colors and
//! blends with (One, OneMinusSrcAlpha) - the same way the browser composites a
//! `premultipliedAlpha: true` WebGL canvas - so pixel values pass through 1:1.

use super::env::EnvUniforms;
use super::geom::FrameGeometry;
use super::meshes;
use eframe::egui_wgpu::wgpu;
use wgpu::util::DeviceExt;

pub const COLOR_FORMAT: wgpu::TextureFormat = wgpu::TextureFormat::Rgba8Unorm;
const DEPTH_FORMAT: wgpu::TextureFormat = wgpu::TextureFormat::Depth24PlusStencil8;
const MSAA: u32 = 4;
const GLOBALS_STRIDE: u64 = 256;

/// Uniforms shared by the gameplay programs (scene.wgsl `Globals`).
#[repr(C)]
#[derive(Clone, Copy, Default, Debug)]
pub struct Globals {
    pub proj: [f32; 4],
    pub eye: [f32; 4],
    pub cam: [f32; 4],
    pub env_left: [f32; 4],
    pub env_right: [f32; 4],
    pub env_pulse: [f32; 4],
}

fn bytes_of<T: Copy>(v: &T) -> &[u8] {
    unsafe { std::slice::from_raw_parts((v as *const T).cast::<u8>(), std::mem::size_of::<T>()) }
}

fn f32_bytes(v: &[f32]) -> &[u8] {
    unsafe { std::slice::from_raw_parts(v.as_ptr().cast::<u8>(), std::mem::size_of_val(v)) }
}

fn u32_bytes(v: &[u32]) -> &[u8] {
    unsafe { std::slice::from_raw_parts(v.as_ptr().cast::<u8>(), std::mem::size_of_val(v)) }
}

/// Inputs of one flush3DFrame().
pub struct FrameParams<'a> {
    pub width: u32,
    pub height: u32,
    pub globals: Globals,
    /// floorMirrorStrength() when the planar note reflection pass runs.
    pub mirror_strength: f32,
    /// Unified DefaultEnvironment uniforms; `None` clears to transparent.
    pub env: Option<&'a EnvUniforms>,
}

struct StaticMesh {
    vbuf: wgpu::Buffer,
    ibuf: wgpu::Buffer,
    count: u32,
}

/// Growable GPU buffer for per-frame streams.
struct Stream {
    buf: wgpu::Buffer,
    cap: u64,
    usage: wgpu::BufferUsages,
    label: &'static str,
}

impl Stream {
    fn new(device: &wgpu::Device, label: &'static str, usage: wgpu::BufferUsages) -> Self {
        let cap = 64 * 1024;
        let buf = device.create_buffer(&wgpu::BufferDescriptor { label: Some(label), size: cap, usage: usage | wgpu::BufferUsages::COPY_DST, mapped_at_creation: false });
        Stream { buf, cap, usage, label }
    }
    fn upload(&mut self, device: &wgpu::Device, queue: &wgpu::Queue, data: &[u8]) {
        if data.is_empty() {
            return;
        }
        let need = data.len() as u64;
        if need > self.cap {
            let mut cap = self.cap;
            while cap < need {
                cap *= 2;
            }
            self.buf = device.create_buffer(&wgpu::BufferDescriptor { label: Some(self.label), size: cap, usage: self.usage | wgpu::BufferUsages::COPY_DST, mapped_at_creation: false });
            self.cap = cap;
        }
        queue.write_buffer(&self.buf, 0, data);
    }
}

struct Targets {
    width: u32,
    height: u32,
    msaa_view: wgpu::TextureView,
    resolve_view: wgpu::TextureView,
    depth_view: wgpu::TextureView,
}

pub struct ViewerGpu {
    globals_buf: wgpu::Buffer,
    scene_bg: wgpu::BindGroup,
    env_buf: wgpu::Buffer,
    env_bg: wgpu::BindGroup,
    p_opaque: wgpu::RenderPipeline,
    p_transparent: wgpu::RenderPipeline,
    p_arc: wgpu::RenderPipeline,
    p_occluder: wgpu::RenderPipeline,
    p_note: wgpu::RenderPipeline,
    p_mirror: wgpu::RenderPipeline,
    p_wall: wgpu::RenderPipeline,
    p_wall_depth: wgpu::RenderPipeline,
    p_env: wgpu::RenderPipeline,
    note_meshes: Vec<StaticMesh>,
    wall_mesh: wgpu::Buffer,
    wall_mesh_count: u32,
    env_vbuf: wgpu::Buffer,
    env_ibuf: wgpu::Buffer,
    env_count: u32,
    vertices: Stream,
    instances: Stream,
    walls: Stream,
    targets: Option<Targets>,
    texture_id: Option<eframe::egui::TextureId>,
    scratch: Vec<f32>,
}

fn blend() -> Option<wgpu::BlendState> {
    let c = wgpu::BlendComponent { src_factor: wgpu::BlendFactor::SrcAlpha, dst_factor: wgpu::BlendFactor::OneMinusSrcAlpha, operation: wgpu::BlendOperation::Add };
    Some(wgpu::BlendState { color: c, alpha: c })
}

fn depth(write: bool, compare: wgpu::CompareFunction) -> Option<wgpu::DepthStencilState> {
    Some(wgpu::DepthStencilState { format: DEPTH_FORMAT, depth_write_enabled: Some(write), depth_compare: Some(compare), stencil: wgpu::StencilState::default(), bias: wgpu::DepthBiasState::default() })
}

struct PipeSpec<'a> {
    label: &'static str,
    module: &'a wgpu::ShaderModule,
    layout: &'a wgpu::PipelineLayout,
    vs: &'static str,
    fs: &'static str,
    buffers: &'a [Option<wgpu::VertexBufferLayout<'a>>],
    blend: Option<wgpu::BlendState>,
    write: wgpu::ColorWrites,
    depth: Option<wgpu::DepthStencilState>,
}

fn pipeline(device: &wgpu::Device, s: PipeSpec) -> wgpu::RenderPipeline {
    device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some(s.label),
        layout: Some(s.layout),
        vertex: wgpu::VertexState { module: s.module, entry_point: Some(s.vs), buffers: s.buffers, compilation_options: Default::default() },
        primitive: wgpu::PrimitiveState { topology: wgpu::PrimitiveTopology::TriangleList, cull_mode: None, ..Default::default() },
        depth_stencil: s.depth,
        multisample: wgpu::MultisampleState { count: MSAA, mask: !0, alpha_to_coverage_enabled: false },
        fragment: Some(wgpu::FragmentState { module: s.module, entry_point: Some(s.fs), targets: &[Some(wgpu::ColorTargetState { format: COLOR_FORMAT, blend: s.blend, write_mask: s.write })], compilation_options: Default::default() }),
        multiview_mask: None,
        cache: None,
    })
}

impl ViewerGpu {
    pub fn new(device: &wgpu::Device, queue: &wgpu::Queue, block_meshes: &[meshes::Mesh], bomb_meshes: &[meshes::Mesh]) -> Self {
        let scene_module = device.create_shader_module(wgpu::ShaderModuleDescriptor { label: Some("viewer-scene"), source: wgpu::ShaderSource::Wgsl(include_str!("shaders/scene.wgsl").into()) });
        let env_module = device.create_shader_module(wgpu::ShaderModuleDescriptor { label: Some("viewer-env"), source: wgpu::ShaderSource::Wgsl(include_str!("shaders/env.wgsl").into()) });

        // --- scene bind group (globals with two dynamic slots + matcap)
        let vf = wgpu::ShaderStages::VERTEX | wgpu::ShaderStages::FRAGMENT;
        let scene_bgl = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("viewer-scene-bgl"),
            entries: &[
                wgpu::BindGroupLayoutEntry {
                    binding: 0,
                    visibility: vf,
                    ty: wgpu::BindingType::Buffer { ty: wgpu::BufferBindingType::Uniform, has_dynamic_offset: true, min_binding_size: wgpu::BufferSize::new(std::mem::size_of::<Globals>() as u64) },
                    count: None,
                },
                wgpu::BindGroupLayoutEntry { binding: 1, visibility: wgpu::ShaderStages::FRAGMENT, ty: wgpu::BindingType::Texture { sample_type: wgpu::TextureSampleType::Float { filterable: true }, view_dimension: wgpu::TextureViewDimension::D2, multisampled: false }, count: None },
                wgpu::BindGroupLayoutEntry { binding: 2, visibility: wgpu::ShaderStages::FRAGMENT, ty: wgpu::BindingType::Sampler(wgpu::SamplerBindingType::Filtering), count: None },
            ],
        });
        let globals_buf = device.create_buffer(&wgpu::BufferDescriptor { label: Some("viewer-globals"), size: GLOBALS_STRIDE * 2, usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST, mapped_at_creation: false });
        let matcap = device.create_texture_with_data(
            queue,
            &wgpu::TextureDescriptor {
                label: Some("viewer-matcap"),
                size: wgpu::Extent3d { width: 256, height: 256, depth_or_array_layers: 1 },
                mip_level_count: 1,
                sample_count: 1,
                dimension: wgpu::TextureDimension::D2,
                format: wgpu::TextureFormat::Rgba8Unorm,
                usage: wgpu::TextureUsages::TEXTURE_BINDING | wgpu::TextureUsages::COPY_DST,
                view_formats: &[],
            },
            wgpu::util::TextureDataOrder::LayerMajor,
            &meshes::studio_matcap(),
        );
        let matcap_view = matcap.create_view(&Default::default());
        let sampler = device.create_sampler(&wgpu::SamplerDescriptor {
            label: Some("viewer-matcap"),
            address_mode_u: wgpu::AddressMode::ClampToEdge,
            address_mode_v: wgpu::AddressMode::ClampToEdge,
            mag_filter: wgpu::FilterMode::Linear,
            min_filter: wgpu::FilterMode::Linear,
            ..Default::default()
        });
        let scene_bg = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("viewer-scene-bg"),
            layout: &scene_bgl,
            entries: &[
                wgpu::BindGroupEntry { binding: 0, resource: wgpu::BindingResource::Buffer(wgpu::BufferBinding { buffer: &globals_buf, offset: 0, size: wgpu::BufferSize::new(std::mem::size_of::<Globals>() as u64) }) },
                wgpu::BindGroupEntry { binding: 1, resource: wgpu::BindingResource::TextureView(&matcap_view) },
                wgpu::BindGroupEntry { binding: 2, resource: wgpu::BindingResource::Sampler(&sampler) },
            ],
        });
        let scene_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor { label: Some("viewer-scene-layout"), bind_group_layouts: &[Some(&scene_bgl)], immediate_size: 0 });

        // --- env bind group
        let env_bgl = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("viewer-env-bgl"),
            entries: &[wgpu::BindGroupLayoutEntry { binding: 0, visibility: vf, ty: wgpu::BindingType::Buffer { ty: wgpu::BufferBindingType::Uniform, has_dynamic_offset: false, min_binding_size: None }, count: None }],
        });
        let env_buf = device.create_buffer(&wgpu::BufferDescriptor { label: Some("viewer-env-u"), size: std::mem::size_of::<EnvUniforms>() as u64, usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST, mapped_at_creation: false });
        let env_bg = device.create_bind_group(&wgpu::BindGroupDescriptor { label: Some("viewer-env-bg"), layout: &env_bgl, entries: &[wgpu::BindGroupEntry { binding: 0, resource: env_buf.as_entire_binding() }] });
        let env_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor { label: Some("viewer-env-layout"), bind_group_layouts: &[Some(&env_bgl)], immediate_size: 0 });

        // --- vertex layouts
        let main_vb = [Some(wgpu::VertexBufferLayout { array_stride: 40, step_mode: wgpu::VertexStepMode::Vertex, attributes: &wgpu::vertex_attr_array![0 => Float32x3, 1 => Float32x3, 2 => Float32x4] })];
        let note_vb = [
            Some(wgpu::VertexBufferLayout { array_stride: 24, step_mode: wgpu::VertexStepMode::Vertex, attributes: &wgpu::vertex_attr_array![0 => Float32x3, 1 => Float32x3] }),
            Some(wgpu::VertexBufferLayout { array_stride: 40, step_mode: wgpu::VertexStepMode::Instance, attributes: &wgpu::vertex_attr_array![2 => Float32x4, 3 => Float32x2, 4 => Float32x4] }),
        ];
        let wall_vb = [
            Some(wgpu::VertexBufferLayout { array_stride: 20, step_mode: wgpu::VertexStepMode::Vertex, attributes: &wgpu::vertex_attr_array![0 => Float32x3, 1 => Float32x2] }),
            Some(wgpu::VertexBufferLayout { array_stride: 56, step_mode: wgpu::VertexStepMode::Instance, attributes: &wgpu::vertex_attr_array![2 => Float32x4, 3 => Float32x4, 4 => Float32x3, 5 => Float32x3] }),
        ];
        let env_vb = [Some(wgpu::VertexBufferLayout { array_stride: std::mem::size_of::<meshes::EnvVertex>() as u64, step_mode: wgpu::VertexStepMode::Vertex, attributes: &wgpu::vertex_attr_array![0 => Float32x3, 1 => Snorm8x4, 2 => Sint8x4] })];

        use wgpu::CompareFunction::{Always, Less};
        let all = wgpu::ColorWrites::ALL;
        let none = wgpu::ColorWrites::empty();
        let spec = |label, module, layout, vs, fs, buffers, blend, write, depth| PipeSpec { label, module, layout, vs, fs, buffers, blend, write, depth };
        let p_opaque = pipeline(device, spec("viewer-opaque", &scene_module, &scene_layout, "vs_main", "fs_main", &main_vb[..], blend(), all, depth(true, Less)));
        let p_transparent = pipeline(device, spec("viewer-transparent", &scene_module, &scene_layout, "vs_main", "fs_main", &main_vb[..], blend(), all, depth(false, Less)));
        let p_arc = pipeline(device, spec("viewer-arc", &scene_module, &scene_layout, "vs_main", "fs_main", &main_vb[..], blend(), all, depth(false, Always)));
        let p_occluder = pipeline(device, spec("viewer-occluder", &scene_module, &scene_layout, "vs_main", "fs_main", &main_vb[..], None, none, depth(true, Less)));
        let p_note = pipeline(device, spec("viewer-note", &scene_module, &scene_layout, "vs_note", "fs_note", &note_vb[..], blend(), all, depth(true, Less)));
        let p_mirror = pipeline(device, spec("viewer-mirror", &scene_module, &scene_layout, "vs_note", "fs_note", &note_vb[..], blend(), all, depth(false, Always)));
        let p_wall = pipeline(device, spec("viewer-wall", &scene_module, &scene_layout, "vs_wall", "fs_wall", &wall_vb[..], blend(), all, depth(false, Less)));
        let p_wall_depth = pipeline(device, spec("viewer-wall-depth", &scene_module, &scene_layout, "vs_wall", "fs_wall", &wall_vb[..], None, none, depth(true, Less)));
        let p_env = pipeline(device, spec("viewer-env", &env_module, &env_layout, "vs_env", "fs_env", &env_vb[..], None, all, depth(true, Less)));

        // --- static meshes
        let mut note_meshes = vec![];
        for m in block_meshes.iter().chain(bomb_meshes.iter()) {
            let vc = m.positions.len() / 3;
            let mut v = Vec::with_capacity(vc * 6);
            for i in 0..vc {
                v.extend_from_slice(&m.positions[i * 3..i * 3 + 3]);
                v.extend_from_slice(&m.normals[i * 3..i * 3 + 3]);
            }
            note_meshes.push(StaticMesh {
                vbuf: device.create_buffer_init(&wgpu::util::BufferInitDescriptor { label: Some("viewer-note-mesh"), contents: f32_bytes(&v), usage: wgpu::BufferUsages::VERTEX }),
                ibuf: device.create_buffer_init(&wgpu::util::BufferInitDescriptor { label: Some("viewer-note-idx"), contents: u32_bytes(&m.indices), usage: wgpu::BufferUsages::INDEX }),
                count: m.indices.len() as u32,
            });
        }
        let wall = meshes::wall_unit_mesh();
        let wall_mesh = device.create_buffer_init(&wgpu::util::BufferInitDescriptor { label: Some("viewer-wall-mesh"), contents: f32_bytes(&wall), usage: wgpu::BufferUsages::VERTEX });
        let env = meshes::environment_mesh();
        let env_bytes = unsafe { std::slice::from_raw_parts(env.vertices.as_ptr().cast::<u8>(), std::mem::size_of_val(env.vertices.as_slice())) };
        let env_vbuf = device.create_buffer_init(&wgpu::util::BufferInitDescriptor { label: Some("viewer-env-v"), contents: env_bytes, usage: wgpu::BufferUsages::VERTEX });
        let mut env_idx = env.indices.clone();
        if env_idx.len() % 2 == 1 {
            env_idx.push(0); // COPY_BUFFER_ALIGNMENT padding; never drawn
        }
        let idx_bytes = unsafe { std::slice::from_raw_parts(env_idx.as_ptr().cast::<u8>(), env_idx.len() * 2) };
        let env_ibuf = device.create_buffer_init(&wgpu::util::BufferInitDescriptor { label: Some("viewer-env-i"), contents: idx_bytes, usage: wgpu::BufferUsages::INDEX });

        ViewerGpu {
            globals_buf,
            scene_bg,
            env_buf,
            env_bg,
            p_opaque,
            p_transparent,
            p_arc,
            p_occluder,
            p_note,
            p_mirror,
            p_wall,
            p_wall_depth,
            p_env,
            note_meshes,
            wall_mesh,
            wall_mesh_count: (wall.len() / 5) as u32,
            env_vbuf,
            env_ibuf,
            env_count: meshes::ENV_INDEX_COUNT as u32,
            vertices: Stream::new(device, "viewer-stream-v", wgpu::BufferUsages::VERTEX),
            instances: Stream::new(device, "viewer-stream-inst", wgpu::BufferUsages::VERTEX),
            walls: Stream::new(device, "viewer-stream-wall", wgpu::BufferUsages::VERTEX),
            targets: None,
            texture_id: None,
            scratch: vec![],
        }
    }

    pub fn texture_id(&self) -> Option<eframe::egui::TextureId> {
        self.texture_id
    }

    fn ensure_targets(&mut self, rs: &eframe::egui_wgpu::RenderState, w: u32, h: u32) {
        if self.targets.as_ref().is_some_and(|t| t.width == w && t.height == h) {
            return;
        }
        let device = &rs.device;
        let size = wgpu::Extent3d { width: w, height: h, depth_or_array_layers: 1 };
        let mk = |label, samples, format, usage| {
            device.create_texture(&wgpu::TextureDescriptor { label: Some(label), size, mip_level_count: 1, sample_count: samples, dimension: wgpu::TextureDimension::D2, format, usage, view_formats: &[] }).create_view(&Default::default())
        };
        let msaa_view = mk("viewer-msaa", MSAA, COLOR_FORMAT, wgpu::TextureUsages::RENDER_ATTACHMENT);
        let resolve_view = mk("viewer-color", 1, COLOR_FORMAT, wgpu::TextureUsages::RENDER_ATTACHMENT | wgpu::TextureUsages::TEXTURE_BINDING);
        let depth_view = mk("viewer-depth", MSAA, DEPTH_FORMAT, wgpu::TextureUsages::RENDER_ATTACHMENT);
        let mut renderer = rs.renderer.write();
        match self.texture_id {
            Some(id) => renderer.update_egui_texture_from_wgpu_texture(device, &resolve_view, wgpu::FilterMode::Linear, id),
            None => self.texture_id = Some(renderer.register_native_texture(device, &resolve_view, wgpu::FilterMode::Linear)),
        }
        self.targets = Some(Targets { width: w, height: h, msaa_view, resolve_view, depth_view });
    }

    /// flush3DFrame(): encode and submit the whole frame.
    pub fn render(&mut self, rs: &eframe::egui_wgpu::RenderState, g: &FrameGeometry, p: &FrameParams) {
        let (w, h) = (p.width.max(1), p.height.max(1));
        self.ensure_targets(rs, w, h);
        let (device, queue) = (&rs.device, &rs.queue);

        // Uniform slots: 0 = normal pass, 1 = planar mirror pass.
        let normal = Globals { env_left: [p.globals.env_left[0], p.globals.env_left[1], p.globals.env_left[2], 0.0], env_right: [p.globals.env_right[0], p.globals.env_right[1], p.globals.env_right[2], 0.0], ..p.globals };
        let mirror = Globals { env_left: [normal.env_left[0], normal.env_left[1], normal.env_left[2], 1.0], env_right: [normal.env_right[0], normal.env_right[1], normal.env_right[2], p.mirror_strength], ..normal };
        queue.write_buffer(&self.globals_buf, 0, bytes_of(&normal));
        queue.write_buffer(&self.globals_buf, GLOBALS_STRIDE, bytes_of(&mirror));
        if let Some(env) = p.env {
            queue.write_buffer(&self.env_buf, 0, env.as_bytes());
        }

        // Concatenate the buffered passes into one stream.
        let streams: [&[f32]; 6] = [&g.arc_transparent, &g.opaque, &g.transparent, &g.wall_occluders, &g.replay_opaque, &g.replay_transparent];
        self.scratch.clear();
        let mut ranges = [(0u32, 0u32); 6];
        for (i, s) in streams.iter().enumerate() {
            let first = (self.scratch.len() / 10) as u32;
            self.scratch.extend_from_slice(s);
            ranges[i] = (first, (s.len() / 10) as u32);
        }
        let vbytes = f32_bytes(&self.scratch).to_vec();
        self.vertices.upload(device, queue, &vbytes);
        self.scratch.clear();
        let mut inst_ranges = vec![];
        for grp in g.note_instances.iter().take(self.note_meshes.len()) {
            let first = (self.scratch.len() / 10) as u32;
            self.scratch.extend_from_slice(grp);
            inst_ranges.push((first, (grp.len() / 10) as u32));
        }
        let ibytes = f32_bytes(&self.scratch).to_vec();
        self.instances.upload(device, queue, &ibytes);
        self.walls.upload(device, queue, f32_bytes(&g.wall_instances));
        let wall_count = (g.wall_instances.len() / 14) as u32;
        let any_notes = inst_ranges.iter().any(|r| r.1 > 0);

        let t = self.targets.as_ref().unwrap();
        let mut encoder = device.create_command_encoder(&wgpu::CommandEncoderDescriptor { label: Some("viewer-frame") });
        {
            let clear = if p.env.is_some() { wgpu::Color { r: 0.001, g: 0.002, b: 0.006, a: 1.0 } } else { wgpu::Color::TRANSPARENT };
            let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                label: Some("viewer-frame"),
                color_attachments: &[Some(wgpu::RenderPassColorAttachment { view: &t.msaa_view, resolve_target: Some(&t.resolve_view), ops: wgpu::Operations { load: wgpu::LoadOp::Clear(clear), store: wgpu::StoreOp::Discard }, depth_slice: None })],
                depth_stencil_attachment: Some(wgpu::RenderPassDepthStencilAttachment {
                    view: &t.depth_view,
                    depth_ops: Some(wgpu::Operations { load: wgpu::LoadOp::Clear(1.0), store: wgpu::StoreOp::Discard }),
                    stencil_ops: Some(wgpu::Operations { load: wgpu::LoadOp::Clear(0), store: wgpu::StoreOp::Discard }),
                }),
                occlusion_query_set: None,
                timestamp_writes: None,
                multiview_mask: None,
            });

            // 1. Unified environment.
            if p.env.is_some() {
                pass.set_pipeline(&self.p_env);
                pass.set_bind_group(0, &self.env_bg, &[]);
                pass.set_vertex_buffer(0, self.env_vbuf.slice(..));
                pass.set_index_buffer(self.env_ibuf.slice(..), wgpu::IndexFormat::Uint16);
                pass.draw_indexed(0..self.env_count, 0, 0..1);
            }
            // 2. Planar note reflections (floor-clipped decal, no depth).
            if p.env.is_some() && p.mirror_strength > 0.0 && any_notes {
                pass.set_pipeline(&self.p_mirror);
                pass.set_bind_group(0, &self.scene_bg, &[GLOBALS_STRIDE as u32]);
                self.draw_notes(&mut pass, &inst_ranges);
            }
            pass.set_bind_group(0, &self.scene_bg, &[0]);
            pass.set_vertex_buffer(0, self.vertices.buf.slice(..));
            let draw_stream = |pass: &mut wgpu::RenderPass, pipe: &wgpu::RenderPipeline, r: (u32, u32)| {
                if r.1 > 0 {
                    pass.set_pipeline(pipe);
                    pass.draw(r.0..r.0 + r.1, 0..1);
                }
            };
            // 3. Arc ribbons: no depth test, no depth write.
            draw_stream(&mut pass, &self.p_arc, ranges[0]);
            // 4. Opaque buffer.
            draw_stream(&mut pass, &self.p_opaque, ranges[1]);
            // 5. Instanced note bodies.
            if any_notes {
                pass.set_pipeline(&self.p_note);
                self.draw_notes(&mut pass, &inst_ranges);
                pass.set_vertex_buffer(0, self.vertices.buf.slice(..));
            }
            // 6. Instanced walls.
            if wall_count > 0 {
                pass.set_pipeline(&self.p_wall);
                pass.set_vertex_buffer(0, self.wall_mesh.slice(..));
                pass.set_vertex_buffer(1, self.walls.buf.slice(..));
                pass.draw(0..self.wall_mesh_count, 0..wall_count);
                pass.set_vertex_buffer(0, self.vertices.buf.slice(..));
            }
            // 7. Transparent buffer.
            draw_stream(&mut pass, &self.p_transparent, ranges[2]);
            // 8. Replay: wall depth occluders, then sabers/headset.
            if ranges[4].1 > 0 || ranges[5].1 > 0 {
                if wall_count > 0 {
                    pass.set_pipeline(&self.p_wall_depth);
                    pass.set_vertex_buffer(0, self.wall_mesh.slice(..));
                    pass.set_vertex_buffer(1, self.walls.buf.slice(..));
                    pass.draw(0..self.wall_mesh_count, 0..wall_count);
                    pass.set_vertex_buffer(0, self.vertices.buf.slice(..));
                }
                draw_stream(&mut pass, &self.p_occluder, ranges[3]);
                draw_stream(&mut pass, &self.p_opaque, ranges[4]);
                draw_stream(&mut pass, &self.p_transparent, ranges[5]);
            }
        }
        queue.submit([encoder.finish()]);
    }

    fn draw_notes(&self, pass: &mut wgpu::RenderPass, ranges: &[(u32, u32)]) {
        for (m, r) in ranges.iter().enumerate() {
            if r.1 == 0 {
                continue;
            }
            let mesh = &self.note_meshes[m];
            pass.set_vertex_buffer(0, mesh.vbuf.slice(..));
            pass.set_vertex_buffer(1, self.instances.buf.slice(..));
            pass.set_index_buffer(mesh.ibuf.slice(..), wgpu::IndexFormat::Uint32);
            pass.draw_indexed(0..mesh.count, 0, r.0..r.0 + r.1);
        }
    }
}

#[cfg(test)]
mod tests {
    fn validate(src: &str) {
        let module = naga::front::wgsl::parse_str(src).unwrap_or_else(|e| panic!("{}", e.emit_to_string(src)));
        naga::valid::Validator::new(naga::valid::ValidationFlags::all(), naga::valid::Capabilities::empty())
            .validate(&module)
            .unwrap_or_else(|e| panic!("{e:?}"));
    }
    #[test]
    fn shaders_validate() {
        validate(include_str!("shaders/scene.wgsl"));
        validate(include_str!("shaders/env.wgsl"));
    }
}
