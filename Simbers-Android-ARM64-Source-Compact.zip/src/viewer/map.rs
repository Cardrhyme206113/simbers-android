//! Map data for the viewer: normalizeBeatmap / compactInfo / NPS statistics
//! (viewer/js/controls/map-state.js) and the palette (controls/palette.js).

use crate::payload::ViewerPayload;
use serde_json::Value;

#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct Note {
    pub b: f64,
    pub x: f64,
    pub y: f64,
    pub c: f64,
    pub d: f64,
}

#[derive(Clone, Copy, Debug, Default)]
pub struct Obstacle {
    pub b: f64,
    pub dur: f64,
    pub x: f64,
    pub y: f64,
    pub w: f64,
    pub h: f64,
}

#[derive(Clone, Copy, Debug, Default)]
pub struct Slider {
    pub c: f64,
    pub hb: f64,
    pub hx: f64,
    pub hy: f64,
    pub hd: f64,
    pub mu: f64,
    pub tb: f64,
    pub tx: f64,
    pub ty: f64,
    pub td: f64,
    pub tmu: f64,
    pub mid: f64,
}

#[derive(Clone, Copy, Debug, Default)]
pub struct Event {
    pub b: f64,
    pub t: f64,
    pub v: f64,
    pub f: f64,
}

#[derive(Clone, Copy, Debug, Default)]
pub struct RotationEvent {
    pub b: f64,
    pub t: f64,
    pub v: f64,
    /// Explicit v3 rotation; `None` for legacy events (value table lookup).
    pub r: Option<f64>,
}

#[derive(Clone, Debug, Default)]
pub struct Beatmap {
    pub notes: Vec<Note>,
    pub obstacles: Vec<Obstacle>,
    pub sliders: Vec<Slider>,
    pub events: Vec<Event>,
    pub ring_events: Vec<Event>,
    pub rotation_events: Vec<RotationEvent>,
}

#[derive(Clone, Debug)]
pub struct Info {
    pub song_name: String,
    pub song_sub_name: String,
    pub song_author: String,
    pub level_author: String,
    pub bpm: f64,
    pub offset: f64,
}

impl Default for Info {
    fn default() -> Self {
        Info { song_name: String::new(), song_sub_name: String::new(), song_author: String::new(), level_author: String::new(), bpm: 60.0, offset: 0.0 }
    }
}

#[derive(Clone, Debug)]
pub struct DifficultyMeta {
    pub difficulty: String,
    pub rank: f64,
    pub njs: f64,
}

#[derive(Clone, Debug)]
pub struct CharacteristicMeta {
    pub name: String,
    pub difficulties: Vec<DifficultyMeta>,
}

/// EMBEDDED: everything the viewer keeps about the loaded payload.
#[derive(Clone, Debug, Default)]
pub struct Embedded {
    pub info: Info,
    pub characteristics: Vec<CharacteristicMeta>,
    /// characteristic -> [(difficulty, beatmap)] in insertion order (JS object key order).
    pub maps: Vec<(String, Vec<(String, Beatmap)>)>,
    pub raw_info: Value,
}

impl Embedded {
    pub fn mode_maps(&self, mode: &str) -> Option<&Vec<(String, Beatmap)>> {
        self.maps.iter().find(|(m, _)| m == mode).map(|(_, v)| v)
    }
    pub fn beatmap(&self, mode: &str, diff: &str) -> Option<&Beatmap> {
        self.mode_maps(mode)?.iter().find(|(d, _)| d == diff).map(|(_, b)| b)
    }
}

pub const SUPPORTED: [&str; 6] = ["Standard", "NoArrows", "OneSaber", "90Degree", "360Degree", "Lawless"];

pub fn is_supported(name: &str) -> bool {
    SUPPORTED.contains(&if name.is_empty() { "Standard" } else { name })
}

pub fn characteristic_label(name: &str) -> String {
    match name {
        "90Degree" => "90°".into(),
        "360Degree" => "360°".into(),
        "" => "Standard".into(),
        n => n.into(),
    }
}

pub fn difficulty_label(name: &str) -> &str {
    if name == "ExpertPlus" { "Expert+" } else { name }
}

// ------------------------------------------------------------- JS coercions

/// `a ?? b ?? ...`: first key that exists and is not null.
fn first<'a>(v: &'a Value, keys: &[&str]) -> Option<&'a Value> {
    keys.iter().find_map(|k| v.get(*k).filter(|x| !x.is_null()))
}

/// `Number(a ?? b ?? dflt)`
fn num(v: &Value, keys: &[&str], dflt: f64) -> f64 {
    first(v, keys).map(crate::util::js_number).unwrap_or(dflt)
}

/// `raw.a || raw.b || ...` for arrays (an empty array is truthy in JS).
fn arr<'a>(v: &'a Value, keys: &[&str]) -> Option<&'a Vec<Value>> {
    for k in keys {
        match v.get(*k) {
            Some(Value::Array(a)) => return Some(a),
            Some(x) if crate::util::js_truthy(x) => return None,
            _ => {}
        }
    }
    None
}

/// `raw.a || raw.b || dflt` for strings.
fn text_or(v: &Value, keys: &[&str], dflt: &str) -> String {
    for k in keys {
        if let Some(x) = v.get(*k) {
            if crate::util::js_truthy(x) {
                return match x {
                    Value::String(s) => s.clone(),
                    Value::Number(n) => crate::util::js_num_to_string(n.as_f64().unwrap_or(0.0)),
                    Value::Bool(b) => b.to_string(),
                    _ => dflt.to_string(),
                };
            }
        }
    }
    dflt.to_string()
}

/// JS sort comparator returning a - b chains; NaN compares as "equal".
fn cmp(a: f64, b: f64) -> std::cmp::Ordering {
    a.partial_cmp(&b).unwrap_or(std::cmp::Ordering::Equal)
}

pub fn compact_info(raw: &Value) -> Info {
    let bpm = num(raw, &["_beatsPerMinute", "bpm"], 60.0);
    let offset = num(raw, &["_songTimeOffset", "offset"], 0.0);
    Info {
        song_name: text_or(raw, &["_songName", "songName"], "Generated Map"),
        song_sub_name: text_or(raw, &["_songSubName", "songSubName"], ""),
        song_author: text_or(raw, &["_songAuthorName", "songAuthor"], "Unknown"),
        level_author: text_or(raw, &["_levelAuthorName", "levelAuthor"], "Simplified Sabers"),
        bpm: if bpm == 0.0 || bpm.is_nan() { 60.0 } else { bpm },
        offset: if offset.is_nan() { 0.0 } else { offset },
    }
}

pub fn normalize_beatmap(raw: &Value) -> Beatmap {
    let mut notes: Vec<Note> = vec![];
    let to_note = |n: &Value| Note {
        b: num(n, &["_time", "b"], 0.0),
        x: num(n, &["_lineIndex", "x"], 0.0),
        y: num(n, &["_lineLayer", "y"], 0.0),
        c: num(n, &["_type", "c"], 0.0),
        d: num(n, &["_cutDirection", "d"], 8.0),
    };
    if let Some(a) = arr(raw, &["_notes", "notes"]) {
        notes.extend(a.iter().map(to_note));
    } else {
        if let Some(Value::Array(a)) = raw.get("colorNotes") {
            notes.extend(a.iter().map(to_note));
        }
        if let Some(Value::Array(a)) = raw.get("bombNotes") {
            notes.extend(a.iter().map(|n| Note { c: 3.0, d: 0.0, ..to_note(n) }));
        }
    }
    notes.sort_by(|a, b| cmp(a.b, b.b).then(cmp(a.c, b.c)));

    let mut obstacles: Vec<Obstacle> = arr(raw, &["_obstacles", "obstacles"])
        .map(|a| {
            a.iter()
                .map(|o| Obstacle {
                    b: num(o, &["_time", "b"], 0.0),
                    dur: num(o, &["_duration", "dur"], 0.0),
                    x: num(o, &["_lineIndex", "x"], 0.0),
                    y: num(o, &["_lineLayer", "y"], 0.0),
                    w: num(o, &["_width", "w"], 1.0),
                    h: num(o, &["_height", "h"], 3.0),
                })
                .collect()
        })
        .unwrap_or_default();
    obstacles.sort_by(|a, b| cmp(a.b, b.b));

    let mut sliders: Vec<Slider> = arr(raw, &["_sliders", "sliders"])
        .map(|a| {
            a.iter()
                .map(|s| Slider {
                    c: num(s, &["_colorType", "c"], 0.0),
                    hb: num(s, &["_headTime", "hb", "b"], 0.0),
                    hx: num(s, &["_headLineIndex", "hx", "x"], 0.0),
                    hy: num(s, &["_headLineLayer", "hy", "y"], 0.0),
                    hd: num(s, &["_headCutDirection", "hd", "d"], 8.0),
                    mu: num(s, &["_headControlPointLengthMultiplier", "mu"], 1.0),
                    tb: num(s, &["_tailTime", "tb"], 0.0),
                    tx: num(s, &["_tailLineIndex", "tx"], 0.0),
                    ty: num(s, &["_tailLineLayer", "ty"], 0.0),
                    td: num(s, &["_tailCutDirection", "td", "tc"], 8.0),
                    tmu: num(s, &["_tailControlPointLengthMultiplier", "tmu"], 1.0),
                    mid: num(s, &["_sliderMidAnchorMode", "mid", "m"], 0.0),
                })
                .collect()
        })
        .unwrap_or_default();
    sliders.sort_by(|a, b| cmp(a.hb, b.hb));

    let mut all: Vec<Event> = arr(raw, &["_events", "events"])
        .map(|a| {
            a.iter()
                .map(|e| Event {
                    b: num(e, &["_time", "b"], 0.0),
                    t: num(e, &["_type", "t"], 0.0),
                    v: num(e, &["_value", "v"], 0.0),
                    f: num(e, &["_floatValue", "f"], 1.0),
                })
                .collect()
        })
        .unwrap_or_default();
    all.sort_by(|a, b| cmp(a.b, b.b).then(cmp(a.t, b.t)).then(cmp(a.v, b.v)));
    let events = all.iter().copied().filter(|e| e.t >= 0.0 && e.t <= 4.0).collect();
    let ring_events = all.iter().copied().filter(|e| e.t == 8.0 || e.t == 9.0).collect();
    let mut rotation_events: Vec<RotationEvent> = all.iter().filter(|e| e.t == 14.0 || e.t == 15.0).map(|e| RotationEvent { b: e.b, t: e.t, v: e.v, r: None }).collect();
    if let Some(a) = arr(raw, &["rotationEvents", "_rotationEvents"]) {
        for e in a {
            let ex = num(e, &["e", "_executionTime"], 0.0);
            rotation_events.push(RotationEvent {
                b: num(e, &["b", "_time"], 0.0),
                t: 14.0 + (if ex.is_nan() { 0.0 } else { ex }).clamp(0.0, 1.0),
                v: 0.0,
                r: Some(num(e, &["r", "_rotation"], 0.0)),
            });
        }
    }
    rotation_events.sort_by(|a, b| cmp(a.b, b.b).then(cmp(a.t, b.t)));
    Beatmap { notes, obstacles, sliders, events, ring_events, rotation_events }
}

/// loadGeneratedPayload / updateGeneratedMaps: builds EMBEDDED.
pub fn embed(payload: &ViewerPayload) -> Embedded {
    let raw_info = payload.info.clone();
    let characteristics: Vec<CharacteristicMeta> = payload
        .characteristics
        .iter()
        .filter(|c| is_supported(&c.name))
        .map(|c| CharacteristicMeta {
            name: if c.name.is_empty() { "Standard".into() } else { c.name.clone() },
            difficulties: c.difficulties.iter().map(|d| DifficultyMeta { difficulty: if d.difficulty.is_empty() { "ExpertPlus".into() } else { d.difficulty.clone() }, rank: d.rank, njs: d.njs }).collect(),
        })
        .collect();
    let mut maps: Vec<(String, Vec<(String, Beatmap)>)> = vec![];
    for item in &payload.maps {
        let ch = if item.characteristic.is_empty() { "Standard".to_string() } else { item.characteristic.clone() };
        if !is_supported(&ch) {
            continue;
        }
        let diff = if item.difficulty.is_empty() { "ExpertPlus".to_string() } else { item.difficulty.clone() };
        let bm = normalize_beatmap(&item.beatmap);
        let slot = match maps.iter().position(|(m, _)| *m == ch) {
            Some(i) => i,
            None => {
                maps.push((ch.clone(), vec![]));
                maps.len() - 1
            }
        };
        let list = &mut maps[slot].1;
        match list.iter_mut().find(|(d, _)| *d == diff) {
            Some(e) => e.1 = bm,
            None => list.push((diff, bm)),
        }
    }
    let characteristics = if characteristics.is_empty() {
        maps.iter().map(|(name, ds)| CharacteristicMeta { name: name.clone(), difficulties: ds.iter().map(|(d, _)| DifficultyMeta { difficulty: d.clone(), rank: 0.0, njs: 0.0 }).collect() }).collect()
    } else {
        characteristics
    };
    Embedded { info: compact_info(&raw_info), characteristics, maps, raw_info }
}

// ------------------------------------------------------------------ NPS

pub fn compact_stat(value: f64) -> String {
    if !value.is_finite() || value < 0.0 {
        return "0".into();
    }
    crate::util::js_num_to_string(crate::util::to_fixed_num(value, 2))
}

fn peak_nps_for_window(notes: &[Note], window_beats: f64, bpm: f64, offset: f64) -> f64 {
    if notes.is_empty() {
        return 0.0;
    }
    let beat_time = 60.0 / bpm.max(0.0001);
    let window = window_beats * beat_time;
    let (mut left, mut peak) = (0usize, 0usize);
    for right in 0..notes.len() {
        let now = notes[right].b * beat_time + offset;
        while left <= right && notes[left].b * beat_time + offset < now - window {
            left += 1;
        }
        peak = peak.max(right + 1 - left);
    }
    peak as f64 / window
}

#[derive(Clone, Copy, Debug, Default)]
pub struct NpsStats {
    pub overall: f64,
    pub p4: f64,
    pub p8: f64,
    pub p16: f64,
}

pub fn nps_stats(color_notes: &[Note], info: &Info, audio_duration: Option<f64>) -> NpsStats {
    let bpm = (if info.bpm.is_nan() || info.bpm == 0.0 { 60.0 } else { info.bpm }).max(0.0001);
    let offset = info.offset;
    if color_notes.is_empty() {
        return NpsStats::default();
    }
    let beat_time = 60.0 / bpm;
    let first = color_notes[0].b * beat_time + offset;
    let last = color_notes[color_notes.len() - 1].b * beat_time + offset;
    let mut len = last - first;
    if len <= 0.0001 {
        len = audio_duration.filter(|d| *d != 0.0 && !d.is_nan()).unwrap_or(beat_time).max(0.0001);
    }
    NpsStats {
        overall: color_notes.len() as f64 / len,
        p4: peak_nps_for_window(color_notes, 4.0, bpm, offset),
        p8: peak_nps_for_window(color_notes, 8.0, bpm, offset),
        p16: peak_nps_for_window(color_notes, 16.0, bpm, offset),
    }
}

// --------------------------------------------------------------- palette

/// Map colors exactly as palette.js resolves them (CSS color strings).
#[derive(Clone, Debug)]
pub struct Palette {
    pub left: String,
    pub right: String,
    pub light_left: String,
    pub light_right: String,
}

impl Default for Palette {
    fn default() -> Self {
        Palette { left: "#c81414".into(), right: "#288ed2".into(), light_left: "#d91616".into(), light_right: "#30acff".into() }
    }
}

fn color_component(v: f64) -> String {
    crate::util::js_num_to_string(crate::util::js_round(if v <= 1.0 { v * 255.0 } else { v }))
}

/// colorFromAny
fn color_from_any(value: Option<&Value>, fallback: &str) -> String {
    let Some(v) = value.filter(|v| crate::util::js_truthy(v)) else { return fallback.into() };
    match v {
        Value::String(s) => s.clone(),
        Value::Array(a) if a.len() >= 3 => {
            let n = |i: usize| crate::util::js_number(&a[i]);
            format!("rgb({},{},{})", color_component(n(0)), color_component(n(1)), color_component(n(2)))
        }
        Value::Object(_) => {
            let pick = |keys: &[&str], idx: &str| first(v, keys).or_else(|| v.get(idx).filter(|x| !x.is_null()));
            match (pick(&["r", "red", "_r"], "0"), pick(&["g", "green", "_g"], "1"), pick(&["b", "blue", "_b"], "2")) {
                (Some(r), Some(g), Some(b)) => format!("rgb({},{},{})", color_component(crate::util::js_number(r)), color_component(crate::util::js_number(g)), color_component(crate::util::js_number(b))),
                _ => fallback.into(),
            }
        }
        _ => fallback.into(),
    }
}

/// applyViewerColors
pub fn resolve_palette(payload_colors: Option<&Value>, raw_info: &Value) -> Palette {
    let mut p = Palette::default();
    let custom = raw_info.get("_customData").filter(|v| crate::util::js_truthy(v));
    let map_colors = payload_colors.filter(|v| crate::util::js_truthy(v)).or(custom);
    let sources = [map_colors, custom, raw_info.get("customData").filter(|v| crate::util::js_truthy(v))];
    for src in sources.into_iter().flatten() {
        if !src.is_object() {
            continue;
        }
        p.left = color_from_any(first(src, &["_colorLeft", "colorLeft", "leftColor", "left"]), &p.left);
        p.right = color_from_any(first(src, &["_colorRight", "colorRight", "rightColor", "right"]), &p.right);
        p.light_left = color_from_any(first(src, &["_envColorLeft", "envColorLeft", "_environmentColor0", "environmentColor0", "environmentColorLeft", "lightColor1"]), &p.light_left);
        p.light_right = color_from_any(first(src, &["_envColorRight", "envColorRight", "_environmentColor1", "environmentColor1", "environmentColorRight", "lightColor2"]), &p.light_right);
    }
    p
}

/// JS parseInt(s, 16) on a prefix (NaN when no hex digit leads).
fn parse_int_hex(s: &str) -> Option<i64> {
    let t = s.trim_start();
    let digits: String = t.chars().take_while(|c| c.is_ascii_hexdigit()).collect();
    if digits.is_empty() {
        return None;
    }
    i64::from_str_radix(&digits[..digits.len().min(15)], 16).ok()
}

/// drawing-primitives.js shade(): `rgb(r,g,b)`; garbage in -> "rgb(NaN,NaN,NaN)".
pub fn shade(hex: &str, factor: f64) -> String {
    let Some(n) = hex.get(1..).and_then(parse_int_hex) else { return "rgb(NaN,NaN,NaN)".into() };
    let c = |shift: i64| (crate::util::js_round((((n >> shift) & 255) as f64) * factor)).clamp(0.0, 255.0);
    format!("rgb({},{},{})", c(16), c(8), c(0))
}

/// webgl-init.js cssRgb01()
pub fn css_rgb01(value: &str) -> [f32; 3] {
    if value.is_empty() {
        return [1.0, 1.0, 1.0];
    }
    if let Some(h) = value.strip_prefix('#') {
        let h: String = if h.len() == 3 { h.chars().flat_map(|c| [c, c]).collect() } else { h.to_string() };
        let Some(n) = parse_int_hex(&h) else { return [f32::NAN; 3] };
        return [((n >> 16) & 255) as f32 / 255.0, ((n >> 8) & 255) as f32 / 255.0, (n & 255) as f32 / 255.0];
    }
    // /[\d.]+/g
    let mut nums = vec![];
    let mut cur = String::new();
    for ch in value.chars().chain(std::iter::once(' ')) {
        if ch.is_ascii_digit() || ch == '.' {
            cur.push(ch);
        } else if !cur.is_empty() {
            nums.push(std::mem::take(&mut cur));
        }
    }
    if nums.len() >= 3 {
        let f = |s: &str| s.parse::<f64>().unwrap_or(f64::NAN) as f32 / 255.0;
        [f(&nums[0]), f(&nums[1]), f(&nums[2])]
    } else {
        [1.0, 1.0, 1.0]
    }
}

/// COLORS.left / COLORS.right
#[derive(Clone, Debug)]
pub struct SaberColors {
    pub front: String,
    pub side: String,
    pub top: String,
    pub edge: String,
}

impl SaberColors {
    pub fn left(p: &Palette) -> Self {
        SaberColors { front: p.left.clone(), side: shade(&p.left, 0.52), top: shade(&p.left, 1.04), edge: shade(&p.left, 1.14) }
    }
    pub fn right(p: &Palette) -> Self {
        SaberColors { front: p.right.clone(), side: shade(&p.right, 0.54), top: shade(&p.right, 1.04), edge: shade(&p.right, 1.14) }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn normalize_and_stats() {
        let raw = serde_json::json!({
            "_notes": [
                {"_time": 2.0, "_lineIndex": 1, "_lineLayer": 0, "_type": 1, "_cutDirection": 1},
                {"_time": 1.0, "_lineIndex": 2, "_lineLayer": 1, "_type": 0, "_cutDirection": 8},
                {"_time": 1.0, "_lineIndex": 0, "_lineLayer": 0, "_type": 3, "_cutDirection": 0}
            ],
            "_obstacles": [{"_time": 4, "_duration": 2, "_lineIndex": 0, "_width": 2, "_type": 0}],
            "_events": [{"_time": 1, "_type": 8, "_value": 0}, {"_time": 0.5, "_type": 2, "_value": 5, "_floatValue": 0.5}, {"_time": 3, "_type": 14, "_value": 4}]
        });
        let bm = normalize_beatmap(&raw);
        assert_eq!(bm.notes.len(), 3);
        assert_eq!((bm.notes[0].b, bm.notes[0].c), (1.0, 0.0));
        assert_eq!(bm.notes[1].c, 3.0);
        assert_eq!(bm.obstacles[0].h, 3.0);
        assert_eq!(bm.events.len(), 1);
        assert_eq!(bm.ring_events.len(), 1);
        assert_eq!(bm.rotation_events.len(), 1);
        assert!(bm.rotation_events[0].r.is_none());
        assert_eq!(compact_stat(3.3149), "3.31");
        assert_eq!(compact_stat(4.0), "4");
        assert_eq!(shade("#c81414", 0.52), "rgb(104,10,10)");
        assert_eq!(shade("rgb(1,2,3)", 0.5), "rgb(NaN,NaN,NaN)");
        assert_eq!(css_rgb01("rgb(NaN,NaN,NaN)"), [1.0, 1.0, 1.0]);
        let c = css_rgb01("#30acff");
        assert!((c[0] - 48.0 / 255.0).abs() < 1e-6);
    }
}
