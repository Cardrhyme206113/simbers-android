//! replay.js rendering half: poseAt / cyberSampleHandAt, the BeatLeader pose
//! conversion, deck clipping, saber/hilt/headset/trail geometry and the HMD
//! first-person camera (cyberUpdateHmdCamera).

use super::geom::{face_normal, hypot, rotate_point_y, FrameGeometry, Target, P3};
use super::replay_sim::{clamp, norm, norm4, qmul, qrot, quat_slerp, Replay, CYBER_PLAYER_HEAD_HEIGHT, CYBER_SCENE_Y_SCALE, HZ};
use crate::util::jsm;

const CYBER_PLATFORM_TOP: f64 = 0.065;
pub const CYBER_HMD_LONG_AXIS_FOV: f64 = (110.0 * std::f64::consts::PI) / 180.0;
pub const POV_BACK_DEFAULT: f64 = 1.4;

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Kind {
    Simulated,
    Recorded,
}

pub struct ReplayView {
    pub data: Replay,
    pub kind: Kind,
    /// replay.entry: (characteristic, difficulty) it was generated for.
    pub entry: (String, String),
    /// cyberHmdZeroCache: headset rotation at the first frame past 0.3 s.
    zero: [f64; 4],
}

#[derive(Clone, Copy, Debug)]
pub struct HmdCamera {
    pub x: f64,
    pub y: f64,
    pub map_z: f64,
    pub world_z: f64,
    pub yaw: f64,
    pub pitch: f64,
    pub roll: f64,
}

/// Scene constants the replay transforms read (usesDefaultEnvironment, nearZ, CAMERA_EYE_Y).
#[derive(Clone, Copy)]
pub struct Space {
    pub default_env: bool,
    pub near_z: f64,
    pub eye_y: f64,
    /// viewRotationAngle(0) in degrees (−cameraYaw in 360° mode).
    pub view_angle: f64,
}

#[derive(Clone, Copy)]
pub struct Pose {
    pub p: [f64; 3],
    pub q: [f64; 4],
}

pub struct Frame {
    pub head: Pose,
    pub left: Pose,
    pub right: Pose,
}

fn frame_index(times: &[f32], t: f64) -> usize {
    let n = times.len();
    let mut k = clamp((t * HZ).floor(), 0.0, n as f64 - 2.0) as usize;
    if times[k] as f64 > t || (times[k + 1] as f64) < t {
        let (mut lo, mut hi) = (0usize, n - 1);
        while lo + 1 < hi {
            let mid = (lo + hi) >> 1;
            if times[mid] as f64 <= t {
                lo = mid;
            } else {
                hi = mid;
            }
        }
        k = lo;
    }
    k
}

fn q4(r: &[f32], i: usize) -> [f64; 4] {
    [r[i] as f64, r[i + 1] as f64, r[i + 2] as f64, r[i + 3] as f64]
}

impl ReplayView {
    pub fn new(data: Replay, kind: Kind, entry: (String, String)) -> ReplayView {
        let mut index = 0;
        while index < data.times.len() - 1 && (data.times[index] as f64) < 0.3 {
            index += 1;
        }
        let zero = q4(&data.head.rot, index * 4);
        ReplayView { data, kind, entry, zero }
    }

    fn sample(&self, m: &super::replay_sim::Motion, k: usize, f: f64) -> Pose {
        let p = [0, 1, 2].map(|j| m.pos[k * 3 + j] as f64 * (1.0 - f) + m.pos[(k + 1) * 3 + j] as f64 * f);
        Pose { p, q: quat_slerp(q4(&m.rot, k * 4), q4(&m.rot, (k + 1) * 4), f) }
    }

    fn kf(&self, t: f64) -> Option<(usize, f64)> {
        let times = &self.data.times;
        if times.len() < 2 {
            return None;
        }
        let k = frame_index(times, t);
        let d = times[k + 1] as f64 - times[k] as f64;
        let f = clamp((t - times[k] as f64) / if d == 0.0 { 1.0 } else { d }, 0.0, 1.0);
        Some((k, f))
    }

    /// poseAt(replay, t)
    pub fn pose_at(&self, t: f64) -> Option<Frame> {
        let (k, f) = self.kf(t)?;
        Some(Frame { head: self.sample(&self.data.head, k, f), left: self.sample(&self.data.left, k, f), right: self.sample(&self.data.right, k, f) })
    }

    /// cyberSampleHandAt(replay, t, hand)
    pub fn hand_at(&self, t: f64, right: bool) -> Option<Pose> {
        let (k, f) = self.kf(t)?;
        let p = &(if right { &self.data.right } else { &self.data.left }).pos;
        let r = &(if right { &self.data.right } else { &self.data.left }).rot;
        let (pi, ri) = (k * 3, k * 4);
        let pos = [0, 1, 2].map(|j| p[pi + j] as f64 + (p[pi + 3 + j] as f64 - p[pi + j] as f64) * f);
        Some(Pose { p: pos, q: quat_slerp(q4(r, ri), q4(r, ri + 4), f) })
    }

    /// cyberUpdateHmdCamera(t) — caller has already checked cyberPOVOn().
    pub fn hmd_camera(&self, t: f64, sp: &Space, behind: f64) -> Option<HmdCamera> {
        let f = self.pose_at(t)?;
        let z = self.zero;
        let q = norm4(qmul(f.head.q, [-z[0], -z[1], -z[2], z[3]]));
        let forward = qrot(q, [0.0, 0.0, 1.0]);
        let right = qrot(q, [1.0, 0.0, 0.0]);
        let yaw = clamp(jsm::atan2(forward[0], forward[2]), -0.9, 0.9);
        let pitch = clamp(jsm::atan2(forward[1], jsm::hypot(forward[0], forward[2])), -0.65, 0.65);
        let roll = clamp(jsm::atan2(right[1], jsm::hypot(right[0], right[2])), -0.43, 0.43);
        let body = Body::new(&f.head, true);
        let world = view_p(body.p, sp);
        let behind = clamp(behind, 0.45, 2.75);
        let cam_x = world.x - jsm::sin(yaw) * behind;
        let cam_y = world.y + 0.08;
        let map_z = world.z - jsm::cos(yaw) * behind;
        Some(HmdCamera { x: cam_x, y: cam_y, map_z, world_z: map_z + super::scene::DEFAULT_ENV_CAMERA_Z, yaw, pitch, roll })
    }

    /// Score state shown by notifyScore (the cyber HUD is hidden, kept for status text).
    pub fn score_at(&self, t: f64) -> (usize, i64, i64) {
        let es = &self.data.events;
        let idx = es.partition_point(|e| e.t <= t);
        let last = if idx > 0 { es.get(idx - 1) } else { None };
        let shown = if self.kind == Kind::Recorded && idx == es.len() { self.data.score } else { last.map(|e| e.cumulative).unwrap_or(0) };
        (idx, shown, last.map(|e| e.combo).unwrap_or(0))
    }
}

/// cyberHmdVerticalFov(aspect)
pub fn hmd_vertical_fov(aspect: f64) -> f64 {
    let a = if aspect.is_finite() && aspect != 0.0 { aspect } else { 1.0 }.clamp(0.1, 10.0);
    2.0 * libm::atan(libm::tan(CYBER_HMD_LONG_AXIS_FOV * 0.5) / a.max(1.0))
}

fn quat_xyz(x: f64, y: f64, z: f64) -> [f64; 4] {
    let (c1, c2, c3) = (jsm::cos(x / 2.0), jsm::cos(y / 2.0), jsm::cos(z / 2.0));
    let (s1, s2, s3) = (jsm::sin(x / 2.0), jsm::sin(y / 2.0), jsm::sin(z / 2.0));
    [s1 * c2 * c3 + c1 * s2 * s3, c1 * s2 * c3 - s1 * c2 * s3, c1 * c2 * s3 + s1 * s2 * c3, c1 * c2 * c3 - s1 * s2 * s3]
}

fn euler_xyz(q: [f64; 4]) -> [f64; 3] {
    let [x, y, z, w] = q;
    let a = 1.0 - 2.0 * (y * y + z * z);
    let b = 2.0 * (x * y - z * w);
    let c = 2.0 * (x * z + y * w);
    let d = 2.0 * (y * z - x * w);
    let e = 1.0 - 2.0 * (x * x + y * y);
    let ry = libm::asin(clamp(c, -1.0, 1.0));
    if c.abs() < 0.9999999 {
        [jsm::atan2(-d, e), ry, jsm::atan2(-b, a)]
    } else {
        [jsm::atan2(2.0 * (y * z + x * w), 1.0 - 2.0 * (y * y + z * z)), ry, 0.0]
    }
}

/// cyberBodyPose(raw, head)
pub struct Body {
    pub q: [f64; 4],
    pub p: [f64; 3],
}

impl Body {
    pub fn new(raw: &Pose, head: bool) -> Body {
        let q = raw.q;
        let o = norm(&[q[3], q[2], q[1], q[0]]);
        let a = euler_xyz([o[0], o[1], o[2], o[3]]);
        let q = quat_xyz(a[0], a[1] + std::f64::consts::PI, -a[2] + if head { std::f64::consts::PI } else { 0.0 });
        Body { q, p: [raw.p[0], raw.p[1], -raw.p[2]] }
    }
    pub fn at(&self, local: [f64; 3]) -> [f64; 3] {
        let r = qrot(self.q, local);
        [self.p[0] + r[0], self.p[1] + r[1], self.p[2] + r[2]]
    }
}

/// cyberViewP(local)
pub fn view_p(l: [f64; 3], sp: &Space) -> P3 {
    let center = if sp.default_env { sp.near_z } else { sp.near_z + 1.0 };
    rotate_point_y(P3::new(l[0] * 2.25, (l[1] - CYBER_PLAYER_HEAD_HEIGHT) * CYBER_SCENE_Y_SCALE + sp.eye_y, center - 1.2 - l[2] * 1.9), sp.view_angle)
}

struct Painter<'a> {
    g: &'a mut FrameGeometry,
    sp: Space,
}

impl Painter<'_> {
    /// cyberQuad
    fn quad(&mut self, t: Target, pts: [[f64; 3]; 4], color: [f32; 3], alpha: f64) {
        let mut q: Vec<P3> = pts.iter().map(|p| view_p(*p, &self.sp)).collect();
        if self.sp.default_env {
            // cyberClipAgainstDeck (Sutherland–Hodgman against the deck top).
            let top = CYBER_PLATFORM_TOP;
            let mut out = Vec::with_capacity(6);
            for i in 0..q.len() {
                let (a, b) = (q[i], q[(i + 1) % q.len()]);
                let (ai, bi) = (a.y >= top, b.y >= top);
                if ai {
                    out.push(a);
                }
                if ai != bi {
                    let f = (top - a.y) / (b.y - a.y);
                    out.push(P3::new(a.x + (b.x - a.x) * f, top, a.z + (b.z - a.z) * f));
                }
            }
            q = out;
        }
        if q.len() < 3 {
            return;
        }
        let n = face_normal(q[0], q[1], q[2]);
        for i in 1..q.len() - 1 {
            self.g.tri(t, q[0], q[i], q[i + 1], color, alpha, Some(n));
        }
    }

    /// cyberBox
    fn bx(&mut self, body: &Body, mid: [f64; 3], half: [f64; 3], color: [f32; 3], alpha: f64, t: Target) {
        let p = |a: f64, b: f64, c: f64| body.at([mid[0] + a * half[0], mid[1] + b * half[1], mid[2] + c * half[2]]);
        let v = [p(-1.0, -1.0, -1.0), p(1.0, -1.0, -1.0), p(1.0, 1.0, -1.0), p(-1.0, 1.0, -1.0), p(-1.0, -1.0, 1.0), p(1.0, -1.0, 1.0), p(1.0, 1.0, 1.0), p(-1.0, 1.0, 1.0)];
        for [a, b, c, d] in [[0, 1, 2, 3], [5, 4, 7, 6], [4, 0, 3, 7], [1, 5, 6, 2], [3, 2, 6, 7], [4, 5, 1, 0]] {
            self.quad(t, [v[a], v[b], v[c], v[d]], color, alpha);
        }
    }

    /// cyberLineCylinder
    fn cyl(&mut self, a: [f64; 3], b: [f64; 3], radius: f64, color: [f32; 3], n: usize) {
        let d = [b[0] - a[0], b[1] - a[1], b[2] - a[2]];
        let m = hypot(&d);
        if m < 1e-6 {
            return;
        }
        let axis = [d[0] * (1.0 / m), d[1] * (1.0 / m), d[2] * (1.0 / m)];
        let hint = if axis[1].abs() > 0.88 { [1.0, 0.0, 0.0] } else { [0.0, 1.0, 0.0] };
        let t = norm(&[axis[1] * hint[2] - axis[2] * hint[1], axis[2] * hint[0] - axis[0] * hint[2], axis[0] * hint[1] - axis[1] * hint[0]]);
        let v = [axis[1] * t[2] - axis[2] * t[1], axis[2] * t[0] - axis[0] * t[2], axis[0] * t[1] - axis[1] * t[0]];
        let s = radius * 0.93;
        let circ = |o: [f64; 3], th: f64| {
            let (c, sn) = (s * jsm::cos(th), s * jsm::sin(th));
            [o[0] + (t[0] * c + v[0] * sn), o[1] + (t[1] * c + v[1] * sn), o[2] + (t[2] * c + v[2] * sn)]
        };
        for i in 0..n {
            let an = (i as f64 * std::f64::consts::PI * 2.0) / n as f64;
            let bn = ((i + 1) as f64 * std::f64::consts::PI * 2.0) / n as f64;
            self.quad(Target::ReplayOpaque, [circ(a, an), circ(a, bn), circ(b, bn), circ(b, an)], color, 1.0);
        }
    }

    fn hilt(&mut self, b: &Body, color: [f32; 3]) {
        self.cyl(b.at([0.0, 0.0, -0.02]), b.at([0.0, 0.0, 0.155]), 0.024, [0.105, 0.12, 0.16], 7);
        self.cyl(b.at([0.0, 0.0, 0.12]), b.at([0.0, 0.0, 0.16]), 0.029, color, 7);
        self.cyl(b.at([0.0, 0.0, -0.015]), b.at([0.0, 0.0, 0.01]), 0.031, [0.53, 0.57, 0.61], 7);
        self.cyl(b.at([0.0, 0.0, 0.04]), b.at([0.0, 0.0, 0.05]), 0.027, [0.31, 0.33, 0.39], 7);
    }

    fn blade(&mut self, b: &Body, color: [f32; 3]) {
        let half = 0.012;
        self.bx(b, [0.0, 0.0, -0.515], [half, half, 0.5], color, 0.99, Target::ReplayOpaque);
        self.bx(b, [0.0, 0.0, -0.515], [half * 0.44, half * 0.44, 0.495], [0.88, 0.94, 1.0], 0.95, Target::ReplayOpaque);
        for (r, a) in [(0.029, 0.19), (0.05, 0.1), (0.075, 0.045)] {
            self.bx(b, [0.0, 0.0, -0.515], [r, r, 0.505], color, a, Target::ReplayTransparent);
        }
    }

    fn headset(&mut self, body: &Body) {
        let o = Target::ReplayOpaque;
        self.bx(body, [0.0, 0.0, -0.065], [0.159, 0.081, 0.071], [0.12, 0.145, 0.17], 1.0, o);
        self.bx(body, [0.0, -0.001, -0.133], [0.15, 0.07, 0.012], [0.3, 0.36, 0.41], 1.0, o);
        self.bx(body, [-0.115, -0.016, -0.147], [0.025, 0.045, 0.009], [0.19, 0.21, 0.25], 1.0, o);
        self.bx(body, [0.115, -0.016, -0.147], [0.025, 0.045, 0.009], [0.19, 0.21, 0.25], 1.0, o);
        self.bx(body, [0.0, 0.075, -0.055], [0.12, 0.007, 0.062], [0.53, 0.58, 0.63], 1.0, o);
        for side in [-1.0, 1.0] {
            let a = body.at([side * 0.145, 0.006, -0.055]);
            let b = body.at([side * 0.18, 0.005, 0.045]);
            let c = body.at([side * 0.147, 0.018, 0.155]);
            self.cyl(a, b, 0.014, [0.37, 0.39, 0.43], 7);
            self.cyl(b, c, 0.013, [0.33, 0.35, 0.39], 7);
        }
        let mk = |a: f64| body.at([0.147 * jsm::cos(a), 0.018 + 0.014 * jsm::sin(a), 0.15 + 0.018 * jsm::sin(a)]);
        for j in 0..8 {
            let a0 = (std::f64::consts::PI * j as f64) / 8.0;
            let a1 = (std::f64::consts::PI * (j + 1) as f64) / 8.0;
            self.cyl(mk(a0), mk(a1), 0.016, [0.34, 0.36, 0.4], 6);
        }
    }

    /// cyberTrail
    fn trail(&mut self, rv: &ReplayView, right: bool, t: f64, color: [f32; 3], steps: usize) {
        if t <= 0.015 {
            return;
        }
        let life = 0.23;
        let mut segs: Vec<([f64; 3], [f64; 3], f64)> = Vec::with_capacity(steps + 1);
        for i in 0..=steps {
            let age = (steps - i) as f64 / steps as f64;
            let tt = (t - age * life).max(0.0);
            let Some(pose) = rv.hand_at(tt, right) else { continue };
            let body = Body::new(&pose, false);
            segs.push((body.at([0.0, 0.0, -0.015]), body.at([0.0, 0.0, -1.015]), age));
        }
        for i in 1..segs.len() {
            let (a, b) = (segs[i - 1], segs[i]);
            let speed = hypot(&[b.1[0] - a.1[0], b.1[1] - a.1[1], b.1[2] - a.1[2]]);
            if !(0.001..=0.85).contains(&speed) {
                continue;
            }
            let bad = [a.0, a.1, b.0, b.1].iter().any(|p| {
                let v = view_p(*p, &self.sp);
                !v.z.is_finite() || v.z < 0.55
            });
            if bad {
                continue;
            }
            let opacity = jsm::pow(1.0 - b.2, 1.6) * 0.18;
            self.quad(Target::ReplayTransparent, [a.0, b.0, b.1, a.1], color, opacity);
            self.quad(Target::ReplayTransparent, [a.1, b.1, b.0, a.0], color, opacity);
        }
    }
}

pub struct DrawOpts {
    pub trails: bool,
    pub headset: bool,
    pub trail_steps: usize,
}

/// replayDraw(t) — the native-WebGL branch.
pub fn draw(g: &mut FrameGeometry, rv: &ReplayView, t: f64, sp: Space, o: &DrawOpts) {
    let Some(frame) = rv.pose_at(t) else { return };
    let left = Body::new(&frame.left, false);
    let right = Body::new(&frame.right, false);
    let (c0, c1) = ([0.98f32, 0.13, 0.26], [0.12f32, 0.59, 1.0]);
    let mut p = Painter { g, sp };
    if o.trails {
        p.trail(rv, false, t, c0, o.trail_steps);
        p.trail(rv, true, t, c1, o.trail_steps);
    }
    p.hilt(&left, c0);
    p.hilt(&right, c1);
    p.blade(&left, c0);
    p.blade(&right, c1);
    if o.headset {
        p.headset(&Body::new(&frame.head, true));
    }
}
