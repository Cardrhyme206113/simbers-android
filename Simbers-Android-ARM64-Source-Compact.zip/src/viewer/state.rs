//! The viewer's runtime state: map-state.js (load/populate/loadDifficulty),
//! playback.js, rotation.js update360Camera, presentation.js (zoom, quality,
//! DPR, adaptive resolution) and renderer.js render() feeding gpu.rs.

use super::audio::Player;
use super::env::{EnvCamera, EnvState, Environment};
use super::geom::FrameGeometry;
use super::gpu::{FrameParams, Globals, ViewerGpu};
use super::lighting::Lighting;
use super::map::{self, Embedded, NpsStats};
use super::meshes;
use super::scene::{self, ActiveMap, Approach, SceneColors, SceneInput, Timing};
use super::replay::{self, HmdCamera, ReplayView, Space};
use super::replay_sim;
use super::Quality;
use std::sync::Arc;
use crate::payload::ViewerPayload;
use std::sync::mpsc::Receiver;
use std::time::Instant;

pub const USER_ZOOM_DEFAULT: f64 = 1.85;
pub const USER_ZOOM_MIN: f64 = 0.65;
pub const USER_ZOOM_MAX: f64 = 1.85;
const MAX_RENDER_FPS: f64 = 120.0;
const FRAME_INTERVAL_MS: f64 = 1000.0 / MAX_RENDER_FPS;

pub struct Viewer {
    pub embedded: Option<Embedded>,
    pub mode: String,
    pub difficulty: String,
    pub active: Option<ActiveMap>,
    timing: Timing,
    colors: SceneColors,
    light_left: [f32; 3],
    light_right: [f32; 3],
    pub left_css: String,
    pub right_css: String,
    pub quality: Quality,
    pub approach: Approach,
    pub player: Player,
    lighting: Lighting,
    env: Environment,
    geometry: FrameGeometry,
    group_count: usize,
    gpu: Option<ViewerGpu>,
    gpu_failed: bool,
    camera_yaw: f64,
    pub user_zoom: f64,
    pub needs_redraw: bool,
    last_visual_time: f64,
    last_frame: Option<Instant>,
    last_rendered: Option<Instant>,
    fps_frames: u32,
    fps_ticks: u32,
    fps_start: Instant,
    pub fps_text: String,
    displayed_fps: f64,
    display_hz: f64,
    adaptive: f64,
    adaptive_drop: u32,
    adaptive_good: u32,
    adaptive_last: Instant,
    pub max_playback: f64,
    hits: Vec<f64>,
    last_playback_time: f64,
    pub nps: NpsStats,
    pub status: String,
    pub highlights_cuts: Vec<f64>,
    pub cover: Option<Vec<u8>>,
    audio_rx: Option<Receiver<Option<crate::audio::Decoded>>>,
    pub audio_loading: bool,
    autoplay: bool,
    started: Instant,
    meshes: (Vec<meshes::Mesh>, Vec<meshes::Mesh>),
    bomb_unit: meshes::BombUnit,
    /// payload.maps beatmaps as raw JSON (characteristic, difficulty, beatmap) for the replay simulator.
    raw_maps: Vec<(String, String, Arc<serde_json::Value>)>,
    raw_bpm: f64,
    raw_offset: f64,
    raw_info: serde_json::Value,
    /// cyberReplayVisible (Viewer mode = Replay · HMD POV).
    pub replay_visible: bool,
    pub replay: Option<ReplayView>,
    replay_rx: Option<Receiver<(u64, (String, String), Result<replay_sim::Replay, String>)>>,
    replay_serial: u64,
    /// cyber-await-first-pose: hide the stage until the first replay pose exists.
    pub await_first_pose: bool,
    hmd: Option<HmdCamera>,
    pub pov_back: f64,
    pub wall_dodge: bool,
    pub show_sabers: bool,
    pub show_headset: bool,
    pub show_trails: bool,
    pub replay_status: String,
}

impl Default for Viewer {
    fn default() -> Self {
        Self::new()
    }
}

impl Viewer {
    pub fn new() -> Viewer {
        let blocks = meshes::arcv_block_meshes();
        let bomb_unit = meshes::bomb_unit_geometry();
        let bombs = meshes::static_bomb_meshes(&bomb_unit);
        let pal = map::Palette::default();
        let now = Instant::now();
        Viewer {
            embedded: None,
            mode: "Standard".into(),
            difficulty: "ExpertPlus".into(),
            active: None,
            timing: Timing::default(),
            colors: SceneColors::new(&map::SaberColors::left(&pal), &map::SaberColors::right(&pal)),
            light_left: map::css_rgb01(&pal.light_left),
            light_right: map::css_rgb01(&pal.light_right),
            left_css: pal.left.clone(),
            right_css: pal.right.clone(),
            quality: Quality::default(),
            approach: Approach::Auto,
            player: Player::new(),
            lighting: Lighting::default(),
            env: Environment::default(),
            geometry: FrameGeometry::default(),
            group_count: blocks.len() + bombs.len(),
            gpu: None,
            gpu_failed: false,
            camera_yaw: 0.0,
            user_zoom: USER_ZOOM_DEFAULT,
            needs_redraw: true,
            last_visual_time: -1.0,
            last_frame: None,
            last_rendered: None,
            fps_frames: 0,
            fps_ticks: 0,
            fps_start: now,
            fps_text: String::new(),
            displayed_fps: 0.0,
            display_hz: 60.0,
            adaptive: 1.0,
            adaptive_drop: 0,
            adaptive_good: 0,
            adaptive_last: now,
            max_playback: f64::INFINITY,
            hits: vec![],
            last_playback_time: 0.0,
            nps: NpsStats::default(),
            status: "No map loaded".into(),
            highlights_cuts: vec![],
            cover: None,
            audio_rx: None,
            audio_loading: false,
            autoplay: false,
            started: now,
            meshes: (blocks, bombs),
            bomb_unit,
            raw_maps: vec![],
            raw_bpm: 60.0,
            raw_offset: 0.0,
            raw_info: serde_json::Value::Null,
            replay_visible: true,
            replay: None,
            replay_rx: None,
            replay_serial: 0,
            await_first_pose: false,
            hmd: None,
            pov_back: replay::POV_BACK_DEFAULT,
            wall_dodge: true,
            show_sabers: true,
            show_headset: true,
            show_trails: true,
            replay_status: String::new(),
        }
    }

    pub fn has_map(&self) -> bool {
        self.embedded.is_some()
    }

    /// clearLoadedMap()
    pub fn clear(&mut self) {
        self.player.clear();
        self.embedded = None;
        self.active = None;
        self.env.clear();
        self.hits.clear();
        self.cover = None;
        self.audio_rx = None;
        self.audio_loading = false;
        self.status = "No map loaded".into();
        self.needs_redraw = true;
        self.discard_replay();
    }

    /// cyberDiscardReplay()
    pub fn discard_replay(&mut self) {
        self.replay = None;
        self.replay_rx = None;
        self.replay_serial += 1;
        self.await_first_pose = false;
        self.hmd = None;
        self.raw_maps.clear();
    }

    fn store_raw(&mut self, payload: &ViewerPayload) {
        let info = &payload.info;
        let num = |keys: [&str; 2], d: f64| -> f64 {
            // +(a || b || d)
            for k in keys {
                match info.get(k) {
                    Some(serde_json::Value::Number(n)) if n.as_f64().unwrap_or(0.0) != 0.0 => return n.as_f64().unwrap_or(d),
                    Some(serde_json::Value::String(s)) if !s.is_empty() => return s.trim().parse().unwrap_or(f64::NAN),
                    _ => {}
                }
            }
            d
        };
        self.raw_bpm = num(["_beatsPerMinute", "beatsPerMinute"], 60.0);
        self.raw_offset = num(["_songTimeOffset", "songTimeOffset"], 0.0);
        self.raw_info = payload.info.clone();
        self.raw_maps = payload.maps.iter().filter(|m| map::is_supported(&m.characteristic)).map(|m| (m.characteristic.clone(), m.difficulty.clone(), Arc::new(m.beatmap.clone()))).collect();
    }

    /// runGeneration({preservePlayback}) on a worker thread. The previous replay
    /// keeps drawing until the new one arrives (the JS version is synchronous).
    pub fn request_replay(&mut self) {
        let Some(entry) = self.raw_maps.iter().find(|(c, d, _)| *c == self.mode && *d == self.difficulty).or_else(|| self.raw_maps.first()).cloned() else {
            return;
        };
        self.replay_serial += 1;
        let serial = self.replay_serial;
        let (bpm, off, eye, dodge) = (self.raw_bpm, self.raw_offset, self.timing.eye_y, self.wall_dodge);
        let (tx, rx) = std::sync::mpsc::channel();
        std::thread::spawn(move || {
            let r = (|| -> Result<replay_sim::Replay, String> {
                let notes = replay_sim::map_notes(&entry.2, bpm, off);
                if notes.iter().filter(|n| n.c < 2.0).count() > 25000 {
                    return Err("Map exceeds 25,000 notes".into());
                }
                let duration = notes.iter().fold(2f64, |a, n| a.max(n.t)) + 2.3;
                let model = replay_sim::Model::shared().map_err(|e| e.to_string())?;
                let walls = replay_sim::map_walls(&entry.2, bpm, off);
                Ok(replay_sim::generate(model, &notes, duration, &walls, eye, dodge))
            })();
            let _ = tx.send((serial, (entry.0, entry.1), r));
        });
        self.replay_rx = Some(rx);
    }

    fn poll_replay(&mut self) {
        let Some(rx) = &self.replay_rx else { return };
        let Ok((serial, entry, r)) = rx.try_recv() else { return };
        self.replay_rx = None;
        if serial != self.replay_serial {
            return;
        }
        match r {
            Ok(r) => {
                self.replay_status = format!("Replay ready · {} notes · simulated score {}", r.events.len(), r.score);
                self.replay = Some(ReplayView::new(r, replay::Kind::Simulated, entry));
            }
            Err(e) => {
                log::warn!("replay: {e}");
                self.replay_status = e;
            }
        }
        self.await_first_pose = false;
        self.last_visual_time = -1.0;
        self.needs_redraw = true;
        self.try_autoplay();
    }

    /// openExternal(file): import a recorded BSOR for the loaded map.
    pub fn import_external(&mut self, bytes: &[u8], map_hash: Option<&str>) -> Result<String, String> {
        if self.embedded.is_none() {
            return Err("Load matching map ZIP first".into());
        }
        let ext = super::bsor::parse(bytes).map_err(|e| e.to_string())?;
        if let Some(h) = map_hash.filter(|h| !h.is_empty()) {
            if ext.text("hash").to_uppercase() != h.to_uppercase() {
                return Err("Replay map SHA-1 does not match loaded map".into());
            }
        }
        let (mode, diff) = (ext.text("mode"), ext.text("difficulty"));
        if self.raw_maps.iter().any(|(c, d, _)| *c == mode && *d == diff) {
            if self.mode != mode {
                self.mode = mode.clone();
            }
            self.load_difficulty(&diff);
        }
        let chosen = self
            .raw_maps
            .iter()
            .find(|(c, d, _)| *c == mode && *d == diff)
            .or_else(|| self.raw_maps.iter().find(|(c, d, _)| *c == self.mode && *d == self.difficulty))
            .or_else(|| self.raw_maps.first())
            .cloned();
        let mut r = ext.replay;
        let entry = chosen.as_ref().map(|(c, d, _)| (c.clone(), d.clone())).unwrap_or_default();
        if let Some((_, _, bm)) = &chosen {
            let walls = replay_sim::map_walls(bm, self.raw_bpm, self.raw_offset);
            let hits = replay_sim::count_wall_hits(&r.head.pos, r.times.len(), &walls, self.timing.eye_y);
            r.wall_stats = replay_sim::WallStats { before: hits, after: hits, wall_count: walls.len(), adjusted: 0 };
        }
        let msg = format!("BSOR imported · {} · {} recorded score", ext.info.get("playerName").and_then(|v| v.as_str()).unwrap_or(""), crate::util::thousands(r.score));
        self.replay_status = format!("Imported {} frames · {} hits · {} other events", r.times.len(), r.hit, r.miss);
        self.replay_serial += 1;
        self.replay_rx = None;
        self.replay = Some(ReplayView::new(r, replay::Kind::Recorded, entry));
        self.show_sabers = true;
        self.player.seek(0.0);
        self.last_visual_time = -1.0;
        self.needs_redraw = true;
        Ok(msg)
    }

    /// saveReplay(): encode the simulated replay of the current map as BSOR.
    pub fn export_bsor(&self, map_zip: &[u8]) -> Result<(String, Vec<u8>), String> {
        let rv = self.replay.as_ref().filter(|r| r.kind == replay::Kind::Simulated).ok_or("Could not generate simulated replay for this map")?;
        let hash = super::bsor::map_hash(map_zip).map_err(|e| e.to_string())?;
        let info = self.raw_info.clone();
        let model = replay_sim::Model::shared().map_err(|e| e.to_string())?;
        let meta = super::bsor::Meta { info: &info, difficulty: &rv.entry.1, characteristic: &rv.entry.0 };
        let bytes = super::bsor::pack(&meta, &rv.data, &hash, &model.info).map_err(|e| e.to_string())?;
        let check = super::bsor::parse(&bytes).map_err(|e| e.to_string())?;
        if check.replay.times.len() != rv.data.times.len() || check.replay.events.len() != rv.data.events.len() {
            return Err("Replay failed integrity check".into());
        }
        Ok((super::bsor::export_name(&info, &rv.entry.1), bytes))
    }

    /// True when a simulated replay for the current chart is ready (no generation running).
    pub fn simulated_ready(&self) -> bool {
        self.replay_rx.is_none() && self.replay.as_ref().is_some_and(|r| r.kind == replay::Kind::Simulated)
    }

    pub fn replay_pending(&self) -> bool {
        self.replay_rx.is_some()
    }

    /// SIMBERS6_VIEW_MODE: switch between Replay (HMD POV) and Map camera.
    pub fn set_replay_visible(&mut self, on: bool) {
        if self.replay_visible == on {
            return;
        }
        self.replay_visible = on;
        if on && self.replay.is_none() && self.replay_rx.is_none() && self.embedded.is_some() {
            self.request_replay();
        }
        if !on {
            self.await_first_pose = false;
            self.hmd = None;
        }
        self.last_visual_time = -1.0;
        self.needs_redraw = true;
    }

    /// Regenerate after a difficulty/mode change once a replay exists (els.difficulty change).
    fn regenerate_if_loaded(&mut self) {
        if self.replay.is_some() || self.replay_rx.is_some() || self.replay_visible {
            self.request_replay();
        }
    }

    pub fn set_wall_dodge(&mut self, on: bool) {
        self.wall_dodge = on;
        if matches!(self.replay.as_ref().map(|r| r.kind), Some(replay::Kind::Simulated)) {
            self.request_replay();
        }
    }

    /// Change difficulty from the dock (loadDifficulty + runGeneration).
    pub fn select_difficulty(&mut self, name: &str) {
        let eye_before = self.timing.eye_y;
        self.load_difficulty(name);
        self.regenerate_with_eye(eye_before);
    }

    fn regenerate_with_eye(&mut self, eye: f64) {
        // runGeneration reads CAMERA_EYE_Y before its own loadDifficulty().
        let cur = self.timing.eye_y;
        self.timing.eye_y = eye;
        self.regenerate_if_loaded();
        self.timing.eye_y = cur;
    }

    fn try_autoplay(&mut self) {
        if !self.autoplay || self.audio_rx.is_some() || (self.replay_visible && self.replay_rx.is_some()) {
            return;
        }
        self.autoplay = false;
        self.player.seek(0.0);
        // Visual-diff hook: SIMBERS_VIEWER_FREEZE=<seconds> opens paused there.
        match std::env::var("SIMBERS_VIEWER_FREEZE").ok().and_then(|v| v.parse::<f64>().ok()) {
            Some(t) => {
                self.player.seek(t);
                if let (Some(e), Some(a)) = (&self.embedded, &self.active) {
                    if is_360(&self.mode) {
                        self.camera_yaw = scene::target_360_yaw(a, &e.info, &self.timing, t);
                    }
                }
            }
            None => self.player.play(),
        }
        self.needs_redraw = true;
    }

    /// loadGeneratedPayload(payload)
    pub fn load(&mut self, payload: &ViewerPayload) {
        self.clear();
        self.max_playback = payload.max_duration_sec.filter(|d| *d > 0.0).unwrap_or(f64::INFINITY);
        let embedded = map::embed(payload);
        let pal = map::resolve_palette(None, &embedded.raw_info);
        self.colors = SceneColors::new(&map::SaberColors::left(&pal), &map::SaberColors::right(&pal));
        self.light_left = map::css_rgb01(&pal.light_left);
        self.light_right = map::css_rgb01(&pal.light_right);
        self.left_css = pal.left.clone();
        self.right_css = pal.right.clone();
        let total = payload.max_duration_sec.unwrap_or(0.0);
        self.highlights_cuts = payload.highlights_cuts.iter().copied().filter(|t| *t > 0.0 && *t < total).collect();
        self.cover = payload.cover_bytes.clone();
        // populateModes()
        let fallback = ["Standard", "90Degree", "360Degree", "OneSaber", "NoArrows"];
        self.mode = fallback
            .iter()
            .find(|m| embedded.mode_maps(m).is_some())
            .map(|m| m.to_string())
            .or_else(|| embedded.characteristics.first().map(|c| c.name.clone()))
            .unwrap_or_else(|| "Standard".into());
        if let Ok(m) = std::env::var("SIMBERS_VIEWER_MODE") {
            if embedded.mode_maps(&m).is_some() {
                self.mode = m; // visual-diff hook
            }
        }
        self.embedded = Some(embedded);
        self.difficulty = self.default_difficulty();
        self.load_difficulty(&self.difficulty.clone());
        self.store_raw(payload);
        // cyberPrewarmReplayFromPayload: the first visible frame is already in HMD POV.
        if self.replay_visible {
            self.await_first_pose = true;
            self.request_replay();
        }
        // Audio decodes off the UI thread; autoplay once it is ready.
        if let Some(bytes) = payload.audio_bytes.clone() {
            let ext = match payload.audio_mime.as_str() {
                "audio/mpeg" => "mp3",
                "audio/wav" | "audio/x-wav" => "wav",
                "audio/mp4" | "audio/aac" => "m4a",
                _ => "ogg",
            };
            let (tx, rx) = std::sync::mpsc::channel();
            std::thread::spawn(move || {
                let d = crate::audio::decode_bytes(&bytes, Some(ext)).map_err(|e| log::warn!("viewer audio decode: {e}")).ok();
                let _ = tx.send(d);
            });
            self.audio_rx = Some(rx);
            self.audio_loading = true;
            self.autoplay = true;
        }
    }

    /// Re-embed new maps for the same song (intensity change) keeping playback.
    pub fn update_maps(&mut self, payload: &ViewerPayload) {
        if self.embedded.is_none() {
            return self.load(payload);
        }
        let embedded = map::embed(payload);
        self.embedded = Some(embedded);
        if self.embedded.as_ref().unwrap().mode_maps(&self.mode).is_none() {
            let fallback = ["Standard", "90Degree", "360Degree", "OneSaber", "NoArrows"];
            if let Some(m) = fallback.iter().find(|m| self.embedded.as_ref().unwrap().mode_maps(m).is_some()) {
                self.mode = m.to_string();
            }
        }
        let d = self.difficulty.clone();
        self.load_difficulty(&d);
        self.store_raw(payload);
        if self.replay_visible {
            self.request_replay();
        }
    }

    /// Ordered (rank) difficulties that exist for the current mode.
    pub fn difficulties(&self) -> Vec<String> {
        let Some(e) = &self.embedded else { return vec![] };
        let Some(maps) = e.mode_maps(&self.mode) else { return vec![] };
        let mut meta: Vec<_> = e.characteristics.iter().find(|c| c.name == self.mode).map(|c| c.difficulties.clone()).unwrap_or_default();
        meta.sort_by(|a, b| a.rank.partial_cmp(&b.rank).unwrap_or(std::cmp::Ordering::Equal));
        let names: Vec<String> = if meta.is_empty() { maps.iter().map(|(d, _)| d.clone()).collect() } else { meta.into_iter().map(|m| m.difficulty).collect() };
        names.into_iter().filter(|n| maps.iter().any(|(d, _)| d == n)).collect()
    }

    pub fn modes(&self) -> Vec<String> {
        self.embedded.as_ref().map(|e| e.characteristics.iter().filter(|c| map::is_supported(&c.name)).map(|c| c.name.clone()).collect()).unwrap_or_default()
    }

    fn default_difficulty(&self) -> String {
        let Some(e) = &self.embedded else { return "ExpertPlus".into() };
        let maps = e.mode_maps(&self.mode);
        if maps.is_some_and(|m| m.iter().any(|(d, _)| d == "ExpertPlus")) {
            return "ExpertPlus".into();
        }
        let names = self.difficulties();
        names.last().cloned().or_else(|| maps.and_then(|m| m.first()).map(|(d, _)| d.clone())).unwrap_or_else(|| "ExpertPlus".into())
    }

    pub fn set_mode(&mut self, mode: &str) {
        let eye_before = self.timing.eye_y;
        self.mode = mode.to_string();
        self.difficulty = self.default_difficulty();
        let d = self.difficulty.clone();
        self.load_difficulty(&d);
        self.regenerate_with_eye(eye_before);
    }

    pub fn set_quality(&mut self, q: Quality) {
        self.quality = q;
        self.adaptive = 1.0;
        self.needs_redraw = true;
    }

    pub fn set_approach(&mut self, a: Approach) {
        self.approach = a;
        let d = self.difficulty.clone();
        self.load_difficulty(&d);
    }

    fn default_env(&self) -> bool {
        scene::uses_default_environment(&self.mode)
    }

    /// loadDifficulty(name)
    pub fn load_difficulty(&mut self, name: &str) {
        let Some(e) = &self.embedded else { return };
        let Some((diff, bm)) = scene::resolve_difficulty(e, &self.mode, name) else {
            self.active = None;
            self.env.clear();
            self.status = "No map loaded".into();
            return;
        };
        let diff = diff.to_string();
        let meta_njs = e.characteristics.iter().find(|c| c.name == self.mode).and_then(|c| c.difficulties.iter().find(|d| d.difficulty == diff)).map(|d| d.njs);
        let default_env = self.default_env();
        self.timing = Timing::compute(e.info.bpm, meta_njs, &diff, default_env, self.approach);
        let active = ActiveMap::from_beatmap(&self.mode, &diff, bm, &e.info);
        let t = self.player.current_time();
        self.camera_yaw = if is_360(&self.mode) { active.rotation_angle_for_time(t) } else { 0.0 };
        self.lighting.reset(t, &active.light_events, e.info.bpm, e.info.offset);
        if default_env {
            self.env.set_map(e.info.bpm, e.info.offset, &active.ring_events);
        } else {
            self.env.clear();
        }
        let dur = self.player.duration();
        self.nps = map::nps_stats(&active.color_notes, &e.info, if dur > 0.0 { Some(dur) } else { None });
        self.status = active.status_text();
        self.difficulty = diff;
        // rebuildHitQueue()
        let (bpm, offset) = (e.info.bpm, e.info.offset);
        let mut times: Vec<f64> = active.color_notes.iter().map(|n| n.b * 60.0 / bpm + offset).collect();
        times.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
        self.hits.clear();
        for t in times {
            if self.hits.last().is_none_or(|p| (p - t).abs() > 0.001) {
                self.hits.push(t);
            }
        }
        self.player.set_hits(self.hits.clone());
        self.last_playback_time = t;
        self.active = Some(active);
        self.needs_redraw = true;
    }

    pub fn duration(&self) -> f64 {
        self.player.duration()
    }

    /// --leftGlow/--rightGlow with their throttled --leftPulse/--rightPulse.
    pub fn glow(&self) -> ([f32; 3], f64, [f32; 3], f64) {
        (self.light_left, self.lighting.css.left, self.light_right, self.lighting.css.right)
    }

    pub fn camera_yaw(&self) -> f64 {
        self.camera_yaw
    }

    pub fn current_time(&self) -> f64 {
        let d = self.duration();
        let t = self.player.current_time();
        if d > 0.0 { t.min(d) } else { t }
    }

    pub fn playing(&self) -> bool {
        !self.player.paused() && !self.player.ended()
    }

    pub fn toggle_play(&mut self) {
        if self.playing() {
            self.player.pause();
        } else {
            self.player.play();
        }
        self.needs_redraw = true;
    }

    pub fn seek(&mut self, t: f64) {
        self.player.seek(t);
        self.needs_redraw = true;
    }

    pub fn set_speed(&mut self, r: f64) {
        self.player.set_rate(r.clamp(0.5, 2.0));
    }

    /// activeCameraFov()
    fn camera_fov(&self) -> f64 {
        2.0 * ((self.timing.fov_y / 2.0).tan() / self.user_zoom).atan()
    }

    /// effectiveRenderDpr()
    pub fn render_dpr(&self, device_dpr: f64) -> f64 {
        if self.quality.native() {
            return device_dpr;
        }
        let mut d = device_dpr.min(self.quality.render_scale().max(0.35));
        if self.default_env() {
            d = d.min(scene::DEFAULT_ENV_MAX_GAMEPLAY_DPR);
        }
        d * self.adaptive
    }

    fn poll_audio(&mut self) {
        let Some(rx) = &self.audio_rx else { return };
        if let Ok(d) = rx.try_recv() {
            self.audio_rx = None;
            self.audio_loading = false;
            self.player.load(d);
            self.player.set_hits(self.hits.clone());
            if let (Some(e), Some(a)) = (&self.embedded, &self.active) {
                let dur = self.player.duration();
                self.nps = map::nps_stats(&a.color_notes, &e.info, if dur > 0.0 { Some(dur) } else { None });
            }
            self.needs_redraw = true;
            self.try_autoplay();
        }
    }

    /// Per-frame tick. Returns true when the GPU texture was redrawn.
    pub fn frame(&mut self, rs: &eframe::egui_wgpu::RenderState, css_w: f64, css_h: f64, device_dpr: f64) -> bool {
        self.poll_audio();
        self.poll_replay();
        let now = Instant::now();
        self.fps_ticks += 1;
        if let Some(last) = self.last_rendered {
            if (now - last).as_secs_f64() * 1000.0 < FRAME_INTERVAL_MS - 0.35 {
                return false;
            }
        }
        self.last_rendered = Some(now);
        let dt = self.last_frame.map(|l| (now - l).as_secs_f64()).unwrap_or(0.016).clamp(0.001, 0.05);
        self.last_frame = Some(now);
        self.fps_frames += 1;
        let el = (now - self.fps_start).as_secs_f64() * 1000.0;
        if el >= 500.0 {
            self.displayed_fps = (self.fps_frames as f64 * 1000.0 / el).round();
            let hz = (self.fps_ticks as f64 * 1000.0 / el).round();
            self.display_hz = ((hz / 10.0).round() * 10.0).clamp(30.0, 120.0);
            self.fps_frames = 0;
            self.fps_ticks = 0;
            self.fps_start = now;
            self.update_adaptive(now);
            let ms = if self.displayed_fps > 0.0 { 1000.0 / self.displayed_fps } else { 0.0 };
            // egui only repaints on demand while paused; keep the last playing sample.
            if self.playing() || self.fps_text.is_empty() && self.displayed_fps > 1.0 {
                self.fps_text = format!("{} FPS · {:.1} ms · display {} Hz", self.displayed_fps, ms, hz);
            }
        }
        // maxViewerPlaybackSec
        if self.max_playback.is_finite() && self.player.current_time() >= self.max_playback && self.playing() {
            self.player.pause();
            self.player.seek(self.max_playback);
        }
        let t = self.current_time();
        let time_changed = (t - self.last_visual_time).abs() > 0.0001;
        let size_w = (css_w * self.render_dpr(device_dpr)).round().max(1.0) as u32;
        let size_h = (css_h * self.render_dpr(device_dpr)).round().max(1.0) as u32;
        if !self.playing() && !self.needs_redraw && !time_changed && self.gpu.is_some() {
            return false;
        }
        self.needs_redraw = false;
        self.last_visual_time = t;
        self.render(rs, t, dt, size_w, size_h, css_w, css_h, now);
        true
    }

    fn update_adaptive(&mut self, now: Instant) {
        if self.quality.native() {
            if self.adaptive != 1.0 {
                self.adaptive = 1.0;
                self.needs_redraw = true;
            }
            self.adaptive_drop = 0;
            self.adaptive_good = 0;
            return;
        }
        if (now - self.adaptive_last).as_millis() < 2200 || !self.playing() {
            return;
        }
        let target = MAX_RENDER_FPS.min(self.display_hz);
        if self.displayed_fps < target * 0.78 {
            self.adaptive_drop += 1;
            self.adaptive_good = 0;
        } else if self.displayed_fps >= target * 0.94 {
            self.adaptive_good += 1;
            self.adaptive_drop = 0;
        } else {
            self.adaptive_drop = 0;
            self.adaptive_good = 0;
        }
        let mut next = self.adaptive;
        if self.adaptive_drop >= 3 {
            next = (self.adaptive * 0.89).max(0.58);
            self.adaptive_drop = 0;
        } else if self.adaptive_good >= 5 {
            next = (self.adaptive + 0.07).min(1.0);
            self.adaptive_good = 0;
        }
        if (next - self.adaptive).abs() > 0.005 {
            self.adaptive = next;
            self.adaptive_last = now;
        }
    }

    pub fn texture_id(&self) -> Option<eframe::egui::TextureId> {
        self.gpu.as_ref().and_then(|g| g.texture_id())
    }

    #[allow(clippy::too_many_arguments)]
    fn render(&mut self, rs: &eframe::egui_wgpu::RenderState, t: f64, dt: f64, w: u32, h: u32, css_w: f64, css_h: f64, now: Instant) {
        if self.gpu.is_none() && !self.gpu_failed {
            let g = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| ViewerGpu::new(&rs.device, &rs.queue, &self.meshes.0, &self.meshes.1)));
            match g {
                Ok(g) => self.gpu = Some(g),
                Err(_) => {
                    self.gpu_failed = true;
                    log::error!("viewer: GPU pipeline creation failed");
                }
            }
        }
        let default_env = self.default_env();
        self.geometry.begin(self.group_count);
        let (Some(e), Some(active)) = (&self.embedded, &self.active) else {
            if let Some(gpu) = &mut self.gpu {
                let globals = Globals::default();
                gpu.render(rs, &self.geometry, &FrameParams { width: w, height: h, globals, mirror_strength: 0.0, env: None });
            }
            return;
        };
        // updateHitSounds: big jumps re-arm the audio thread's scheduler.
        if t < self.last_playback_time - 0.08 || t - self.last_playback_time > 0.75 {
            self.player.set_hits(self.hits.clone());
        }
        self.last_playback_time = t;
        let (bpm, offset) = (e.info.bpm, e.info.offset);
        let now_ms = (now - self.started).as_secs_f64() * 1000.0;
        self.lighting.update(t, dt, &active.light_events, bpm, offset, now_ms);
        // update360Camera
        if is_360(&self.mode) {
            let target = scene::target_360_yaw(active, &e.info, &self.timing, t);
            let delta = super::geom::wrap_degrees(target - self.camera_yaw);
            let eased = delta * (1.0 - (-6.2 * dt.max(0.001)).exp());
            let max_step = 220.0 * dt.max(0.001);
            self.camera_yaw += eased.clamp(-max_step, max_step);
        } else {
            self.camera_yaw = 0.0;
        }
        let input = SceneInput {
            t,
            info: &e.info,
            map: active,
            timing: &self.timing,
            colors: &self.colors,
            quality: self.quality,
            paused: !self.playing(),
            camera_yaw_deg: self.camera_yaw,
            block_meshes: &self.meshes.0,
            bomb_unit: &self.bomb_unit,
        };
        scene::build(&mut self.geometry, &input);

        // cyberUpdateHmdCamera + replayDraw
        let space = Space { default_env, near_z: self.timing.near_z, eye_y: self.timing.eye_y, view_angle: if is_360(&self.mode) { -self.camera_yaw } else { 0.0 } };
        self.hmd = None;
        if let (true, Some(rv)) = (self.replay_visible, &self.replay) {
            if default_env {
                self.hmd = rv.hmd_camera(t, &space, self.pov_back);
            }
            if self.show_sabers {
                let mobile = css_w.min(css_h) < 700.0;
                let steps = if self.displayed_fps > 0.0 && self.displayed_fps < 38.0 { 6 } else if mobile { 10 } else { 12 };
                let opts = replay::DrawOpts { trails: self.show_trails, headset: self.show_headset && self.hmd.is_none(), trail_steps: steps };
                replay::draw(&mut self.geometry, rv, t, space, &opts);
            }
        }
        let hmd = self.hmd;

        let fov = match hmd {
            Some(_) => replay::hmd_vertical_fov(css_w / css_h.max(1.0)),
            None => self.camera_fov(),
        };
        let env_u = if default_env {
            let st = EnvState {
                time: t,
                quality: self.quality,
                light: self.lighting.environment_state(),
                fov,
                canvas_w: w,
                canvas_h: h,
                camera: match hmd {
                    Some(h) => EnvCamera { pos: [h.x, h.y, h.world_z], yaw: h.yaw, pitch: h.pitch, roll: h.roll },
                    None => EnvCamera { pos: [0.0, self.timing.eye_y, scene::DEFAULT_ENV_CAMERA_Z], yaw: if is_360(&self.mode) { self.camera_yaw.to_radians() } else { 0.0 }, pitch: scene::CAMERA_PITCH, roll: 0.0 },
                },
            };
            Some(self.env.frame(&st, &self.geometry.casters))
        } else {
            None
        };
        let (lp, rp) = self.lighting.reflection_pulses();
        let far = if default_env { 9000.0 } else { 80f64.max(self.timing.far_z * 2.0) };
        let globals = Globals {
            proj: [(fov * 0.5).tan() as f32, (css_w / css_h.max(1.0)).max(0.001) as f32, 0.055, far as f32],
            eye: match hmd {
                Some(h) => [h.x as f32, h.y as f32, h.map_z as f32, h.yaw as f32],
                None => [0.0, self.timing.eye_y as f32, 0.0, 0.0],
            },
            cam: match hmd {
                Some(h) => [h.pitch as f32, h.roll as f32, self.quality.matcap_strength() as f32, t as f32],
                None => [scene::CAMERA_PITCH as f32, 0.0, self.quality.matcap_strength() as f32, t as f32],
            },
            env_left: [self.light_left[0], self.light_left[1], self.light_left[2], 0.0],
            env_right: [self.light_right[0], self.light_right[1], self.light_right[2], 0.0],
            env_pulse: [lp as f32, rp as f32, w as f32, h as f32],
        };
        let mirror_strength = if default_env { self.quality.floor_mirror_strength() as f32 } else { 0.0 };
        if let Some(gpu) = &mut self.gpu {
            gpu.render(rs, &self.geometry, &FrameParams { width: w, height: h, globals, mirror_strength, env: env_u.as_ref() });
        }
    }
}

pub fn is_360(mode: &str) -> bool {
    mode == "360Degree"
}
