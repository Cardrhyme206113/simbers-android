//! CPU side of the unified DefaultEnvironment renderer
//! (js/environment-renderer.js): ring spin/zoom animation, camera matrices,
//! floor-reflection caster selection and the uniform block for env.wgsl.

use super::Quality;
use super::geom::Caster;
use super::map::Event;

const ENV_FAR: f64 = 5.0;
const ENV_CLOSE: f64 = 2.0;
const ENV_SPIN_SPEED: f64 = 2.0;
const ENV_SMALL_ROT: f64 = 90.0;
const ENV_BIG_ROT: f64 = 45.0;
pub const DEFAULT_ENV_CAMERA_Z: f64 = -2.0;

#[derive(Clone, Copy, Debug)]
struct SpinEv {
    time: f64,
    start_angle: f64,
    target_angle: f64,
    start_step: f64,
    target_step: f64,
}

/// Uniform block shared with env.wgsl (std140-compatible layout).
#[repr(C)]
#[derive(Clone, Copy)]
pub struct EnvUniforms {
    pub vp: [f32; 16],
    pub cam: [f32; 4],
    pub view_dir: [f32; 4],
    pub modes: [i32; 4],
    pub p0: [f32; 4],
    pub p1: [f32; 4],
    pub p2: [f32; 4],
    pub mirror_pos: [[f32; 4]; 8],
    pub mirror_ext: [[f32; 4]; 8],
    pub mirror_col: [[f32; 4]; 8],
    pub mirror_rot: [[f32; 4]; 8],
    pub small_angles: [f32; 32],
    pub big_angles: [f32; 64],
}

impl Default for EnvUniforms {
    fn default() -> Self {
        // SAFETY-free zero init: every field is plain numeric data.
        EnvUniforms {
            vp: [0.0; 16],
            cam: [0.0; 4],
            view_dir: [0.0; 4],
            modes: [0; 4],
            p0: [0.0; 4],
            p1: [0.0; 4],
            p2: [0.0; 4],
            mirror_pos: [[0.0; 4]; 8],
            mirror_ext: [[0.0; 4]; 8],
            mirror_col: [[0.0; 4]; 8],
            mirror_rot: [[0.0; 4]; 8],
            small_angles: [0.0; 32],
            big_angles: [0.0; 64],
        }
    }
}

impl EnvUniforms {
    pub fn as_bytes(&self) -> &[u8] {
        // EnvUniforms is #[repr(C)] made only of 4-byte scalars: no padding.
        unsafe { std::slice::from_raw_parts((self as *const Self).cast::<u8>(), std::mem::size_of::<Self>()) }
    }
}

/// Camera pose the environment draws from (either the fixed spectator camera
/// or the replay HMD camera).
#[derive(Clone, Copy, Debug)]
pub struct EnvCamera {
    pub pos: [f64; 3],
    pub yaw: f64,
    pub pitch: f64,
    pub roll: f64,
}

pub struct EnvState {
    pub time: f64,
    pub quality: Quality,
    pub light: super::lighting::EnvLight,
    pub fov: f64,
    pub canvas_w: u32,
    pub canvas_h: u32,
    pub camera: EnvCamera,
}

pub struct Environment {
    bpm: f64,
    offset: f64,
    raw_spin: Vec<Event>,
    raw_zoom: Vec<Event>,
    small_events: Vec<SpinEv>,
    big_events: Vec<SpinEv>,
    has_map: bool,
    small_a: [f32; 30],
    big_a: [f32; 59],
    /// Values the GPU currently sees (updated only when a change exceeds the
    /// JS threshold, exactly like the per-vertex angle buffer upload).
    gpu_small: [f32; 30],
    gpu_big: [f32; 59],
    last_anim: f64,
    rings_neutral: bool,
}

impl Default for Environment {
    fn default() -> Self {
        Environment {
            bpm: 120.0,
            offset: 0.0,
            raw_spin: vec![],
            raw_zoom: vec![],
            small_events: vec![],
            big_events: vec![],
            has_map: false,
            small_a: [0.0; 30],
            big_a: [0.0; 59],
            gpu_small: [0.0; 30],
            gpu_big: [0.0; 59],
            last_anim: f64::NAN,
            rings_neutral: false,
        }
    }
}

fn env_prog(dt: f64) -> f64 {
    if dt <= 0.0 {
        return 0.0;
    }
    (1.0 - crate::util::jsm::pow(2.0, -dt * ENV_SPIN_SPEED * 2.0)).min(1.0)
}

fn lerp(a: f64, b: f64, t: f64) -> f64 {
    a + (b - a) * t
}

/// envHash: Math.imul based integer hash, returns the uint32 result.
fn env_hash(n: f64) -> u32 {
    let mut n = (if n.is_finite() { n.trunc() as i64 } else { 0 }) as u32;
    n ^= 0x9e37_79b9;
    n = (n ^ (n >> 16)).wrapping_mul(0x85eb_ca6b);
    n = (n ^ (n >> 13)).wrapping_mul(0xc2b2_ae35);
    n ^ (n >> 16)
}

/// JS `x | 0` for event types.
fn int32(x: f64) -> i32 {
    if x.is_finite() { (x.trunc() as i64) as i32 } else { 0 }
}

impl Environment {
    fn event_seconds(&self, e: &Event) -> f64 {
        (e.b * 60.0) / self.bpm.max(0.001) + self.offset
    }

    fn build_spin_events(&self, rot: f64) -> Vec<SpinEv> {
        let mut out: Vec<SpinEv> = Vec::with_capacity(self.raw_spin.len());
        for (i, q) in self.raw_spin.iter().enumerate() {
            let tm = self.event_seconds(q);
            let b = if q.b.is_nan() { 0.0 } else { q.b };
            let h = env_hash(crate::util::js_round(b * 1000.0) + (i as f64) * 131.0);
            let dir = if h & 1 == 1 { 1.0 } else { -1.0 };
            let step = (((h >> 8) % 1001) as f64 / 1000.0) * 10.0 - 5.0;
            let (mut st_a, mut st_s) = (0.0, 0.0);
            if let Some(prev) = out.last() {
                let pp = env_prog(tm - prev.time);
                st_a = lerp(prev.start_angle, prev.target_angle, pp);
                st_s = lerp(prev.start_step, prev.target_step, pp);
            }
            let target = out.last().map(|p| p.target_angle).unwrap_or(0.0) + dir * rot;
            out.push(SpinEv { time: tm, start_angle: st_a, target_angle: target, start_step: st_s, target_step: step });
        }
        out
    }

    fn rebuild_ring_events(&mut self) {
        self.raw_spin.sort_by(|a, b| a.b.partial_cmp(&b.b).unwrap_or(std::cmp::Ordering::Equal));
        self.raw_zoom.sort_by(|a, b| a.b.partial_cmp(&b.b).unwrap_or(std::cmp::Ordering::Equal));
        self.small_events = self.build_spin_events(ENV_SMALL_ROT);
        self.big_events = self.build_spin_events(ENV_BIG_ROT);
        self.last_anim = f64::NAN;
        self.rings_neutral = false;
    }

    /// setMap({bpm, offset, events: activeRingEvents})
    pub fn set_map(&mut self, bpm: f64, offset: f64, ring_events: &[Event]) {
        self.has_map = true;
        self.bpm = (if bpm == 0.0 || bpm.is_nan() { 120.0 } else { bpm }).max(0.001);
        self.offset = if offset.is_nan() { 0.0 } else { offset };
        self.raw_spin = ring_events.iter().copied().filter(|x| int32(x.t) == 8).collect();
        self.raw_zoom = ring_events.iter().copied().filter(|x| int32(x.t) == 9).collect();
        self.rebuild_ring_events();
    }

    pub fn clear(&mut self) {
        self.has_map = false;
        self.raw_spin.clear();
        self.raw_zoom.clear();
        self.rebuild_ring_events();
    }

    fn ring_angle_at(&self, t: f64, small: bool, id: usize) -> f64 {
        let evs = if small { &self.small_events } else { &self.big_events };
        if evs.is_empty() {
            return 0.0;
        }
        let target = t - id as f64 / 60.0;
        let lo = evs.partition_point(|e| e.time <= target);
        if lo == 0 {
            return 0.0;
        }
        let e = &evs[lo - 1];
        let q = env_prog(target - e.time);
        lerp(e.start_angle, e.target_angle, q) + lerp(e.start_step, e.target_step, q) * id as f64
    }

    fn zoom_at(&self, t: f64) -> f64 {
        if self.raw_zoom.is_empty() {
            return ENV_FAR;
        }
        let (mut prev_time, mut from, mut to, mut far) = (0.0, ENV_FAR, ENV_FAR, false);
        for z in &self.raw_zoom {
            let tm = self.event_seconds(z);
            if t < tm {
                break;
            }
            let p = env_prog(tm - prev_time);
            from = lerp(from, to, p);
            prev_time = tm;
            far = !far;
            to = if far { ENV_CLOSE } else { ENV_FAR };
        }
        lerp(from, to, env_prog(t - prev_time))
    }

    fn update_rings(&mut self, t: f64) {
        if self.last_anim.is_finite() && (t - self.last_anim).abs() < 0.00025 {
            return;
        }
        self.last_anim = t;
        if self.small_events.is_empty() && self.big_events.is_empty() {
            if self.rings_neutral {
                return;
            }
            self.small_a = [0.0; 30];
            self.big_a = [0.0; 59];
            self.gpu_small = [0.0; 30];
            self.gpu_big = [0.0; 59];
            self.rings_neutral = true;
            return;
        }
        self.rings_neutral = false;
        let mut changed = false;
        for id in 0..30 {
            let a = (self.ring_angle_at(t, true, id) * std::f64::consts::PI) / 180.0;
            if (a - self.small_a[id] as f64).abs() > 0.00006 {
                changed = true;
            }
            self.small_a[id] = a as f32;
        }
        for id in 0..59 {
            let a = (self.ring_angle_at(t, false, id) * std::f64::consts::PI) / 180.0;
            if (a - self.big_a[id] as f64).abs() > 0.00006 {
                changed = true;
            }
            self.big_a[id] = a as f32;
        }
        if changed {
            self.gpu_small = self.small_a;
            self.gpu_big = self.big_a;
        }
    }

    /// draw(state, floorReflectionNotes): returns the uniform block.
    pub fn frame(&mut self, st: &EnvState, casters: &[Caster]) -> EnvUniforms {
        let mut u = EnvUniforms::default();
        // Mirror caster selection.
        let quality_budget = st.quality.mirror_budget();
        let budget = quality_budget.min(((casters.len() as f64 * 0.9).ceil() as usize).max(1));
        let mut count = 0usize;
        if budget > 0 && !casters.is_empty() {
            let mut choices: Vec<Caster> = vec![];
            for o in casters {
                let z = o.z + DEFAULT_ENV_CAMERA_Z;
                if !(o.x + o.y + z).is_finite() || z < 4.0 || z > 120.0 {
                    continue;
                }
                choices.push(Caster { z, ..*o });
            }
            // Array.prototype.sort is stable.
            let mut idx: Vec<usize> = (0..choices.len()).collect();
            idx.sort_by(|&a, &b| choices[a].z.partial_cmp(&choices[b].z).unwrap_or(std::cmp::Ordering::Equal));
            let notes: Vec<usize> = idx.iter().copied().filter(|&i| choices[i].kind == 0.0 || choices[i].kind == 3.0).collect();
            let bomb = idx.iter().copied().find(|&i| choices[i].kind == 1.0);
            let wall = idx.iter().copied().find(|&i| choices[i].kind == 2.0);
            let mut picks: Vec<usize> = vec![];
            picks.extend(bomb);
            picks.extend(wall);
            for &o in &notes {
                if picks.len() >= budget {
                    break;
                }
                picks.push(o);
            }
            for &o in &idx {
                if picks.len() >= budget {
                    break;
                }
                if !picks.contains(&o) {
                    picks.push(o);
                }
            }
            picks.sort_by(|&a, &b| choices[a].z.partial_cmp(&choices[b].z).unwrap_or(std::cmp::Ordering::Equal));
            count = budget.min(picks.len());
            for (i, &p) in picks.iter().take(count).enumerate() {
                let o = &choices[p];
                u.mirror_pos[i] = [o.x as f32, o.y as f32, o.z as f32, o.kind as f32];
                u.mirror_ext[i] = [o.hx as f32, o.hy as f32, o.hz as f32, o.angle as f32];
                u.mirror_col[i] = [o.r as f32, o.g as f32, o.b as f32, o.opacity as f32];
                u.mirror_rot[i] = [crate::util::jsm::cos(o.angle) as f32, crate::util::jsm::sin(o.angle) as f32, 0.0, 0.0];
            }
        }

        let t = if st.time.is_nan() { 0.0 } else { st.time.max(0.0) };
        self.update_rings(t);
        let c = &st.camera;
        let proj = perspective(st.fov, st.canvas_w as f64 / (st.canvas_h.max(1)) as f64, 0.055, 9000.0);
        let view = look(c.pos, c.yaw, c.pitch, c.roll);
        u.vp = mul(&proj, &view);
        u.cam = [c.pos[0] as f32, c.pos[1] as f32, c.pos[2] as f32, 0.0];
        let cpv = crate::util::jsm::cos(c.pitch);
        u.view_dir = [
            (crate::util::jsm::sin(c.yaw) * cpv) as f32,
            crate::util::jsm::sin(c.pitch) as f32,
            (crate::util::jsm::cos(c.yaw) * cpv) as f32,
            self.zoom_at(t) as f32,
        ];
        u.modes = [st.light.scene_mode, st.light.ring_mode, count as i32, 0];
        // bright 0, rings 1, glow pass 0, glow strength 1
        u.p0 = [0.0, 1.0, 0.0, 1.0];
        u.p1 = [st.light.scene_amt.max(0.0) as f32, st.light.ring_amt.max(0.0) as f32, st.quality.env_quality_fx() as f32, t as f32];
        u.p2 = [if self.has_map { 0.0 } else { 1.0 }, 0.0, 0.0, 0.0];
        u.small_angles[..30].copy_from_slice(&self.gpu_small);
        u.big_angles[..59].copy_from_slice(&self.gpu_big);
        u
    }
}

/// perspective(fy, a, n, f) as a column-major Float32Array.
fn perspective(fy: f64, a: f64, n: f64, f: f64) -> [f32; 16] {
    let t = 1.0 / (fy / 2.0).tan();
    let nf = 1.0 / (n - f);
    [(t / a) as f32, 0.0, 0.0, 0.0, 0.0, t as f32, 0.0, 0.0, 0.0, 0.0, ((f + n) * nf) as f32, -1.0, 0.0, 0.0, (2.0 * f * n * nf) as f32, 0.0]
}

fn mul(a: &[f32; 16], b: &[f32; 16]) -> [f32; 16] {
    let mut o = [0f32; 16];
    for c in 0..4 {
        for r in 0..4 {
            o[c * 4 + r] = (a[r] as f64 * b[c * 4] as f64 + a[4 + r] as f64 * b[c * 4 + 1] as f64 + a[8 + r] as f64 * b[c * 4 + 2] as f64 + a[12 + r] as f64 * b[c * 4 + 3] as f64) as f32;
        }
    }
    o
}

fn look(e: [f64; 3], y: f64, p: f64, r: f64) -> [f32; 16] {
    use crate::util::jsm::{cos, sin};
    let cp = cos(p);
    let f = [sin(y) * cp, sin(p), cos(y) * cp];
    let (mut sx, mut sy, mut sz) = (f[2], 0.0, -f[0]);
    let sl = super::geom::hypot(&[sx, sz]);
    let sl = if sl == 0.0 || sl.is_nan() { 1.0 } else { sl };
    sx /= sl;
    sz /= sl;
    let (mut ux, mut uy, mut uz) = (sz * f[1], sx * f[2] - sz * f[0], -sx * f[1]);
    let (cr, sr) = (cos(r), sin(r));
    let s0 = [sx, sy, sz];
    let u0 = [ux, uy, uz];
    sx = s0[0] * cr + u0[0] * sr;
    sy = s0[1] * cr + u0[1] * sr;
    sz = s0[2] * cr + u0[2] * sr;
    ux = u0[0] * cr - s0[0] * sr;
    uy = u0[1] * cr - s0[1] * sr;
    uz = u0[2] * cr - s0[2] * sr;
    [
        sx as f32,
        ux as f32,
        -f[0] as f32,
        0.0,
        sy as f32,
        uy as f32,
        -f[1] as f32,
        0.0,
        sz as f32,
        uz as f32,
        -f[2] as f32,
        0.0,
        (-(sx * e[0] + sy * e[1] + sz * e[2])) as f32,
        (-(ux * e[0] + uy * e[1] + uz * e[2])) as f32,
        (f[0] * e[0] + f[1] * e[1] + f[2] * e[2]) as f32,
        1.0,
    ]
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn hash_matches_js() {
        // Reference values from the JS envHash in Node.
        let got: Vec<u32> = [0.0, 1000.0, 131.0, -5.0, 123456789.0].iter().map(|&n| env_hash(n)).collect();
        assert_eq!(got, vec![2462723854, 1438098670, 3014685165, 2095690390, 3077212414]);
    }
}
