//! Viewer audio: the `<audio>` element (playbackRate with preservesPitch) and
//! the ArcViewer hitsound scheduler (drawing-primitives.js scheduleOneArcHit /
//! rebuildHitQueue), rendered by one cpal output stream.
//!
//! Music at speed != 1 goes through a WSOLA time-stretcher (pitch kept, like
//! `preservesPitch = true`). Hitsounds are mixed in song time: the buffer index
//! is `songTime - (hitTime - 0.185)`, i.e. they play with playbackRate = speed,
//! exactly as the Web Audio sources do.

use crate::audio::Decoded;
use cpal::traits::{DeviceTrait, HostTrait, StreamTrait};
use parking_lot::Mutex;
use std::sync::Arc;
use std::time::Instant;

static HITSOUND_RAW: &[u8] = include_bytes!("../../assets/viewer/arc_hitsound_48k_f32.raw");
const HIT_RATE: f64 = 48000.0;
pub const ARC_HITSOUND_OFFSET: f64 = 0.185;

/// WSOLA frame (output samples), hop and search tolerance.
const W: usize = 2048;
const HS: usize = W / 2;
const TOL: i64 = 384;

struct Stretch {
    /// Source read position (source samples) of the next analysis frame.
    in_pos: f64,
    /// Natural continuation of the previously used frame (source samples).
    prev_nat: Option<f64>,
    ola: Vec<[f32; 2]>,
    ready: std::collections::VecDeque<[f32; 2]>,
    window: Vec<f32>,
}

impl Stretch {
    fn new() -> Self {
        let window = (0..W).map(|n| (0.5 - 0.5 * (2.0 * std::f64::consts::PI * n as f64 / W as f64).cos()) as f32).collect();
        Stretch { in_pos: 0.0, prev_nat: None, ola: vec![[0.0; 2]; W], ready: Default::default(), window }
    }
    fn reset(&mut self, src_pos: f64) {
        self.in_pos = src_pos;
        self.prev_nat = None;
        self.ola.iter_mut().for_each(|s| *s = [0.0; 2]);
        self.ready.clear();
    }
}

struct Shared {
    music: Option<Arc<Decoded>>,
    hits: Arc<Vec<f64>>,
    hit_pcm: Arc<Vec<[f32; 2]>>,
    playing: bool,
    ended: bool,
    rate: f64,
    /// Song time of the next output sample.
    song: f64,
    /// Song time when playback (re)started; hits that were already too close are skipped.
    armed_from: f64,
    /// Direct (rate 1) read position in source samples.
    direct_pos: f64,
    stretch: Stretch,
    stretching: bool,
    /// Clock: song time at the start of the last rendered block and when it was rendered.
    clock_song: f64,
    clock_end: f64,
    clock_at: Option<Instant>,
}

pub struct Player {
    shared: Arc<Mutex<Shared>>,
    started: bool,
    stop: Option<std::sync::mpsc::Sender<()>>,
}

impl Default for Player {
    fn default() -> Self {
        Self::new()
    }
}

fn hit_pcm() -> Vec<[f32; 2]> {
    HITSOUND_RAW.chunks_exact(8).map(|c| [f32::from_le_bytes([c[0], c[1], c[2], c[3]]), f32::from_le_bytes([c[4], c[5], c[6], c[7]])]).collect()
}

impl Player {
    pub fn new() -> Player {
        let shared = Shared {
            music: None,
            hits: Arc::new(vec![]),
            hit_pcm: Arc::new(hit_pcm()),
            playing: false,
            ended: false,
            rate: 1.0,
            song: 0.0,
            armed_from: 0.0,
            direct_pos: 0.0,
            stretch: Stretch::new(),
            stretching: false,
            clock_song: 0.0,
            clock_end: 0.0,
            clock_at: None,
        };
        Player { shared: Arc::new(Mutex::new(shared)), started: false, stop: None }
    }

    /// Opens the output device on a dedicated thread (cpal streams are not Send everywhere).
    fn ensure_stream(&mut self) {
        if self.started {
            return;
        }
        self.started = true;
        let shared = self.shared.clone();
        let (tx, rx) = std::sync::mpsc::channel::<()>();
        self.stop = Some(tx);
        std::thread::Builder::new()
            .name("viewer-audio".into())
            .spawn(move || {
                let host = cpal::default_host();
                let Some(device) = host.default_output_device() else {
                    log::warn!("viewer audio: no output device");
                    return;
                };
                let Ok(cfg) = device.default_output_config() else {
                    log::warn!("viewer audio: no output config");
                    return;
                };
                let format = cfg.sample_format();
                let config: cpal::StreamConfig = cfg.into();
                let stream = match format {
                    cpal::SampleFormat::F32 => build::<f32>(&device, &config, shared),
                    cpal::SampleFormat::I16 => build::<i16>(&device, &config, shared),
                    cpal::SampleFormat::U16 => build::<u16>(&device, &config, shared),
                    other => {
                        log::warn!("viewer audio: unsupported sample format {other:?}");
                        return;
                    }
                };
                match stream {
                    Ok(s) => {
                        if let Err(e) = s.play() {
                            log::warn!("viewer audio: play failed: {e}");
                        }
                        let _ = rx.recv();
                        drop(s);
                    }
                    Err(e) => log::warn!("viewer audio: stream failed: {e}"),
                }
            })
            .ok();
    }

    pub fn load(&mut self, music: Option<Decoded>) {
        self.ensure_stream();
        let mut s = self.shared.lock();
        s.music = music.map(Arc::new);
        s.playing = false;
        s.ended = false;
        s.song = 0.0;
        s.direct_pos = 0.0;
        s.stretch.reset(0.0);
        s.clock_song = 0.0;
        s.clock_end = 0.0;
        s.clock_at = None;
    }

    pub fn clear(&mut self) {
        let mut s = self.shared.lock();
        s.music = None;
        s.playing = false;
        s.hits = Arc::new(vec![]);
        s.song = 0.0;
        s.clock_song = 0.0;
        s.clock_at = None;
    }

    pub fn has_music(&self) -> bool {
        self.shared.lock().music.is_some()
    }

    /// sortedSoundHits (song seconds, deduplicated within 1 ms).
    pub fn set_hits(&self, hits: Vec<f64>) {
        let mut s = self.shared.lock();
        s.hits = Arc::new(hits);
        s.armed_from = s.song;
    }

    pub fn duration(&self) -> f64 {
        self.shared.lock().music.as_ref().map(|m| m.duration()).unwrap_or(0.0)
    }

    pub fn play(&mut self) {
        self.ensure_stream();
        let mut s = self.shared.lock();
        if s.music.is_none() {
            return;
        }
        let dur = s.music.as_ref().map(|m| m.duration()).unwrap_or(0.0);
        if s.ended || s.song >= dur {
            let t = 0.0;
            seek_locked(&mut s, t);
        }
        s.playing = true;
        s.ended = false;
        s.armed_from = s.song;
        s.clock_song = s.song;
        s.clock_end = s.song;
        s.clock_at = None;
    }

    pub fn pause(&self) {
        let mut s = self.shared.lock();
        if s.playing {
            let t = current_locked(&s);
            s.playing = false;
            seek_locked(&mut s, t);
        }
    }

    pub fn paused(&self) -> bool {
        !self.shared.lock().playing
    }

    pub fn ended(&self) -> bool {
        self.shared.lock().ended
    }

    pub fn seek(&self, t: f64) {
        let mut s = self.shared.lock();
        let dur = s.music.as_ref().map(|m| m.duration()).unwrap_or(0.0);
        seek_locked(&mut s, t.clamp(0.0, dur.max(0.0)));
        s.ended = false;
    }

    pub fn rate(&self) -> f64 {
        self.shared.lock().rate
    }

    pub fn set_rate(&self, r: f64) {
        let mut s = self.shared.lock();
        let t = current_locked(&s);
        s.rate = r;
        seek_locked(&mut s, t);
    }

    /// els.audio.currentTime
    pub fn current_time(&self) -> f64 {
        current_locked(&self.shared.lock())
    }
}

impl Drop for Player {
    fn drop(&mut self) {
        if let Some(tx) = self.stop.take() {
            let _ = tx.send(());
        }
    }
}

fn current_locked(s: &Shared) -> f64 {
    if !s.playing {
        return s.song;
    }
    match s.clock_at {
        Some(at) => (s.clock_song + at.elapsed().as_secs_f64() * s.rate).min(s.clock_end),
        None => s.clock_song,
    }
}

fn seek_locked(s: &mut Shared, t: f64) {
    let rate = s.music.as_ref().map(|m| m.sample_rate).unwrap_or(44100.0);
    s.song = t;
    s.direct_pos = t * rate;
    s.stretch.reset(t * rate);
    s.armed_from = t;
    s.clock_song = t;
    s.clock_end = t;
    s.clock_at = None;
}

fn build<T>(device: &cpal::Device, config: &cpal::StreamConfig, shared: Arc<Mutex<Shared>>) -> Result<cpal::Stream, cpal::BuildStreamError>
where
    T: cpal::SizedSample + cpal::FromSample<f32>,
{
    let channels = config.channels as usize;
    let dev_rate = config.sample_rate.0 as f64;
    let mut block: Vec<[f32; 2]> = vec![];
    device.build_output_stream(
        config,
        move |data: &mut [T], _info: &cpal::OutputCallbackInfo| {
            let frames = data.len() / channels.max(1);
            block.resize(frames, [0.0; 2]);
            {
                let mut s = shared.lock();
                render(&mut s, &mut block, dev_rate);
            }
            for (f, out) in data.chunks_mut(channels.max(1)).enumerate() {
                let [l, r] = block[f];
                for (c, v) in out.iter_mut().enumerate() {
                    let x = match (channels, c) {
                        (1, _) => (l + r) * 0.5,
                        (_, 0) => l,
                        (_, 1) => r,
                        _ => 0.0,
                    };
                    *v = T::from_sample(x.clamp(-1.0, 1.0));
                }
            }
        },
        |e| log::warn!("viewer audio stream error: {e}"),
        None,
    )
}

fn sample_at(m: &Decoded, pos: f64) -> [f32; 2] {
    if pos < 0.0 {
        return [0.0; 2];
    }
    let i = pos.floor() as usize;
    let frac = (pos - i as f64) as f32;
    let len = m.len();
    if i + 1 >= len {
        return [0.0; 2];
    }
    let ch = |c: usize| {
        let d = &m.channels[c.min(m.channels.len() - 1)];
        d[i] + (d[i + 1] - d[i]) * frac
    };
    [ch(0), ch(1)]
}

fn mono_at(m: &Decoded, pos: f64) -> f32 {
    let s = sample_at(m, pos);
    s[0] + s[1]
}

fn render(s: &mut Shared, block: &mut [[f32; 2]], dev_rate: f64) {
    block.iter_mut().for_each(|x| *x = [0.0; 2]);
    let Some(music) = s.music.clone() else { return };
    if !s.playing {
        return;
    }
    let start_song = s.song;
    let step = music.sample_rate / dev_rate; // source samples per output sample at rate 1
    let dur = music.duration();
    let n = block.len();
    if (s.rate - 1.0).abs() < 1e-9 {
        if s.stretching {
            s.direct_pos = s.song * music.sample_rate;
            s.stretching = false;
        }
        for out in block.iter_mut() {
            *out = sample_at(&music, s.direct_pos);
            s.direct_pos += step;
        }
        s.song = s.direct_pos / music.sample_rate;
    } else {
        if !s.stretching {
            s.stretch.reset(s.song * music.sample_rate);
            s.stretching = true;
        }
        let rate = s.rate;
        let st = &mut s.stretch;
        let mut produced = 0;
        while produced < n {
            if let Some(v) = st.ready.pop_front() {
                block[produced] = v;
                produced += 1;
                continue;
            }
            // Pick the analysis frame closest in waveform to the natural continuation.
            let mut chosen = st.in_pos;
            if let Some(nat) = st.prev_nat {
                let mut best = f32::MIN;
                let mut best_d = 0i64;
                let mut d = -TOL;
                while d <= TOL {
                    let cand = st.in_pos + d as f64 * step;
                    let mut acc = 0.0f32;
                    let mut k = 0;
                    while k < HS {
                        acc += mono_at(&music, cand + k as f64 * step) * mono_at(&music, nat + k as f64 * step);
                        k += 8;
                    }
                    if acc > best {
                        best = acc;
                        best_d = d;
                    }
                    d += 4;
                }
                chosen = st.in_pos + best_d as f64 * step;
            }
            for k in 0..W {
                let v = sample_at(&music, chosen + k as f64 * step);
                let w = st.window[k];
                st.ola[k][0] += v[0] * w;
                st.ola[k][1] += v[1] * w;
            }
            for k in 0..HS {
                st.ready.push_back(st.ola[k]);
            }
            st.ola.copy_within(HS.., 0);
            for k in W - HS..W {
                st.ola[k] = [0.0; 2];
            }
            st.prev_nat = Some(chosen + HS as f64 * step);
            st.in_pos += HS as f64 * step * rate;
        }
        s.song += n as f64 * rate / dev_rate;
    }

    // Hitsounds, indexed by song time.
    let hits = s.hits.clone();
    let pcm = s.hit_pcm.clone();
    let hit_len = pcm.len() as f64 / HIT_RATE;
    let end_song = start_song + n as f64 * s.rate / dev_rate;
    let lo = hits.partition_point(|h| *h < start_song - hit_len);
    let per = s.rate / dev_rate;
    for &h in hits[lo..].iter() {
        let pre = h - ARC_HITSOUND_OFFSET;
        if pre > end_song {
            break;
        }
        if h - s.armed_from <= 0.002 * s.rate {
            continue; // scheduleOneArcHit: too late to schedule
        }
        // Started inside the pre-roll: Web Audio starts at the hit with offset 0.185.
        let begin = if pre < s.armed_from { h } else { pre };
        for (k, out) in block.iter_mut().enumerate() {
            let song = start_song + k as f64 * per;
            if song < begin {
                continue;
            }
            let idx = (song - pre) * HIT_RATE;
            let i = idx.floor() as usize;
            if i + 1 >= pcm.len() {
                break;
            }
            let f = (idx - i as f64) as f32;
            out[0] += pcm[i][0] + (pcm[i + 1][0] - pcm[i][0]) * f;
            out[1] += pcm[i][1] + (pcm[i + 1][1] - pcm[i][1]) * f;
        }
    }

    s.clock_song = start_song;
    s.clock_end = s.song;
    s.clock_at = Some(Instant::now());
    if s.song >= dur {
        s.playing = false;
        s.ended = true;
        s.song = dur;
    }
}
