//! core/zip-reader.js — bounded stored/deflate ZIP reader (same checks and errors).

use anyhow::{Result, bail};
use std::collections::HashMap;

pub struct Limits {
    pub max_archive_bytes: usize,
    pub max_entries: usize,
    pub max_entry_bytes: usize,
    pub max_total_bytes: usize,
}

impl Default for Limits {
    fn default() -> Self {
        Self { max_archive_bytes: 256 << 20, max_entries: 400, max_entry_bytes: 160 << 20, max_total_bytes: 384 << 20 }
    }
}

#[derive(Clone, Debug)]
pub struct Entry {
    pub name: String,
    method: u16,
    compressed: usize,
    plain: usize,
    start: usize,
}

pub struct ZipReader<'a> {
    bytes: &'a [u8],
    by_name: HashMap<String, usize>,
    pub files: Vec<Entry>,
    max_entry_bytes: usize,
}

impl<'a> ZipReader<'a> {
    pub fn new(bytes: &'a [u8], lim: Limits) -> Result<Self> {
        if bytes.len() > lim.max_archive_bytes {
            bail!("Map ZIP is too large to import safely.");
        }
        if bytes.len() < 22 {
            bail!("Map ZIP is incomplete.");
        }
        let u16_at = |o: usize| -> usize { if o + 2 <= bytes.len() { u16::from_le_bytes([bytes[o], bytes[o + 1]]) as usize } else { 0 } };
        let u32_at = |o: usize| -> usize { if o + 4 <= bytes.len() { u32::from_le_bytes([bytes[o], bytes[o + 1], bytes[o + 2], bytes[o + 3]]) as usize } else { 0 } };
        let mut eocd: Option<usize> = None;
        let lo = bytes.len().saturating_sub(65557);
        let mut p = bytes.len() - 22;
        loop {
            if u32_at(p) == 0x06054b50 && p + 22 + u16_at(p + 20) <= bytes.len() {
                eocd = Some(p);
                break;
            }
            if p == lo {
                break;
            }
            p -= 1;
        }
        let Some(eocd) = eocd else { bail!("Map ZIP has no valid central directory.") };
        let count = u16_at(eocd + 10);
        let dir_len = u32_at(eocd + 12);
        let dir_start = u32_at(eocd + 16);
        if count > lim.max_entries || count == 0 || count == 0xffff || dir_len == 0xffff_ffff || dir_start == 0xffff_ffff || dir_start > eocd || dir_len > eocd - dir_start {
            bail!("Map ZIP has an unsupported or oversized directory.");
        }
        let mut by_name = HashMap::new();
        let mut files = Vec::with_capacity(count);
        let mut offset = dir_start;
        let mut total = 0usize;
        for _ in 0..count {
            if offset + 46 > eocd || u32_at(offset) != 0x02014b50 {
                bail!("Map ZIP contains a damaged directory entry.");
            }
            let flags = u16_at(offset + 8);
            let method = u16_at(offset + 10) as u16;
            let compressed = u32_at(offset + 20);
            let plain = u32_at(offset + 24);
            let nl = u16_at(offset + 28);
            let el = u16_at(offset + 30);
            let cl = u16_at(offset + 32);
            let local = u32_at(offset + 42);
            let end = offset + 46 + nl + el + cl;
            if end > dir_start + dir_len || end > bytes.len() || local + 30 > bytes.len() || u32_at(local) != 0x04034b50 {
                bail!("Map ZIP has an invalid file offset.");
            }
            if flags & 1 != 0 {
                bail!("Encrypted ZIP files are unsupported.");
            }
            if compressed == 0xffff_ffff || plain == 0xffff_ffff || local == 0xffff_ffff {
                bail!("ZIP64 archives are unsupported.");
            }
            if plain > lim.max_entry_bytes {
                bail!("Map ZIP contains an oversized entry.");
            }
            total += plain;
            if total > lim.max_total_bytes {
                bail!("Map ZIP expands beyond the memory limit.");
            }
            let name = String::from_utf8_lossy(&bytes[offset + 46..offset + 46 + nl]).into_owned();
            let normalized = name.replace('\\', "/");
            let drive = normalized.len() >= 2 && normalized.as_bytes()[0].is_ascii_alphabetic() && normalized.as_bytes()[1] == b':';
            if name.is_empty() || normalized.starts_with('/') || drive || normalized.chars().any(|c| (c as u32) < 0x20) || normalized.split('/').any(|p| p == "..") {
                bail!("Map ZIP contains an unsafe filename.");
            }
            let key = normalized.to_lowercase();
            if by_name.contains_key(&key) {
                bail!("Map ZIP has duplicate filenames.");
            }
            let data_start = local + 30 + u16_at(local + 26) + u16_at(local + 28);
            if data_start > bytes.len() || compressed > bytes.len() - data_start {
                bail!("Map ZIP contains a truncated entry.");
            }
            by_name.insert(key, files.len());
            files.push(Entry { name: normalized, method, compressed, plain, start: data_start });
            offset = end;
        }
        if offset != dir_start + dir_len {
            bail!("Map ZIP has inconsistent directory length.");
        }
        Ok(Self { bytes, by_name, files, max_entry_bytes: lim.max_entry_bytes })
    }

    fn read_entry(&self, e: &Entry) -> Result<Vec<u8>> {
        let packed = &self.bytes[e.start..e.start + e.compressed];
        match e.method {
            0 => {
                if packed.len() != e.plain {
                    bail!("Map ZIP stored entry is corrupt.");
                }
                Ok(packed.to_vec())
            }
            8 => {
                let limit = e.plain.min(self.max_entry_bytes);
                let out = miniz_oxide::inflate::decompress_to_vec_with_limit(packed, limit + 1).map_err(|err| {
                    if matches!(err.status, miniz_oxide::inflate::TINFLStatus::HasMoreOutput) {
                        anyhow::anyhow!("Map ZIP entry exceeds its declared uncompressed size.")
                    } else {
                        anyhow::anyhow!("Map ZIP has a corrupted compressed entry.")
                    }
                })?;
                if out.len() > limit {
                    bail!("Map ZIP entry exceeds its declared uncompressed size.");
                }
                if out.len() != e.plain {
                    bail!("Map ZIP has a corrupted compressed entry.");
                }
                Ok(out)
            }
            m => bail!("Unsupported ZIP compression method {m}."),
        }
    }

    /// get(filename): case-insensitive, also matches a single enclosing folder.
    pub fn get(&self, filename: &str) -> Result<Option<Vec<u8>>> {
        let n = filename.replace('\\', "/");
        let n = n.strip_prefix("./").unwrap_or(&n).to_lowercase();
        if n.is_empty() || n.split('/').any(|p| p == "..") {
            bail!("Invalid map file reference.");
        }
        let idx = self.by_name.get(&n).copied().or_else(|| {
            let suffix = format!("/{n}");
            self.files.iter().position(|f| f.name.to_lowercase().ends_with(&suffix))
        });
        match idx {
            Some(i) => Ok(Some(self.read_entry(&self.files[i])?)),
            None => Ok(None),
        }
    }
}
