//! storage/history.js — "Past Jobs" archive. The browser stores records with
//! ZIP/audio/cover Blobs in IndexedDB (or OPFS); natively each record is a
//! folder: <data>/history/<id>/{record.json, map.zip, audio.bin, cover.png}.

use super::kv::data_dir;
use anyhow::{Result, bail};
use serde::{Deserialize, Serialize};
use serde_json::Value;
use std::path::PathBuf;

/// PAST_JOBS_MAX
pub const MAX_JOBS: usize = 25;

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct JobRecord {
    pub id: String,
    pub created_at: f64,
    pub name: String,
    pub zip_name: String,
    #[serde(default)]
    pub youtube_source: Option<Value>,
    pub zip_size: u64,
    pub audio_name: String,
    pub audio_type: String,
    pub audio_size: u64,
    #[serde(default)]
    pub nps: Option<f64>,
    #[serde(default)]
    pub note_count: Option<u64>,
    #[serde(default)]
    pub duration: f64,
    #[serde(default = "hundred")]
    pub intensity: f64,
}

fn hundred() -> f64 {
    100.0
}

/// In-progress row (in memory only; only finished ZIPs enter persistent history).
#[derive(Clone, Debug)]
pub struct PendingJob {
    pub id: String,
    pub generation_id: u64,
    pub name: String,
    pub created_at: f64,
    pub audio_size: u64,
    pub stage: String,
    pub cover: Option<Vec<u8>>,
    pub duration: f64,
}

fn root() -> PathBuf {
    data_dir().join("history")
}

/// pastJobsOpfsKey
fn key(id: &str) -> Result<&str> {
    if id.is_empty() || id.len() > 128 || !id.bytes().all(|b| b.is_ascii_alphanumeric() || b == b'_' || b == b'-') {
        bail!("Invalid map archive identifier.");
    }
    Ok(id)
}

fn job_dir(id: &str) -> Result<PathBuf> {
    Ok(root().join(key(id)?))
}

/// pastJobsId (crypto.randomUUID equivalent, v4).
pub fn new_id() -> String {
    let mut b = [0u8; 16];
    let seed = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_nanos()).unwrap_or(0);
    let mut x = seed as u64 ^ ((seed >> 64) as u64) ^ (std::process::id() as u64).rotate_left(32) ^ (&b as *const _ as u64);
    for byte in &mut b {
        // splitmix64
        x = x.wrapping_add(0x9E37_79B9_7F4A_7C15);
        let mut z = x;
        z = (z ^ (z >> 30)).wrapping_mul(0xBF58_476D_1CE4_E5B9);
        z = (z ^ (z >> 27)).wrapping_mul(0x94D0_49BB_1331_11EB);
        *byte = (z ^ (z >> 31)) as u8;
    }
    b[6] = (b[6] & 0x0f) | 0x40;
    b[8] = (b[8] & 0x3f) | 0x80;
    let h: String = b.iter().map(|v| format!("{v:02x}")).collect();
    format!("{}-{}-{}-{}-{}", &h[0..8], &h[8..12], &h[12..16], &h[16..20], &h[20..32])
}

/// pastJobsSize
pub fn size_text(bytes: f64) -> String {
    if !bytes.is_finite() || bytes < 0.0 {
        return "—".into();
    }
    if bytes >= 1_048_576.0 {
        format!("{} MB", crate::util::to_fixed(bytes / 1_048_576.0, 1))
    } else {
        format!("{} KB", 1f64.max(crate::util::js_round(bytes / 1024.0)))
    }
}

/// m:ss duration used in the cards.
pub fn duration_text(d: f64) -> String {
    if d.is_finite() && d > 0.0 { format!("{}:{:02}", (d / 60.0).floor(), (d % 60.0).floor() as u64) } else { String::new() }
}

/// pastJobsReadAll (newest first).
pub fn read_all() -> Result<Vec<JobRecord>> {
    let mut jobs = vec![];
    let Ok(rd) = std::fs::read_dir(root()) else { return Ok(jobs) };
    for e in rd.flatten() {
        let p = e.path().join("record.json");
        if let Ok(text) = std::fs::read_to_string(&p) {
            if let Ok(r) = serde_json::from_str::<JobRecord>(&text) {
                if key(&r.id).is_ok() && e.path().join("map.zip").exists() {
                    jobs.push(r);
                }
            }
        }
    }
    jobs.sort_by(|a, b| b.created_at.partial_cmp(&a.created_at).unwrap_or(std::cmp::Ordering::Equal));
    Ok(jobs)
}

pub struct SaveInput<'a> {
    pub record: JobRecord,
    pub zip: &'a [u8],
    pub audio: &'a [u8],
    pub cover: &'a [u8],
}

/// store.put(record) — written to a temp folder, then renamed into place.
pub fn put(input: SaveInput) -> Result<()> {
    let dir = job_dir(&input.record.id)?;
    let tmp = root().join(format!(".tmp-{}", input.record.id));
    let _ = std::fs::remove_dir_all(&tmp);
    std::fs::create_dir_all(&tmp)?;
    std::fs::write(tmp.join("map.zip"), input.zip)?;
    std::fs::write(tmp.join("audio.bin"), input.audio)?;
    std::fs::write(tmp.join("cover.png"), input.cover)?;
    std::fs::write(tmp.join("record.json"), serde_json::to_vec_pretty(&input.record)?)?;
    let _ = std::fs::remove_dir_all(&dir);
    std::fs::rename(&tmp, &dir)?;
    Ok(())
}

/// pastJobsEnqueueSave: put + prune, evicting the oldest jobs on a full disk.
pub fn save(input: SaveInput) -> Result<()> {
    let id = input.record.id.clone();
    let zip = input.zip.to_vec();
    let audio = input.audio.to_vec();
    let cover = input.cover.to_vec();
    let record = input.record.clone();
    match put(input) {
        Ok(()) => prune(),
        Err(err) => {
            let full = err.downcast_ref::<std::io::Error>().is_some_and(|e| e.kind() == std::io::ErrorKind::StorageFull || e.raw_os_error() == Some(112));
            if !full {
                return Err(err);
            }
            let mut older: Vec<_> = read_all()?.into_iter().filter(|j| j.id != id).collect();
            older.reverse();
            let mut last = err;
            for old in older {
                delete(&old.id)?;
                match put(SaveInput { record: record.clone(), zip: &zip, audio: &audio, cover: &cover }) {
                    Ok(()) => return prune(),
                    Err(e) => last = e,
                }
            }
            Err(last)
        }
    }
}

/// pastJobsPrune
pub fn prune() -> Result<()> {
    let jobs = read_all()?;
    for j in jobs.iter().skip(MAX_JOBS) {
        delete(&j.id)?;
    }
    Ok(())
}

pub fn delete(id: &str) -> Result<()> {
    let d = job_dir(id)?;
    if d.exists() {
        std::fs::remove_dir_all(d)?;
    }
    Ok(())
}

pub fn clear() -> Result<()> {
    for j in read_all()? {
        delete(&j.id)?;
    }
    Ok(())
}

pub fn read_zip(id: &str) -> Result<Vec<u8>> {
    std::fs::read(job_dir(id)?.join("map.zip")).map_err(|_| anyhow::anyhow!("This job has no saved map ZIP."))
}

pub fn read_audio(id: &str) -> Option<Vec<u8>> {
    std::fs::read(job_dir(id).ok()?.join("audio.bin")).ok()
}

pub fn read_cover(id: &str) -> Option<Vec<u8>> {
    std::fs::read(job_dir(id).ok()?.join("cover.png")).ok()
}

/// pastJobsZipToViewerPayload for a saved record.
pub fn viewer_payload(job: &JobRecord) -> Result<crate::payload::ViewerPayload> {
    let zip = read_zip(&job.id)?;
    let audio = read_audio(&job.id).map(|b| (b, job.audio_type.clone()));
    crate::payload::from_zip(&zip, audio, read_cover(&job.id))
}

/// Writes the archived source audio to a temp file named like the original so
/// "Reprocess" can feed it back through the normal file pipeline.
pub fn materialize_audio(job: &JobRecord) -> Result<PathBuf> {
    let bytes = read_audio(&job.id).ok_or_else(|| anyhow::anyhow!("This job has no archived source audio."))?;
    let dir = std::env::temp_dir().join("SimplifiedSabers").join(key(&job.id)?);
    std::fs::create_dir_all(&dir)?;
    let name: String = job.audio_name.chars().map(|c| if r#"\/:*?"<>|"#.contains(c) || (c as u32) < 0x20 { '_' } else { c }).collect();
    let path = dir.join(if name.is_empty() { "song.mp3".to_string() } else { name });
    std::fs::write(&path, bytes)?;
    Ok(path)
}
