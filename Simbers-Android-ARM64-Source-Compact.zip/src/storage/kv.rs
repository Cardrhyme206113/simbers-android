//! localStorage replacement: a small JSON key/value file in the app data folder.
use parking_lot::Mutex;
use std::collections::BTreeMap;
use std::path::PathBuf;
use std::sync::LazyLock;

pub fn data_dir() -> PathBuf {
    #[cfg(target_os = "android")]
    let base = crate::platform::data_dir();
    #[cfg(not(target_os = "android"))]
    let base = dirs::data_dir().unwrap_or_else(|| PathBuf::from("."));
    let dir = base.join("SimplifiedSabers");
    let _ = std::fs::create_dir_all(&dir);
    dir
}

fn store_path() -> PathBuf {
    data_dir().join("local-storage.json")
}

static STORE: LazyLock<Mutex<BTreeMap<String, String>>> = LazyLock::new(|| {
    let map = std::fs::read_to_string(store_path())
        .ok()
        .and_then(|s| serde_json::from_str::<BTreeMap<String, String>>(&s).ok())
        .unwrap_or_default();
    Mutex::new(map)
});

pub fn get(key: &str) -> Option<String> {
    STORE.lock().get(key).cloned()
}

pub fn set(key: &str, value: &str) -> bool {
    let mut s = STORE.lock();
    s.insert(key.to_string(), value.to_string());
    let text = serde_json::to_string_pretty(&*s).unwrap_or_default();
    let tmp = store_path().with_extension("tmp");
    std::fs::write(&tmp, text).is_ok() && std::fs::rename(&tmp, store_path()).is_ok()
}
