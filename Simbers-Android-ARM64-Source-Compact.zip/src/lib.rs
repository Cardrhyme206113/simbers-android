//! Android library entry point; the existing native CLI remains in main.rs.
pub mod analysis;
pub mod audio;
pub mod export;
pub mod job;
pub mod mapgen;
pub mod payload;
pub mod pipeline;
pub mod platform;
pub mod settings;
pub mod storage;
pub mod ui;
pub mod util;
pub mod viewer;
pub mod youtube;

#[cfg(target_os = "android")]
#[unsafe(no_mangle)]
pub fn android_main(app: winit::platform::android::activity::AndroidApp) {
    android_logger::init_once(
        android_logger::Config::default().with_max_level(log::LevelFilter::Info)
    );
    platform::initialize(app.clone());
    if let Err(e) = ui::run_android(app) {
        log::error!("Simbers Android failed: {e:#}");
    }
}
