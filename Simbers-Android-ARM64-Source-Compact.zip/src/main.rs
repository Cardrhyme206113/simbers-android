//! Simplified Sabers — native Rust port.

pub mod analysis;
pub mod audio;
pub mod export;
pub mod job;
pub mod mapgen;
pub mod payload;
pub mod platform;
pub mod pipeline;
pub mod settings;
pub mod storage;
pub mod ui;
pub mod util;
pub mod viewer;
pub mod youtube;

use parking_lot::Mutex;
use std::sync::Arc;

fn main() -> anyhow::Result<()> {
    let args: Vec<String> = std::env::args().collect();
    if args.len() < 2 || args[1] == "ui" {
        return ui::run(args.get(2).map(std::path::PathBuf::from));
    }
    if args.len() >= 3 && args[1] == "replay-dump" {
        // Debug: simulated replay summary for numeric comparison with the JS simulator.
        use viewer::replay_sim as rs;
        let zip = std::fs::read(&args[2])?;
        let p = payload::from_zip(&zip, None, None)?;
        let m = p.maps.iter().find(|m| m.characteristic == "Standard" && m.difficulty == "ExpertPlus").unwrap_or(&p.maps[0]);
        let jsnum = |k: &[&str], d: f64| k.iter().find_map(|k| p.info.get(*k).and_then(|v| v.as_f64()).filter(|v| *v != 0.0)).unwrap_or(d);
        let bpm = jsnum(&["_beatsPerMinute", "beatsPerMinute"], 60.0);
        let off = jsnum(&["_songTimeOffset", "songTimeOffset"], 0.0);
        let notes = rs::map_notes(&m.beatmap, bpm, off);
        let dur = notes.iter().fold(2f64, |a, n| a.max(n.t)) + 2.3;
        let walls = rs::map_walls(&m.beatmap, bpm, off);
        let eye: f64 = args.get(3).and_then(|s| s.parse().ok()).unwrap_or(viewer::scene::DEFAULT_ENV_CAMERA_Y);
        let model = rs::Model::load()?;
        let t0 = std::time::Instant::now();
        let r = rs::generate(&model, &notes, dur, &walls, eye, true);
        eprintln!("generate {:?}", t0.elapsed());
        let pick = |v: &[f32], w: usize| -> Vec<f32> { [0usize, 100, 1000, r.times.len() / 2, r.times.len() - 1].iter().flat_map(|&i| v[i * w..i * w + w].to_vec()).collect() };
        let out = serde_json::json!({
            "n": r.times.len(), "score": r.score, "hit": r.hit, "miss": r.miss, "maxCombo": r.max_combo, "events": r.events.len(),
            "walls": [r.wall_stats.before, r.wall_stats.after, r.wall_stats.wall_count, r.wall_stats.adjusted],
            "lp": pick(&r.left.pos, 3), "lr": pick(&r.left.rot, 4), "rp": pick(&r.right.pos, 3), "rr": pick(&r.right.rot, 4),
            "hp": pick(&r.head.pos, 3), "hr": pick(&r.head.rot, 4),
            "ev": r.events.iter().take(5).map(|e| serde_json::json!([e.id, e.t, e.kind, e.points, e.cumulative])).collect::<Vec<_>>(),
        });
        println!("{out}");
        let hash = viewer::bsor::map_hash(&zip)?;
        let meta = viewer::bsor::Meta { info: &p.info, difficulty: &m.difficulty, characteristic: &m.characteristic };
        let bytes = viewer::bsor::pack(&meta, &r, &hash, &model.info)?;
        println!("{{\"hash\":\"{hash}\",\"bsorLen\":{},\"bsorSha\":\"{}\",\"name\":\"{}\"}}", bytes.len(), viewer::bsor::sha1_hex_upper(&bytes), viewer::bsor::export_name(&p.info, &m.difficulty));
        let back = viewer::bsor::parse(&bytes)?;
        println!("roundtrip frames {} events {} score {} hit {} miss {} maxCombo {} player {}", back.replay.times.len(), back.replay.events.len(), back.replay.score, back.replay.hit, back.replay.miss, back.replay.max_combo, back.text("playerName"));
        return Ok(());
    }
    if args.len() >= 2 && args[1] == "gen" {
        let input = std::path::PathBuf::from(args.get(2).ok_or_else(|| anyhow::anyhow!("usage: simbers gen <audio> [out.zip] [intensity%] [full|highlights|clip]"))?);
        let intensity: f64 = args.get(4).and_then(|s| s.parse().ok()).unwrap_or(100.0);
        let timing = Arc::new(Mutex::new(Some(job::TimingProfile::new(&export::safe_base_name(input.file_name().and_then(|n| n.to_str()).unwrap_or("song")), 0.0))));
        let last = Arc::new(Mutex::new(String::new()));
        let l2 = last.clone();
        let progress: job::ProgressFn = Arc::new(move |v, text| {
            if let Some(t) = text {
                let mut l = l2.lock();
                if *l != t {
                    eprintln!("[{:>5.1}%] {t}", v * 100.0);
                    *l = t;
                }
            }
        });
        let job = job::Job::new(progress, timing.clone());
        let features = mapgen::FeatureOptions { bombs: true, walls: true, arcs: true, bot_optimizer: true };
        let started = util::now_ms();
        // [mode]: full | highlights | clip (only matters past audio.highlightsMinutes)
        let mode = args.get(5).and_then(|s| pipeline::LongSongMode::parse(s)).unwrap_or(pipeline::LongSongMode::Full);
        let opts = pipeline::RunOptions { intensity, features, mode, youtube: None };
        let r = pipeline::run_file(&input, &opts, &job)?;
        let (built, a, zip) = (&r.built, &r.analysis, &r.zip);
        if let Some(p) = &r.highlights {
            eprintln!("highlights: {} sections, {:.1}s → {:.1}s", p.sections.len(), p.source_duration, p.duration);
        }
        let out = args.get(3).map(std::path::PathBuf::from).unwrap_or_else(|| std::path::PathBuf::from(format!("{}_SimplifiedSabers.zip", built.song_name)));
        std::fs::write(&out, zip)?;
        eprintln!(
            "done in {:.1}s · {:.1}s audio · {} events · E+ {:.2} NPS · {} → {}",
            (util::now_ms() - started) / 1000.0,
            a.duration,
            a.patterns.segments.len(),
            built.expert_plus_nps,
            out.display(),
            zip.len()
        );
        eprintln!("{}", job::format_profile(timing.lock().as_ref()));
        if std::env::var("SIMBERS_NO_HISTORY").is_err() {
            let size = std::fs::metadata(&input).map(|m| m.len()).unwrap_or(0);
            let rec = pipeline::history_record(&r, &input, size, intensity, None, util::epoch_ms());
            let audio = std::fs::read(&input)?;
            match storage::history::save(storage::history::SaveInput { record: rec, zip, audio: &audio, cover: &built.cover }) {
                Ok(()) => eprintln!("saved to Past Jobs"),
                Err(e) => eprintln!("Couldn't save map: {e}"),
            }
        }
        return Ok(());
    }
    if args.len() >= 4 && args[1] == "yt-cover" {
        let src = youtube::Source { id: args[2].clone(), title: String::new(), author: String::new() };
        let url = format!("https://i.ytimg.com/vi/{}/hqdefault.jpg", args[2]);
        let img = youtube::fetch_image(&url, 4500);
        eprintln!("fetched: {:?} bytes", img.as_ref().map(|b| b.len()));
        if let Some(b) = &img {
            eprintln!("decoded: {:?}", youtube::decode_jpeg(b).map(|(w, h, p)| (w, h, p.len())));
        }
        std::fs::write(&args[3], youtube::square_cover(&src)?)?;
        return Ok(());
    }
    if args.len() >= 3 && args[1] == "yt" {
        // simbers yt "<query or URL>" [pick#]  → search, import (built-in yt-dlp), generate
        let never = || false;
        let hits = youtube::search(&args[2], &never)?;
        for (i, h) in hits.iter().enumerate() {
            println!("{i}: {} — {} [{}]", h.title, h.author, youtube::duration_text(h.length));
        }
        let Some(pick) = args.get(3).and_then(|s| s.parse::<usize>().ok()) else { return Ok(()) };
        let hit = hits.get(pick).ok_or_else(|| anyhow::anyhow!("no such result"))?;
        let mut last = String::new();
        let mut status = |m: String| {
            if m != last {
                eprintln!("{m}");
                last = m;
            }
        };
        let imp = match youtube::import(hit, &never, &mut status) {
            Ok(imp) => imp,
            Err(f) => {
                eprintln!("{}", f.report);
                return Err(f.into());
            }
        };
        eprintln!("{}
", imp.report);
        let timing = Arc::new(Mutex::new(Some(job::TimingProfile::new(&imp.source.title, 0.0))));
        let progress: job::ProgressFn = Arc::new(|_, _| {});
        let job = job::Job::new(progress, timing.clone());
        let features = mapgen::FeatureOptions { bombs: true, walls: true, arcs: true, bot_optimizer: true };
        let opts = pipeline::RunOptions { intensity: 100.0, features, mode: pipeline::LongSongMode::Full, youtube: Some(imp.source.clone()) };
        let r = pipeline::run_file(&imp.path, &opts, &job)?;
        let out = format!("{}_SimplifiedSabers.zip", r.built.song_name);
        std::fs::write(&out, &r.zip)?;
        eprintln!("map → {out} ({} bytes), E+ {:.2} NPS", r.zip.len(), r.built.expert_plus_nps);
        return Ok(());
    }
    if args.len() >= 2 && args[1] == "history" {
        match args.get(2).map(String::as_str) {
            Some("delete") => storage::history::delete(args.get(3).map(String::as_str).unwrap_or(""))?,
            Some("clear") => storage::history::clear()?,
            _ => {}
        }
        for j in storage::history::read_all()? {
            println!(
                "{}  {}  {}  {} ZIP  {} AUDIO  {}  {}",
                j.id,
                j.name,
                j.nps.map(|n| format!("EXPERT+ {} NPS", util::to_fixed(n, 2))).unwrap_or_default(),
                storage::history::size_text(j.zip_size as f64),
                storage::history::size_text(j.audio_size as f64),
                j.note_count.map(|n| format!("{n} NOTES")).unwrap_or_default(),
                storage::history::duration_text(j.duration),
            );
        }
        return Ok(());
    }
    if args.len() >= 3 && args[1] == "inspect" {
        let zip = std::fs::read(&args[2])?;
        let p = payload::from_zip(&zip, None, None)?;
        for c in &p.characteristics {
            println!("{}: {}", c.name, c.difficulties.iter().map(|d| format!("{}(njs {})", d.difficulty, d.njs)).collect::<Vec<_>>().join(", "));
        }
        println!("maps {} · audio {} ({} bytes) · cover {} bytes", p.maps.len(), p.audio_mime, p.audio_bytes.as_ref().map_or(0, |a| a.len()), p.cover_bytes.as_ref().map_or(0, |a| a.len()));
        return Ok(());
    }
    println!("usage: simbers gen <audio> [out.zip] [intensity%] [full|highlights|clip]");
    Ok(())
}
