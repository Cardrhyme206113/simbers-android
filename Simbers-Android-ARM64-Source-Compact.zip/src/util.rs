//! JavaScript-compatible numeric helpers. Every function mirrors the exact
//! semantics of the original browser code so generation stays bit-close.

use std::fmt::Write as _;

pub const PI: f64 = std::f64::consts::PI;

/// FNV-1a over UTF-16 code units (`hashString` in note-patterns.js).
#[inline]
pub fn hash_string(value: &str) -> u32 {
    let mut h: u32 = 2166136261;
    for unit in value.encode_utf16() {
        h ^= unit as u32;
        h = h.wrapping_mul(16777619);
    }
    h
}

#[inline]
pub fn clamp(x: f64, a: f64, b: f64) -> f64 {
    // Math.max(a, Math.min(b, x)) incl. NaN propagation like JS.
    if x.is_nan() || a.is_nan() || b.is_nan() {
        return f64::NAN;
    }
    a.max(b.min(x))
}

#[inline]
pub fn sigmoid(x: f64) -> f64 {
    1.0 / (1.0 + libm::exp(-x))
}

/// `median` from core/math.js (sorted copy, mean of middle two when even).
pub fn median(arr: &[f64]) -> f64 {
    let n = arr.len();
    if n == 0 {
        return f64::NAN; // JS: (undefined + undefined) / 2 => NaN
    }
    let mut a = arr.to_vec();
    a.sort_by(|x, y| x.partial_cmp(y).unwrap_or(std::cmp::Ordering::Equal));
    if n % 2 == 1 { a[n >> 1] } else { (a[(n >> 1) - 1] + a[n >> 1]) / 2.0 }
}

pub fn median_f32(arr: &[f32]) -> f64 {
    let n = arr.len();
    if n == 0 {
        return f64::NAN;
    }
    let mut a = arr.to_vec();
    a.sort_by(|x, y| x.partial_cmp(y).unwrap_or(std::cmp::Ordering::Equal));
    if n % 2 == 1 { a[n >> 1] as f64 } else { (a[(n >> 1) - 1] as f64 + a[n >> 1] as f64) / 2.0 }
}

/// JS `Math.round` (round half up toward +inf).
#[inline]
pub fn js_round(x: f64) -> f64 {
    (x + 0.5).floor()
}

/// `x.toFixed(f)` as a string, following the ECMAScript tie rule (pick the
/// larger n, i.e. half away from zero on the exact binary value).
pub fn to_fixed(x: f64, f: usize) -> String {
    if !x.is_finite() {
        return if x.is_nan() { "NaN".into() } else if x > 0.0 { "Infinity".into() } else { "-Infinity".into() };
    }
    if x.abs() >= 1e21 {
        return js_num_to_string(x);
    }
    let neg = x < 0.0;
    let ax = x.abs();
    let wide = format!("{:.*}", f + 25, ax);
    let dot = wide.find('.').unwrap();
    let tail = &wide[dot + 1 + f..];
    let tie = tail.as_bytes()[0] == b'5' && tail.as_bytes()[1..].iter().all(|&c| c == b'0');
    let mut s = if tie {
        // Round half up on the exact value.
        let scaled = format!("{:.*}", f, ax + 0.5 * 10f64.powi(-(f as i32)));
        // Guard: if adding introduced error, fall back to manual increment.
        manual_round_up(&wide[..dot + 1 + f], f).unwrap_or(scaled)
    } else {
        format!("{:.*}", f, ax)
    };
    if neg && s.bytes().any(|c| c.is_ascii_digit() && c != b'0') {
        s.insert(0, '-');
    } else if neg {
        // JS: (-0.00001).toFixed(2) => "-0.00"
        s.insert(0, '-');
    }
    s
}

fn manual_round_up(truncated: &str, f: usize) -> Option<String> {
    let mut digits: Vec<u8> = truncated.bytes().filter(|c| *c != b'.').collect();
    let mut i = digits.len();
    loop {
        if i == 0 {
            digits.insert(0, b'1');
            break;
        }
        i -= 1;
        if digits[i] == b'9' {
            digits[i] = b'0';
        } else {
            digits[i] += 1;
            break;
        }
    }
    let int_len = digits.len() - f;
    let mut out = String::from_utf8(digits[..int_len].to_vec()).ok()?;
    if f > 0 {
        out.push('.');
        out.push_str(std::str::from_utf8(&digits[int_len..]).ok()?);
    }
    Some(out)
}

/// `+x.toFixed(f)`
#[inline]
pub fn to_fixed_num(x: f64, f: usize) -> f64 {
    if !x.is_finite() {
        return x;
    }
    let s = to_fixed(x, f);
    let v: f64 = s.parse().unwrap_or(f64::NAN);
    if v == 0.0 { 0.0 } else { v }
}

/// ECMAScript Number::toString(10).
pub fn js_num_to_string(v: f64) -> String {
    if v.is_nan() {
        return "NaN".into();
    }
    if v == 0.0 {
        return "0".into();
    }
    if v.is_infinite() {
        return if v > 0.0 { "Infinity".into() } else { "-Infinity".into() };
    }
    let mut out = String::new();
    if v < 0.0 {
        out.push('-');
    }
    let mut buf = ryu::Buffer::new();
    let s = buf.format_finite(v.abs());
    let (mant, exp) = match s.find('e') {
        Some(i) => (&s[..i], s[i + 1..].parse::<i32>().unwrap()),
        None => (s, 0),
    };
    let int_len = mant.find('.').unwrap_or(mant.len()) as i32;
    let mut digits: Vec<u8> = mant.bytes().filter(|c| *c != b'.').collect();
    let mut lead = 0;
    while lead < digits.len() - 1 && digits[lead] == b'0' {
        lead += 1;
    }
    digits.drain(..lead);
    while digits.len() > 1 && *digits.last().unwrap() == b'0' {
        digits.pop();
    }
    let k = digits.len() as i32;
    let n = int_len + exp - lead as i32;
    let ds = std::str::from_utf8(&digits).unwrap();
    if k <= n && n <= 21 {
        out.push_str(ds);
        for _ in 0..(n - k) {
            out.push('0');
        }
    } else if 0 < n && n <= 21 {
        out.push_str(&ds[..n as usize]);
        out.push('.');
        out.push_str(&ds[n as usize..]);
    } else if -6 < n && n <= 0 {
        out.push_str("0.");
        for _ in 0..(-n) {
            out.push('0');
        }
        out.push_str(ds);
    } else {
        let e = n - 1;
        out.push_str(&ds[..1]);
        if k > 1 {
            out.push('.');
            out.push_str(&ds[1..]);
        }
        let _ = write!(out, "e{}{}", if e >= 0 { "+" } else { "-" }, e.abs());
    }
    out
}

/// JS-faithful `JSON.stringify` for serde_json values.
pub mod json {
    use super::js_num_to_string;
    use serde_json::Value;

    fn is_array_index(k: &str) -> Option<u32> {
        if k.is_empty() || k.len() > 10 {
            return None;
        }
        if k != "0" && k.starts_with('0') {
            return None;
        }
        if !k.bytes().all(|c| c.is_ascii_digit()) {
            return None;
        }
        let v: u64 = k.parse().ok()?;
        if v < u32::MAX as u64 { Some(v as u32) } else { None }
    }

    fn ordered_keys(map: &serde_json::Map<String, Value>) -> Vec<&String> {
        let mut ints: Vec<(u32, &String)> = Vec::new();
        let mut rest: Vec<&String> = Vec::new();
        for k in map.keys() {
            match is_array_index(k) {
                Some(i) => ints.push((i, k)),
                None => rest.push(k),
            }
        }
        ints.sort_by_key(|(i, _)| *i);
        let mut out: Vec<&String> = ints.into_iter().map(|(_, k)| k).collect();
        out.extend(rest);
        out
    }

    pub fn escape_into(out: &mut String, s: &str) {
        out.push('"');
        for ch in s.chars() {
            match ch {
                '"' => out.push_str("\\\""),
                '\\' => out.push_str("\\\\"),
                '\u{08}' => out.push_str("\\b"),
                '\u{0c}' => out.push_str("\\f"),
                '\n' => out.push_str("\\n"),
                '\r' => out.push_str("\\r"),
                '\t' => out.push_str("\\t"),
                c if (c as u32) < 0x20 => {
                    out.push_str(&format!("\\u{:04x}", c as u32));
                }
                c => out.push(c),
            }
        }
        out.push('"');
    }

    fn num(out: &mut String, n: &serde_json::Number) {
        if let Some(i) = n.as_i64() {
            out.push_str(&i.to_string());
        } else if let Some(u) = n.as_u64() {
            out.push_str(&u.to_string());
        } else {
            let f = n.as_f64().unwrap_or(f64::NAN);
            if f.is_finite() { out.push_str(&js_num_to_string(f)) } else { out.push_str("null") }
        }
    }

    fn write(out: &mut String, v: &Value, indent: Option<usize>, depth: usize) {
        match v {
            Value::Null => out.push_str("null"),
            Value::Bool(b) => out.push_str(if *b { "true" } else { "false" }),
            Value::Number(n) => num(out, n),
            Value::String(s) => escape_into(out, s),
            Value::Array(a) => {
                if a.is_empty() {
                    out.push_str("[]");
                    return;
                }
                out.push('[');
                for (i, item) in a.iter().enumerate() {
                    if i > 0 {
                        out.push(',');
                    }
                    if let Some(w) = indent {
                        out.push('\n');
                        for _ in 0..(depth + 1) * w {
                            out.push(' ');
                        }
                    }
                    write(out, item, indent, depth + 1);
                }
                if let Some(w) = indent {
                    out.push('\n');
                    for _ in 0..depth * w {
                        out.push(' ');
                    }
                }
                out.push(']');
            }
            Value::Object(m) => {
                if m.is_empty() {
                    out.push_str("{}");
                    return;
                }
                out.push('{');
                for (i, k) in ordered_keys(m).into_iter().enumerate() {
                    if i > 0 {
                        out.push(',');
                    }
                    if let Some(w) = indent {
                        out.push('\n');
                        for _ in 0..(depth + 1) * w {
                            out.push(' ');
                        }
                    }
                    escape_into(out, k);
                    out.push(':');
                    if indent.is_some() {
                        out.push(' ');
                    }
                    write(out, &m[k.as_str()], indent, depth + 1);
                }
                if let Some(w) = indent {
                    out.push('\n');
                    for _ in 0..depth * w {
                        out.push(' ');
                    }
                }
                out.push('}');
            }
        }
    }

    pub fn stringify(v: &Value) -> String {
        let mut s = String::with_capacity(4096);
        write(&mut s, v, None, 0);
        s
    }

    pub fn stringify_pretty(v: &Value) -> String {
        let mut s = String::with_capacity(4096);
        write(&mut s, v, Some(2), 0);
        s
    }
}

/// Build a JSON number from an f64, using an integer representation when the
/// value is integral (so output matches JS which has no int/float split).
#[inline]
pub fn jnum(x: f64) -> serde_json::Value {
    if x.is_finite() && x.fract() == 0.0 && x.abs() < 9.0e15 {
        let i = x as i64;
        if i == 0 {
            return serde_json::Value::from(0i64);
        }
        serde_json::Value::from(i)
    } else if x.is_finite() {
        serde_json::Number::from_f64(x).map(serde_json::Value::Number).unwrap_or(serde_json::Value::Null)
    } else {
        serde_json::Value::Null
    }
}

/// JS `Number(value)` coercion for settings values.
pub fn js_number(v: &serde_json::Value) -> f64 {
    use serde_json::Value;
    match v {
        Value::Null => 0.0,
        Value::Bool(b) => {
            if *b { 1.0 } else { 0.0 }
        }
        Value::Number(n) => n.as_f64().unwrap_or(f64::NAN),
        Value::String(s) => {
            let t = s.trim();
            if t.is_empty() { 0.0 } else { t.parse::<f64>().unwrap_or(f64::NAN) }
        }
        Value::Array(a) => match a.len() {
            0 => 0.0,
            1 => js_number(&a[0]),
            _ => f64::NAN,
        },
        Value::Object(_) => f64::NAN,
    }
}

/// JS `Boolean(value)`
pub fn js_truthy(v: &serde_json::Value) -> bool {
    use serde_json::Value;
    match v {
        Value::Null => false,
        Value::Bool(b) => *b,
        Value::Number(n) => {
            let f = n.as_f64().unwrap_or(0.0);
            f != 0.0 && !f.is_nan()
        }
        Value::String(s) => !s.is_empty(),
        _ => true,
    }
}

/// Minimal performance.now() equivalent in milliseconds.
pub fn now_ms() -> f64 {
    use std::sync::OnceLock;
    use std::time::Instant;
    static START: OnceLock<Instant> = OnceLock::new();
    START.get_or_init(Instant::now).elapsed().as_secs_f64() * 1000.0
}

/// Wall-clock milliseconds since the Unix epoch (Date.now()).
pub fn date_now_ms() -> f64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_millis() as f64)
        .unwrap_or(0.0)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn numbers() {
        assert_eq!(js_num_to_string(1.0), "1");
        assert_eq!(js_num_to_string(0.1 + 0.2), "0.30000000000000004");
        assert_eq!(js_num_to_string(0.000001), "0.000001");
        assert_eq!(js_num_to_string(1e-7), "1e-7");
        assert_eq!(js_num_to_string(1e21), "1e+21");
        assert_eq!(js_num_to_string(123456.789), "123456.789");
        assert_eq!(js_num_to_string(-2.5), "-2.5");
        assert_eq!(to_fixed(0.125, 2), "0.13");
        assert_eq!(to_fixed(1.005, 2), "1.00");
        assert_eq!(to_fixed(2.5, 0), "3");
        assert_eq!(to_fixed(1.03125, 4), "1.0313");
        assert_eq!(to_fixed(12.34567, 4), "12.3457");
        assert_eq!(hash_string("abc"), 440920331);
    }
}

/// V8 `Math.*` equivalents. V8 uses fdlibm ports; the `libm` crate is a port of
/// the same FreeBSD msun/fdlibm sources, so results match to the last bit far
/// more often than the platform C runtime does.
pub mod jsm {
    #[inline] pub fn exp(x: f64) -> f64 { libm::exp(x) }
    #[inline] pub fn log1p(x: f64) -> f64 { libm::log1p(x) }
    #[inline] pub fn log2(x: f64) -> f64 { libm::log2(x) }
    #[inline] pub fn log(x: f64) -> f64 { libm::log(x) }
    #[inline] pub fn cos(x: f64) -> f64 { libm::cos(x) }
    #[inline] pub fn sin(x: f64) -> f64 { libm::sin(x) }
    #[inline] pub fn atan2(y: f64, x: f64) -> f64 { libm::atan2(y, x) }
    #[inline] pub fn pow(x: f64, y: f64) -> f64 { libm::pow(x, y) }
    #[inline] pub fn sqrt(x: f64) -> f64 { x.sqrt() }

    /// V8 Math.hypot for two arguments (max-scaled Kahan summation).
    #[inline]
    pub fn hypot(a: f64, b: f64) -> f64 {
        let x = a.abs();
        let y = b.abs();
        if x.is_infinite() || y.is_infinite() {
            return f64::INFINITY;
        }
        if x.is_nan() || y.is_nan() {
            return f64::NAN;
        }
        let max = if x > y { x } else { y };
        if max == 0.0 {
            return 0.0;
        }
        let mut sum = 0.0f64;
        let mut comp = 0.0f64;
        for v in [x, y] {
            let n = v / max;
            let summand = n * n - comp;
            let prelim = sum + summand;
            comp = (prelim - sum) - summand;
            sum = prelim;
        }
        sum.sqrt() * max
    }
}

/// Date.now()
pub fn epoch_ms() -> f64 {
    std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_millis() as f64).unwrap_or(0.0)
}

/// `new Date(ms).toLocaleString()` in the user's (Turkish) locale: dd.mm.yyyy HH:MM:SS.
pub fn local_datetime_text(epoch_ms: f64) -> String {
    use chrono::TimeZone;
    match chrono::Local.timestamp_millis_opt(epoch_ms as i64).single() {
        Some(t) => t.format("%d.%m.%Y %H:%M:%S").to_string(),
        None => String::new(),
    }
}

/// `n.toLocaleString()` for integers in the user's (Turkish) locale: 491.970
pub fn thousands(n: i64) -> String {
    let s = n.unsigned_abs().to_string();
    let mut out = String::new();
    for (i, c) in s.chars().enumerate() {
        if i > 0 && (s.len() - i) % 3 == 0 {
            out.push('.');
        }
        out.push(c);
    }
    if n < 0 { format!("-{out}") } else { out }
}
