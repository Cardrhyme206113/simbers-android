//! Audio input: decoding (audio/input.js) and PCM preparation (audio/analysis.js).

pub mod highlights;

use crate::settings as adv;
use std::path::Path;

/// Decoded PCM (AudioBuffer equivalent).
#[derive(Clone, Debug)]
pub struct Decoded {
    pub channels: Vec<Vec<f32>>,
    pub sample_rate: f64,
}

impl Decoded {
    pub fn len(&self) -> usize {
        self.channels.first().map(|c| c.len()).unwrap_or(0)
    }
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }
    pub fn duration(&self) -> f64 {
        self.len() as f64 / self.sample_rate
    }
}

fn decode_symphonia(bytes: Vec<u8>, ext: Option<&str>) -> anyhow::Result<Decoded> {
    use symphonia::core::codecs::audio::AudioDecoderOptions;
    use symphonia::core::errors::Error;
    use symphonia::core::formats::probe::Hint;
    use symphonia::core::formats::{FormatOptions, TrackType};
    use symphonia::core::io::MediaSourceStream;
    use symphonia::core::meta::MetadataOptions;
    let mss = MediaSourceStream::new(Box::new(std::io::Cursor::new(bytes)), Default::default());
    let mut hint = Hint::new();
    if let Some(e) = ext {
        hint.with_extension(e);
    }
    let mut format = symphonia::default::get_probe().probe(&hint, mss, FormatOptions::default(), MetadataOptions::default())?;
    let track = format.default_track(TrackType::Audio).ok_or_else(|| anyhow::anyhow!("no audio track"))?;
    let params = track.codec_params.as_ref().and_then(|p| p.audio()).ok_or_else(|| anyhow::anyhow!("no audio codec params"))?;
    let mut decoder = symphonia::default::get_codecs().make_audio_decoder(params, &AudioDecoderOptions::default())?;
    let track_id = track.id;
    let mut channels: Vec<Vec<f32>> = vec![];
    let mut rate = 0u32;
    let mut scratch: Vec<f32> = vec![];
    loop {
        let packet = match format.next_packet() {
            Ok(Some(p)) => p,
            Ok(None) => break,
            Err(Error::IoError(_)) => break,
            Err(e) => return Err(e.into()),
        };
        if packet.track_id != track_id {
            continue;
        }
        match decoder.decode(&packet) {
            Ok(buf) => {
                let nch = buf.spec().channels().count().max(1);
                rate = buf.spec().rate();
                if channels.is_empty() {
                    channels = vec![vec![]; nch];
                } else if channels.len() != nch {
                    continue;
                }
                scratch.resize(buf.samples_interleaved(), 0.0);
                buf.copy_to_slice_interleaved(&mut scratch);
                for frame in scratch.chunks_exact(nch) {
                    for (c, v) in frame.iter().enumerate() {
                        channels[c].push(*v);
                    }
                }
            }
            Err(Error::DecodeError(_)) => continue,
            Err(e) => return Err(e.into()),
        }
    }
    if channels.is_empty() || rate == 0 || channels[0].is_empty() {
        anyhow::bail!("decoder produced no audio");
    }
    Ok(Decoded { channels, sample_rate: rate as f64 })
}

/// Fallback: system ffmpeg (Opus/WebM and anything symphonia rejects).
#[cfg(not(target_os = "android"))]
fn decode_ffmpeg(path: &Path) -> anyhow::Result<Decoded> {
    let probe = std::process::Command::new("ffprobe")
        .args(["-v", "error", "-select_streams", "a:0", "-show_entries", "stream=sample_rate,channels", "-of", "csv=p=0"])
        .arg(path)
        .output()?;
    let s = String::from_utf8_lossy(&probe.stdout);
    let mut it = s.trim().split(',');
    let rate: u32 = it.next().unwrap_or("48000").trim().parse().unwrap_or(48000);
    let nch: usize = it.next().unwrap_or("2").trim().parse::<usize>().unwrap_or(2).clamp(1, 8);
    let out = std::process::Command::new("ffmpeg")
        .args(["-v", "error", "-i"])
        .arg(path)
        .args(["-f", "f32le", "-acodec", "pcm_f32le", "-ac", &nch.to_string(), "-ar", &rate.to_string(), "-"])
        .output()?;
    if !out.status.success() || out.stdout.is_empty() {
        anyhow::bail!("ffmpeg could not decode: {}", String::from_utf8_lossy(&out.stderr));
    }
    let samples: Vec<f32> = out.stdout.chunks_exact(4).map(|b| f32::from_le_bytes([b[0], b[1], b[2], b[3]])).collect();
    let mut channels = vec![Vec::with_capacity(samples.len() / nch); nch];
    for frame in samples.chunks_exact(nch) {
        for (c, v) in frame.iter().enumerate() {
            channels[c].push(*v);
        }
    }
    Ok(Decoded { channels, sample_rate: rate as f64 })
}

pub fn decode_file(path: &Path) -> anyhow::Result<(Decoded, Vec<u8>)> {
    let bytes = std::fs::read(path)?;
    let ext = path.extension().and_then(|e| e.to_str()).map(|s| s.to_lowercase());
    match decode_symphonia(bytes.clone(), ext.as_deref()) {
        Ok(d) => Ok((d, bytes)),
        Err(e) => {
            #[cfg(target_os = "android")]
            return Err(anyhow::anyhow!("Unsupported audio format on Android (Symphonia): {e}. Try MP3, FLAC, WAV or M4A/AAC."));
            #[cfg(not(target_os = "android"))]
            {
                log::warn!("symphonia decode failed ({e}); trying ffmpeg");
                Ok((decode_ffmpeg(path)?, bytes))
            }
        }
    }
}

pub struct Prepared {
    pub mono: Vec<f32>,
    pub output_channels: Vec<Vec<f32>>,
}

fn out_channel_count(buf: &Decoded) -> usize {
    (adv::integer("audio.channels", 2.0).max(1) as usize).min(buf.channels.len().max(1))
}

/// resampleUnifiedAudio
pub fn resample_unified(buf: &Decoded, target: f64, max_seconds: f64) -> Prepared {
    let src_rate = buf.sample_rate;
    let src_len = buf.len().min((max_seconds * src_rate).floor() as usize);
    let out_ch = out_channel_count(buf);
    let out_len = ((src_len as f64 * target) / src_rate).floor() as usize;
    let input = &buf.channels;
    let mut channels = vec![vec![0f32; out_len]; out_ch];
    let mut mono = vec![0f32; out_len];
    if src_len == 0 {
        return Prepared { mono, output_channels: channels };
    }
    for i in 0..out_len {
        let pos = i as f64 * src_rate / target;
        let j = pos.floor() as usize;
        let k = (src_len - 1).min(j + 1);
        let f = pos - j as f64;
        let mut sum = 0f64;
        for (c, src) in input.iter().enumerate() {
            let value = src[j] as f64 * (1.0 - f) + src[k] as f64 * f;
            if (out_ch > 1 || input.len() == 1) && c < out_ch {
                channels[c][i] = value as f32;
            }
            sum += value;
        }
        let down = (sum / input.len() as f64) as f32;
        mono[i] = down;
        if out_ch == 1 && input.len() > 1 {
            channels[0][i] = down;
        }
    }
    Prepared { mono, output_channels: channels }
}

/// downmixAndResample (high processing mode)
pub fn downmix_and_resample(buf: &Decoded, target: f64, max_seconds: f64) -> Vec<f32> {
    let src_rate = buf.sample_rate;
    let src_len = buf.len().min((max_seconds * src_rate).floor() as usize);
    let out_len = ((src_len as f64 * target) / src_rate).floor() as usize;
    let ch = &buf.channels;
    if src_len == 0 {
        return vec![];
    }
    (0..out_len)
        .map(|i| {
            let pos = (i as f64 * src_rate) / target;
            let i0 = pos.floor() as usize;
            let i1 = (src_len - 1).min(i0 + 1);
            let t = pos - i0 as f64;
            let mut s = 0f64;
            for c in ch {
                s += c[i0] as f64 * (1.0 - t) + c[i1] as f64 * t;
            }
            (s / ch.len() as f64) as f32
        })
        .collect()
}

/// resampleChannelsForOutput
pub fn resample_channels_for_output(buf: &Decoded, target: f64, max_seconds: f64) -> Vec<Vec<f32>> {
    let src_rate = buf.sample_rate;
    let src_len = buf.len().min((max_seconds * src_rate).floor() as usize);
    let n = out_channel_count(buf);
    if src_rate == target {
        return (0..n).map(|c| buf.channels[c][..src_len].to_vec()).collect();
    }
    let out_len = ((src_len as f64 * target) / src_rate).floor() as usize;
    let mut outs = vec![vec![0f32; out_len]; n];
    if src_len == 0 {
        return outs;
    }
    for i in 0..out_len {
        let pos = (i as f64 * src_rate) / target;
        let i0 = pos.floor() as usize;
        let i1 = (src_len - 1).min(i0 + 1);
        let t = pos - i0 as f64;
        for c in 0..n {
            let s = &buf.channels[c];
            outs[c][i] = (s[i0] as f64 * (1.0 - t) + s[i1] as f64 * t) as f32;
        }
    }
    outs
}

/// Decode in-memory audio (symphonia first, system ffmpeg as fallback).
pub fn decode_bytes(bytes: &[u8], ext: Option<&str>) -> anyhow::Result<Decoded> {
    match decode_symphonia(bytes.to_vec(), ext) {
        Ok(d) => Ok(d),
        Err(e) => {
            #[cfg(target_os = "android")]
            return Err(anyhow::anyhow!("Unsupported audio format on Android (Symphonia): {e}. Try MP3, FLAC, WAV or M4A/AAC."));
            #[cfg(not(target_os = "android"))]
            {
                log::warn!("symphonia decode failed ({e}); trying ffmpeg");
                let tmp = std::env::temp_dir().join(format!("simbers-decode-{}.{}", std::process::id(), ext.unwrap_or("bin")));
                std::fs::write(&tmp, bytes)?;
                let r = decode_ffmpeg(&tmp);
                let _ = std::fs::remove_file(&tmp);
                r
            }
        }
    }
}
