//! audio/highlights.js — rhythm-aligned "Highlights Edit" for long songs.
//! Float32Array storage is emulated with f32 storage + f64 math.

use super::Decoded;
use crate::util::js_round;

pub const EDIT_FADE_SECONDS: f64 = 0.085;

pub struct Envelope {
    pub rms: Vec<f32>,
    pub step_seconds: f64,
}

#[derive(Clone, Copy, Debug)]
pub struct BeatGrid {
    pub seconds: f64,
    pub confidence: f64,
}

#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Section {
    pub start: f64,
    pub end: f64,
}

#[derive(Clone, Copy, Debug)]
pub struct Cut {
    pub time: f64,
    pub from: f64,
    pub previous_end: f64,
}

#[derive(Clone, Debug)]
pub struct Plan {
    pub sections: Vec<Section>,
    pub cuts: Vec<Cut>,
    pub duration: f64,
    pub source_duration: f64,
    pub pulse_seconds: Option<f64>,
}

/// JS `a || b` for numbers read from a Float32Array (undefined / 0 / NaN fall through).
#[inline]
fn or(v: Option<&f32>, fallback: f64) -> f64 {
    match v {
        Some(&x) if x != 0.0 && !x.is_nan() => x as f64,
        _ => fallback,
    }
}


/// simbersHighlightsEnvelope
pub fn envelope(buf: &Decoded, step_seconds: f64) -> Envelope {
    let sr = buf.sample_rate;
    let left = &buf.channels[0];
    let right = if buf.channels.len() > 1 { &buf.channels[1] } else { left };
    let len = buf.len();
    let hop = (js_round(sr * step_seconds) as usize).max(1);
    let n = len.div_ceil(hop);
    let mut rms = vec![0f32; n];
    for (i, slot) in rms.iter_mut().enumerate() {
        let start = i * hop;
        let end = len.min(start + hop);
        let stride = ((end - start) / 48).max(1);
        let (mut sum, mut cnt) = (0f64, 0usize);
        let mut j = start;
        while j < end {
            let s = (left[j] as f64 + right[j] as f64) * 0.5;
            sum += s * s;
            cnt += 1;
            j += stride;
        }
        *slot = (sum / cnt.max(1) as f64).sqrt() as f32;
    }
    Envelope { rms, step_seconds: hop as f64 / sr }
}

/// simbersHighlightsBeatGrid
pub fn beat_grid(env: &Envelope) -> Option<BeatGrid> {
    let rms = &env.rms;
    let dt = env.step_seconds;
    if rms.len() < 80 {
        return None;
    }
    let mut novelty = vec![0f32; rms.len()];
    let mut total = 0f64;
    for i in 1..rms.len() {
        let prev = rms[i - 1] as f64;
        let prev2 = if i >= 2 { or(rms.get(i - 2), prev) } else { prev };
        novelty[i] = (rms[i] as f64 - (prev * 0.85 + prev2 * 0.15)).max(0.0) as f32;
        total += novelty[i] as f64;
    }
    if total < 0.0002 {
        return None;
    }
    let mut winner: Option<BeatGrid> = None;
    let lo = (js_round(0.32 / dt) as i64).max(2);
    let hi = js_round(0.85 / dt) as i64;
    let mut lag = lo;
    while lag <= hi {
        let l = lag as usize;
        let (mut sim, mut norm) = (0f64, 0f64);
        for i in l..novelty.len() {
            sim += novelty[i] as f64 * novelty[i - l] as f64;
            norm += novelty[i] as f64 * novelty[i] as f64;
        }
        let confidence = sim / norm.max(1e-9);
        if winner.is_none_or(|w| confidence > w.confidence) {
            winner = Some(BeatGrid { seconds: lag as f64 * dt, confidence });
        }
        lag += 1;
    }
    winner.filter(|w| w.confidence >= 0.12)
}

/// simbersHighlightsSnap
pub fn snap(time: f64, target_duration: f64, total_duration: f64, env: &Envelope, grid: Option<BeatGrid>) -> f64 {
    let dt = env.step_seconds;
    let rms = &env.rms;
    let radius = 1.8f64.min(0.32f64.max(target_duration * 0.025));
    let from = 0f64.max(js_round((time - radius) / dt)) as i64;
    let to = ((rms.len() as f64 - 1.0).min(js_round((time + radius) / dt))) as i64;
    let mut best = 0f64.max(total_duration.min(time));
    let mut best_score = f64::NEG_INFINITY;
    let mut i = from;
    while i <= to {
        let iu = i as usize;
        let t = i as f64 * dt;
        if !(t < 0.01 || t > total_duration - 0.01) {
            let r = rms[iu] as f64;
            let quiet = 1.0 / (1.0 + 100.0 * r);
            let before = if iu >= 1 { or(rms.get(iu - 1), r) } else { r };
            let local = (before + r + or(rms.get(iu + 1), r)) / 3.0;
            let local_break = 1.0 / (1.0 + local * 80.0);
            let pulse = match grid {
                Some(g) => 1.0 - ((t / g.seconds) - js_round(t / g.seconds)).abs() * 2.0,
                None => 0.5,
            };
            let distance = (t - time).abs() / radius;
            let score = quiet * 0.28 + local_break * 0.24 + pulse * if grid.is_some() { 0.40 } else { 0.0 } - distance * 0.17;
            if score > best_score {
                best_score = score;
                best = t;
            }
        }
        i += 1;
    }
    best
}

/// simbersPlanHighlights (defaults: minSectionSeconds 26, maxSections 12)
pub fn plan(buf: &Decoded, limit_seconds: f64) -> anyhow::Result<Plan> {
    plan_with(buf, limit_seconds, 26.0, 12)
}

pub fn plan_with(buf: &Decoded, limit_seconds: f64, min_section_seconds: f64, max_sections: usize) -> anyhow::Result<Plan> {
    let duration = buf.duration();
    if !(duration > 0.0) || !(limit_seconds > 0.0) {
        anyhow::bail!("Invalid highlights duration");
    }
    if duration <= limit_seconds + 0.05 {
        return Ok(Plan { sections: vec![Section { start: 0.0, end: duration }], cuts: vec![], duration, source_duration: duration, pulse_seconds: None });
    }
    let env = envelope(buf, 0.25);
    let grid = beat_grid(&env);
    let count = 2f64.max((max_sections as f64).min((limit_seconds / min_section_seconds).floor()).min((duration / 195.0).ceil())) as usize;
    let fade = EDIT_FADE_SECONDS;
    let nominal = (limit_seconds + (count as f64 - 1.0) * fade) / count as f64;
    let mut sections: Vec<Section> = Vec::with_capacity(count);
    for i in 0..count {
        let ideal = (duration - nominal).min(i as f64 * (duration - nominal) / 1f64.max(count as f64 - 1.0));
        let mut start = if i == 0 { 0.0 } else { snap(ideal, nominal, duration, &env, grid) };
        if let Some(last) = sections.last() {
            start = (last.end + 0.1).max(start);
        }
        let ideal_end = duration.min(start + nominal);
        let mut end = if i == count - 1 { duration } else { snap(ideal_end, nominal, duration, &env, grid) };
        end = duration.min((start + 8f64.max(nominal - 3.0)).max((start + nominal + 2.0).min(end)));
        sections.push(Section { start, end });
    }
    let total = sections.iter().fold(0.0, |a, s| a + s.end - s.start) - fade * (sections.len() as f64 - 1.0);
    if total > limit_seconds + 0.01 {
        let mut extra = total - limit_seconds;
        let mut i = sections.len() as i64 - 1;
        while i >= 0 && extra > 0.0 {
            let s = &mut sections[i as usize];
            let allowed = 0f64.max(s.end - s.start - 8.0);
            let take = extra.min(allowed);
            s.end -= take;
            extra -= take;
            i -= 1;
        }
    }
    let mut cuts = vec![];
    let mut offset = 0f64;
    for i in 0..sections.len() {
        if i > 0 {
            offset -= fade;
            cuts.push(Cut { time: offset, from: sections[i].start, previous_end: sections[i - 1].end });
        }
        offset += sections[i].end - sections[i].start;
    }
    Ok(Plan { sections, cuts, duration: offset, source_duration: duration, pulse_seconds: grid.map(|g| g.seconds) })
}

/// simbersAssembleHighlights
pub fn assemble(source: &Decoded, plan: &Plan, cancel: &dyn Fn() -> anyhow::Result<()>) -> anyhow::Result<Decoded> {
    let sr = source.sample_rate;
    let fade_frames = js_round(EDIT_FADE_SECONDS * sr) as usize;
    let secs: Vec<(usize, usize)> = plan.sections.iter().map(|s| ((s.start * sr).floor() as usize, (s.end * sr).floor() as usize)).collect();
    let total: usize = secs.iter().map(|(a, b)| b - a).sum();
    let out_len = (total as i64 - (fade_frames * secs.len().saturating_sub(1)) as i64).max(1) as usize;
    let nch = source.channels.len().min(2);
    let mut channels = Vec::with_capacity(nch);
    for c in 0..nch {
        let input = &source.channels[c];
        let mut target = vec![0f32; out_len];
        let mut pos = 0usize;
        for (k, &(start, end)) in secs.iter().enumerate() {
            cancel()?;
            let length = end - start;
            let overlap = if k > 0 { fade_frames.min(length).min(pos) } else { 0 };
            for j in 0..overlap {
                let t = (j as f64 + 0.5) / overlap as f64;
                let idx = pos - overlap + j;
                target[idx] = (target[idx] as f64 * (1.0 - t) + input[start + j] as f64 * t) as f32;
            }
            // TypedArray.set throws on overflow in JS; the plan math guarantees it fits.
            let src = &input[start + overlap..end];
            let n = src.len().min(out_len.saturating_sub(pos));
            target[pos..pos + n].copy_from_slice(&src[..n]);
            pos += length - overlap;
        }
        channels.push(target);
    }
    Ok(Decoded { channels, sample_rate: sr })
}

/// simbersSelectedSongLimit
pub fn selected_song_limit() -> f64 {
    10f64.max(15f64.min(crate::settings::number("audio.highlightsMinutes", 12.0))) * 60.0
}
