//! Platform bridge: desktop rfd and Android Storage Access Framework.
//! Android never relies on direct access to public /sdcard paths.
use std::path::PathBuf;

#[cfg(not(target_os = "android"))]
pub fn pick_file() -> Option<PathBuf> {
    rfd::FileDialog::new().pick_file()
}

#[cfg(not(target_os = "android"))]
pub fn save_bytes(name: &str, bytes: &[u8]) -> anyhow::Result<Option<PathBuf>> {
    let extension = name.rsplit_once('.').map(|(_, ext)| ext).unwrap_or("zip");
    let Some(path) = rfd::FileDialog::new()
        .set_file_name(name).add_filter("File", &[extension]).save_file() else {
            return Ok(None);
        };
    std::fs::write(&path, bytes)?;
    Ok(Some(path))
}

#[cfg(target_os = "android")]
mod android {
    use anyhow::{Context, Result};
    use jni::{JNIEnv, JavaVM};
    use jni::objects::{JClass, JObject, JString, JValue};
    use std::collections::VecDeque;
    use std::path::PathBuf;
    use std::sync::{Mutex, OnceLock};
    use winit::platform::android::activity::AndroidApp;

    static APP: OnceLock<AndroidApp> = OnceLock::new();
    static EVENTS: Mutex<VecDeque<FileEvent>> = Mutex::new(VecDeque::new());

    #[derive(Debug)]
    pub enum FileEvent {
        Opened(PathBuf),
        Notice(String),
    }

    pub fn initialize(app: AndroidApp) {
        let _ = APP.set(app);
    }

    pub fn data_dir() -> PathBuf {
        APP.get().and_then(AndroidApp::internal_data_path)
            .unwrap_or_else(|| PathBuf::from("/data/local/tmp"))
    }

    fn call_activity(method: &str, signature: &str, args: &[JValue<'_, '_>]) -> Result<()> {
        let app = APP.get().context("Android activity is not initialized")?;
        // The Java VM is owned by Android; `JavaVM::from_raw` only wraps it.
        let jvm = unsafe { JavaVM::from_raw(app.vm_as_ptr() as *mut jni::sys::JavaVM) }?;
        let mut env = jvm.attach_current_thread()?;
        // Activity is an OS-owned global reference from ANativeActivity.
        let activity = unsafe { JObject::from_raw(app.activity_as_ptr() as jni::sys::jobject) };
        env.call_method(&activity, method, signature, args)
            .with_context(|| format!("calling Android.{method}"))?;
        Ok(())
    }

    pub fn pick_file() -> Option<PathBuf> {
        if let Err(e) = call_activity("pickFile", "()V", &[]) {
            EVENTS.lock().unwrap().push_back(FileEvent::Notice(format!("Cannot open Android picker: {e:#}")));
        }
        None // Android file picking completes asynchronously via JNI callback.
    }

    pub fn save_bytes(name: &str, bytes: &[u8]) -> Result<Option<PathBuf>> {
        let dir = data_dir().join("simbers-exports");
        std::fs::create_dir_all(&dir)?;
        let safe_name = name.chars().map(|c| if c == '/' || c == '\\' || c == '\0' { '_' } else { c }).collect::<String>();
        let temp = dir.join(format!("{}-{}", std::process::id(), safe_name));
        std::fs::write(&temp, bytes)?;

        // Use a local wrapper here because JNI string refs have to be created
        // within the same JNIEnv as the call itself.
        let app = APP.get().context("Android activity is not initialized")?;
        let jvm = unsafe { JavaVM::from_raw(app.vm_as_ptr() as *mut jni::sys::JavaVM) }?;
        let mut env = jvm.attach_current_thread()?;
        let activity = unsafe { JObject::from_raw(app.activity_as_ptr() as jni::sys::jobject) };
        let local_path = JObject::from(env.new_string(temp.to_string_lossy().as_ref())?);
        let title = JObject::from(env.new_string(name)?);
        env.call_method(&activity, "saveFile", "(Ljava/lang/String;Ljava/lang/String;)V", &[
            JValue::Object(&local_path), JValue::Object(&title),
        ])?;
        Ok(None) // Save completes in Android's document-picker result callback.
    }

    pub fn take_events() -> Vec<FileEvent> {
        EVENTS.lock().unwrap().drain(..).collect()
    }

    // Java's `nativeFilePicked(String)` (runs on a Java-managed thread).
    #[unsafe(no_mangle)]
    pub extern "system" fn Java_io_simbers_app_SimbersActivity_nativeFilePicked(
        mut env: JNIEnv<'_>, _class: JClass<'_>, path: JString<'_>
    ) {
        if let Ok(s) = env.get_string(&path) {
            EVENTS.lock().unwrap().push_back(FileEvent::Opened(PathBuf::from(s.to_string_lossy().into_owned())));
        }
    }

    // Notifications from SAF import/export (success and failure).
    #[unsafe(no_mangle)]
    pub extern "system" fn Java_io_simbers_app_SimbersActivity_nativeFileMessage(
        mut env: JNIEnv<'_>, _class: JClass<'_>, text: JString<'_>
    ) {
        if let Ok(s) = env.get_string(&text) {
            EVENTS.lock().unwrap().push_back(FileEvent::Notice(s.to_string_lossy().into_owned()));
        }
    }
}

#[cfg(target_os = "android")]
pub use android::{FileEvent, data_dir, initialize, pick_file, save_bytes, take_events};
