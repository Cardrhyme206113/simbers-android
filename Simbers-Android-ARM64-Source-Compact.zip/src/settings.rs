//! Persisted advanced settings (settings.js / defaults.js / persisted-settings.js).
//! The settings tree is kept dynamic (JSON) so dotted-path semantics, deep merge
//! rules and reset-by-category behave exactly like the original.

use crate::storage::kv;
use crate::util::{js_number, js_truthy};
use parking_lot::RwLock;
use serde_json::{Map, Value};
use std::sync::LazyLock;

pub const ADV_STORAGE_KEY: &str = "simbers-advanced-settings-v2";
pub const AUDIO_BITRATE_KEY: &str = "simbers-audio-bitrate-kbps-v2";

pub const ADV_DEFAULTS_JSON: &str = r#"{
  "audio": {"bitrateKbps": 80, "processingMode": "normal", "analysisRate": 22050, "outputRate": 32000,
    "highlightsMinutes": 12, "channels": 2, "encoderRate": 48000, "frameSize": 960, "queueLimit": 48,
    "preSkip": 312, "bitrateMode": "constant"},
  "pitch": {"fftSize": 4096, "hopSize": 1024, "minMidi": 36, "maxMidi": 96, "tracks": 1, "confidence": 0.9,
    "ambiguity": 0.1, "stability": 2.5, "harmonics": 8, "localOnsetWeight": 0.1, "globalFluxWeight": 0.002,
    "residualCenter": 2.8, "residualSlope": 0.6, "yieldEveryFrames": 24},
  "detector": {"fftSize": 1024, "hopSize": 256, "sensitivity": 1, "minimumGapMs": 20, "stabilityGate": true,
    "autoDensityFloor": true, "targetEventDensity": 1, "minimumStateChange": 0.28, "stateChangeThreshold": 0.4,
    "stabilityWindowMs": 185},
  "spectral": {"edges": "38,90,180,360,720,1440,2880,5760", "neighborRadius": 1, "bandSlope": 0.035,
    "magnitudeScale": 10, "energyScale": 800},
  "patterns": {"contextBeats": 4, "similarityThreshold": 0.78, "transposeInvariant": true, "endPaddingSec": 0.03,
    "minimumSegmentSec": 0.035, "similarityScale": 4, "melodyJitter": 0.05},
  "flow": {"segmentStateWeight": 0.56, "segmentBeatWeight": 0.29, "segmentActivityWeight": 0.15,
    "wristConservatism": 1, "macroSimilarity": 0.83, "motifStrength": 0.9, "corpusVariety": 0.85,
    "laneBalance": 1.3, "doubleAccentRate": 0.16, "fullDoubleNotes": false},
  "arcs": {"naturalMinGap": 0.12, "naturalMaxGap": 1.35, "minimumDistance": 0.45, "maximumDistance": 3.25,
    "movementLaunchWeight": 0.62, "movementParityWeight": 0.38, "musicalMelodyWeight": 0.48,
    "musicalStateWeight": 0.32, "musicalGroupWeight": 0.2, "idealDistance": 1.45, "distanceRange": 1.65,
    "scoreMovementWeight": 0.44, "scoreMusicalWeight": 0.32, "scoreTimingWeight": 0.14,
    "scoreDistanceWeight": 0.1, "oppositeHandTolerance": 0.075, "maximumSkippedNotes": 2, "controlBase": 0.62,
    "controlGapWeight": 0.92, "controlDistanceWeight": 0.13, "controlMinimum": 0.65, "controlMaximum": 1.42},
  "bombs": {"cadenceFloor": 5, "alternateHandTolerance": 0.08, "reactionMarginHard": 0.075,
    "reactionMarginExpert": 0.06, "reactionMarginExpertPlus": 0.045, "noteCollisionMargin": 0.095,
    "noteCollisionMarginExpertPlus": 0.075, "bombSeparationSec": 0.38, "bombSeparationExpertPlus": 0.28,
    "lagFloorMultiplier": 0.82, "requiredGapExtra": 0.055, "scoreAttackWeight": 0.58, "scoreGapWeight": 0.27,
    "hardFlowBonus": 0.16, "mediumFlowBonus": 0.07},
  "walls": {"cadenceFloor": 8, "minimumSongTime": 1.8, "startOffsetHard": 0.12, "startOffsetExpert": 0.1,
    "startOffsetExpertPlus": 0.085, "nextNoteMarginHard": 0.11, "nextNoteMarginExpert": 0.09,
    "nextNoteMarginExpertPlus": 0.075, "durationScale": 0.76, "separationHard": 2.75, "separationExpert": 2.15,
    "separationExpertPlus": 1.65, "maximumSideWidth": 2, "crouchWidth": 4, "crouchHeight": 3, "sideHeight": 5},
  "lighting": {"minimumEventGap": 0.085, "sectionSeconds": 8, "stateTransitionThreshold": 0.78,
    "groupOffsetSec": 0.012, "transitionBrightnessBase": 0.5, "transitionBrightnessStrength": 0.12,
    "flashStrengthThreshold": 0.78, "flashCooldownSec": 0.18, "fadeStrengthThreshold": 0.52,
    "fadeStateThreshold": 0.48, "fadeBeatThreshold": 0.58, "staticActivityThreshold": 0.42,
    "brightnessBase": 0.5, "brightnessStrength": 0.52, "brightnessActivity": 0.14, "brightnessMinimum": 0.46,
    "brightnessMaximum": 1.18, "sideStrengthThreshold": 0.42, "sideBeatThreshold": 0.5,
    "sideFlashThreshold": 0.68, "sideBrightnessScale": 0.88, "strongStrengthThreshold": 0.72,
    "strongStateThreshold": 0.78, "strongFlashThreshold": 0.84, "strongBrightnessAdd": 0.1, "rapidGapSec": 0.3,
    "rapidStrengthThreshold": 0.48, "rapidOffsetSec": 0.058, "rapidBrightnessBase": 0.66,
    "rapidBrightnessStrength": 0.26, "quietGapSec": 1.15, "quietActivityThreshold": 0.48,
    "quietOffsetMaximum": 0.72, "quietOffsetRatio": 0.48, "endPaddingSec": 0.025},
  "output": {"deflateText": true, "prettyInfo": true, "autoPreview": true, "autoGenerateOnDrop": true},
  "features": {"bombs": true, "walls": true, "arcs": true, "botOptimizer": true},
  "difficulty": {
    "easy": {"enabled": true, "label": "Easy", "difficulty": "Easy", "rank": 1, "filename": "EasyStandard.dat",
      "minimumGapMs": 200, "noteJumpMovementSpeed": 10, "arcMinGap": 0.3, "arcMaxGap": 0.7, "arcEveryEvents": 6,
      "arcScoreFloor": 0.5, "bombEveryEvents": 0, "bombLagMin": 0.18, "bombLagMax": 0.24, "bombDirectRate": 0.1,
      "bombFollowRate": 0.2, "wallEveryEvents": 0, "wallMinimumGap": 0.58, "wallMinDuration": 0.28,
      "wallMaxDuration": 0.48, "wallWidth": 1, "crouchWallRate": 0, "crouchMinimumGap": 0.76,
      "weightEasy": 0.85, "weightMedium": 0.15, "weightHard": 0},
    "medium": {"enabled": true, "label": "Medium", "difficulty": "Normal", "rank": 3,
      "filename": "NormalStandard.dat", "minimumGapMs": 140, "noteJumpMovementSpeed": 11.5, "arcMinGap": 0.23,
      "arcMaxGap": 0.6, "arcEveryEvents": 5, "arcScoreFloor": 0.48, "bombEveryEvents": 0, "bombLagMin": 0.18,
      "bombLagMax": 0.24, "bombDirectRate": 0.1, "bombFollowRate": 0.2, "wallEveryEvents": 0,
      "wallMinimumGap": 0.58, "wallMinDuration": 0.28, "wallMaxDuration": 0.48, "wallWidth": 1,
      "crouchWallRate": 0, "crouchMinimumGap": 0.76, "weightEasy": 0.1, "weightMedium": 0.82, "weightHard": 0.08},
    "hard": {"enabled": true, "label": "Hard", "difficulty": "Hard", "rank": 5, "filename": "HardStandard.dat",
      "minimumGapMs": 130, "noteJumpMovementSpeed": 12.25, "arcMinGap": 0.2, "arcMaxGap": 0.55,
      "arcEveryEvents": 5, "arcScoreFloor": 0.47, "bombEveryEvents": 14, "bombLagMin": 0.18, "bombLagMax": 0.24,
      "bombDirectRate": 0.1, "bombFollowRate": 0.2, "wallEveryEvents": 20, "wallMinimumGap": 0.58,
      "wallMinDuration": 0.28, "wallMaxDuration": 0.48, "wallWidth": 1, "crouchWallRate": 0,
      "crouchMinimumGap": 0.76, "weightEasy": 0.05, "weightMedium": 0.8, "weightHard": 0.15},
    "expert": {"enabled": true, "label": "Expert", "difficulty": "Expert", "rank": 7,
      "filename": "ExpertStandard.dat", "minimumGapMs": 120, "noteJumpMovementSpeed": 13, "arcMinGap": 0.17,
      "arcMaxGap": 0.5, "arcEveryEvents": 5, "arcScoreFloor": 0.46, "bombEveryEvents": 10, "bombLagMin": 0.14,
      "bombLagMax": 0.2, "bombDirectRate": 0.28, "bombFollowRate": 0.42, "wallEveryEvents": 15,
      "wallMinimumGap": 0.52, "wallMinDuration": 0.28, "wallMaxDuration": 0.58, "wallWidth": 2,
      "crouchWallRate": 0.18, "crouchMinimumGap": 0.76, "weightEasy": 0, "weightMedium": 0.7, "weightHard": 0.3},
    "expertPlus": {"enabled": true, "label": "Expert+", "difficulty": "ExpertPlus", "rank": 9,
      "filename": "ExpertPlusStandard.dat", "minimumGapMs": 100, "noteJumpMovementSpeed": 14, "arcMinGap": 0.14,
      "arcMaxGap": 0.42, "arcEveryEvents": 4, "arcScoreFloor": 0.48, "bombEveryEvents": 7, "bombLagMin": 0.1,
      "bombLagMax": 0.16, "bombDirectRate": 0.48, "bombFollowRate": 0.42, "wallEveryEvents": 11,
      "wallMinimumGap": 0.44, "wallMinDuration": 0.24, "wallMaxDuration": 0.56, "wallWidth": 2,
      "crouchWallRate": 0.3, "crouchMinimumGap": 0.66, "weightEasy": 0, "weightMedium": 0.6, "weightHard": 0.4}
  }
}"#;

pub static ADV_DEFAULTS: LazyLock<Value> =
    LazyLock::new(|| serde_json::from_str(ADV_DEFAULTS_JSON).expect("defaults json"));

static SETTINGS: LazyLock<RwLock<Value>> = LazyLock::new(|| RwLock::new(load_persisted()));

/// advDeepMerge: only keys present in `base`; same JS type required.
pub fn deep_merge(base: &mut Value, extra: &Value) {
    let (Some(bm), Some(em)) = (base.as_object_mut(), extra.as_object()) else { return };
    let keys: Vec<String> = bm.keys().cloned().collect();
    for key in keys {
        let Some(value) = em.get(&key) else { continue };
        let b = bm.get_mut(&key).unwrap();
        if b.is_object() {
            deep_merge(b, value);
        } else {
            let same_type = matches!(
                (&*b, value),
                (Value::Bool(_), Value::Bool(_)) | (Value::String(_), Value::String(_)) | (Value::Number(_), Value::Number(_))
            );
            if same_type && value.as_f64().map(|f| f.is_finite()).unwrap_or(true) {
                *b = value.clone();
            }
        }
    }
}

fn load_persisted() -> Value {
    let mut settings = ADV_DEFAULTS.clone();
    if let Some(saved) = kv::get(ADV_STORAGE_KEY).and_then(|s| serde_json::from_str::<Value>(&s).ok()) {
        deep_merge(&mut settings, &saved);
    }
    if let Some(audio) = settings.get_mut("audio").and_then(|a| a.as_object_mut()) {
        audio.remove("maxSeconds");
        audio.remove("allowFullSong");
    }
    let hands_key = "simbers7-dynamic-hands-default-v1";
    if kv::get(hands_key).is_none() {
        settings["flow"]["fullDoubleNotes"] = Value::Bool(false);
        kv::set(hands_key, "1");
        kv::set(ADV_STORAGE_KEY, &crate::util::json::stringify(&settings));
    }
    settings
}

pub fn get(path: &str) -> Option<Value> {
    let s = SETTINGS.read();
    let mut v: &Value = &s;
    for part in path.split('.') {
        v = v.as_object()?.get(part)?;
    }
    Some(v.clone())
}

pub fn get_str(path: &str, fallback: &str) -> String {
    match get(path) {
        Some(Value::String(s)) => s,
        Some(Value::Null) | None => fallback.to_string(),
        Some(other) => match other {
            Value::Number(n) => crate::util::js_num_to_string(n.as_f64().unwrap_or(0.0)),
            Value::Bool(b) => b.to_string(),
            _ => fallback.to_string(),
        },
    }
}

pub fn number(path: &str, fallback: f64) -> f64 {
    let v = match get(path) {
        Some(v) => js_number(&v),
        None => fallback,
    };
    if v.is_finite() { v } else { fallback }
}

pub fn integer(path: &str, fallback: f64) -> i64 {
    crate::util::js_round(number(path, fallback)) as i64
}

pub fn boolean(path: &str, fallback: bool) -> bool {
    match get(path) {
        Some(Value::Bool(b)) => b,
        Some(v) => js_truthy(&v),
        None => fallback,
    }
}

pub fn number_list(path: &str, fallback: &[f64]) -> Vec<f64> {
    let raw = match get(path) {
        Some(Value::String(s)) => s,
        Some(Value::Number(n)) => crate::util::js_num_to_string(n.as_f64().unwrap_or(0.0)),
        _ => fallback.iter().map(|f| crate::util::js_num_to_string(*f)).collect::<Vec<_>>().join(","),
    };
    let list: Vec<f64> = raw
        .split(',')
        .map(|v| {
            let t = v.trim();
            if t.is_empty() { 0.0 } else { t.parse::<f64>().unwrap_or(f64::NAN) }
        })
        .filter(|v| v.is_finite())
        .collect();
    if list.is_empty() { fallback.to_vec() } else { list }
}

pub fn nearest_power_of_two(path: &str, fallback: f64) -> usize {
    let n = number(path, fallback).max(2.0);
    2f64.powf(crate::util::js_round(n.log2())) as usize
}

pub fn set(path: &str, value: Value) {
    let mut s = SETTINGS.write();
    let parts: Vec<&str> = path.split('.').collect();
    let mut target: &mut Value = &mut s;
    for part in &parts[..parts.len() - 1] {
        if !target.get(*part).map(|v| v.is_object()).unwrap_or(false) {
            target.as_object_mut().unwrap().insert(part.to_string(), Value::Object(Map::new()));
        }
        target = target.get_mut(*part).unwrap();
    }
    target.as_object_mut().unwrap().insert(parts[parts.len() - 1].to_string(), value);
}

pub fn save() {
    let s = SETTINGS.read();
    kv::set(ADV_STORAGE_KEY, &crate::util::json::stringify(&s));
}

pub fn reset_path(path: &str) {
    let parts: Vec<&str> = path.split('.').collect();
    let mut source: &Value = &ADV_DEFAULTS;
    for p in &parts {
        match source.get(*p) {
            Some(v) => source = v,
            None => return,
        }
    }
    let source = source.clone();
    set(path, source);
}

pub fn reset_all() {
    *SETTINGS.write() = ADV_DEFAULTS.clone();
}

pub fn category_path(category: &str) -> String {
    match category {
        "easy" | "medium" | "hard" | "expert" | "expertPlus" => format!("difficulty.{category}"),
        _ => category.to_string(),
    }
}

/// applyAdvancedSettingsToRuntime (bitrate clamp & persistence part).
pub fn apply_runtime() {
    let bitrate = (crate::util::js_round(number("audio.bitrateKbps", 80.0) / 16.0) * 16.0).clamp(16.0, 128.0);
    set("audio.bitrateKbps", crate::util::jnum(bitrate));
    kv::set(AUDIO_BITRATE_KEY, &crate::util::js_num_to_string(bitrate));
}

pub fn snapshot() -> Value {
    SETTINGS.read().clone()
}
