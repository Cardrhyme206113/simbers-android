//! Viewer payload (the object the page posts to the viewer iframe), built either
//! from a fresh generation or from a saved/imported map ZIP
//! (pastJobsZipToViewerPayload).

use crate::storage::zip_reader::{Limits, ZipReader};
use serde_json::Value;

#[derive(Clone, Debug)]
pub struct DifficultyRef {
    pub difficulty: String,
    pub rank: f64,
    pub filename: String,
    pub njs: f64,
}

#[derive(Clone, Debug)]
pub struct CharacteristicRef {
    pub name: String,
    pub difficulties: Vec<DifficultyRef>,
}

#[derive(Clone, Debug)]
pub struct MapEntry {
    pub characteristic: String,
    pub difficulty: String,
    pub rank: f64,
    pub filename: String,
    pub njs: f64,
    pub beatmap: Value,
}

#[derive(Clone, Debug, Default)]
pub struct ViewerPayload {
    pub info: Value,
    pub characteristics: Vec<CharacteristicRef>,
    pub maps: Vec<MapEntry>,
    pub audio_bytes: Option<Vec<u8>>,
    pub audio_mime: String,
    pub cover_bytes: Option<Vec<u8>>,
    pub max_duration_sec: Option<f64>,
    pub highlights_cuts: Vec<f64>,
}

fn s<'a>(v: &'a Value, keys: &[&str]) -> Option<&'a Value> {
    keys.iter().find_map(|k| v.get(*k).filter(|x| !x.is_null()))
}

/// JS `Number(x || 0)`
fn num(v: Option<&Value>) -> f64 {
    match v {
        Some(Value::Number(n)) => n.as_f64().unwrap_or(0.0),
        Some(Value::String(t)) => t.trim().parse().unwrap_or(if t.trim().is_empty() { 0.0 } else { f64::NAN }),
        Some(Value::Bool(b)) => *b as u8 as f64,
        _ => 0.0,
    }
}

fn text(v: Option<&Value>) -> Option<String> {
    match v {
        Some(Value::String(t)) if !t.is_empty() => Some(t.clone()),
        _ => None,
    }
}

/// pastJobsZipToViewerPayload. `fallback_audio` = archived source (bytes, mime).
pub fn from_zip(zip: &[u8], fallback_audio: Option<(Vec<u8>, String)>, fallback_cover: Option<Vec<u8>>) -> anyhow::Result<ViewerPayload> {
    let z = ZipReader::new(zip, Limits::default())?;
    let info_bytes = z.get("Info.dat")?.ok_or_else(|| anyhow::anyhow!("Saved ZIP is missing Info.dat."))?;
    let info: Value = serde_json::from_slice(&info_bytes)?;
    let mut characteristics = vec![];
    let mut maps = vec![];
    let empty = vec![];
    let sets = s(&info, &["_difficultyBeatmapSets", "difficultyBeatmapSets"]).and_then(|v| v.as_array()).unwrap_or(&empty);
    for set in sets {
        let characteristic = text(s(set, &["_beatmapCharacteristicName"])).or_else(|| text(s(set, &["beatmapCharacteristicName"]))).or_else(|| text(s(set, &["characteristic"]))).unwrap_or_else(|| "Standard".into());
        let mut diffs = vec![];
        let defs = s(set, &["_difficultyBeatmaps", "difficultyBeatmaps"]).and_then(|v| v.as_array()).unwrap_or(&empty);
        for def in defs {
            let Some(filename) = text(def.get("_beatmapFilename")).or_else(|| text(def.get("beatmapDataFilename"))).or_else(|| text(def.get("beatmapFilename"))) else { continue };
            let Some(content) = z.get(&filename)? else { continue };
            let beatmap: Value = serde_json::from_slice(&content)?;
            let difficulty = text(def.get("_difficulty")).or_else(|| text(def.get("difficulty"))).unwrap_or_else(|| "ExpertPlus".into());
            let rank = num(def.get("_difficultyRank").filter(|v| truthy(v)).or(def.get("difficultyRank")));
            let njs = num(def.get("_noteJumpMovementSpeed").filter(|v| truthy(v)).or(def.get("noteJumpMovementSpeed")));
            diffs.push(DifficultyRef { difficulty: difficulty.clone(), rank, filename: filename.clone(), njs });
            maps.push(MapEntry { characteristic: characteristic.clone(), difficulty, rank, filename, njs, beatmap });
        }
        if !diffs.is_empty() {
            characteristics.push(CharacteristicRef { name: characteristic, difficulties: diffs });
        }
    }
    if maps.is_empty() {
        anyhow::bail!("Saved ZIP contains no playable beatmaps.");
    }
    let song = text(info.get("_songFilename")).or_else(|| text(info.get("songFilename"))).unwrap_or_else(|| "song.ogg".into());
    let lower = song.to_lowercase();
    let mut audio_mime = if lower.ends_with(".mp3") {
        "audio/mpeg"
    } else if lower.ends_with(".wav") {
        "audio/wav"
    } else if lower.ends_with(".webm") {
        "audio/webm"
    } else {
        "audio/ogg"
    }
    .to_string();
    let mut audio = z.get(&song)?;
    if audio.is_none() {
        if let Some((b, m)) = fallback_audio {
            audio = Some(b);
            audio_mime = if m.is_empty() { "audio/mpeg".into() } else { m };
        }
    }
    let cover_name = text(info.get("_coverImageFilename")).or_else(|| text(info.get("coverImageFilename"))).unwrap_or_else(|| "cover.png".into());
    let cover = z.get(&cover_name)?.or(fallback_cover);
    Ok(ViewerPayload { info, characteristics, maps, audio_bytes: audio, audio_mime, cover_bytes: cover, max_duration_sec: None, highlights_cuts: vec![] })
}

fn truthy(v: &Value) -> bool {
    match v {
        Value::Null => false,
        Value::Bool(b) => *b,
        Value::Number(n) => n.as_f64().is_some_and(|x| x != 0.0 && !x.is_nan()),
        Value::String(t) => !t.is_empty(),
        _ => true,
    }
}
