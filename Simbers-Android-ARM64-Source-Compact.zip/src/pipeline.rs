//! runAnalysis + prepareMapBuild + buildCharacteristicSetsForIntensity + startBackgroundExport.

use crate::analysis::attack::{self, AttackLabData};
use crate::analysis::patterns::{self, PatternOpts, Patterns};
use crate::analysis::spectral::{self, PitchAnalysis, PitchOpts};
use crate::audio::{self, Decoded};
use crate::export::{self, CharacteristicSet};
use crate::job::Job;
use crate::mapgen::beatmaps::{self, Difficulty, GenInput, LightEvent};
use crate::mapgen::grid::Grid;
use crate::mapgen::{self, FeatureOptions, bot, guard, lighting, select};
use crate::settings as adv;
use crate::util::{hash_string, now_ms, to_fixed_num};
use serde_json::Value;
use std::path::Path;
use std::sync::Arc;

/// Browser File.type for common extensions (Chromium on Windows).
pub fn mime_for(path: &Path) -> &'static str {
    match path.extension().and_then(|e| e.to_str()).map(|s| s.to_lowercase()).as_deref() {
        Some("mp3") => "audio/mpeg",
        Some("ogg") | Some("oga") => "audio/ogg",
        Some("opus") => "audio/ogg",
        Some("wav") => "audio/wav",
        Some("flac") => "audio/flac",
        Some("m4a") => "audio/x-m4a",
        Some("mp4") => "video/mp4",
        Some("aac") => "audio/aac",
        Some("webm") => "audio/webm",
        Some("weba") => "audio/webm",
        _ => "",
    }
}

/// songSeed(file)
pub fn song_seed(name: &str, bytes: &[u8], mime: &str) -> u32 {
    let mut h = hash_string(&format!("{}|{}|{mime}", if name.is_empty() { "song" } else { name }, bytes.len()));
    let head = &bytes[..bytes.len().min(65536)];
    let tail = &bytes[bytes.len().saturating_sub(65536)..];
    for part in [head, tail] {
        let mut i = 0;
        while i < part.len() {
            h ^= part[i] as u32;
            h = h.wrapping_mul(16777619);
            i += 17;
        }
    }
    h
}

pub struct Analysis {
    pub pitch: PitchAnalysis,
    pub lab: AttackLabData,
    pub patterns: Patterns,
    pub grid: Option<Grid>,
    pub duration: f64,
    pub output_channels: Vec<Vec<f32>>,
    pub output_rate: f64,
}

pub fn analyze(decoded: &Decoded, max_seconds: f64, job: &Job) -> anyhow::Result<Analysis> {
    let high = adv::get_str("audio.processingMode", "normal") == "high";
    let analysis_rate = if high { (adv::integer("audio.analysisRate", 22050.0).max(8000)) as f64 } else { 22050.0 };
    let output_rate = if high { (adv::integer("audio.outputRate", 32000.0).max(8000)) as f64 } else { 22050.0 };
    job.note("processingMode", if high { "high" } else { "normal" });
    job.set_progress(0.045, "Preparing PCM samples…");
    let t = now_ms();
    let (mono, output_channels) = if high {
        (audio::downmix_and_resample(decoded, analysis_rate, max_seconds), audio::resample_channels_for_output(decoded, output_rate, max_seconds))
    } else {
        let p = audio::resample_unified(decoded, analysis_rate, max_seconds);
        (p.mono, p.output_channels)
    };
    job.check()?;
    job.stage("resampleInputs", now_ms() - t);
    // Comparison harness hook (tools/js-harness): dump the exact analysis PCM.
    if let Ok(p) = std::env::var("SIMBERS_DUMP_PCM") {
        let mut b = Vec::with_capacity(mono.len() * 4);
        for s in &mono {
            b.extend_from_slice(&s.to_le_bytes());
        }
        std::fs::write(&p, b)?;
    }
    job.set_progress(0.05, "Computing pitch/timbre spectral frontend…");
    let unified = if high {
        None
    } else {
        match spectral::compute_unified(&mono, analysis_rate, job) {
            Ok(u) => u,
            Err(e) => {
                job.check()?;
                log::warn!("Unified analysis unavailable; falling back: {e}");
                job.note("unifiedFallback", e.to_string());
                None
            }
        }
    };
    let opts = PitchOpts {
        tracks: adv::integer("pitch.tracks", 1.0).max(1) as usize,
        confidence: adv::number("pitch.confidence", 0.9),
        ambiguity: adv::number("pitch.ambiguity", 0.1),
        stability: adv::number("pitch.stability", 2.5),
    };
    let pitch = spectral::analyze_samples(&mono, analysis_rate, opts, unified, job)?;
    job.check()?;
    {
        let p = &pitch.performance;
        job.stage("sharedFftFrontend", p.shared_fft_frontend);
        job.stage("pitchTracking", p.pitch_tracking);
        job.stage("foregroundSelection", p.foreground_selection);
        job.note("sharedFftSize", if p.shared_fft_size > 0 { p.shared_fft_size } else { pitch.frame_size });
        job.note("sharedFftHop", if p.shared_fft_hop > 0 { p.shared_fft_hop as i64 } else { adv::integer("detector.hopSize", 256.0) });
        job.note("pitchStride", p.pitch_stride.max(1));
        job.note("pitchFrames", if p.pitch_frames > 0 { p.pitch_frames } else { pitch.frames.len() });
        if p.spectral_frames > 0 {
            job.note("spectralFrames", p.spectral_frames);
        } else {
            job.note("spectralFrames", "legacy fallback");
        }
    }
    if let Some(t) = job.timing.lock().as_mut() {
        t.duration_sec = max_seconds;
    }
    job.set_progress(0.77, "Detecting original Attack Lab V2 onsets…");
    let lab = attack::prepare(&mono, analysis_rate, job)?;
    job.set_progress(0.82, "Detecting beat events and repeated patterns…");
    let t = now_ms();
    let popts = PatternOpts {
        context_beats: adv::integer("patterns.contextBeats", 4.0).max(1) as usize,
        threshold: adv::number("patterns.similarityThreshold", 0.78),
        transpose_invariant: adv::boolean("patterns.transposeInvariant", true),
        sensitivity: adv::number("detector.sensitivity", 1.0),
        minimum_gap_ms: adv::number("detector.minimumGapMs", 20.0).max(1.0),
    };
    let (pats, _det) = patterns::analyze(&pitch, &lab, popts, job)?;
    job.check()?;
    job.stage("beatPatternAnalysis", now_ms() - t);
    job.stage("similarityAllPairs", pats.similarity_ms);
    job.note("similarityPairs", pats.compared_pairs);
    job.note("quietRejectedOnsets", pats.quiet_rejected_candidate_count);
    let grid = beatmaps::grid_for_patterns(&pats);
    let duration = pitch.duration;
    Ok(Analysis { pitch, lab, patterns: pats, grid, duration, output_channels, output_rate })
}

pub struct Built {
    pub seed: String,
    pub song_name: String,
    pub sets: Vec<CharacteristicSet>,
    pub info: Value,
    pub cover: Vec<u8>,
    pub lights: Arc<Vec<LightEvent>>,
    pub expert_plus_nps: f64,
    pub expected_count: usize,
}

/// buildCharacteristicSetsForIntensity
pub fn build_sets(a: &Analysis, seed: &str, lights: Arc<Vec<LightEvent>>, features: FeatureOptions, intensity: f64, job: &Job) -> anyhow::Result<(Vec<CharacteristicSet>, usize)> {
    let configs = mapgen::difficulty_configs();
    let timing = |n: &str, ms: f64| job.accumulate(n, ms);
    let input = GenInput { analysis: &a.pitch, patterns: &a.patterns, grid: a.grid.as_ref(), duration: a.duration, nps_cap: select::nps_cap_for_intensity(intensity), timing: &timing };
    let ctx = input.select_ctx();
    let reference = select::expert_plus_reference(&ctx);
    if reference.is_empty() {
        anyhow::bail!("Expert+ reference map produced no usable beat events.");
    }
    let enabled: Vec<_> = configs
        .iter()
        .filter(|c| adv::boolean(&format!("difficulty.{}.enabled", c.id), true))
        .map(|c| select::intensity_adjusted(c, intensity, &reference))
        .collect();
    if enabled.is_empty() {
        anyhow::bail!("Enable at least one difficulty in Settings.");
    }
    let mut standard: Vec<Difficulty> = enabled.iter().map(|c| beatmaps::build_beatmap(&input, seed, c, lights.clone(), features, &beatmaps::GenOptions { characteristic: "Standard", lawless_level: 0.0 })).collect::<anyhow::Result<_>>()?;
    let check = || job.check();
    if features.bot_optimizer {
        let mut prog = |f: f64, l: &str| job.set_progress(0.865 + 0.046 * f, l);
        let m = bot::run_second_pass(&mut standard, Some(features), seed, &check, &mut prog)?;
        job.stage("botSecondPass", m.elapsed_ms);
        job.note("botVariants", m.models);
        job.note("botCheckedNotes", m.evaluated);
        job.note("botTroubleSpotsReviewed", m.reviewed);
        job.note("botSimplifiedArrows", m.changed);
        job.note("botRiskFlagsBefore", m.warnings_before);
        job.note("botRiskFlagsAfter", m.warnings_after);
        job.note("botMeanMsPerDifficultyRun", to_fixed_num(m.elapsed_ms / (2.0 * m.models as f64 * standard.len() as f64), 2));
    } else {
        job.stage("botSecondPass", 0.0);
        job.note("botVariants", "disabled");
    }
    let mut prog = |f: f64, l: &str| job.set_progress(0.913 + 0.025 * f, l);
    let pm = guard::run_physical_flow_guard(&mut standard, Some(features), seed, &check, &mut prog)?;
    job.stage("physicalFlowPass", pm.elapsed_ms);
    job.note("physicalFlagged", pm.flagged);
    job.note("physicalRepairedPhrases", pm.repaired_phrases);
    job.note("physicalRiskBefore", to_fixed_num(pm.risk_before, 2));
    job.note("physicalRiskAfter", to_fixed_num(pm.risk_after, 2));
    job.note("physicalUnresolved", pm.unresolved);
    let no_arrows = standard.iter().map(beatmaps::make_no_arrows).collect();
    let one_saber = standard.iter().map(|d| beatmaps::build_one_saber(d, seed, lights.clone(), features)).collect::<anyhow::Result<_>>()?;
    let r90 = standard.iter().map(|d| beatmaps::build_rotation(d, seed, "90Degree")).collect();
    let r360 = standard.iter().map(|d| beatmaps::build_rotation(d, seed, "360Degree")).collect();
    let lawless = enabled.iter().map(|c| beatmaps::build_lawless(&input, seed, c, lights.clone(), features)).collect::<anyhow::Result<_>>()?;
    let sets = vec![
        CharacteristicSet { characteristic: "Standard", difficulties: standard },
        CharacteristicSet { characteristic: "NoArrows", difficulties: no_arrows },
        CharacteristicSet { characteristic: "OneSaber", difficulties: one_saber },
        CharacteristicSet { characteristic: "90Degree", difficulties: r90 },
        CharacteristicSet { characteristic: "360Degree", difficulties: r360 },
        CharacteristicSet { characteristic: "Lawless", difficulties: lawless },
    ];
    Ok((sets, configs.len()))
}

/// prepareMapBuild
pub fn prepare_map_build(a: &Analysis, seed_num: u32, song_name: &str, features: FeatureOptions, intensity: f64, youtube: Option<&crate::youtube::Source>, job: &Job) -> anyhow::Result<Built> {
    let seed = seed_num.to_string();
    job.map_instrumentation.store(true, std::sync::atomic::Ordering::Relaxed);
    job.set_progress(0.845, "Building beat-driven default lighting…");
    let t = now_ms();
    let lights = Arc::new(lighting::build(&a.patterns.segments, a.duration, &seed));
    job.stage("mapLighting", now_ms() - t);
    job.set_progress(0.855, "Building Standard, No Arrows, One Saber, 90 Degree, 360 Degree, Lawless difficulties…");
    let t = now_ms();
    let built = build_sets(a, &seed, lights.clone(), features, intensity, job);
    job.map_instrumentation.store(false, std::sync::atomic::Ordering::Relaxed);
    let (sets, expected_count) = built?;
    job.stage("mapGeneration", now_ms() - t);
    let expert_plus_nps = sets[0].difficulties.iter().find(|d| d.config.id == "expertPlus").map(|d| d.nps).unwrap_or(0.0);
    job.set_progress(0.94, "Creating cover and preview…");
    let t = now_ms();
    let cover = match youtube {
        Some(y) => crate::youtube::square_cover(y).or_else(|e| {
            log::warn!("[Simbers YouTube] Thumbnail unavailable; using standard cover: {e}");
            export::cover::create_cover(song_name)
        })?,
        None => export::cover::create_cover(song_name)?,
    };
    job.stage("coverGeneration", now_ms() - t);
    let mut info = export::make_info(song_name, a.duration, &sets);
    if let (Some(y), Some(obj)) = (youtube, info.as_object_mut()) {
        obj.insert("_songName".into(), Value::String(if y.title.is_empty() { song_name.to_string() } else { y.title.clone() }));
        obj.insert("_songAuthorName".into(), Value::String(if y.author.is_empty() { "Unknown".into() } else { y.author.clone() }));
    }
    export::validate_info(&info, &sets, expected_count)?;
    job.note("difficulties", sets.iter().map(|s| s.difficulties.len()).sum::<usize>());
    job.note("events", a.patterns.segments.len());
    job.note("generatedNotes", sets.iter().flat_map(|s| s.difficulties.iter()).map(|d| d.note_count).sum::<usize>());
    let flows: std::collections::HashSet<&String> = sets.iter().flat_map(|s| s.difficulties.iter()).flat_map(|d| d.used_flow_ids.iter()).collect();
    job.note("uniqueCorpusFlows", flows.len());
    job.note("detector", "V2");
    Ok(Built { seed, song_name: song_name.to_string(), sets, info, cover, lights, expert_plus_nps, expected_count })
}

/// prepareExportAudio + packageFastContext
pub fn export_zip(built: &Built, a: &Analysis, source_bytes: &[u8], source_duration: f64, job: &Job) -> anyhow::Result<Vec<u8>> {
    let t = now_ms();
    let check = || job.check();
    let audio = match export::reusable_ogg(source_bytes, source_duration, a.duration, a.output_channels.len()) {
        Some(d) => {
            job.note("audioExportMethod", format!("source OGG {} passthrough", d.codec));
            source_bytes.to_vec()
        }
        None => {
            job.note("audioExportCodec", "Ogg Vorbis/libvorbis (Beat Saber compatible)");
            let mut prog = |r: f64| job.set_progress(r, format!("Encoding audio… {}%", (r * 100.0).round()));
            export::encode_ogg_vorbis(&a.output_channels, a.output_rate, &check, &mut prog)?
        }
    };
    job.stage("oggEncode", now_ms() - t);
    let t = now_ms();
    let mut prog = |r: f64| job.set_progress(r, "Packaging ZIP…");
    let zip = export::package(&built.info, &built.sets, &audio, &built.cover, built.expected_count, &check, &mut prog)?;
    job.stage("zipPackage", now_ms() - t);
    Ok(zip)
}

/// simbersLongSongMode: what to do with songs longer than selectedSongLimit.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum LongSongMode {
    Full,
    Highlights,
    Clip,
}

impl LongSongMode {
    pub fn parse(s: &str) -> Option<Self> {
        match s {
            "full" => Some(Self::Full),
            "highlights" => Some(Self::Highlights),
            "clip" => Some(Self::Clip),
            _ => None,
        }
    }
}

/// Result of a full build; `highlights` is set when the Highlights Edit was used.
pub struct RunOutput {
    pub built: Built,
    pub analysis: Analysis,
    pub zip: Vec<u8>,
    pub highlights: Option<audio::highlights::Plan>,
    /// Preview audio for the viewer (source bytes, or the encoded highlights Ogg).
    pub preview_audio: Vec<u8>,
    pub preview_mime: String,
}

/// Decode only (the UI asks the long-song question between decode and analysis).
pub fn decode(path: &Path, job: &Job) -> anyhow::Result<(Decoded, Vec<u8>)> {
    job.set_progress(0.04, "Decoding audio…");
    let t = now_ms();
    let r = audio::decode_file(path)?;
    job.stage("decodeAudio", now_ms() - t);
    Ok(r)
}

/// Headless end-to-end build (used by the CLI and by the UI worker thread).
pub fn run_file(path: &Path, opts: &RunOptions, job: &Job) -> anyhow::Result<RunOutput> {
    let (decoded, bytes) = decode(path, job)?;
    run_decoded(path, decoded, bytes, opts, job)
}

#[derive(Clone, Debug)]
pub struct RunOptions {
    pub intensity: f64,
    pub features: FeatureOptions,
    pub mode: LongSongMode,
    pub youtube: Option<crate::youtube::Source>,
}

/// runAnalysis after decode: highlights/clip handling, analysis, map build, export.
pub fn run_decoded(path: &Path, decoded: Decoded, bytes: Vec<u8>, opts: &RunOptions, job: &Job) -> anyhow::Result<RunOutput> {
    use audio::highlights;
    let (intensity, features, mode) = (opts.intensity, opts.features, opts.mode);
    let file_name = path.file_name().and_then(|n| n.to_str()).unwrap_or("song");
    let mime = mime_for(path);
    let seed = song_seed(file_name, &bytes, mime);
    let song_name = export::safe_base_name(file_name);
    let source_duration = decoded.duration();
    let limit = highlights::selected_song_limit();
    let mut plan = None;
    let active = if mode == LongSongMode::Highlights && source_duration > limit {
        job.set_progress(0.045, "Finding rhythm-aligned highlights across the song…");
        let p = highlights::plan(&decoded, limit)?;
        let check = || job.check();
        let edited = highlights::assemble(&decoded, &p, &check)?;
        job.check()?;
        if let Ok(dir) = std::env::var("SIMBERS_DUMP_HIGHLIGHTS") {
            dump_highlights(Path::new(&dir), &decoded, &edited, &p)?;
        }
        job.note("highlightsSegments", p.sections.len());
        job.note("highlightsSourceSeconds", crate::util::to_fixed(source_duration, 1));
        job.note("highlightsOutputSeconds", crate::util::to_fixed(edited.duration(), 1));
        plan = Some(p);
        edited
    } else {
        decoded
    };
    let max_seconds = if mode == LongSongMode::Clip { active.duration().min(limit) } else { active.duration() };
    let a = analyze(&active, max_seconds, job)?;
    drop(active);
    let mut preview_audio = bytes.clone();
    let mut preview_mime = if mime.is_empty() { "audio/mpeg".to_string() } else { mime.to_string() };
    let mut highlights_ogg = None;
    if plan.is_some() {
        job.set_progress(0.835, "Encoding edited highlights for synchronized preview…");
        let t = now_ms();
        let check = || job.check();
        let mut prog = |f: f64| job.set_progress(0.835 + 0.008 * f.min(1.0), format!("Encoding highlights… {}%", (f * 100.0).round()));
        let ogg = export::encode_ogg_vorbis(&a.output_channels, a.output_rate, &check, &mut prog)?;
        job.stage("highlightsVorbisEncode", now_ms() - t);
        preview_audio = ogg.clone();
        preview_mime = "audio/ogg".into();
        highlights_ogg = Some(ogg);
    }
    let mut built = prepare_map_build(&a, seed, &song_name, features, intensity, opts.youtube.as_ref(), job)?;
    if let Some(p) = &plan {
        apply_highlights_info(&mut built.info, p);
    }
    let zip = match &highlights_ogg {
        Some(ogg) => {
            job.note("audioExportMethod", "pre-encoded edited highlights (Ogg Vorbis)");
            package_with_audio(&built, ogg, job)?
        }
        None => export_zip(&built, &a, &bytes, source_duration, job)?,
    };
    Ok(RunOutput { built, analysis: a, zip, highlights: plan, preview_audio, preview_mime })
}

/// Comparison harness hook (tools/js-harness/highlights.js).
fn dump_highlights(dir: &Path, source: &Decoded, edited: &Decoded, p: &audio::highlights::Plan) -> anyhow::Result<()> {
    std::fs::create_dir_all(dir)?;
    let write = |name: &str, d: &Decoded| -> anyhow::Result<()> {
        let mut b = Vec::with_capacity(d.len() * d.channels.len() * 4);
        for c in &d.channels {
            for s in c {
                b.extend_from_slice(&s.to_le_bytes());
            }
        }
        Ok(std::fs::write(dir.join(name), b)?)
    };
    write("source.f32", source)?;
    write("edited.f32", edited)?;
    let plan = serde_json::json!({
        "sampleRate": source.sample_rate, "channels": source.channels.len(), "length": source.len(),
        "sections": p.sections.iter().map(|s| serde_json::json!({"start": s.start, "end": s.end})).collect::<Vec<_>>(),
        "cuts": p.cuts.iter().map(|c| serde_json::json!({"time": c.time, "from": c.from, "previousEnd": c.previous_end})).collect::<Vec<_>>(),
        "duration": p.duration, "sourceDuration": p.source_duration, "pulseSeconds": p.pulse_seconds,
    });
    std::fs::write(dir.join("plan.json"), serde_json::to_string(&plan)?)?;
    Ok(())
}

/// The Info.dat edits runAnalysis makes for a Highlights Edit.
pub fn apply_highlights_info(info: &mut Value, plan: &audio::highlights::Plan) {
    let cuts: Vec<Value> = plan.cuts.iter().map(|c| serde_json::json!(to_fixed_num(c.time, 3))).collect();
    if let Some(obj) = info.as_object_mut() {
        let cd = obj.entry("_customData").or_insert_with(|| Value::Object(Default::default()));
        if !cd.is_object() {
            *cd = Value::Object(Default::default());
        }
        cd.as_object_mut().unwrap().insert("_simbersHighlightsCuts".into(), Value::Array(cuts));
        obj.insert("_songSubName".into(), Value::String(format!("Highlights Edit · {} sections", plan.sections.len())));
    }
}

fn package_with_audio(built: &Built, audio: &[u8], job: &Job) -> anyhow::Result<Vec<u8>> {
    let t = now_ms();
    let check = || job.check();
    let mut prog = |r: f64| job.set_progress(r, "Packaging ZIP…");
    let zip = export::package(&built.info, &built.sets, audio, &built.cover, built.expected_count, &check, &mut prog)?;
    job.stage("zipPackage", now_ms() - t);
    Ok(zip)
}

/// Viewer payload for a fresh generation (prepareMapBuild's viewerPayload).
pub fn viewer_payload(r: &RunOutput) -> crate::payload::ViewerPayload {
    use crate::payload::*;
    let sets = &r.built.sets;
    ViewerPayload {
        info: r.built.info.clone(),
        characteristics: sets
            .iter()
            .map(|s| CharacteristicRef {
                name: s.characteristic.to_string(),
                difficulties: s.difficulties.iter().map(|d| DifficultyRef { difficulty: d.config.difficulty.clone(), rank: d.config.rank, filename: d.filename.clone(), njs: d.config.note_jump_movement_speed }).collect(),
            })
            .collect(),
        maps: sets
            .iter()
            .flat_map(|s| s.difficulties.iter())
            .map(|d| MapEntry {
                characteristic: if d.characteristic.is_empty() { "Standard".into() } else { d.characteristic.clone() },
                difficulty: d.config.difficulty.clone(),
                rank: d.config.rank,
                filename: d.filename.clone(),
                njs: d.config.note_jump_movement_speed,
                beatmap: d.beatmap.to_json(),
            })
            .collect(),
        audio_bytes: Some(r.preview_audio.clone()),
        audio_mime: r.preview_mime.clone(),
        cover_bytes: Some(r.built.cover.clone()),
        max_duration_sec: Some(r.analysis.duration),
        highlights_cuts: r.highlights.as_ref().map(|p| p.cuts.iter().map(|c| c.time).collect()).unwrap_or_default(),
    }
}

/// pastJobsEnqueueSave record for a finished build.
pub fn history_record(r: &RunOutput, source: &Path, source_size: u64, intensity: f64, youtube: Option<&crate::youtube::Source>, created_at: f64) -> crate::storage::history::JobRecord {
    let all: Vec<&Difficulty> = r.built.sets.iter().flat_map(|s| s.difficulties.iter()).collect();
    let standard = all
        .iter()
        .find(|d| (d.characteristic.is_empty() || d.characteristic == "Standard") && d.config.id == "expertPlus")
        .or_else(|| all.iter().find(|d| d.config.id == "expertPlus"));
    let file_name = source.file_name().and_then(|n| n.to_str()).unwrap_or("");
    let song = &r.built.song_name;
    crate::storage::history::JobRecord {
        id: crate::storage::history::new_id(),
        created_at,
        name: if song.is_empty() { "Untitled".into() } else { song.clone() },
        zip_name: format!("{}_SimplifiedSabers.zip", if song.is_empty() { "Generated" } else { song }),
        youtube_source: youtube.and_then(|y| serde_json::to_value(y).ok()),
        zip_size: r.zip.len() as u64,
        audio_name: if file_name.is_empty() { format!("{}.mp3", if song.is_empty() { "song" } else { song }) } else { file_name.to_string() },
        audio_type: { let m = mime_for(source); if m.is_empty() { "audio/mpeg".into() } else { m.into() } },
        audio_size: source_size,
        nps: standard.map(|d| d.nps).filter(|v| v.is_finite()),
        note_count: standard.map(|d| d.beatmap.notes.len() as u64),
        duration: r.analysis.duration,
        intensity: if intensity > 0.0 { intensity } else { 100.0 },
    }
}
