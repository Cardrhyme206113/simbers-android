//! 8-variant note-space robustness review (bot-robustness.js).

use super::FeatureOptions;
use super::GNote;
use super::beatmaps::Difficulty;
use super::choreo::{HState, cross_risk, hand_step, sc2_median};
use super::corpus::{ANGLES, CNote, OPPOSITE, angular_error};
use super::swing::human_flow_audit;
use crate::util::{js_round, jsm, now_ms};
use serde_json::Value;
use std::collections::HashMap;

pub const BOT_COUNT: usize = 8;

#[derive(Clone, Copy, Debug)]
pub struct Profile {
    pub strict: f64,
    pub jitter: f64,
    pub delay: f64,
    pub phase: f64,
    pub fatigue: f64,
}

pub fn profiles() -> Vec<Profile> {
    (0..BOT_COUNT)
        .map(|i| Profile {
            strict: 0.84 + ((i * 13) % 32) as f64 / 31.0 * 0.34,
            jitter: 0.006 + ((i * 7) % 11) as f64 / 10.0 * 0.022,
            delay: (((i * 19) % 17) as f64 - 8.0) * 0.0022,
            phase: i as f64 * 1.61803398875,
            fatigue: 0.82 + ((i * 23) % 31) as f64 / 30.0 * 0.36,
        })
        .collect()
}

pub struct Ctx {
    pub order: Vec<usize>,
    pub previous: Vec<i32>,
    pub following: Vec<i32>,
    pub partner: Vec<i32>,
}

pub fn context(notes: &[GNote]) -> Ctx {
    let mut order: Vec<usize> = (0..notes.len()).filter(|&i| notes[i].type_ == 0 || notes[i].type_ == 1).collect();
    order.sort_by(|&a, &b| notes[a].time.partial_cmp(&notes[b].time).unwrap().then(notes[a].type_.cmp(&notes[b].type_)).then(a.cmp(&b)));
    let n = notes.len();
    let (mut previous, mut following, mut partner) = (vec![-1i32; n], vec![-1i32; n], vec![-1i32; n]);
    let mut last = [-1i32; 2];
    for &index in &order {
        let hand = notes[index].type_ as usize;
        previous[index] = last[hand];
        if last[hand] >= 0 {
            following[last[hand] as usize] = index as i32;
        }
        let other = last[1 - hand];
        if other >= 0 && (notes[index].time - notes[other as usize].time).abs() < 0.001 {
            partner[index] = other;
            partner[other as usize] = index as i32;
        }
        last[hand] = index as i32;
    }
    Ctx { order, previous, following, partner }
}

fn transition(prev: Option<&GNote>, note: &GNote, p: &Profile, index: i64, hand: i32, next: bool) -> f64 {
    let Some(prev) = prev else { return 0.0 };
    let t = note.time + p.delay + p.jitter * jsm::sin(index as f64 * 1.171 + p.phase + if next { 2.0 } else { 0.0 });
    let pt = prev.time + p.delay + p.jitter * jsm::sin((index - 1) as f64 * 1.171 + p.phase);
    let ps = HState { x: prev.line_index, y: prev.line_layer, d: prev.cut_direction, t: pt, strain: 0.12 * p.fatigue, cost: 0.0 };
    match hand_step(Some(&ps), CNote { x: note.line_index, y: note.line_layer, d: note.cut_direction }, t, hand, p.strict) {
        None => 2.1,
        Some(s) => 2f64.min(0f64.max((s.cost - 0.75) / 1.6)),
    }
}

pub fn pair_cost(a: &GNote, b: &GNote) -> f64 {
    if (a.time - b.time).abs() > 0.17 {
        return 0.0;
    }
    let red = if a.type_ == 0 { a } else { b };
    let blue = if a.type_ == 1 { a } else { b };
    if red.line_index >= blue.line_index {
        return 3.0;
    }
    if cross_risk(
        CNote { x: red.line_index, y: red.line_layer, d: red.cut_direction },
        CNote { x: blue.line_index, y: blue.line_layer, d: blue.cut_direction },
        a.time - b.time,
    ) >= 100.0
    {
        3.0
    } else {
        0.0
    }
}

fn local_risk(notes: &[GNote], ctx: &Ctx, index: usize, p: &Profile) -> f64 {
    let n = &notes[index];
    let prev = (ctx.previous[index] >= 0).then(|| &notes[ctx.previous[index] as usize]);
    let mut risk = transition(prev, n, p, index as i64, n.type_, false);
    if ctx.following[index] >= 0 {
        let f = ctx.following[index] as usize;
        risk += 0.55 * transition(Some(n), &notes[f], p, f as i64, n.type_, true);
    }
    if ctx.partner[index] >= 0 {
        risk += pair_cost(n, &notes[ctx.partner[index] as usize]) * 0.65;
    }
    risk
}

fn ang(a: i32, b: i32) -> f64 {
    angular_error(ANGLES[a.clamp(0, 8) as usize], ANGLES[b.clamp(0, 8) as usize])
}

pub fn check_directions(notes: &[GNote], ctx: &Ctx, index: usize, direction: i32) -> bool {
    let check_one = |i: usize, d: i32| -> bool {
        if d == 2 || d == 3 || d > 7 {
            return false;
        }
        if ctx.previous[i] >= 0 && ang(d, notes[ctx.previous[i] as usize].cut_direction) < 135.0 {
            return false;
        }
        if ctx.following[i] >= 0 && ang(d, notes[ctx.following[i] as usize].cut_direction) < 135.0 {
            return false;
        }
        true
    };
    if !check_one(index, direction) {
        return false;
    }
    let oi = ctx.partner[index];
    if oi < 0 {
        return true;
    }
    let mut a = notes[index].clone();
    a.cut_direction = direction;
    pair_cost(&a, &notes[oi as usize]) < 0.001
}

fn phrase_groups(notes: &[GNote], ctx: &Ctx) -> Vec<Vec<usize>> {
    let mut result: Vec<Vec<usize>> = vec![];
    let mut by_hand: [Vec<usize>; 2] = [vec![], vec![]];
    for &i in &ctx.order {
        by_hand[notes[i].type_ as usize].push(i);
    }
    for hn in &by_hand {
        let mut phrase: Vec<usize> = vec![];
        for &index in hn {
            let n = &notes[index];
            let brk = match phrase.last() {
                _ if phrase.len() >= 6 => true,
                None => false,
                Some(&l) => {
                    let last = &notes[l];
                    n.time - last.time > 0.95 || (n.flow_phrase.is_some() && last.flow_phrase.is_some() && n.flow_phrase != last.flow_phrase && phrase.len() >= 3)
                }
            };
            if brk {
                result.push(std::mem::take(&mut phrase));
            }
            phrase.push(index);
        }
        if !phrase.is_empty() {
            result.push(phrase);
        }
    }
    result.sort_by(|a, b| notes[a[0]].time.partial_cmp(&notes[b[0]].time).unwrap().then(notes[a[0]].type_.cmp(&notes[b[0]].type_)));
    result
}

fn phrase_risk(notes: &[GNote], ctx: &Ctx, phrase: &[usize], p: &Profile) -> f64 {
    phrase.iter().map(|&i| local_risk(notes, ctx, i, p)).fold(0.0, |a, b| a + b)
}

fn phrase_cadence(notes: &[GNote], phrase: &[usize]) -> String {
    let gaps: Vec<f64> = (1..phrase.len()).map(|j| notes[phrase[j]].time - notes[phrase[j - 1]].time).collect();
    let mid = sc2_median(&gaps);
    let tail: String = gaps.iter().map(|&g| if g < mid * 0.76 { 's' } else if g > mid * 1.55 { 'l' } else { 'm' }).collect();
    format!("{}/{}/{}/{tail}", notes[phrase[0]].type_, phrase.len(), crate::util::js_num_to_string(js_round(mid / 0.075)))
}

fn try_phrase(notes: &mut [GNote], ctx: &Ctx, phrase: &[usize], dirs: &[i32], profiles: &[Profile]) -> f64 {
    if dirs.len() != phrase.len() {
        return f64::INFINITY;
    }
    let originals: Vec<i32> = phrase.iter().map(|&i| notes[i].cut_direction).collect();
    for (j, &i) in phrase.iter().enumerate() {
        notes[i].cut_direction = dirs[j];
    }
    let result = if phrase.iter().any(|&i| !check_directions(notes, ctx, i, notes[i].cut_direction)) {
        f64::INFINITY
    } else {
        let mut risk = 0.0;
        for p in profiles {
            risk += phrase_risk(notes, ctx, phrase, p);
        }
        let changes = originals.iter().zip(dirs).filter(|(a, b)| a != b).count();
        risk / profiles.len() as f64 + changes as f64 * 1.15
    };
    for (j, &i) in phrase.iter().enumerate() {
        notes[i].cut_direction = originals[j];
    }
    result
}

#[derive(Clone, Debug, Default)]
pub struct BotSummary {
    pub elapsed_ms: f64,
    pub models: usize,
    pub evaluated: usize,
    pub reviewed: usize,
    pub changed: usize,
    pub warnings_before: usize,
    pub warnings_after: usize,
    pub phrases_reused: usize,
}

pub fn run_second_pass(
    diffs: &mut [Difficulty],
    features: Option<FeatureOptions>,
    seed: &str,
    check: &dyn Fn() -> anyhow::Result<()>,
    progress: &mut dyn FnMut(f64, &str),
) -> anyhow::Result<BotSummary> {
    let started = now_ms();
    let profiles = profiles();
    let total = 1usize.max(diffs.len() * (BOT_COUNT * 2 + 1)) as f64;
    let mut s = BotSummary { models: BOT_COUNT, ..Default::default() };
    let mut completed = 0usize;
    let threshold_flag = (profiles.len() as f64 * (7.0 / 32.0)).ceil() as u8;
    for (di, diff) in diffs.iter_mut().enumerate() {
        let label = if diff.config.label.is_empty() { format!("#{}", di + 1) } else { diff.config.label.clone() };
        let ctx = context(&diff.source_notes);
        let phrases = phrase_groups(&diff.source_notes, &ctx);
        let mut risk_sum = vec![0f32; phrases.len()];
        let mut flagged = vec![0u8; phrases.len()];
        for (run, p) in profiles.iter().enumerate() {
            check()?;
            for (i, ph) in phrases.iter().enumerate() {
                let r = phrase_risk(&diff.source_notes, &ctx, ph, p);
                risk_sum[i] = (risk_sum[i] as f64 + r) as f32;
                if r > 1.3f64.max(ph.len() as f64 * 0.80) {
                    flagged[i] += 1;
                }
            }
            completed += 1;
            if run % 2 == 1 {
                progress(1f64.min(completed as f64 / total), &format!("Bot phrase review · {label} · {}/{}", run + 1, profiles.len()));
            }
        }
        let mut priorities: Vec<(usize, f64)> = (0..phrases.len())
            .map(|i| (i, risk_sum[i] as f64 / profiles.len() as f64))
            .filter(|&(i, r)| flagged[i] >= threshold_flag || r > phrases[i].len() as f64 * 0.92)
            .collect();
        priorities.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal));
        let budget = priorities.len().min(6usize.max((phrases.len() as f64 * 0.15).ceil() as usize));
        let mut library: HashMap<String, Vec<i32>> = HashMap::new();
        for ph in &phrases {
            let key = phrase_cadence(&diff.source_notes, ph);
            if !library.contains_key(&key) && ph.iter().all(|&i| check_directions(&diff.source_notes, &ctx, i, diff.source_notes[i].cut_direction)) {
                library.insert(key, ph.iter().map(|&i| diff.source_notes[i].cut_direction).collect());
            }
        }
        let mut fixed_here = 0usize;
        for (i, &(pi, _)) in priorities.iter().take(budget).enumerate() {
            check()?;
            if i % 12 == 0 {
                progress(1f64.min(completed as f64 / total), &format!("Bot phrase repair · {label} · {i}/{budget}"));
            }
            let phrase = &phrases[pi];
            s.reviewed += 1;
            let notes = &mut diff.source_notes;
            let original: Vec<i32> = phrase.iter().map(|&i| notes[i].cut_direction).collect();
            let mut best = original.clone();
            let mut best_is_stored = false;
            let mut best_risk = try_phrase(notes, &ctx, phrase, &original, &profiles);
            let mut cands: Vec<(Vec<i32>, bool)> = vec![];
            if let Some(st) = library.get(&phrase_cadence(notes, phrase)) {
                cands.push((st.clone(), true));
            }
            for start in [0, 1, 4, 5, 6, 7] {
                cands.push(((0..phrase.len()).map(|j| if j % 2 == 1 { OPPOSITE[start as usize] } else { start }).collect(), false));
            }
            for (c, stored) in &cands {
                let r = try_phrase(notes, &ctx, phrase, c, &profiles);
                if r < best_risk - 0.001 {
                    best_risk = r;
                    best = c.clone();
                    best_is_stored = *stored;
                }
            }
            let baseline = try_phrase(notes, &ctx, phrase, &original, &profiles);
            if best_risk.is_finite() && best_risk < baseline - 0.85 {
                for (j, &ni) in phrase.iter().enumerate() {
                    if notes[ni].cut_direction != best[j] {
                        notes[ni].cut_direction = best[j];
                        fixed_here += 1;
                        s.changed += 1;
                    }
                }
                if best_is_stored {
                    s.phrases_reused += 1;
                }
            }
        }
        completed += 1;
        progress(1f64.min(completed as f64 / total), &format!("Bot phrases repaired · {label} · {fixed_here} arrows"));
        for (run, p) in profiles.iter().enumerate() {
            check()?;
            for ph in &phrases {
                if phrase_risk(&diff.source_notes, &ctx, ph, p) > 1.3f64.max(ph.len() as f64 * 0.80) {
                    s.warnings_after += 1;
                }
            }
            completed += 1;
            if run % 2 == 1 {
                progress(1f64.min(completed as f64 / total), &format!("Bot phrase verify · {label} · {}/{}", run + 1, profiles.len()));
            }
        }
        s.warnings_before += flagged.iter().map(|&f| f as usize).sum::<usize>();
        s.evaluated += ctx.order.len();
        let broken = human_flow_audit(&diff.source_notes, false);
        if broken > 0 {
            anyhow::bail!("Bot phrase continuity regression ({broken})");
        }
        diff.sync_color_notes(false)?;
        if features.map(|f| f.arcs).unwrap_or(false) && fixed_here > 0 {
            diff.beatmap.sliders = super::arcs::build(&diff.source_notes, &diff.config);
            diff.arc_count = diff.beatmap.sliders.len();
        }
        let cd = &mut diff.beatmap.custom_data;
        cd.insert("_botRobustness".into(), Value::from(format!("{} lightweight phrase-level swing/reach/timing variants", profiles.len())));
        cd.insert("_botReviewedPhrases".into(), Value::from(s.reviewed));
        cd.insert("_botArrowCorrections".into(), Value::from(fixed_here));
        cd.insert("_botPhraseReprises".into(), Value::from(s.phrases_reused));
    }
    progress(1f64.min(completed as f64 / total), &format!("Bot phrase validation complete · {} arrows optimized", s.changed));
    s.elapsed_ms = now_ms() - started;
    let _ = seed;
    Ok(s)
}
