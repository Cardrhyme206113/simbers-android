//! Map generation (generation/*.js).

pub mod arcs;
pub mod beatmaps;
pub mod bombs;
pub mod bot;
pub mod choreo;
pub mod corpus;
pub mod grid;
pub mod guard;
pub mod lighting;
pub mod nps;
pub mod select;
pub mod swing;
pub mod walls;

use crate::analysis::patterns::Segment;
use crate::settings as adv;
use serde_json::Value;
use std::sync::Arc;

/// A generated colour note (the JS objects flowing through generation).
#[derive(Clone, Debug, Default)]
pub struct GNote {
    pub event_index: i64,
    pub time: f64,
    pub line_index: i32,
    pub line_layer: i32,
    pub type_: i32,
    pub cut_direction: i32,
    pub flow_difficulty: String,
    pub segment: Option<Arc<Segment>>,
    pub flow_source: Option<&'static str>,
    pub flow_phrase: Option<usize>,
    pub flow_motif: Option<&'static str>,
    pub flow_speed_pressure: f64,
    pub one_saber_source_hand: Option<i32>,
    pub notation_section: Option<usize>,
}

pub fn density_fraction(id: &str) -> Option<f64> {
    match id {
        "easy" => Some(0.2),
        "medium" => Some(0.4),
        "hard" => Some(0.6),
        "expert" => Some(0.8),
        "expertPlus" => Some(1.0),
        _ => None,
    }
}

pub fn lawless_level(id: &str) -> Option<f64> {
    density_fraction(id)
}

pub const DIFFICULTY_IDS: [&str; 5] = ["easy", "medium", "hard", "expert", "expertPlus"];

#[derive(Clone, Debug, Default)]
pub struct DifficultyConfig {
    pub id: String,
    pub label: String,
    pub difficulty: String,
    pub rank: f64,
    pub filename: String,
    pub minimum_gap_ms: f64,
    pub note_jump_movement_speed: f64,
    pub arc_min_gap: f64,
    pub arc_max_gap: f64,
    pub arc_every_events: f64,
    pub arc_score_floor: f64,
    pub bomb_every_events: f64,
    pub bomb_lag_min: f64,
    pub bomb_lag_max: f64,
    pub bomb_direct_rate: f64,
    pub bomb_follow_rate: f64,
    pub wall_every_events: f64,
    pub wall_minimum_gap: f64,
    pub wall_min_duration: f64,
    pub wall_max_duration: f64,
    pub wall_width: f64,
    pub crouch_wall_rate: f64,
    pub crouch_minimum_gap: f64,
    pub weights: [f64; 3],
    // intensityAdjustedConfig fields
    pub intensity_percent: f64,
    pub expert_plus_intensity_percent: f64,
    pub difficulty_density_percent: f64,
    pub target_relative_percent: f64,
    pub expert_plus_reference_count: usize,
    pub expert_plus_reference_segments: Vec<Arc<Segment>>,
    pub target_event_count: usize,
    pub base_minimum_gap_ms: f64,
}

fn js_num(v: Option<&Value>, fallback: f64) -> f64 {
    match v {
        None | Some(Value::Null) => fallback,
        Some(x) => crate::util::js_number(x),
    }
}

fn js_str(v: Option<&Value>, fallback: &str) -> String {
    match v {
        None | Some(Value::Null) => fallback.to_string(),
        Some(Value::String(s)) => s.clone(),
        Some(x) => crate::job::js_value_string(x),
    }
}

/// DIFFICULTY_CONFIGS after applyAdvancedDifficultySettings().
pub fn difficulty_configs() -> Vec<DifficultyConfig> {
    let defaults = &adv::ADV_DEFAULTS["difficulty"];
    DIFFICULTY_IDS
        .iter()
        .map(|id| {
            let d = &defaults[*id];
            let s = adv::get(&format!("difficulty.{id}")).unwrap_or(Value::Object(Default::default()));
            let g = |k: &str| s.get(k).or(d.get(k));
            let dn = |k: &str| crate::util::js_number(&d[k]);
            let rnd = crate::util::js_round;
            let mut c = DifficultyConfig { id: id.to_string(), ..Default::default() };
            c.label = js_str(g("label"), d["label"].as_str().unwrap());
            c.difficulty = js_str(g("difficulty"), d["difficulty"].as_str().unwrap());
            c.rank = rnd(js_num(g("rank"), dn("rank"))).max(1.0);
            c.filename = js_str(g("filename"), d["filename"].as_str().unwrap());
            c.minimum_gap_ms = js_num(g("minimumGapMs"), dn("minimumGapMs")).max(1.0);
            c.note_jump_movement_speed = js_num(g("noteJumpMovementSpeed"), dn("noteJumpMovementSpeed")).max(0.1);
            c.arc_min_gap = js_num(g("arcMinGap"), dn("arcMinGap")).max(0.001);
            c.arc_max_gap = js_num(g("arcMaxGap"), dn("arcMaxGap")).max(c.arc_min_gap);
            c.arc_every_events = rnd(js_num(g("arcEveryEvents"), dn("arcEveryEvents"))).max(1.0);
            c.arc_score_floor = js_num(g("arcScoreFloor"), dn("arcScoreFloor"));
            c.bomb_every_events = rnd(js_num(g("bombEveryEvents"), 0.0)).max(0.0);
            c.bomb_lag_min = js_num(g("bombLagMin"), 0.1).max(0.0);
            c.bomb_lag_max = js_num(g("bombLagMax"), 0.2).max(c.bomb_lag_min);
            c.bomb_direct_rate = js_num(g("bombDirectRate"), 0.0);
            c.bomb_follow_rate = js_num(g("bombFollowRate"), 0.0);
            c.wall_every_events = rnd(js_num(g("wallEveryEvents"), 0.0)).max(0.0);
            c.wall_minimum_gap = js_num(g("wallMinimumGap"), 0.5).max(0.0);
            c.wall_min_duration = js_num(g("wallMinDuration"), 0.2).max(0.001);
            c.wall_max_duration = js_num(g("wallMaxDuration"), 0.5).max(c.wall_min_duration);
            c.wall_width = rnd(js_num(g("wallWidth"), 1.0)).max(1.0);
            c.crouch_wall_rate = js_num(g("crouchWallRate"), 0.0);
            c.crouch_minimum_gap = js_num(g("crouchMinimumGap"), 0.75).max(0.0);
            let mut w = [
                js_num(g("weightEasy"), dn("weightEasy")).max(0.0),
                js_num(g("weightMedium"), dn("weightMedium")).max(0.0),
                js_num(g("weightHard"), dn("weightHard")).max(0.0),
            ];
            let total = w[0] + w[1] + w[2];
            if total <= 0.0 {
                w[0] = 1.0;
            } else {
                w[0] /= total;
                w[1] /= total;
                w[2] /= total;
            }
            c.weights = w;
            c.base_minimum_gap_ms = c.minimum_gap_ms;
            c
        })
        .collect()
}

#[derive(Clone, Copy, Debug)]
pub struct FeatureOptions {
    pub bombs: bool,
    pub walls: bool,
    pub arcs: bool,
    pub bot_optimizer: bool,
}
