//! Natural arcs (arcs.js).

use super::beatmaps::Slider;
use super::{DifficultyConfig, GNote};
use crate::settings as adv;
use crate::util::{clamp, jsm, to_fixed_num, PI};
use std::collections::HashSet;

pub const CUT_DEG: [f64; 8] = [0.0, 180.0, 270.0, 90.0, 315.0, 45.0, 225.0, 135.0];
pub const CUT_VEC: [(f64, f64); 8] = [(0.0, 1.0), (0.0, -1.0), (-1.0, 0.0), (1.0, 0.0), (-0.707, 0.707), (0.707, 0.707), (-0.707, -0.707), (0.707, -0.707)];

pub fn vector_angle(dx: f64, dy: f64) -> f64 {
    let r = jsm::atan2(dx, dy);
    let mut d = (r * 180.0) / PI;
    if d < 0.0 {
        d += 360.0;
    }
    d
}

pub fn cut_angle(code: i32) -> f64 {
    if (0..8).contains(&code) { CUT_DEG[code as usize] } else { 180.0 }
}

pub fn angle_distance(a: f64, b: f64) -> f64 {
    (((a - b + 540.0) % 360.0) - 180.0).abs()
}

fn control_multiplier(a: &GNote, b: &GNote) -> f64 {
    let gap = b.time - a.time;
    let distance = jsm::hypot((b.line_index - a.line_index) as f64, (b.line_layer - a.line_layer) as f64);
    to_fixed_num(
        clamp(
            adv::number("arcs.controlBase", 0.62) + gap * adv::number("arcs.controlGapWeight", 0.92) + distance * adv::number("arcs.controlDistanceWeight", 0.13),
            adv::number("arcs.controlMinimum", 0.65),
            adv::number("arcs.controlMaximum", 1.42),
        ),
        3,
    )
}

struct Cand {
    a: usize,
    b: usize,
    score: f64,
    launch_error: f64,
    gap: f64,
}

pub fn build(notes: &[GNote], config: &DifficultyConfig) -> Vec<Slider> {
    let mut by_hand: [Vec<usize>; 2] = [vec![], vec![]];
    for h in 0..2 {
        by_hand[h] = (0..notes.len()).filter(|&i| notes[i].type_ == h as i32).collect();
        by_hand[h].sort_by_key(|&i| notes[i].event_index);
    }
    let mut hand_index = vec![0usize; notes.len()];
    for h in 0..2 {
        for (k, &i) in by_hand[h].iter().enumerate() {
            hand_index[i] = k;
        }
    }
    let event_count = notes.iter().map(|n| n.event_index + 1).max().unwrap_or(0).max(0);
    if event_count < 2 {
        return vec![];
    }
    let cadence = 3f64.max(if config.arc_every_events != 0.0 { config.arc_every_events } else { 5.0 }) as i64;
    let p = |k: &str, d: f64| adv::number(k, d);
    let (nmin, nmax, dmin, dmax) = (p("arcs.naturalMinGap", 0.12), p("arcs.naturalMaxGap", 1.35), p("arcs.minimumDistance", 0.45), p("arcs.maximumDistance", 3.25));
    let (mlw, mpw, mmw, msw, mgw) = (p("arcs.movementLaunchWeight", 0.62), p("arcs.movementParityWeight", 0.38), p("arcs.musicalMelodyWeight", 0.48), p("arcs.musicalStateWeight", 0.32), p("arcs.musicalGroupWeight", 0.2));
    let (ideal_d, d_range) = (p("arcs.idealDistance", 1.45), p("arcs.distanceRange", 1.65));
    let (smw, smuw, stw, sdw) = (p("arcs.scoreMovementWeight", 0.44), p("arcs.scoreMusicalWeight", 0.32), p("arcs.scoreTimingWeight", 0.14), p("arcs.scoreDistanceWeight", 0.1));
    let max_skip = adv::integer("arcs.maximumSkippedNotes", 2.0).max(1) as usize;
    let tol = p("arcs.oppositeHandTolerance", 0.075);
    let natural = |hi: usize, ti: usize| -> Option<Cand> {
        let (head, tail) = (&notes[hi], &notes[ti]);
        let gap = tail.time - head.time;
        if gap < nmin || gap > nmax {
            return None;
        }
        let dx = (tail.line_index - head.line_index) as f64;
        let dy = (tail.line_layer - head.line_layer) as f64;
        let distance = jsm::hypot(dx, dy);
        if distance < dmin || distance > dmax {
            return None;
        }
        let travel = vector_angle(dx, dy);
        let ha = cut_angle(head.cut_direction);
        let ta = cut_angle(tail.cut_direction);
        let launch_error = angle_distance(ha, travel);
        let parity_error = angle_distance(ta, (ha + 180.0) % 360.0);
        let movement = clamp(mlw * (1.0 - clamp(launch_error / 120.0, 0.0, 1.0)) + mpw * (1.0 - clamp(parity_error / 120.0, 0.0, 1.0)), 0.0, 1.0);
        let mv = |n: &GNote| n.segment.as_ref().map(|s| s.melody_value).filter(|v| !v.is_nan()).unwrap_or(0.0);
        let sc = |n: &GNote| n.segment.as_ref().map(|s| s.state_change).filter(|v| !v.is_nan()).unwrap_or(0.0);
        let melody_diff = (mv(head) - mv(tail)).abs();
        let state_diff = (sc(head) - sc(tail)).abs();
        let hg = head.segment.as_ref().and_then(|s| s.group.clone()).filter(|g| !g.is_empty());
        let tg = tail.segment.as_ref().and_then(|s| s.group.clone()).filter(|g| !g.is_empty());
        let same = if hg.is_some() && tg.is_some() && hg == tg { 1.0 } else { 0.0 };
        let musical = clamp(mmw * (1.0 - clamp(melody_diff / 0.45, 0.0, 1.0)) + msw * (1.0 - clamp(state_diff / 0.4, 0.0, 1.0)) + mgw * same, 0.0, 1.0);
        let ideal_gap = (config.arc_min_gap + config.arc_max_gap) / 2.0;
        let radius = 0.08f64.max((config.arc_max_gap - config.arc_min_gap) / 2.0);
        let timing = 1.0 - clamp((gap - ideal_gap).abs() / radius, 0.0, 1.0);
        let dist_score = 1.0 - clamp((distance - ideal_d).abs() / 0.001f64.max(d_range), 0.0, 1.0);
        let score = smw * movement + smuw * musical + stw * timing + sdw * dist_score;
        Some(Cand { a: hi, b: ti, score, launch_error, gap })
    };
    let mut used: HashSet<(i32, usize)> = HashSet::new();
    let mut selected: Vec<Cand> = vec![];
    let mut previous_side: Option<i32> = None;
    let mut ws = 0i64;
    while ws < event_count - 1 {
        let we = event_count.min(ws + cadence);
        let mut cands: Vec<Cand> = vec![];
        for side in 0..2 {
            let hn = &by_hand[side];
            for i in 0..hn.len().saturating_sub(1) {
                let head = hn[i];
                let ei = notes[head].event_index;
                if ei < ws || ei >= we {
                    continue;
                }
                for skip in 1..=max_skip {
                    let Some(&tail) = hn.get(i + skip) else { continue };
                    if used.contains(&(side as i32, hand_index[head])) || used.contains(&(side as i32, hand_index[tail])) {
                        continue;
                    }
                    if let Some(c) = natural(head, tail) {
                        cands.push(c);
                    }
                }
            }
        }
        cands.sort_by(|a, b| {
            b.score.partial_cmp(&a.score).unwrap().then(a.launch_error.partial_cmp(&b.launch_error).unwrap()).then(a.gap.partial_cmp(&b.gap).unwrap())
        });
        if !cands.is_empty() {
            let mut ci = 0;
            if let Some(ps) = previous_side
                && let Some(k) = cands.iter().position(|c| notes[c.a].type_ != ps && c.score >= cands[0].score - tol)
            {
                ci = k;
            }
            let c = cands.swap_remove(ci);
            used.insert((notes[c.a].type_, hand_index[c.a]));
            used.insert((notes[c.b].type_, hand_index[c.b]));
            previous_side = Some(notes[c.a].type_);
            selected.push(c);
        }
        ws += cadence;
    }
    if selected.is_empty() {
        let mut all: Vec<Cand> = vec![];
        for hn in &by_hand {
            for i in 0..hn.len().saturating_sub(1) {
                for skip in 1..=max_skip {
                    let Some(&tail) = hn.get(i + skip) else { continue };
                    if let Some(c) = natural(hn[i], tail) {
                        all.push(c);
                    }
                }
            }
        }
        all.sort_by(|a, b| b.score.partial_cmp(&a.score).unwrap().then(a.launch_error.partial_cmp(&b.launch_error).unwrap()));
        if !all.is_empty() {
            selected.push(all.swap_remove(0));
        }
    }
    let mut out: Vec<Slider> = selected
        .iter()
        .map(|c| {
            let (a, b) = (&notes[c.a], &notes[c.b]);
            let m = control_multiplier(a, b);
            Slider {
                color_type: a.type_,
                head_time: to_fixed_num(a.time, 4),
                head_line_index: a.line_index,
                head_line_layer: a.line_layer,
                head_cut_direction: a.cut_direction,
                head_mult: m,
                tail_time: to_fixed_num(b.time, 4),
                tail_line_index: b.line_index,
                tail_line_layer: b.line_layer,
                tail_cut_direction: b.cut_direction,
                tail_mult: m,
                mid_anchor_mode: 0,
            }
        })
        .collect();
    out.sort_by(|a, b| a.head_time.partial_cmp(&b.head_time).unwrap().then(a.color_type.cmp(&b.color_type)));
    out
}
