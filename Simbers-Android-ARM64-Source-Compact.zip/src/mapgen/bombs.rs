//! Bombs (bombs.js) and walls (walls.js).

use super::arcs::CUT_VEC;
use super::beatmaps::{MapNote, Obstacle, Slider};
use super::{DifficultyConfig, GNote};
use crate::settings as adv;
use crate::util::{clamp, hash_string, js_round, to_fixed_num};
use std::collections::BTreeMap;

fn sign_step(v: f64) -> i32 {
    if v > 0.15 {
        1
    } else if v < -0.15 {
        -1
    } else {
        0
    }
}

fn cut_vec(code: i32) -> (f64, f64) {
    if (0..8).contains(&code) { CUT_VEC[code as usize] } else { CUT_VEC[1] }
}

fn note_touches_arc(n: &GNote, sliders: &[Slider]) -> bool {
    sliders.iter().any(|s| {
        s.color_type == n.type_
            && (((s.head_time - n.time).abs() < 0.001 && s.head_line_index == n.line_index && s.head_line_layer == n.line_layer)
                || ((s.tail_time - n.time).abs() < 0.001 && s.tail_line_index == n.line_index && s.tail_line_layer == n.line_layer))
    })
}

fn z(v: f64) -> f64 {
    if v.is_nan() { 0.0 } else { v }
}

fn bomb_style(n: &GNote, config: &DifficultyConfig, seed: &str) -> &'static str {
    let group = n.segment.as_ref().and_then(|s| s.group.clone()).unwrap_or_default();
    let cluster = match &n.segment {
        Some(s) => s.cluster.to_string(),
        None => crate::util::js_num_to_string(js_round(0.0)),
    };
    let sig = format!("{group}|{cluster}|{}|{}", n.type_, n.cut_direction);
    let v = hash_string(&format!("{seed}|{}|{sig}|bomb-style", config.id)) as f64 / 4294967296.0;
    if v < config.bomb_direct_rate {
        "direct"
    } else if v < config.bomb_direct_rate + config.bomb_follow_rate {
        "follow"
    } else {
        "side"
    }
}

fn positions(n: &GNote, style: &str) -> Vec<(i32, i32, &'static str)> {
    let cut = cut_vec(n.cut_direction);
    let (sx, sy) = (sign_step(cut.0), sign_step(cut.1));
    let perp = [(-sy, sx), (sy, -sx)];
    let mut out: Vec<(i32, i32, &'static str)> = vec![];
    let mut add = |x: i32, y: i32, l: &'static str| {
        let x = x.clamp(0, 3);
        let y = y.clamp(0, 2);
        if !out.iter().any(|c| c.0 == x && c.1 == y) {
            out.push((x, y, l));
        }
    };
    let (x, y) = (n.line_index, n.line_layer);
    match style {
        "direct" => {
            add(x, y, "direct");
            add(x + perp[0].0, y + perp[0].1, "side-fallback");
            add(x + perp[1].0, y + perp[1].1, "side-fallback");
        }
        "follow" => {
            add(x + sx, y + sy, "follow");
            add(x, y, "direct-fallback");
            add(x + perp[0].0, y + perp[0].1, "side-fallback");
        }
        _ => {
            add(x + perp[0].0, y + perp[0].1, "side");
            add(x + perp[1].0, y + perp[1].1, "side");
            add(x, y, "direct-fallback");
        }
    }
    out
}

fn candidate_score(n: &GNote, next_time: f64, config: &DifficultyConfig, seed: &str) -> f64 {
    let available = (next_time - n.time).max(0.0);
    let lag_max = if config.bomb_lag_max == 0.0 { 0.2 } else { config.bomb_lag_max };
    let required = lag_max + adv::number("bombs.requiredGapExtra", 0.055);
    let gap_score = clamp(available / required.max(0.001), 0.0, 1.0);
    let (sc, bs, ac) = match &n.segment {
        Some(s) => (z(s.state_change), z(s.beat_strength), z(s.activity)),
        None => (0.0, 0.0, 0.0),
    };
    let attack = clamp(0.48 * sc + 0.32 * bs + 0.2 * ac, 0.0, 1.0);
    let flow_bonus = match n.flow_difficulty.as_str() {
        "hard" => adv::number("bombs.hardFlowBonus", 0.16),
        "medium" => adv::number("bombs.mediumFlowBonus", 0.07),
        _ => 0.0,
    };
    let tie = (hash_string(&format!("{seed}|{}|{}|{}|bomb-score", config.id, n.event_index, n.type_)) % 1000) as f64 / 1000000.0;
    adv::number("bombs.scoreAttackWeight", 0.58) * attack + adv::number("bombs.scoreGapWeight", 0.27) * gap_score + flow_bonus + tie
}

fn by_event(notes: &[GNote]) -> BTreeMap<i64, Vec<usize>> {
    let mut m: BTreeMap<i64, Vec<usize>> = BTreeMap::new();
    for (i, n) in notes.iter().enumerate() {
        m.entry(n.event_index).or_default().push(i);
    }
    m
}

pub fn build_bombs(notes: &[GNote], sliders: &[Slider], config: &DifficultyConfig, seed: &str) -> Vec<MapNote> {
    if config.bomb_every_events == 0.0 {
        return vec![];
    }
    let be = by_event(notes);
    let indices: Vec<i64> = be.keys().copied().collect();
    let cadence = (adv::integer("bombs.cadenceFloor", 5.0).max(1) as f64).max(config.bomb_every_events) as usize;
    let mut bombs: Vec<(MapNote, i32)> = vec![];
    let mut prev_hand: Option<i32> = None;
    let tol = adv::number("bombs.alternateHandTolerance", 0.08);
    let reaction = match config.id.as_str() {
        "expertPlus" => adv::number("bombs.reactionMarginExpertPlus", 0.045),
        "expert" => adv::number("bombs.reactionMarginExpert", 0.06),
        _ => adv::number("bombs.reactionMarginHard", 0.075),
    };
    let lag_floor = config.bomb_lag_min * adv::number("bombs.lagFloorMultiplier", 0.82);
    let collision = if config.id == "expertPlus" { adv::number("bombs.noteCollisionMarginExpertPlus", 0.075) } else { adv::number("bombs.noteCollisionMargin", 0.095) };
    let separation = if config.id == "expertPlus" { adv::number("bombs.bombSeparationExpertPlus", 0.28) } else { adv::number("bombs.bombSeparationSec", 0.38) };
    let mut ws = 0usize;
    while ws < indices.len() {
        let window = &indices[ws..(ws + cadence).min(indices.len())];
        struct C {
            note: usize,
            next_time: f64,
            score: f64,
        }
        let mut cands: Vec<C> = vec![];
        for &ei in window {
            let next_time = indices.iter().find(|&&i| i > ei).map(|i| notes[be[i][0]].time).unwrap_or(f64::INFINITY);
            for &ni in &be[&ei] {
                if note_touches_arc(&notes[ni], sliders) {
                    continue;
                }
                cands.push(C { note: ni, next_time, score: candidate_score(&notes[ni], next_time, config, seed) });
            }
        }
        cands.sort_by(|a, b| b.score.partial_cmp(&a.score).unwrap().then(notes[a.note].time.partial_cmp(&notes[b.note].time).unwrap()));
        let mut placed: Option<(MapNote, i32)> = None;
        for c in &cands {
            let n = &notes[c.note];
            if let Some(ph) = prev_hand
                && n.type_ == ph
                && cands.iter().any(|o| notes[o.note].type_ != ph && o.score >= c.score - tol)
            {
                continue;
            }
            let style = bomb_style(n, config, seed);
            let ru = hash_string(&format!("{seed}|{}|{}|{}|bomb-lag", config.id, n.event_index, n.type_)) as f64 / 4294967296.0;
            let mut lag = config.bomb_lag_min + ru * (config.bomb_lag_max - config.bomb_lag_min);
            if c.next_time.is_finite() {
                lag = lag.min(c.next_time - n.time - reaction);
            }
            if lag < lag_floor {
                continue;
            }
            let bt = n.time + lag;
            for (x, y, _label) in positions(n, style) {
                if notes.iter().any(|o| o.line_index == x && o.line_layer == y && (o.time - bt).abs() < collision) {
                    continue;
                }
                if bombs.iter().any(|(b, _)| (b.time - bt).abs() < separation && (b.line_index - x).abs() + (b.line_layer - y).abs() <= 1) {
                    continue;
                }
                placed = Some((MapNote { time: to_fixed_num(bt, 4), line_index: x, line_layer: y, type_: 3, cut_direction: 0 }, n.type_));
                break;
            }
            if placed.is_some() {
                break;
            }
        }
        if let Some(p) = placed {
            prev_hand = Some(p.1);
            bombs.push(p);
        }
        ws += cadence;
    }
    let mut out: Vec<MapNote> = bombs.into_iter().map(|b| b.0).collect();
    out.sort_by(|a, b| a.time.partial_cmp(&b.time).unwrap());
    out
}

pub fn build_walls(notes: &[GNote], sliders: &[Slider], bombs: &[MapNote], config: &DifficultyConfig, seed: &str) -> Vec<Obstacle> {
    if config.wall_every_events == 0.0 {
        return vec![];
    }
    let be = by_event(notes);
    let indices: Vec<i64> = be.keys().copied().collect();
    struct C {
        event_index: i64,
        start: f64,
        duration: f64,
        gap: f64,
        score: f64,
    }
    let min_gap = if config.wall_minimum_gap == 0.0 { 0.5 } else { config.wall_minimum_gap };
    let start_offset = match config.id.as_str() {
        "expertPlus" => adv::number("walls.startOffsetExpertPlus", 0.085),
        "expert" => adv::number("walls.startOffsetExpert", 0.1),
        _ => adv::number("walls.startOffsetHard", 0.12),
    };
    let next_margin = match config.id.as_str() {
        "expertPlus" => adv::number("walls.nextNoteMarginExpertPlus", 0.075),
        "expert" => adv::number("walls.nextNoteMarginExpert", 0.09),
        _ => adv::number("walls.nextNoteMarginHard", 0.11),
    };
    let min_song = adv::number("walls.minimumSongTime", 1.8);
    let scale = adv::number("walls.durationScale", 0.76);
    let mut cands: Vec<C> = vec![];
    for i in 0..indices.len().saturating_sub(1) {
        let cur = &be[&indices[i]];
        let nxt = &be[&indices[i + 1]];
        let ct = notes[cur[0]].time;
        let nt = notes[nxt[0]].time;
        let gap = nt - ct;
        if gap < min_gap || ct < min_song {
            continue;
        }
        let max_dur = gap - start_offset - next_margin;
        if max_dur < config.wall_min_duration {
            continue;
        }
        let start = ct + start_offset;
        let duration = clamp(max_dur * scale, config.wall_min_duration, config.wall_max_duration);
        let end = start + duration;
        let m = 0.055;
        if bombs.iter().any(|b| b.time >= start - m && b.time <= end + m) || sliders.iter().any(|s| s.head_time < end + m && s.tail_time > start - m) {
            continue;
        }
        let (c, n) = (&notes[cur[0]], &notes[nxt[0]]);
        let seg = |g: &GNote, f: fn(&crate::analysis::patterns::Segment) -> f64| g.segment.as_ref().map(|s| z(f(s))).unwrap_or(0.0);
        let attack = clamp(0.5 * seg(c, |s| s.state_change) + 0.3 * seg(c, |s| s.beat_strength) + 0.2 * seg(c, |s| s.activity), 0.0, 1.0);
        let gap_score = clamp((gap - min_gap) / 0.75, 0.0, 1.0);
        let phrase = clamp((seg(c, |s| s.melody_value) - seg(n, |s| s.melody_value)).abs() / 0.45, 0.0, 1.0);
        let tie = (hash_string(&format!("{seed}|{}|{}|wall-score", config.id, c.event_index)) % 1000) as f64 / 1000000.0;
        cands.push(C { event_index: indices[i], start, duration, gap, score: 0.46 * attack + 0.36 * gap_score + 0.18 * phrase + tie });
    }
    if cands.is_empty() {
        return vec![];
    }
    let cadence = (adv::integer("walls.cadenceFloor", 8.0).max(1) as f64).max(config.wall_every_events) as i64;
    let sep = match config.id.as_str() {
        "expertPlus" => adv::number("walls.separationExpertPlus", 1.65),
        "expert" => adv::number("walls.separationExpert", 2.15),
        _ => adv::number("walls.separationHard", 2.75),
    };
    let mut walls: Vec<Obstacle> = vec![];
    let mut last_end = -999.0;
    let mut prev_side: Option<u32> = None;
    let mut ws = 0i64;
    while ws < indices.len() as i64 {
        let we = ws + cadence;
        let mut pool: Vec<&C> = cands.iter().filter(|c| c.event_index >= ws && c.event_index < we && c.start - last_end >= sep).collect();
        pool.sort_by(|a, b| b.score.partial_cmp(&a.score).unwrap().then(b.gap.partial_cmp(&a.gap).unwrap()));
        if let Some(ch) = pool.first() {
            let side = match prev_side {
                None => hash_string(&format!("{seed}|{}|first-wall-side", config.id)) % 2,
                Some(p) => 1 - p,
            };
            walls.push(Obstacle { type_: 0, time: to_fixed_num(ch.start, 4), duration: to_fixed_num(ch.duration, 4), line_index: if side == 0 { 0 } else { 3 }, width: 1 });
            prev_side = Some(side);
            last_end = ch.start + ch.duration;
        }
        ws += cadence;
    }
    walls.sort_by(|a, b| a.time.partial_cmp(&b.time).unwrap());
    walls
}
