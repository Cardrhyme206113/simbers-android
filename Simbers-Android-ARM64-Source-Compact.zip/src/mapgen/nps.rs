//! NPS ceiling, adaptive double accents and post-cap solo balance (nps-cap.js).

use super::GNote;
use super::choreo::{Ev, Macro, Plan, groove_hand};
use serde_json::{Value, json};
use std::collections::{HashMap, HashSet};

pub struct AccentResult {
    pub added: usize,
    pub removed: usize,
}

pub fn cap_double_accents(plans: &mut [Plan], macros: &[Macro], events: &[Ev], target_nps: f64, accent_rate: f64) -> AccentResult {
    let tn = if target_nps == 0.0 || target_nps.is_nan() { 4.0 } else { target_nps };
    let target = crate::util::js_round(tn).clamp(1.0, 9.0) as i64;
    let n = events.len();
    if n == 0 || plans.is_empty() {
        return AccentResult { added: 0, removed: 0 };
    }
    let window = 4.0;
    let max_window_notes = (target * 4) as i32;
    struct Cand {
        p: usize,
        index: usize,
        extra_hand: usize,
        existing: bool,
        strength: f64,
        accent: bool,
    }
    let mut cands: Vec<Cand> = vec![];
    for (p, plan) in plans.iter().enumerate() {
        let m = &macros[plan.macro_idx];
        let left: HashSet<usize> = plan.schedule[0].iter().copied().collect();
        let right: HashSet<usize> = plan.schedule[1].iter().copied().collect();
        for index in m.start..m.end {
            let (il, ir) = (left.contains(&index), right.contains(&index));
            if !il && !ir {
                continue;
            }
            let existing = il && ir;
            let relative = index - m.start;
            let primary = if existing { groove_hand(m.rhythm, relative, plan.seed) } else if il { 0 } else { 1 };
            let s = events[index].strength;
            let strength = if s.is_nan() { 0.0 } else { s };
            let accent = relative % 4 == 0;
            if !existing && relative == 0 && strength <= 0.45 {
                continue;
            }
            cands.push(Cand { p, index, extra_hand: (1 - primary) as usize, existing, strength, accent });
        }
    }
    if cands.is_empty() {
        return AccentResult { added: 0, removed: 0 };
    }
    let mut baseline = vec![0i32; n];
    let mut first_window = vec![0usize; n];
    let (mut left, mut right) = (0usize, 0usize);
    for index in 0..n {
        while right < n && events[right].t < events[index].t + window {
            right += 1;
        }
        baseline[index] = (right - index) as i32;
        while left < index && events[left].t <= events[index].t - window {
            left += 1;
        }
        first_window[index] = left;
    }
    let mut size = 1usize;
    while size < n {
        size *= 2;
    }
    let mut maxima = vec![0i32; size * 2];
    let mut pending = vec![0i32; size * 2];
    maxima[size..size + n].copy_from_slice(&baseline);
    for i in (1..size).rev() {
        maxima[i] = maxima[i * 2].max(maxima[i * 2 + 1]);
    }
    fn max_in(maxima: &[i32], pending: &[i32], lo: usize, hi: usize, node: usize, start: usize, end: usize) -> i64 {
        if hi < start || end < lo {
            return i64::MIN / 4;
        }
        if lo <= start && end <= hi {
            return maxima[node] as i64;
        }
        let mid = (start + end) >> 1;
        pending[node] as i64 + max_in(maxima, pending, lo, hi, node * 2, start, mid).max(max_in(maxima, pending, lo, hi, node * 2 + 1, mid + 1, end))
    }
    fn add_range(maxima: &mut [i32], pending: &mut [i32], lo: usize, hi: usize, node: usize, start: usize, end: usize) {
        if hi < start || end < lo {
            return;
        }
        if lo <= start && end <= hi {
            maxima[node] += 1;
            pending[node] += 1;
            return;
        }
        let mid = (start + end) >> 1;
        add_range(maxima, pending, lo, hi, node * 2, start, mid);
        add_range(maxima, pending, lo, hi, node * 2 + 1, mid + 1, end);
        maxima[node] = pending[node] + maxima[node * 2].max(maxima[node * 2 + 1]);
    }
    let base_rate = if accent_rate.is_finite() { accent_rate } else { 0.16 }.clamp(0.04, 0.42);
    let max_rate = 0.44f64.min(0.08f64.max(base_rate * 2.0));
    let budget: Vec<usize> = plans.iter().map(|p| {
        let m = &macros[p.macro_idx];
        1usize.max(((m.end - m.start) as f64 * max_rate).floor() as usize)
    }).collect();
    let mut count = vec![0u16; plans.len()];
    cands.sort_by(|a, b| {
        (b.existing as i32 - a.existing as i32)
            .cmp(&0)
            .then((b.accent as i32 - a.accent as i32).cmp(&0))
            .then(b.strength.partial_cmp(&a.strength).unwrap_or(std::cmp::Ordering::Equal))
            .then(a.index.cmp(&b.index))
    });
    let (mut added, mut removed) = (0, 0);
    let mut additions: Vec<[Vec<usize>; 2]> = plans.iter().map(|_| [vec![], vec![]]).collect();
    let mut removals: Vec<[HashSet<usize>; 2]> = plans.iter().map(|_| [HashSet::new(), HashSet::new()]).collect();
    for c in &cands {
        let lo = first_window[c.index];
        if count[c.p] as usize >= budget[c.p] || max_in(&maxima, &pending, lo, c.index, 1, 0, size - 1) >= max_window_notes as i64 {
            if c.existing {
                removals[c.p][c.extra_hand].insert(c.index);
                removed += 1;
            }
            continue;
        }
        count[c.p] += 1;
        add_range(&mut maxima, &mut pending, lo, c.index, 1, 0, size - 1);
        if !c.existing {
            additions[c.p][c.extra_hand].push(c.index);
            added += 1;
        }
    }
    for p in 0..plans.len() {
        for hand in 0..2 {
            let (add, rem) = (&additions[p][hand], &removals[p][hand]);
            if add.is_empty() && rem.is_empty() {
                continue;
            }
            let mut s: Vec<usize> = plans[p].schedule[hand].iter().copied().filter(|i| !rem.contains(i)).collect();
            s.extend_from_slice(add);
            s.sort();
            plans[p].schedule[hand] = s;
        }
    }
    AccentResult { added, removed }
}

pub struct CulledBalance {
    pub notes: Vec<GNote>,
    pub switched: usize,
    pub solo_counts: [i64; 2],
    pub double_count: usize,
    pub has_rule: bool,
}

impl CulledBalance {
    pub fn to_json(&self) -> Value {
        let mut v = json!({"soloCounts": self.solo_counts, "doubleCount": self.double_count, "switched": self.switched});
        if self.has_rule {
            v["rule"] = Value::from("NPS culling keeps both original saber candidates; 4-8-note solo phrase balancing and mirrored repeated sections");
        }
        v
    }
}

pub fn balance_culled_solo_hands(selected: Vec<GNote>, originals: &[GNote]) -> CulledBalance {
    if selected.is_empty() || originals.is_empty() {
        return CulledBalance { notes: selected, switched: 0, solo_counts: [0, 0], double_count: 0, has_rule: false };
    }
    let mut cands: HashMap<i64, [Option<usize>; 2]> = HashMap::new();
    for (i, n) in originals.iter().enumerate() {
        if n.type_ != 0 && n.type_ != 1 {
            continue;
        }
        cands.entry(n.event_index).or_insert([None, None])[n.type_ as usize] = Some(i);
    }
    struct Event {
        key: i64,
        notes: Vec<usize>,
        phrase: Option<usize>,
    }
    let mut seq: Vec<Event> = vec![];
    let mut pos: HashMap<i64, usize> = HashMap::new();
    for (i, n) in selected.iter().enumerate() {
        let k = n.event_index;
        let idx = *pos.entry(k).or_insert_with(|| {
            seq.push(Event { key: k, notes: vec![], phrase: n.flow_phrase });
            seq.len() - 1
        });
        seq[idx].notes.push(i);
    }
    struct Run {
        phrase: Option<usize>,
        events: Vec<usize>,
    }
    let mut runs: Vec<Run> = vec![];
    for (ei, e) in seq.iter().enumerate() {
        if let Some(prev) = runs.last_mut()
            && prev.phrase == e.phrase
        {
            prev.events.push(ei);
            continue;
        }
        runs.push(Run { phrase: e.phrase, events: vec![ei] });
    }
    let mut freq: HashMap<Option<usize>, usize> = HashMap::new();
    for r in &runs {
        *freq.entry(r.phrase).or_insert(0) += 1;
    }
    let mut seen: HashMap<Option<usize>, usize> = HashMap::new();
    let mut first_hand: HashMap<Option<usize>, i32> = HashMap::new();
    let mut balance = [0i64; 2];
    let mut double_count = 0;
    let mut output: HashMap<i64, usize> = HashMap::new(); // -> originals index
    let full_pair = |k: i64| cands.get(&k).map(|p| p[0].is_some() && p[1].is_some()).unwrap_or(false);
    for e in &seq {
        if e.notes.len() == 2 {
            double_count += 1;
            continue;
        }
        if !full_pair(e.key) {
            balance[selected[e.notes[0]].type_ as usize] += 1;
        }
    }
    let mut last_hand: i32 = 1;
    let mut solo_streak = 0;
    struct Block {
        events: Vec<usize>,
        penalty: f64,
    }
    let mut repair_blocks: Vec<Block> = vec![];
    for run in &runs {
        let mutable: Vec<usize> = run.events.iter().copied().filter(|&ei| seq[ei].notes.len() == 1 && full_pair(seq[ei].key)).collect();
        if mutable.is_empty() {
            continue;
        }
        let occurrence = *seen.get(&run.phrase).unwrap_or(&0);
        seen.insert(run.phrase, occurrence + 1);
        let repeated = *freq.get(&run.phrase).unwrap_or(&0) > 1;
        let mut lead = if repeated && first_hand.contains_key(&run.phrase) {
            first_hand[&run.phrase] ^ (occurrence as i32 & 1)
        } else if balance[0] < balance[1] {
            0
        } else if balance[1] < balance[0] {
            1
        } else {
            1 - last_hand
        };
        if lead == last_hand && solo_streak >= 4 {
            lead = 1 - lead;
        }
        if repeated && occurrence == 0 {
            first_hand.insert(run.phrase, lead);
        }
        let mut i = 0;
        while i < mutable.len() {
            let whole: Vec<usize> = mutable[i..(i + 8).min(mutable.len())].to_vec();
            let mut j = 0;
            repair_blocks.push(Block { events: whole.clone(), penalty: 0.0 });
            while j < whole.len() {
                let sub = &whole[j..(j + 4).min(whole.len())];
                if sub.len() >= 4 {
                    repair_blocks.push(Block { events: sub.to_vec(), penalty: 1.0 });
                }
                j += 4;
            }
            i += 8;
        }
        for (i, &ei) in mutable.iter().enumerate() {
            let e = &seq[ei];
            let block = i / 8;
            let mut desired = lead ^ (block as i32 & 1);
            if !repeated && i % 8 == 0 && mutable.len() - i < 8 && (balance[0] - balance[1]).abs() >= 6 {
                desired = if balance[0] > balance[1] { 1 } else { 0 };
            }
            let current = &selected[e.notes[0]];
            match cands[&e.key][desired as usize] {
                Some(rep) => {
                    output.insert(e.key, rep);
                    balance[desired as usize] += 1;
                }
                None => balance[current.type_ as usize] += 1,
            }
            solo_streak = if desired == last_hand { solo_streak + 1 } else { 1 };
            last_hand = desired;
        }
    }
    for _ in 0..repair_blocks.len() {
        let diff = balance[0] - balance[1];
        if diff.abs() <= 3 {
            break;
        }
        let dominant = if diff > 0 { 0 } else { 1 };
        let mut best: Option<(usize, f64)> = None;
        for (bi, b) in repair_blocks.iter().enumerate() {
            if b.events.is_empty() || !b.events.iter().all(|&ei| output.get(&seq[ei].key).map(|&o| originals[o].type_ == dominant).unwrap_or(false)) {
                continue;
            }
            let future = diff.abs() - 2 * b.events.len() as i64;
            if future.abs() >= diff.abs() {
                continue;
            }
            let score = future.abs() as f64 + b.penalty * 0.07;
            if best.map(|x| score < x.1).unwrap_or(true) {
                best = Some((bi, score));
            }
        }
        let Some((bi, _)) = best else { break };
        for &ei in &repair_blocks[bi].events {
            let k = seq[ei].key;
            output.insert(k, cands[&k][1 - dominant as usize].unwrap());
            balance[dominant as usize] -= 1;
            balance[1 - dominant as usize] += 1;
        }
    }
    let mut notes = Vec::with_capacity(selected.len());
    let mut switched = 0;
    for e in &seq {
        if e.notes.len() != 1 || !output.contains_key(&e.key) {
            for &i in &e.notes {
                notes.push(selected[i].clone());
            }
        } else {
            let o = &originals[output[&e.key]];
            if o.type_ != selected[e.notes[0]].type_ {
                switched += 1;
            }
            notes.push(o.clone());
        }
    }
    CulledBalance { notes, switched, solo_counts: balance, double_count, has_rule: true }
}

fn importance(n: &GNote) -> f64 {
    match &n.segment {
        Some(s) => {
            let z = |v: f64| if v.is_nan() { 0.0 } else { v };
            0.62 * z(s.beat_strength) + 0.26 * z(s.state_change) + 0.12 * z(s.activity)
        }
        None => 0.0,
    }
}

/// sc2LimitNoteDensity
pub fn limit_note_density(notes: Vec<GNote>, target_nps: i64) -> Vec<GNote> {
    if notes.len() < 2 {
        return notes;
    }
    let target = target_nps.clamp(1, 9) as usize;
    let tf = target as f64;
    let song_start = notes[0].time;
    let full_span = (notes[notes.len() - 1].time - song_start).max(1.0);
    let theoretical_max = notes.len().min((tf * full_span + 1e-8).floor() as usize);
    let imp: Vec<f64> = notes.iter().map(importance).collect();
    let select = |phase: f64| -> Vec<usize> {
        let mut selected: Vec<usize> = vec![];
        let mut offset = 0;
        while offset < notes.len() {
            let bucket_id = (notes[offset].time - song_start + phase + 1e-9).floor();
            let bucket_start = song_start + bucket_id - phase;
            let mut end = offset + 1;
            while end < notes.len() && (notes[end].time - song_start + phase + 1e-9).floor() == bucket_id {
                end += 1;
            }
            struct Onset {
                time: f64,
                primary: usize,
                extras: Vec<usize>,
                score: f64,
                selected: bool,
            }
            let mut onsets: Vec<Onset> = vec![];
            let mut i = offset;
            while i < end {
                let mut j = i + 1;
                while j < end && (notes[j].time - notes[i].time).abs() < 1e-5 {
                    j += 1;
                }
                onsets.push(Onset { time: notes[i].time, primary: i, extras: (i + 1..j).collect(), score: imp[i], selected: false });
                i = j;
            }
            let mut slot_best: Vec<Option<(usize, f64)>> = vec![None; target];
            for (oi, o) in onsets.iter().enumerate() {
                let slot = (((o.time - bucket_start) * tf).floor().max(0.0) as usize).min(target - 1);
                let center = bucket_start + (slot as f64 + 0.5) / tf;
                let distance = (o.time - center).abs();
                let better = match slot_best[slot] {
                    None => true,
                    Some((pi, pd)) => {
                        let p = &onsets[pi];
                        distance < pd - 0.015 || ((distance - pd).abs() <= 0.015 && (o.score > p.score || (o.score == p.score && o.time < p.time)))
                    }
                };
                if better {
                    slot_best[slot] = Some((oi, distance));
                }
            }
            let mut chosen: Vec<usize> = vec![];
            for w in slot_best.iter().flatten() {
                if onsets[w.0].selected {
                    continue;
                }
                onsets[w.0].selected = true;
                chosen.push(onsets[w.0].primary);
            }
            if chosen.len() < target {
                let mut spare: Vec<usize> = (0..onsets.len()).filter(|&k| !onsets[k].selected).collect();
                spare.sort_by(|&a, &b| onsets[b].score.partial_cmp(&onsets[a].score).unwrap().then(onsets[a].time.partial_cmp(&onsets[b].time).unwrap()));
                for k in spare {
                    if chosen.len() >= target {
                        break;
                    }
                    onsets[k].selected = true;
                    chosen.push(onsets[k].primary);
                }
            }
            if chosen.len() < target {
                let mut extras: Vec<usize> = onsets.iter().filter(|o| o.selected).flat_map(|o| o.extras.iter().copied()).collect();
                extras.sort_by(|&a, &b| imp[b].partial_cmp(&imp[a]).unwrap().then(notes[a].time.partial_cmp(&notes[b].time).unwrap()));
                for x in extras {
                    if chosen.len() >= target {
                        break;
                    }
                    chosen.push(x);
                }
            }
            chosen.sort_by(|&a, &b| notes[a].time.partial_cmp(&notes[b].time).unwrap().then(notes[a].type_.cmp(&notes[b].type_)));
            selected.extend(chosen);
            offset = end;
        }
        let mut filtered: Vec<usize> = vec![];
        let mut first_active = 0;
        for &i in &selected {
            while first_active < filtered.len() && notes[filtered[first_active]].time <= notes[i].time - 4.0 + 1e-9 {
                first_active += 1;
            }
            if filtered.len() - first_active < 4 * target {
                filtered.push(i);
            }
        }
        if filtered.len() < 2 {
            return filtered;
        }
        let duration = (notes[*filtered.last().unwrap()].time - notes[filtered[0]].time).max(1.0);
        let max_notes = 1usize.max((tf * duration + 1e-8).floor() as usize);
        if filtered.len() <= max_notes {
            return filtered;
        }
        if max_notes == 1 {
            let mut best = filtered[0];
            for &n in &filtered[1..] {
                if imp[n] > imp[best] {
                    best = n;
                }
            }
            return vec![best];
        }
        let interior = &filtered[1..filtered.len() - 1];
        let mut ranked: Vec<(usize, f64)> = interior.iter().enumerate().map(|(k, &n)| (k, imp[n])).collect();
        ranked.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap().then(a.0.cmp(&b.0)));
        let keep: HashSet<usize> = ranked.iter().take(max_notes - 2).map(|r| r.0).collect();
        let mut out = vec![filtered[0]];
        out.extend(interior.iter().enumerate().filter(|(k, _)| keep.contains(k)).map(|(_, &n)| n));
        out.push(*filtered.last().unwrap());
        out
    };
    let rate = |v: &[usize]| v.len() as f64 / (notes[*v.last().unwrap()].time - notes[v[0]].time).max(1.0);
    let mut best = select(0.0);
    if best.len() < theoretical_max {
        for phase in [0.25, 0.5, 0.75] {
            let attempt = select(phase);
            if attempt.len() > best.len() || (attempt.len() == best.len() && attempt.len() > 1 && rate(&attempt) > rate(&best) + 1e-7) {
                best = attempt;
            }
            if best.len() >= theoretical_max {
                break;
            }
        }
    }
    best.into_iter().map(|i| notes[i].clone()).collect()
}
