//! Walls live in bombs.rs (shared helpers).
pub use super::bombs::build_walls;
