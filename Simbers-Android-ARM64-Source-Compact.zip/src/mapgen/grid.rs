//! Conservative metrical grid (musical-grid.js).

use crate::util::{js_round, jsm, to_fixed_num, PI};

#[derive(Clone, Debug)]
pub struct Grid {
    pub bpm: f64,
    pub period: f64,
    pub origin: f64,
    pub snap_origin: f64,
    pub snap_subdivision: f64,
    pub beats_per_bar: usize,
    pub confidence: f64,
    pub fundamental_evidence: f64,
    pub eighth_evidence: f64,
    pub sixteenth_evidence: f64,
    pub downbeat_evidence: f64,
    pub downbeat_reliable: bool,
    pub bar_seconds: f64,
}

impl Grid {
    pub fn to_json(&self) -> serde_json::Value {
        use crate::util::jnum;
        serde_json::json!({
            "bpm": jnum(self.bpm), "confidence": jnum(self.confidence),
            "beatsPerBar": self.beats_per_bar, "downbeatReliable": self.downbeat_reliable,
            "downbeatEvidence": jnum(self.downbeat_evidence), "eighthEvidence": jnum(self.eighth_evidence),
            "sixteenthEvidence": jnum(self.sixteenth_evidence),
        })
    }
}

/// (t, accent) rows.
pub fn infer(rows_in: &[(f64, f64)]) -> Option<Grid> {
    if rows_in.len() < 24 {
        return None;
    }
    let mut rows: Vec<(f64, f64)> = rows_in
        .iter()
        .map(|&(t, s)| {
            let s = if s.is_nan() { 0.0 } else { s };
            (t, 0.02f64.max(2f64.min(s)))
        })
        .filter(|r| r.0.is_finite())
        .collect();
    rows.sort_by(|a, b| a.0.partial_cmp(&b.0).unwrap());
    if rows.len() < 24 || rows[rows.len() - 1].0 - rows[0].0 < 8.0 {
        return None;
    }
    let step = rows.len().div_ceil(1400).max(1);
    let sampled: Vec<(f64, f64)> = rows.iter().enumerate().filter(|(i, _)| i % step == 0).map(|(_, r)| *r).collect();
    let t0 = sampled[0].0;
    let tau = PI * 2.0;
    let total = sampled.iter().fold(0.0, |s, e| s + 0.25 + e.1);
    struct W {
        bpm: f64,
        period: f64,
        confidence: f64,
        fundamental: f64,
        eighths: f64,
        sixteenths: f64,
        phase: f64,
        half_phase: f64,
        quarter_phase: f64,
    }
    let mut winner: Option<W> = None;
    let evaluate = |bpm: f64, winner: &mut Option<W>| {
        let period = 60.0 / bpm;
        let (mut r1, mut i1, mut r2, mut i2, mut r4, mut i4) = (0.0, 0.0, 0.0, 0.0, 0.0, 0.0);
        for e in &sampled {
            let angle = tau * (((e.0 - t0) / period) % 1.0);
            let w = 0.25 + e.1;
            let c = jsm::cos(angle);
            let si = jsm::sin(angle);
            let c2 = c * c - si * si;
            let s2 = 2.0 * c * si;
            let c4 = c2 * c2 - s2 * s2;
            let s4 = 2.0 * c2 * s2;
            r1 += w * c;
            i1 += w * si;
            r2 += w * c2;
            i2 += w * s2;
            r4 += w * c4;
            i4 += w * s4;
        }
        let fundamental = jsm::hypot(r1, i1) / total;
        let eighths = jsm::hypot(r2, i2) / total;
        let sixteenths = jsm::hypot(r4, i4) / total;
        let score = 0.32 * fundamental + 0.48 * eighths + 0.20 * sixteenths;
        let better = match winner.as_ref() {
            None => true,
            Some(w) => score > w.confidence + 1e-6 || ((score - w.confidence).abs() <= 1e-6 && bpm > w.bpm),
        };
        if better {
            *winner = Some(W {
                bpm,
                period,
                confidence: score,
                fundamental,
                eighths,
                sixteenths,
                phase: jsm::atan2(i1, r1) / tau,
                half_phase: jsm::atan2(i2, r2) / tau,
                quarter_phase: jsm::atan2(i4, r4) / tau,
            });
        }
    };
    let mut bpm = 72.0;
    while bpm <= 200.0 {
        evaluate(bpm, &mut winner);
        bpm += 2.0;
    }
    let approximate = winner.as_ref().unwrap().bpm;
    let mut bpm = 72f64.max(approximate - 2.0);
    let hi = 200f64.min(approximate + 2.0);
    while bpm <= hi {
        evaluate(bpm, &mut winner);
        bpm += 0.25;
    }
    let w = winner.unwrap();
    if w.confidence < 0.54 || w.eighths.max(w.sixteenths) < 0.56 {
        return None;
    }
    let phase = if w.fundamental >= 0.2 { w.phase * w.period } else { (w.half_phase * w.period) / 2.0 };
    let origin = t0 + phase;
    let snap_origin = t0 + (w.quarter_phase * w.period) / 4.0;
    let mut chosen: Option<(usize, usize, f64)> = None;
    for bpb in [3usize, 4] {
        let mut sums = vec![0f64; bpb];
        let mut counts = vec![0usize; bpb];
        for e in &sampled {
            let beat = js_round((e.0 - origin) / w.period);
            if (e.0 - origin - beat * w.period).abs() > w.period * 0.2 {
                continue;
            }
            let k = (((beat as i64) % bpb as i64) + bpb as i64) % bpb as i64;
            sums[k as usize] += e.1;
            counts[k as usize] += 1;
        }
        let means: Vec<f64> = sums.iter().zip(&counts).map(|(s, c)| s / (*c).max(1) as f64).collect();
        let maxv = means.iter().cloned().fold(f64::NEG_INFINITY, f64::max);
        let strongest = means.iter().position(|v| *v == maxv).unwrap_or(0);
        let mut sorted = means.clone();
        sorted.sort_by(|a, b| b.partial_cmp(a).unwrap());
        let evidence = (sorted[0] - sorted[1]) / sorted[0].max(0.1);
        if counts[strongest] >= 3 && chosen.map(|c| evidence > c.2 + 0.05).unwrap_or(true) {
            chosen = Some((bpb, strongest, evidence));
        }
    }
    let downbeat_reliable = chosen.map(|c| c.2 >= 0.12).unwrap_or(false);
    let beats_per_bar = if downbeat_reliable { chosen.unwrap().0 } else { 4 };
    Some(Grid {
        bpm: to_fixed_num(w.bpm, 2),
        period: w.period,
        origin: origin + if downbeat_reliable { chosen.unwrap().1 as f64 * w.period } else { 0.0 },
        snap_origin,
        snap_subdivision: 4.0,
        beats_per_bar,
        confidence: to_fixed_num(w.confidence, 3),
        fundamental_evidence: to_fixed_num(w.fundamental, 3),
        eighth_evidence: to_fixed_num(w.eighths, 3),
        sixteenth_evidence: to_fixed_num(w.sixteenths, 3),
        downbeat_evidence: to_fixed_num(chosen.map(|c| c.2).unwrap_or(0.0), 3),
        downbeat_reliable,
        bar_seconds: w.period * beats_per_bar as f64,
    })
}

/// sc2SnapEventsToGrid on a list of times (mutated in place).
pub fn snap_events(times: &mut [f64], grid: Option<&Grid>) -> (usize, f64) {
    let Some(g) = grid else { return (0, 0.0) };
    if g.confidence < 0.58 || g.sixteenth_evidence < 0.55 {
        return (0, 0.0);
    }
    let interval = g.period / g.snap_subdivision;
    let max_shift = 0.018f64.min(0.24 * interval);
    let proposed: Vec<Option<f64>> = times
        .iter()
        .map(|&t| {
            let time = g.snap_origin + js_round((t - g.snap_origin) / interval) * interval;
            if (time - t).abs() <= max_shift { Some(time) } else { None }
        })
        .collect();
    let evidence = proposed.iter().filter(|p| p.is_some()).count() as f64 / times.len().max(1) as f64;
    if evidence < 0.65 {
        return (0, 0.0);
    }
    let mut count = 0;
    let mut shift = 0f64;
    for i in 0..times.len() {
        let Some(snapped) = proposed[i] else { continue };
        let prev = if i > 0 { times[i - 1] } else { f64::NEG_INFINITY };
        let next = if i + 1 < times.len() { times[i + 1] } else { f64::INFINITY };
        if snapped - prev < 0.083 || next - snapped < 0.083 {
            continue;
        }
        let moved = (snapped - times[i]).abs();
        if moved < 0.0002 {
            continue;
        }
        times[i] = snapped;
        shift = shift.max(moved);
        count += 1;
    }
    (count, to_fixed_num(shift * 1000.0, 2))
}

pub fn bar_alignment(t: f64, grid: Option<&Grid>) -> f64 {
    let Some(g) = grid.filter(|g| g.downbeat_reliable) else { return 0.0 };
    let distance = (t - g.origin) / g.bar_seconds;
    let phase = (distance - js_round(distance)).abs();
    jsm::exp(-jsm::pow((phase * g.bar_seconds) / (0.34 * g.period), 2.0))
}

pub fn metrical_length(start: f64, end: f64, grid: Option<&Grid>) -> f64 {
    let Some(g) = grid.filter(|g| g.downbeat_reliable) else { return 0.0 };
    let bars = (end - start) / g.bar_seconds;
    let error = (bars - 4.0).abs().min((bars - 8.0).abs());
    jsm::exp(-jsm::pow(error / 0.85, 2.0))
}
