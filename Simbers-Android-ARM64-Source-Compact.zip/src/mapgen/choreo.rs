//! Human-phrase choreography planner (choreography.js, "human-phrase-reuse-beam-v6").

use super::corpus::{self, ANGLES, CNote, DIRS, Entry, LIBRARY, MIRROR, OPPOSITE, angular_error};
use super::grid::{self, Grid};
use super::{GNote, DifficultyConfig};
use crate::analysis::patterns::Segment;
use crate::analysis::spectral::PitchAnalysis;
use crate::settings as adv;
use crate::util::{clamp, hash_string, jnum, js_round, jsm, median, to_fixed_num};
use serde_json::{Map, Value, json};
use std::collections::{HashMap, HashSet, VecDeque};
use std::sync::{Arc, LazyLock};

pub const MOTIFS: [&str; 7] = ["bounce", "orbit", "diagonal", "wave", "zigzag", "sweep", "corpus"];
pub const RHYTHMS: [&str; 6] = ["alternate", "right-lead", "left-lead", "call-response", "syncopated", "alternating-double"];
const STATES: usize = 96;

#[inline]
pub fn sc2_random(s: &str) -> f64 {
    hash_string(s) as f64 / 4294967296.0
}

pub fn sc2_median(a: &[f64]) -> f64 {
    if a.is_empty() { 0.4 } else { median(a) }
}

#[derive(Clone, Debug)]
pub struct Ev {
    pub t: f64,
    pub sound: Vec<f64>,
    pub melody: f64,
    pub strength: f64,
    pub state: f64,
    pub cluster: usize,
    pub segment: Arc<Segment>,
    pub pitch: f64,
    pub activity: f64,
    pub flow_speed_pressure: f64,
    pub flow_nps4: f32,
    pub flow_nps8: f32,
}

fn num_or0(v: f64) -> f64 {
    if v.is_nan() { 0.0 } else { v }
}

pub fn sc2_events(a: &PitchAnalysis, segments: &[Arc<Segment>]) -> Vec<Ev> {
    segments
        .iter()
        .map(|s| {
            let sound = corpus::audio_signature(a, s).unwrap_or_else(|| s.sequence.iter().map(|v| 0.05f64.max(1.0 + 0.4 * num_or0(*v))).collect());
            let seq = &s.sequence;
            let (mut sum, mut c) = (0.0, 0usize);
            for v in seq.iter() {
                if v.is_finite() {
                    sum += v;
                    c += 1;
                }
            }
            let m = num_or0(s.melody_value);
            Ev {
                t: s.start,
                sound,
                melody: if m == 0.0 { 0.5 } else { m },
                strength: clamp(num_or0(s.beat_strength), 0.0, 2.0),
                state: clamp(num_or0(s.state_change), 0.0, 2.0),
                cluster: s.cluster,
                segment: s.clone(),
                pitch: if c > 0 { sum / c as f64 } else { 0.0 },
                activity: num_or0(s.activity),
                flow_speed_pressure: 0.0,
                flow_nps4: 0.0,
                flow_nps8: 0.0,
            }
        })
        .collect()
}

#[derive(Clone, Debug)]
pub struct Descriptor {
    sound: Vec<Vec<f32>>,
    strength: [f32; 12],
    pitch: [f32; 12],
    state: [f32; 12],
    occ: [u16; 12],
    span: f64,
    n: usize,
    bars: Option<f64>,
}

#[derive(Clone, Debug)]
pub struct Macro {
    pub start: usize,
    pub end: usize,
    pub len: usize,
    pub approx_bars: Option<f64>,
    pub bar_aligned: bool,
    pub descriptor: Option<Descriptor>,
    pub group: usize,
    pub motif: &'static str,
    pub rhythm: &'static str,
    pub lead: i32,
    pub hand_motifs: [&'static str; 2],
}

fn new_macro(start: usize, end: usize) -> Macro {
    Macro { start, end, len: end - start, approx_bars: None, bar_aligned: false, descriptor: None, group: 0, motif: "corpus", rhythm: "alternate", lead: 0, hand_motifs: ["bounce", "bounce"] }
}

fn macro_segments(ev: &[Ev], g: Option<&Grid>) -> Vec<Macro> {
    let n = ev.len();
    if n == 0 {
        return vec![];
    }
    if n <= 15 {
        return vec![new_macro(0, n)];
    }
    let ts: Vec<f64> = ev.iter().map(|e| e.t).collect();
    let sounds: Vec<Vec<f64>> = ev.iter().map(|e| e.sound.clone()).collect();
    let states: Vec<f64> = ev.iter().map(|e| e.state).collect();
    let b = corpus::boundaries(&ts, &sounds, &states);
    let bnd = |i: usize, d: f64| -> f64 {
        let v = b.get(i).copied().unwrap_or(0.0) as f64;
        if v == 0.0 { d } else { v }
    };
    let mut dp = vec![-1e12f64; n + 1];
    let mut previous = vec![0usize; n + 1];
    dp[0] = 0.0;
    let target = 24.0;
    let reliable = g.map(|g| g.downbeat_reliable).unwrap_or(false);
    let tat = |i: usize| -> f64 { if i < n { ev[i].t } else { ev[i - 1].t } };
    for i in 0..n {
        if dp[i] < -1e10 {
            continue;
        }
        for len in 12..=48usize {
            let end = i + len;
            if end > n {
                break;
            }
            let tail = n - end;
            if tail > 0 && tail < 8 {
                continue;
            }
            let lf = len as f64;
            let shape = [16.0, 24.0, 32.0, 40.0].iter().map(|x: &f64| (x - lf).abs() / x).fold(f64::INFINITY, f64::min);
            let weak = if tail == 0 && len < 12 { 0.5 } else { 0.0 };
            let meter = if reliable {
                2.0 * grid::bar_alignment(tat(end), g) + 0.9 * grid::bar_alignment(ev[i].t, g) + 1.8 * grid::metrical_length(ev[i].t, tat(end), g)
            } else {
                0.0
            };
            let score = dp[i] + 1.3 * bnd(end, 0.75) + meter - 0.65 * shape - (0.3 * (lf - target).abs()) / target - weak - 1.25;
            if score > dp[end] {
                dp[end] = score;
                previous[end] = i;
            }
        }
        if n - i < 12 && i > 0 {
            let end = n;
            let score = dp[i] - 0.75 + 1.3 * bnd(end, 0.7);
            if score > dp[end] {
                dp[end] = score;
                previous[end] = i;
            }
        }
    }
    if dp[n] < -1e10 {
        return vec![new_macro(0, n)];
    }
    let mut out = vec![];
    let mut end = n;
    while end > 0 {
        let i = previous[end];
        if i >= end {
            break;
        }
        out.push(new_macro(i, end));
        end = i;
    }
    if out.is_empty() {
        return vec![new_macro(0, n)];
    }
    out.reverse();
    if let Some(gr) = g.filter(|g| g.downbeat_reliable) {
        for m in out.iter_mut() {
            let start = ev[m.start].t;
            let end = tat(m.end);
            m.approx_bars = Some(js_round((end - start) / gr.bar_seconds).max(1.0));
            m.bar_aligned = grid::bar_alignment(start, g) > 0.6 && grid::bar_alignment(end, g) > 0.6;
        }
    }
    out
}

fn f32add(a: f32, b: f64) -> f32 {
    (a as f64 + b) as f32
}

fn macro_descriptor(m: &Macro, ev: &[Ev]) -> Descriptor {
    let bins = 12usize;
    let bands = ev.first().map(|e| e.sound.len()).filter(|l| *l > 0).unwrap_or(8);
    let mut sound = vec![vec![0f32; bands]; bins];
    let mut strength = [0f32; 12];
    let mut pitch = [0f32; 12];
    let mut state = [0f32; 12];
    let mut counts = [0u16; 12];
    let st = ev[m.start].t;
    let ed = ev[m.end - 1].t;
    let span = (ed - st).max(0.01);
    for e in &ev[m.start..m.end] {
        let b = clamp(((bins as f64 * (e.t - st)) / span).floor(), 0.0, (bins - 1) as f64) as usize;
        counts[b] = counts[b].wrapping_add(1);
        strength[b] = f32add(strength[b], e.strength);
        pitch[b] = f32add(pitch[b], e.pitch);
        state[b] = f32add(state[b], e.state);
        for k in 0..bands {
            let v = e.sound.get(k).copied().unwrap_or(0.0);
            sound[b][k] = f32add(sound[b][k], if v.is_nan() { 0.0 } else { v });
        }
    }
    let mut occ = [0u16; 12];
    for b in 0..bins {
        let denom = if counts[b] == 0 { 1.0 } else { counts[b] as f64 };
        occ[b] = counts[b];
        strength[b] = (strength[b] as f64 / denom) as f32;
        pitch[b] = (pitch[b] as f64 / denom) as f32;
        state[b] = (state[b] as f64 / denom) as f32;
        for k in 0..bands {
            sound[b][k] = (sound[b][k] as f64 / denom) as f32;
        }
    }
    Descriptor { sound, strength, pitch, state, occ, span, n: m.len, bars: m.approx_bars }
}

fn cos_f32(a: &[f32], b: &[f32]) -> f64 {
    if a.is_empty() || b.is_empty() {
        return 0.0;
    }
    let (mut s, mut aa, mut bb) = (0.0f64, 0.0f64, 0.0f64);
    for i in 0..a.len().min(b.len()) {
        let (x, y) = (a[i] as f64, b[i] as f64);
        s += x * y;
        aa += x * x;
        bb += y * y;
    }
    if aa * bb > 1e-10 { 0f64.max(1f64.min(s / (aa * bb).sqrt())) } else { 0.0 }
}

fn macro_similarity(a: &Descriptor, b: &Descriptor) -> f64 {
    let count_ratio = a.n.min(b.n) as f64 / a.n.max(b.n) as f64;
    if count_ratio < 0.7 {
        return 0.0;
    }
    if let (Some(x), Some(y)) = (a.bars, b.bars)
        && (x - y).abs() > 1.0
    {
        return 0.0;
    }
    let (mut acoustic, mut rhythm, mut dynamics, mut pitch, mut used) = (0.0, 0.0, 0.0, 0.0, 0usize);
    for j in 0..12 {
        let busy = a.occ[j] as u32 + b.occ[j] as u32;
        if busy == 0 {
            continue;
        }
        let both = a.occ[j] != 0 && b.occ[j] != 0;
        acoustic += if both { cos_f32(&a.sound[j], &b.sound[j]) } else { 0.0 };
        let (ao, bo) = (a.occ[j] as f64, b.occ[j] as f64);
        rhythm += 1.0 - 1f64.min((ao - bo).abs() / 1f64.max(ao).max(bo));
        dynamics += 1.0 - 1f64.min((a.strength[j] as f64 - b.strength[j] as f64).abs() + 0.3 * (a.state[j] as f64 - b.state[j] as f64).abs());
        pitch += 1.0 - 1f64.min((a.pitch[j] as f64 - b.pitch[j] as f64).abs() / 1.6);
        used += 1;
    }
    if used == 0 {
        return 0.0;
    }
    (count_ratio * (0.37 * acoustic + 0.32 * rhythm + 0.2 * dynamics + 0.11 * pitch)) / used as f64
}

fn group_macros(macros: &mut [Macro], ev: &[Ev], threshold: f64, seed: &str) -> usize {
    let mut refs: Vec<usize> = vec![];
    let mut repeated = 0;
    let motif_start = hash_string(&format!("{seed}|motif-start")) as usize % MOTIFS.len();
    for mi in 0..macros.len() {
        let d = macro_descriptor(&macros[mi], ev);
        macros[mi].descriptor = Some(d);
        let mut best: i64 = -1;
        let mut similarity = threshold;
        for (i, &r) in refs.iter().enumerate() {
            let rd = macros[r].descriptor.as_ref().unwrap();
            if (ev[macros[mi].start].t - ev[macros[r].start].t).abs() < 3f64.max(rd.span * 0.72) {
                continue;
            }
            let v = macro_similarity(macros[mi].descriptor.as_ref().unwrap(), rd);
            if v > similarity {
                similarity = v;
                best = i as i64;
            }
        }
        let best = if best < 0 {
            refs.push(mi);
            refs.len() - 1
        } else {
            repeated += 1;
            best as usize
        };
        let m = &mut macros[mi];
        m.group = best;
        let group_seed = format!("{seed}|macro|{best}");
        m.motif = MOTIFS[(best + motif_start) % MOTIFS.len()];
        m.rhythm = RHYTHMS[hash_string(&format!("{group_seed}|rhythm")) as usize % RHYTHMS.len()];
        m.lead = match m.rhythm {
            "right-lead" => 1,
            "left-lead" => 0,
            _ => (hash_string(&format!("{group_seed}|hand")) % 2) as i32,
        };
    }
    repeated
}

fn hand_motif_styles(m: &Macro, seed: &str) -> [&'static str; 2] {
    const M: [&str; 6] = ["bounce", "orbit", "diagonal", "wave", "zigzag", "sweep"];
    let primary = if m.motif == "corpus" { M[hash_string(&format!("{seed}|{}|primary", m.group)) as usize % M.len()] } else { m.motif };
    let j = M.iter().position(|x| *x == primary).map(|v| v as i64).unwrap_or(-1);
    let other = M[((j.max(0) as usize) + 1 + (hash_string(&format!("{seed}|{}|secondary", m.group)) as usize % (M.len() - 1))) % M.len()];
    if m.lead == 0 { [primary, other] } else { [other, primary] }
}

pub fn groove_hand(style: &str, j: usize, seed: u32) -> i32 {
    match style {
        "right-lead" => [1, 1, 0, 1, 1, 0][j % 6],
        "left-lead" => [0, 0, 1, 0, 0, 1][j % 6],
        "call-response" => [0, 0, 1, 1, 0, 0, 1, 1][j % 8],
        "syncopated" => [1, 0, 1, 1, 0, 1, 0, 0][j % 8],
        _ => ((j as u64 + (seed % 2) as u64) % 2) as i32,
    }
}

pub struct Plan {
    pub macro_idx: usize,
    pub seed: u32,
    pub schedule: [Vec<usize>; 2],
}

fn assign_schedule(m: &Macro, ev: &[Ev], config: &DifficultyConfig, seed: u32, accent_override: f64) -> [Vec<usize>; 2] {
    if adv::boolean("flow.fullDoubleNotes", false) {
        let idx: Vec<usize> = (m.start..m.end).collect();
        return [idx.clone(), idx];
    }
    let difficulty = config.id.to_lowercase();
    let doubles = if difficulty.contains("easy") {
        0.1
    } else if difficulty.contains("medium") {
        0.13
    } else if difficulty.contains("expertplus") {
        0.27
    } else if difficulty.contains("expert") {
        0.22
    } else {
        0.18
    };
    let mut chosen: [Vec<usize>; 2] = [vec![], vec![]];
    let strengths: Vec<f64> = ev[m.start..m.end].iter().map(|e| e.strength).collect();
    let strength_mid = sc2_median(&strengths);
    let ao = if accent_override == 0.0 || accent_override.is_nan() { doubles } else { accent_override };
    let sync_rate = clamp(ao, 0.04, 0.42);
    for i in m.start..m.end {
        let relative = i - m.start;
        let e = &ev[i];
        let primary = groove_hand(m.rhythm, relative, seed) as usize;
        let is_accent = (relative % 4 == 0 || relative % 8 == 4) && e.strength >= strength_mid * 0.86;
        let eligible = is_accent && sc2_random(&format!("{seed}|accent|{}|{relative}", m.group)) < sync_rate * 2.35;
        let double = eligible && (relative > 0 || e.strength > 0.45);
        chosen[primary].push(i);
        if double {
            chosen[1 - primary].push(i);
        }
    }
    for h in 0..2 {
        let mut j = 1usize;
        while j < chosen[h].len() {
            let i = chosen[h][j];
            let last = chosen[h][j - 1];
            if ev[i].t - ev[last].t < 0.105 && !chosen[1 - h].contains(&i) {
                chosen[h].remove(j);
                chosen[1 - h].push(i);
                chosen[1 - h].sort();
                continue;
            }
            j += 1;
        }
    }
    chosen
}

#[derive(Clone, Debug)]
pub struct SoloBalance {
    pub before: [usize; 2],
    pub after: [usize; 2],
    pub mirrored_phrases: usize,
    pub mirrored_solo_notes: usize,
    pub balanced_macros: usize,
}

impl SoloBalance {
    pub fn to_json(&self) -> Value {
        json!({"before": self.before, "after": self.after, "mirroredPhrases": self.mirrored_phrases,
            "mirroredSoloNotes": self.mirrored_solo_notes, "balancedMacros": self.balanced_macros,
            "rule": "mirrored recurring-section solos; alternating 4-8-note phrases in one-off sections"})
    }
}

fn balance_solo_phrases(plans: &mut [Plan], macros: &[Macro], events: &[Ev]) -> SoloBalance {
    let mut frequency: HashMap<usize, usize> = HashMap::new();
    for p in plans.iter() {
        *frequency.entry(macros[p.macro_idx].group).or_insert(0) += 1;
    }
    let mut seen: HashMap<usize, usize> = HashMap::new();
    let mut first_phase: HashMap<usize, usize> = HashMap::new();
    let mut totals = [0usize; 2];
    let mut before = [0usize; 2];
    let mut last_times = [f64::NEG_INFINITY; 2];
    let (mut mirrored_phrases, mut mirrored_solo, mut balanced) = (0, 0, 0);
    let mut last_dominant: i32 = -1;
    for pi in 0..plans.len() {
        let m = &macros[plans[pi].macro_idx];
        let mut left: HashSet<usize> = plans[pi].schedule[0].iter().copied().collect();
        let mut right: HashSet<usize> = plans[pi].schedule[1].iter().copied().collect();
        let mut singles: Vec<(usize, usize)> = vec![];
        for i in m.start..m.end {
            if left.contains(&i) != right.contains(&i) {
                let hand = if left.contains(&i) { 0 } else { 1 };
                singles.push((i, hand));
                before[hand] += 1;
            }
        }
        let count = singles.len();
        let l = singles.iter().filter(|s| s.1 == 0).count();
        let r = count - l;
        let biased = count >= 6 && (l as f64 - r as f64).abs() / count as f64 >= 0.17;
        let occurrence = *seen.get(&m.group).unwrap_or(&0);
        seen.insert(m.group, occurrence + 1);
        if biased {
            let repeated = frequency[&m.group] > 1;
            let blocks: Vec<Vec<(usize, usize)>> = if repeated {
                vec![singles.clone()]
            } else {
                let mut bc = 2usize.max(count.div_ceil(8));
                if bc % 2 == 1 {
                    bc += 1;
                }
                (0..bc).map(|k| singles[(k * count) / bc..((k + 1) * count) / bc].to_vec()).filter(|b| !b.is_empty()).collect()
            };
            let original_lead = if l > r { 0 } else { 1 };
            let phase = if repeated && first_phase.contains_key(&m.group) {
                first_phase[&m.group] ^ (occurrence % 2)
            } else {
                let want_other = last_dominant == original_lead as i32 || totals[original_lead] > totals[1 - original_lead] + 3;
                let ph = if want_other { 1 } else { 0 };
                if repeated {
                    first_phase.insert(m.group, ph);
                }
                ph
            };
            let next_sched: [Option<usize>; 2] = [
                plans.get(pi + 1).and_then(|p| p.schedule[0].first().copied()),
                plans.get(pi + 1).and_then(|p| p.schedule[1].first().copied()),
            ];
            let too_close = |l: &HashSet<usize>, r: &HashSet<usize>| -> usize {
                let mut violations = 0;
                for hand in 0..2 {
                    let mut prev = last_times[hand];
                    let mut idx: Vec<usize> = if hand == 0 { l.iter().copied().collect() } else { r.iter().copied().collect() };
                    idx.sort();
                    for i in idx {
                        let t = events[i].t;
                        if t - prev < 0.105 - 1e-7 {
                            violations += 1;
                        }
                        prev = t;
                    }
                    if let Some(n0) = next_sched[hand]
                        && events[n0].t - prev < 0.105 - 1e-7
                    {
                        violations += 1;
                    }
                }
                violations
            };
            let mut baseline = too_close(&left, &right);
            for (k, block) in blocks.iter().enumerate() {
                if (phase ^ (k % 2)) == 0 {
                    continue;
                }
                for &(idx, hand) in block {
                    if hand == 0 {
                        left.remove(&idx);
                        right.insert(idx);
                    } else {
                        right.remove(&idx);
                        left.insert(idx);
                    }
                }
                let v = too_close(&left, &right);
                if v > baseline {
                    for &(idx, hand) in block {
                        if hand == 0 {
                            right.remove(&idx);
                            left.insert(idx);
                        } else {
                            left.remove(&idx);
                            right.insert(idx);
                        }
                    }
                } else {
                    baseline = v;
                    mirrored_phrases += 1;
                    mirrored_solo += block.len();
                }
            }
            let mut s0: Vec<usize> = left.into_iter().collect();
            s0.sort();
            let mut s1: Vec<usize> = right.into_iter().collect();
            s1.sort();
            plans[pi].schedule = [s0, s1];
            balanced += 1;
        }
        let (mut in_l, mut in_r) = (0, 0);
        for &(idx, _) in &singles {
            if plans[pi].schedule[0].contains(&idx) {
                in_l += 1;
            } else {
                in_r += 1;
            }
        }
        totals[0] += in_l;
        totals[1] += in_r;
        if in_l != in_r {
            last_dominant = if in_l > in_r { 0 } else { 1 };
        }
        for h in 0..2 {
            if let Some(&last) = plans[pi].schedule[h].last() {
                last_times[h] = events[last].t;
            }
        }
    }
    SoloBalance { before, after: totals, mirrored_phrases, mirrored_solo_notes: mirrored_solo, balanced_macros: balanced }
}

struct Chunk {
    len: usize,
    indices: Vec<usize>,
}

fn slot_chunks(indices: &[usize], ev: &[Ev], g: Option<&Grid>) -> Vec<Chunk> {
    let n = indices.len();
    if n == 0 {
        return vec![];
    }
    if n <= 10 {
        return vec![Chunk { len: n, indices: indices.to_vec() }];
    }
    let mut dp = vec![-1e12f64; n + 1];
    let mut prev = vec![0usize; n + 1];
    dp[0] = 0.0;
    let gaps: Vec<f64> = (1..n).map(|k| ev[indices[k]].t - ev[indices[k - 1]].t).collect();
    let med = sc2_median(&gaps);
    let reliable = g.map(|g| g.downbeat_reliable).unwrap_or(false);
    for i in 0..n {
        if dp[i] < -1e10 {
            continue;
        }
        for len in 3..=10usize {
            let end = i + len;
            if end > n {
                break;
            }
            let mut score = dp[i] - 0.42 - 0.075 * (len as f64 - 8.0).abs();
            if end < n {
                let gap = ev[indices[end]].t - ev[indices[end - 1]].t;
                score += 0.7f64.min(0f64.max(gap / 0.1f64.max(med) - 1.0) * 0.5);
                if reliable {
                    score += 0.28 * grid::bar_alignment(ev[indices[end]].t, g);
                }
            }
            if score > dp[end] {
                dp[end] = score;
                prev[end] = i;
            }
        }
    }
    if dp[n] < -1e10 {
        return vec![Chunk { len: n, indices: indices.to_vec() }];
    }
    let mut chunks = vec![];
    let mut end = n;
    while end > 0 {
        let mut start = prev[end];
        if start >= end {
            start = 0;
        }
        chunks.push(Chunk { len: end - start, indices: indices[start..end].to_vec() });
        end = start;
    }
    chunks.reverse();
    chunks
}

pub fn motif_note(motif: &str, hand: i32, index: usize) -> CNote {
    let outer = if hand == 0 { 0 } else { 3 };
    let inner = if hand == 0 { 1 } else { 2 };
    let even = index % 2 == 0;
    let dx = if hand == 0 { 1 } else { -1 };
    match motif {
        "bounce" => CNote { x: if index % 4 < 2 { outer } else { inner }, y: if even { 2 } else { 0 }, d: if even { 1 } else { 0 } },
        "orbit" => {
            let orbit = [(outer, 2), (outer, 1), (outer, 0), (inner, 0), (inner, 1), (inner, 2)];
            let (x, y) = orbit[index % 6];
            CNote { x, y, d: if even { 1 } else { 0 } }
        }
        "wave" => CNote { x: if even { outer } else { inner }, y: [0, 1, 2, 1][index % 4], d: if even { 0 } else { 1 } },
        "diagonal" => CNote {
            x: if even { outer } else { inner },
            y: if even { 2 } else { 0 },
            d: if hand == 0 {
                if even { 7 } else { 4 }
            } else if even {
                6
            } else {
                5
            },
        },
        "zigzag" => CNote { x: if even { outer } else { inner }, y: [0, 2, 1, 2, 0, 1][index % 6], d: if even { 1 } else { 0 } },
        "sweep" => CNote {
            x: if even { inner } else { outer },
            y: [2, 1, 0, 1][index % 4],
            d: if even {
                if dx > 0 { 7 } else { 6 }
            } else if dx > 0 {
                4
            } else {
                5
            },
        },
        _ => CNote { x: if hand != 0 { 3 } else { 0 }, y: if even { 2 } else { 0 }, d: if even { 1 } else { 0 } },
    }
}

#[inline]
fn state_code(x: i32, y: i32, d: i32) -> usize {
    ((x * 3 + y) * 8 + d) as usize
}

pub struct GeoCache {
    pub angle: Vec<f64>,
    pub reach: Vec<f64>,
    pub cross: Vec<f64>,
}

pub static GEO: LazyLock<GeoCache> = LazyLock::new(|| {
    let mut states = vec![(0, 0, 0); STATES];
    for x in 0..4 {
        for y in 0..3 {
            for d in 0..8 {
                states[state_code(x, y, d)] = (x, y, d);
            }
        }
    }
    let mut angle = vec![0f64; STATES * STATES];
    let mut reach = vec![0f64; STATES * STATES];
    let mut cross = vec![0f64; STATES * STATES];
    for a in 0..STATES {
        let (px, py, pd) = states[a];
        let pv = DIRS[pd as usize];
        for b in 0..STATES {
            let (nx, ny, nd) = states[b];
            let v = DIRS[nd as usize];
            let idx = a * STATES + b;
            angle[idx] = angular_error(ANGLES[nd as usize], (ANGLES[pd as usize] + 180.0) % 360.0);
            reach[idx] = jsm::hypot(
                nx as f64 - v.0 * 0.48 - (px as f64 + pv.0 * 0.48),
                ny as f64 - v.1 * 0.48 - (py as f64 + pv.1 * 0.48),
            );
            cross[idx] = cross_risk_uncached(CNote { x: px, y: py, d: pd }, CNote { x: nx, y: ny, d: nd }, 0.0);
        }
    }
    GeoCache { angle, reach, cross }
});

#[derive(Clone, Copy, Debug)]
pub struct HState {
    pub x: i32,
    pub y: i32,
    pub d: i32,
    pub t: f64,
    pub strain: f64,
    pub cost: f64,
}

impl HState {
    pub fn note(&self) -> CNote {
        CNote { x: self.x, y: self.y, d: self.d }
    }
}

/// sc2HandStep
pub fn hand_step(prev: Option<&HState>, note: CNote, t: f64, hand: i32, strict: f64) -> Option<HState> {
    if note.x < 0 || note.x > 3 || note.y < 0 || note.y > 2 {
        return None;
    }
    let d = if note.d == 8 { prev.map(|p| OPPOSITE[p.d as usize]).unwrap_or(1) } else { note.d };
    if !(0..=7).contains(&d) {
        return None;
    }
    let vec = DIRS[d as usize];
    let home = if hand == 0 { 0.7 } else { 2.3 };
    let cross = if hand == 0 { 0.max(note.x - 1) } else { 0.max(2 - note.x) } as f64;
    let mut cost = 0.2 * (note.x as f64 - home).abs() + cross * 0.52 * strict + if note.y == 2 { 0.08 } else { 0.0 };
    let mut strain = 0.0;
    if let Some(p) = prev {
        let dt = t - p.t;
        if dt < 0.082 {
            return None;
        }
        if cross > 0.0 && dt < 0.24 * strict {
            return None;
        }
        if dt < 1.3 {
            let geo = &*GEO;
            let si = state_code(p.x, p.y, p.d) * STATES + state_code(note.x, note.y, d);
            let err = geo.angle[si];
            let cap = if dt < 0.23 {
                60.0
            } else if dt < 0.34 {
                95.0
            } else if dt < 0.5 {
                130.0
            } else {
                180.0
            };
            if err > cap / strict {
                return None;
            }
            if err > 135.0 && dt < 0.62 * strict {
                return None;
            }
            let reach = geo.reach[si];
            if reach / dt.max(0.1) > 11.5 / strict {
                return None;
            }
            strain = (p.strain - dt * 1.45).max(0.0) + err / 210.0 + (0.065 * reach) / dt.max(0.22) + cross * 0.14;
            if strain > 2.55 / strict {
                return None;
            }
            cost += err / 125.0 + (0.065 * reach) / dt.max(0.15) + 0.22 * strain;
        } else {
            cost += 0.08;
        }
    }
    if note.y == 2 && vec.1 > 0.3 {
        cost += 0.17 * strict;
    }
    if note.y == 0 && vec.1 < -0.3 {
        cost += 0.12 * strict;
    }
    Some(HState { x: note.x, y: note.y, d, t, strain, cost })
}

struct Repair {
    state: HState,
    note: CNote,
    score: f64,
    fit: f64,
}

fn repair_note(note: CNote, prev: Option<&HState>, t: f64, hand: i32, strict: f64) -> Option<Repair> {
    let dirs = [note.d, prev.map(|p| OPPOSITE[p.d as usize]).unwrap_or(1), 0, 1, 4, 5, 6, 7, 2, 3];
    let xs = [note.x, (note.x + if hand != 0 { 1 } else { -1 }).clamp(0, 3), if hand != 0 { 3 } else { 0 }, if hand != 0 { 2 } else { 1 }];
    let ys = [note.y, (note.y - 1).clamp(0, 2), (note.y + 1).clamp(0, 2), 1];
    let mut best: Option<Repair> = None;
    let mut visited = [false; 108];
    for &x in &xs {
        for &y in &ys {
            for &d in &dirs {
                let key = ((x * 3 + y) * 9 + d) as usize;
                if key >= 108 || visited[key] {
                    continue;
                }
                visited[key] = true;
                let Some(state) = hand_step(prev, CNote { x, y, d }, t, hand, strict) else { continue };
                let fit = 1.15 * (x - note.x).abs() as f64 + 0.75 * (y - note.y).abs() as f64 + if d == note.d { 0.0 } else { 0.9 };
                let score = state.cost + 1.65 * fit;
                if best.as_ref().map(|b| score < b.score).unwrap_or(true) {
                    best = Some(Repair { state, note: CNote { x, y, d }, score, fit });
                }
            }
        }
    }
    best
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum Kind {
    Motif,
    Corpus,
    Bridge,
    TempoFallback,
    JointRepair,
}

impl Kind {
    pub fn as_str(&self) -> &'static str {
        match self {
            Kind::Motif => "motif",
            Kind::Corpus => "corpus",
            Kind::Bridge => "bridge",
            Kind::TempoFallback => "tempo-fallback",
            Kind::JointRepair => "joint-repair",
        }
    }
}

#[derive(Clone, Debug)]
pub struct PNote {
    pub event_index: usize,
    pub time: f64,
    pub hand: i32,
    pub x: i32,
    pub y: i32,
    pub d: i32,
    pub source: bool,
    pub original: Option<CNote>,
    pub kind: Option<Kind>,
    pub macro_group: Option<usize>,
    pub motif: Option<&'static str>,
}

struct EvalResult {
    end: Option<HState>,
    cost: f64,
    repairs: usize,
    notes: Vec<PNote>,
}

fn evaluate_sequence(seq: &[(CNote, bool)], indices: &[usize], ev: &[Ev], hand: i32, initial: Option<HState>, strict: f64, max_repair: usize) -> Option<EvalResult> {
    let mut state = initial;
    let mut cost = 0.0;
    let mut repairs = 0;
    let mut notes = Vec::with_capacity(seq.len());
    for (k, &(goal, source)) in seq.iter().enumerate() {
        let time = ev[indices[k]].t;
        let direct = hand_step(state.as_ref(), goal, time, hand, strict);
        let (actual, note) = match direct {
            Some(s) => (s, CNote { x: goal.x, y: goal.y, d: s.d }),
            None => {
                if repairs >= max_repair {
                    return None;
                }
                let fix = repair_note(goal, state.as_ref(), time, hand, strict)?;
                cost += 2.0 + fix.fit * 1.65;
                repairs += 1;
                (fix.state, fix.note)
            }
        };
        cost += actual.cost;
        state = Some(actual);
        notes.push(PNote { event_index: indices[k], time, hand, x: note.x, y: note.y, d: note.d, source, original: Some(goal), kind: None, macro_group: None, motif: None });
    }
    Some(EvalResult { end: state, cost, repairs, notes })
}

fn shape_penalty(seq: &[(CNote, bool)], motif: &str, hand: i32, start: usize, strength: f64) -> f64 {
    if motif == "corpus" || strength <= 0.0 {
        return 0.0;
    }
    let mut score = 0.0;
    for (i, (n, _)) in seq.iter().enumerate() {
        let desired = motif_note(motif, hand, start + i);
        score += 0.55 * (desired.y - n.y).abs() as f64 + 0.32 * (desired.x - n.x).abs() as f64 + if desired.d != n.d { 0.22 } else { 0.0 };
    }
    score * strength
}

pub fn candidates(len: usize, seed: &str, stored: Option<&'static Entry>, limit: usize, speed_pressure: f64) -> Vec<&'static Entry> {
    let lib = &*LIBRARY;
    let pool = &lib.by_length[len];
    if pool.is_empty() {
        return stored.into_iter().collect();
    }
    let mut entries: Vec<&'static Entry> = vec![];
    let mut seen: HashSet<u32> = HashSet::new();
    let mut families: HashMap<u32, usize> = HashMap::new();
    let mut add = |e: &'static Entry, entries: &mut Vec<&'static Entry>| {
        if !e.smooth_phrase || seen.contains(&e.off) {
            return;
        }
        let f = families.entry(e.family).or_insert(0);
        if *f >= 2 {
            return;
        }
        seen.insert(e.off);
        *f += 1;
        entries.push(e);
    };
    if let Some(s) = stored
        && s.len == len
    {
        add(s, &mut entries);
    }
    let n = limit.min(pool.len());
    let cuts = [0.0, 0.25, 0.55, 0.8, 1.0];
    let salt = hash_string(seed);
    if speed_pressure > 0.28 {
        let easy = &lib.fast_by_length[len];
        let reserve = 2usize.max(js_round(n as f64 * 0.36 * speed_pressure) as usize);
        let extra = if stored.is_some() { 1 } else { 0 };
        let mut k = 0usize;
        while k < reserve * 25 && entries.len() < reserve + extra {
            let range = if k % 3 == 0 { easy.len() } else { 1usize.max((easy.len() as f64 * 0.32).floor() as usize) };
            if range == 0 {
                break;
            }
            let id = (sc2_random(&format!("{salt}|fast|{k}")) * range as f64).floor() as usize;
            add(&easy[id.min(easy.len() - 1)], &mut entries);
            k += 1;
        }
    }
    let mut k = 0usize;
    while k < n * 14 && entries.len() < n {
        let tier = k % 4;
        let lo = (pool.len() as f64 * cuts[tier]).floor() as usize;
        let hi = (lo + 1).max((pool.len() as f64 * cuts[tier + 1]).floor() as usize);
        let u = sc2_random(&format!("{salt}|stratum|{k}"));
        add(&pool[(pool.len() - 1).min(lo + (u * (hi - lo) as f64).floor() as usize)], &mut entries);
        k += 1;
    }
    entries
}

#[derive(Clone, Debug)]
pub struct LaneState {
    recent: VecDeque<i32>,
    counts: [i64; 3],
    global: [i64; 3],
    total: i64,
}

impl LaneState {
    pub fn new() -> Self {
        LaneState { recent: VecDeque::new(), counts: [0; 3], global: [0; 3], total: 0 }
    }
    pub fn remember(&mut self, y: i32) {
        if !(0..=2).contains(&y) {
            return;
        }
        self.recent.push_back(y);
        self.counts[y as usize] += 1;
        self.global[y as usize] += 1;
        self.total += 1;
        if self.recent.len() > 64 {
            let old = self.recent.pop_front().unwrap();
            self.counts[old as usize] -= 1;
        }
    }
    pub fn bias(&self, strength: f64) -> [f64; 3] {
        if strength <= 0.0 {
            return [0.0; 3];
        }
        let w = self.recent.len() as f64;
        let all = self.total as f64;
        let ld = 3f64.max(w * 0.2);
        let gd = 8f64.max(all * 0.22);
        let mut out = [0.0; 3];
        for y in 0..3 {
            out[y] = strength * (1.45 * clamp((self.counts[y] as f64 - w / 3.0) / ld, -1.7, 1.7) + 0.55 * clamp((self.global[y] as f64 - all / 3.0) / gd, -1.5, 1.5));
        }
        out
    }
    fn sequence_penalty(&self, notes: &[PNote], strength: f64) -> f64 {
        if strength <= 0.0 || notes.is_empty() {
            return 0.0;
        }
        let mut local = self.counts;
        let mut global = self.global;
        let mut total = self.total as f64;
        let mut w = self.recent.len() as f64;
        let mut penalty = 0.0;
        for n in notes {
            let y = n.y as usize;
            let ld = 3f64.max(w * 0.2);
            let gd = 8f64.max(total * 0.22);
            penalty += strength * (1.45 * clamp((local[y] as f64 - w / 3.0) / ld, -1.7, 1.7) + 0.55 * clamp((global[y] as f64 - total / 3.0) / gd, -1.5, 1.5));
            local[y] += 1;
            global[y] += 1;
            w += 1.0;
            total += 1.0;
        }
        penalty
    }
}

struct Intent {
    wildness: f64,
}

fn phrase_intent(m: &Macro, ev: &[Ev], config: &DifficultyConfig) -> Intent {
    let (mut s, mut mv, mut act) = (0.0, 0.0, 0.0);
    for e in &ev[m.start..m.end] {
        s += e.strength;
        mv += e.state;
        act += e.activity;
    }
    let n = m.len.max(1) as f64;
    let level = super::density_fraction(&config.id).unwrap_or(0.6);
    let energy = clamp((0.43 * s) / n + (0.32 * mv) / n + (0.25 * act) / n, 0.0, 1.0);
    Intent { wildness: clamp(0.19 + 0.35 * level + 0.35 * energy, 0.2, 0.89) }
}

fn chunk_contour(ch: &Chunk, ev: &[Ev], g: Option<&Grid>) -> Vec<f64> {
    let n = ch.indices.len();
    let reliable = g.map(|g| g.downbeat_reliable).unwrap_or(false);
    let values: Vec<f64> = ch
        .indices
        .iter()
        .map(|&i| {
            let e = &ev[i];
            let meter = if reliable { 0.25 * grid::bar_alignment(e.t, g) } else { 0.0 };
            e.strength.max(0.0) + 0.6 * e.state.max(0.0) + meter
        })
        .collect();
    let mean = values.iter().fold(0.0, |a, b| a + b) / n.max(1) as f64;
    values.iter().map(|v| clamp((v - mean) / 0.3f64.max(mean + 0.15), -1.0, 1.0)).collect()
}

fn gesture_cost(notes: &[PNote], contour: &[f64]) -> f64 {
    if notes.len() < 2 || contour.is_empty() {
        return 0.0;
    }
    let mut total = 0.0;
    for i in 1..notes.len() {
        let (a, b) = (&notes[i - 1], &notes[i]);
        let movement = 2.6f64.min(0.6 * (a.x - b.x).abs() as f64 + 0.8 * (a.y - b.y).abs() as f64);
        let requested = 0.95 + 0.65 * contour.get(i).copied().unwrap_or(0.0);
        total += (movement - requested).abs();
    }
    total / (notes.len() - 1) as f64
}

#[derive(Clone, Debug, Default)]
pub struct DensityProfile {
    pub peak4: f64,
    pub peak8: f64,
    pub adapted_events: usize,
    pub beat_seconds: f64,
}

impl DensityProfile {
    pub fn to_json(&self) -> Value {
        json!({"peak4": jnum(self.peak4), "peak8": jnum(self.peak8), "adaptedEvents": self.adapted_events,
            "beatSeconds": jnum(self.beat_seconds), "adaptedChunks": 0})
    }
}

fn scheduled_density_profile(ev: &mut [Ev], plans: &[Plan], g: Option<&Grid>) -> DensityProfile {
    let beat_seconds = match g {
        Some(g) if g.confidence >= 0.51 => g.period,
        _ => 0.5,
    };
    let mut times: Vec<f64> = vec![];
    for p in plans {
        for hand in &p.schedule {
            for &i in hand {
                times.push(ev[i].t);
            }
        }
    }
    times.sort_by(|a, b| a.partial_cmp(b).unwrap());
    let windows = [4.0 * beat_seconds, 8.0 * beat_seconds];
    let density: Vec<Vec<f32>> = windows
        .iter()
        .map(|&w| {
            let (mut left, mut right) = (0usize, 0usize);
            let mut values = vec![0f32; ev.len()];
            for i in 0..ev.len() {
                let t = ev[i].t;
                let (start, end) = (t - w * 0.5, t + w * 0.5);
                while left < times.len() && times[left] < start {
                    left += 1;
                }
                while right < times.len() && times[right] <= end {
                    right += 1;
                }
                values[i] = (right.saturating_sub(left) as f64 / w) as f32;
            }
            values
        })
        .collect();
    let (mut peak4, mut peak8, mut adapted) = (0f64, 0f64, 0usize);
    for i in 0..ev.len() {
        let n4 = density[0][i] as f64;
        let n8 = density[1][i] as f64;
        peak4 = peak4.max(n4);
        peak8 = peak8.max(n8);
        let burst = clamp((n4 - 6.6) / 4.2, 0.0, 1.0);
        let sustained = clamp((n8 - 6.1) / 3.6, 0.0, 1.0);
        ev[i].flow_speed_pressure = burst.max(sustained * 0.93);
        ev[i].flow_nps4 = density[0][i];
        ev[i].flow_nps8 = density[1][i];
        if ev[i].flow_speed_pressure > 0.15 {
            adapted += 1;
        }
    }
    DensityProfile { peak4: to_fixed_num(peak4, 2), peak8: to_fixed_num(peak8, 2), adapted_events: adapted, beat_seconds: to_fixed_num(beat_seconds, 4) }
}

fn chunk_speed_pressure(indices: &[usize], ev: &[Ev]) -> f64 {
    let (mut total, mut peak) = (0.0, 0f64);
    for &i in indices {
        let v = ev[i].flow_speed_pressure;
        total += v;
        peak = peak.max(v);
    }
    (0.72 * total) / indices.len().max(1) as f64 + 0.28 * peak
}

fn dense_phrase_ease_cost(notes: &[PNote], previous: Option<&HState>, pressure: f64) -> f64 {
    if pressure <= 0.01 || notes.is_empty() {
        return 0.0;
    }
    let (mut diag, mut lateral, mut long_side, mut repeats) = (0.0, 0.0, 0.0, 0.0);
    let mut prev: Option<(i32, i32, f64)> = previous.map(|p| (p.x, p.y, p.t));
    for n in notes {
        if (4..=7).contains(&n.d) {
            diag += 1.0;
        }
        if let Some((px, py, pt)) = prev {
            let dx = (n.x - px).abs() as f64;
            let dt = n.time - pt;
            let urgency = if dt > 0.0 && dt < 0.32 { 1.3 } else { 1.0 };
            lateral += dx * urgency;
            long_side += (dx - 1.0).max(0.0) * urgency;
            if n.x == px && n.y == py && dt < 0.33 {
                repeats += 1.0;
            }
        }
        prev = Some((n.x, n.y, n.time));
    }
    pressure * (1.15 * diag + 1.75 * lateral + 2.4 * long_side + 1.3 * repeats)
}

#[derive(Clone)]
struct Template {
    kind: Kind,
    entry: Option<&'static Entry>,
    seq: Vec<(CNote, bool)>,
}

struct ChunkTemplates {
    key: String,
    broad_key: String,
    stored: Option<&'static Entry>,
    style: &'static str,
    templates: Vec<Template>,
    speed_pressure: f64,
    contour: Vec<f64>,
}

#[allow(clippy::too_many_arguments)]
fn chunk_templates(m: &Macro, ev: &[Ev], hand: i32, ch: &Chunk, ci: usize, slot_cursor: usize, seed: &str, motif_strength: f64, diversity: f64, cache: &HashMap<String, &'static Entry>, g: Option<&Grid>) -> ChunkTemplates {
    let gaps: Vec<f64> = (1..ch.indices.len()).map(|j| (ev[ch.indices[j]].t - ev[ch.indices[j - 1]].t).max(0.001)).collect();
    let base_gap = sc2_median(&gaps);
    let tempo_band = js_round(base_gap / 0.075) as i64;
    let cadence: String = gaps
        .iter()
        .map(|&g| if g < base_gap * 0.76 { 's' } else if g > base_gap * 1.55 { 'l' } else { 'm' })
        .collect();
    let key = format!("{hand}/{}/{tempo_band}/{cadence}", ch.len);
    let broad_key = format!("{hand}/{}/{tempo_band}", ch.len);
    let stored = cache.get(&key).or_else(|| cache.get(&broad_key)).copied();
    let style = m.hand_motifs[hand as usize];
    let mut templates = vec![];
    let speed_pressure = chunk_speed_pressure(&ch.indices, ev);
    if style != "corpus" && motif_strength > 0.0 && hand == m.lead && ci % 4 == 0 {
        templates.push(Template { kind: Kind::Motif, entry: None, seq: (0..ch.indices.len()).map(|j| (motif_note(style, hand, slot_cursor + j), false)).collect() });
    }
    if ch.len >= 3 {
        let cseed = format!("{seed}|{}|{hand}|{ci}|{}", m.group, ch.len);
        let count = if diversity > 0.5 { 32 } else { 24 };
        for e in candidates(ch.len, &cseed, stored, count, speed_pressure) {
            templates.push(Template { kind: Kind::Corpus, entry: Some(e), seq: corpus::read_source(e, hand) });
        }
    }
    templates.push(Template { kind: Kind::Bridge, entry: None, seq: (0..ch.indices.len()).map(|j| (motif_note("bounce", hand, slot_cursor + j), false)).collect() });
    ChunkTemplates { key, broad_key, stored, style, templates, speed_pressure, contour: chunk_contour(ch, ev, g) }
}

#[allow(clippy::too_many_arguments)]
fn score_flow_choice(t: &Template, a: &EvalResult, hand: i32, slot_cursor: usize, intent: &Intent, motif_strength: f64, diversity: f64, usage: &HashMap<u32, usize>, lane: &LaneState, lane_balance: f64, stored: Option<&'static Entry>, style: &str, contour: &[f64], speed_pressure: f64, previous: Option<&HState>) -> f64 {
    let mut score = a.cost + a.repairs as f64 * 1.5;
    score += dense_phrase_ease_cost(&a.notes, previous, speed_pressure);
    match t.kind {
        Kind::Corpus => {
            let e = t.entry.unwrap();
            score += shape_penalty(&t.seq, style, hand, slot_cursor, motif_strength * 0.07);
            score += 2.5 * (e.wild - intent.wildness).abs() - 0.6 * e.support;
            if e.wild > intent.wildness + 0.28 {
                score += 2.0 * (e.wild - intent.wildness - 0.28);
            }
            score += diversity * 0.20 * e.genericity;
            score += 0.55 * gesture_cost(&a.notes, contour);
            if stored.map(|s| s.off == e.off).unwrap_or(false) {
                score -= 7.0;
            } else {
                score += diversity * 0.08 * jsm::log1p(*usage.get(&e.off).unwrap_or(&0) as f64);
            }
        }
        Kind::Motif => score += 4.0 + 0.6 * gesture_cost(&a.notes, contour),
        _ => score += 11.0,
    }
    if lane_balance > 0.0 {
        score += lane.sequence_penalty(&a.notes, lane_balance);
    }
    score
}

#[derive(Clone)]
struct Sel {
    kind: Kind,
    entry: Option<&'static Entry>,
    len: usize,
    key: String,
    broad_key: String,
    reused: bool,
}

#[derive(Clone)]
struct BeamPlan {
    state: Option<HState>,
    cost: f64,
    repairs: usize,
    corpus: usize,
    motif: usize,
    notes: Vec<PNote>,
    selected: Vec<Sel>,
    lane: LaneState,
}

struct HandPlan {
    notes: Vec<PNote>,
    state: Option<HState>,
    repairs: usize,
    corpus: usize,
    motif: usize,
    selected: Vec<Sel>,
}

pub struct PlannerShared {
    cache: HashMap<String, &'static Entry>,
    usage: HashMap<u32, usize>,
    owners: HashSet<(usize, u32)>,
    family_usage: HashMap<u32, usize>,
    family_owners: HashSet<(usize, u32)>,
}

#[allow(clippy::too_many_arguments)]
fn plan_hand_in_macro(m: &Macro, ev: &[Ev], hand: i32, indices: &[usize], previous: Option<HState>, seed: &str, strict: f64, sh: &mut PlannerShared, motif_strength: f64, diversity: f64, lane_hist: &mut LaneState, lane_balance: f64, config: &DifficultyConfig, g: Option<&Grid>) -> HandPlan {
    let chunks = slot_chunks(indices, ev, g);
    let intent = phrase_intent(m, ev, config);
    let width = 3;
    let mut groups = vec![];
    let mut cursor = 0;
    for (ci, ch) in chunks.iter().enumerate() {
        groups.push(chunk_templates(m, ev, hand, ch, ci, cursor, seed, motif_strength, diversity, &sh.cache, g));
        cursor += ch.len;
    }
    let mut beam = vec![BeamPlan { state: previous, cost: 0.0, repairs: 0, corpus: 0, motif: 0, notes: vec![], selected: vec![], lane: lane_hist.clone() }];
    cursor = 0;
    for (ci, ch) in chunks.iter().enumerate() {
        let group = &groups[ci];
        let mut expanded: Vec<BeamPlan> = vec![];
        for plan in &beam {
            let mut accepted = 0;
            for t in &group.templates {
                let max_repair = if t.kind == Kind::Bridge { ch.len } else { 2usize.min((ch.len as f64 * 0.28).floor() as usize) };
                let Some(attempt) = evaluate_sequence(&t.seq, &ch.indices, ev, hand, plan.state, strict, max_repair) else { continue };
                accepted += 1;
                let delta = score_flow_choice(t, &attempt, hand, cursor, &intent, motif_strength, diversity, &sh.usage, &plan.lane, lane_balance, group.stored, group.style, &group.contour, group.speed_pressure, plan.state.as_ref());
                let mut lane = plan.lane.clone();
                for n in &attempt.notes {
                    lane.remember(n.y);
                }
                let mut notes = plan.notes.clone();
                notes.extend(attempt.notes.into_iter().map(|mut n| {
                    n.kind = Some(t.kind);
                    n
                }));
                let mut selected = plan.selected.clone();
                selected.push(Sel {
                    kind: t.kind,
                    entry: t.entry,
                    len: ch.len,
                    key: group.key.clone(),
                    broad_key: group.broad_key.clone(),
                    reused: t.entry.is_some() && group.stored.map(|s| Some(s.off) == t.entry.map(|e| e.off)).unwrap_or(false),
                });
                expanded.push(BeamPlan {
                    state: attempt.end,
                    cost: plan.cost + delta,
                    repairs: plan.repairs + attempt.repairs,
                    corpus: plan.corpus + if t.kind == Kind::Corpus { 1 } else { 0 },
                    motif: plan.motif + if t.kind == Kind::Motif { 1 } else { 0 },
                    notes,
                    selected,
                    lane,
                });
            }
            if accepted == 0 {
                let mut state = plan.state;
                let mut repairs = 0;
                let mut lane = plan.lane.clone();
                let mut notes = plan.notes.clone();
                for j in 0..ch.len {
                    let idx = ch.indices[j];
                    let time = ev[idx].t;
                    let goal = motif_note("bounce", hand, cursor + j);
                    let Some(r) = repair_note(goal, state.as_ref(), time, hand, strict) else { continue };
                    state = Some(r.state);
                    repairs += 1;
                    notes.push(PNote { event_index: idx, time, hand, x: r.note.x, y: r.note.y, d: r.note.d, original: Some(goal), source: false, kind: Some(Kind::Bridge), macro_group: None, motif: None });
                    lane.remember(r.note.y);
                }
                let mut selected = plan.selected.clone();
                selected.push(Sel { kind: Kind::Bridge, entry: None, len: ch.len, key: group.key.clone(), broad_key: group.broad_key.clone(), reused: false });
                expanded.push(BeamPlan { state, lane, cost: plan.cost + 15.0 + repairs as f64 * 3.0, repairs: plan.repairs + repairs, corpus: plan.corpus, motif: plan.motif, notes, selected });
            }
        }
        expanded.sort_by(|a, b| a.cost.partial_cmp(&b.cost).unwrap_or(std::cmp::Ordering::Equal).then(a.repairs.cmp(&b.repairs)));
        let mut distinct: HashSet<(Option<(i32, i32, i32)>, Kind, Option<u32>)> = HashSet::new();
        let mut survivors = vec![];
        for plan in expanded {
            let exit = plan.state.map(|s| (s.x, s.y, s.d));
            let tail = plan.selected.last().unwrap();
            let id = (exit, tail.kind, tail.entry.map(|e| e.off));
            if !distinct.insert(id) {
                continue;
            }
            survivors.push(plan);
            if survivors.len() >= width {
                break;
            }
        }
        beam = survivors;
        cursor += ch.len;
    }
    let Some(best) = beam.into_iter().next() else {
        return HandPlan { notes: vec![], state: previous, repairs: 0, corpus: 0, motif: 0, selected: vec![] };
    };
    for n in &best.notes {
        lane_hist.remember(n.y);
    }
    for item in &best.selected {
        let Some(e) = item.entry else { continue };
        sh.cache.entry(item.key.clone()).or_insert(e);
        sh.cache.entry(item.broad_key.clone()).or_insert(e);
        if sh.owners.insert((m.group, e.off)) {
            *sh.usage.entry(e.off).or_insert(0) += 1;
        }
        if sh.family_owners.insert((m.group, e.family)) {
            *sh.family_usage.entry(e.family).or_insert(0) += 1;
        }
    }
    HandPlan { notes: best.notes, state: best.state, repairs: best.repairs, corpus: best.corpus, motif: best.motif, selected: best.selected }
}

pub fn cross_risk_uncached(l: CNote, r: CNote, dt: f64) -> f64 {
    if dt.abs() > 0.17 {
        return 0.0;
    }
    if l.x == r.x && l.y == r.y {
        return 100.0;
    }
    if l.x > r.x {
        return 100.0;
    }
    let lv = DIRS[l.d as usize];
    let rv = DIRS[r.d as usize];
    let mut min = 100f64;
    for j in 0..=8 {
        let f = j as f64 / 8.0 - 0.5;
        let x1 = l.x as f64 + f * lv.0 * 1.15;
        let y1 = l.y as f64 + f * lv.1 * 1.15;
        let x2 = r.x as f64 + f * rv.0 * 1.15;
        let y2 = r.y as f64 + f * rv.1 * 1.15;
        min = min.min(jsm::hypot(x1 - x2, y1 - y2));
    }
    if min < 0.45 {
        return 100.0;
    }
    let inward = lv.0 > 0.33 && rv.0 < -0.33;
    if inward && l.x == 1 && r.x == 2 && ((l.y - r.y) as f64).abs() < 1.1 {
        return 100.0;
    }
    (0.6 - min).max(0.0) * 2.0
}

/// sc2CrossRisk(left, right, dt)
pub fn cross_risk(l: CNote, r: CNote, dt: f64) -> f64 {
    if dt.abs() > 0.17 {
        return 0.0;
    }
    if l.x < 0 || l.x > 3 || r.x < 0 || r.x > 3 || l.y < 0 || l.y > 2 || r.y < 0 || r.y > 2 || l.d < 0 || l.d > 7 || r.d < 0 || r.d > 7 {
        if l.d < 0 || l.d > 8 || r.d < 0 || r.d > 8 {
            return 0.0;
        }
        return cross_risk_uncached(l, r, dt);
    }
    GEO.cross[state_code(l.x, l.y, l.d) * STATES + state_code(r.x, r.y, r.d)]
}

struct JointFix {
    state: HState,
    shape: f64,
}

fn joint_repair(goal: CNote, prev: Option<&HState>, t: f64, hand: i32, other: Option<&HState>, strict: f64) -> Option<JointFix> {
    let dirs = [goal.d, prev.map(|p| OPPOSITE[p.d as usize]).unwrap_or(1), 0, 1, 4, 5, 6, 7];
    let xs = [goal.x, if hand == 0 { 0 } else { 3 }, if hand == 0 { 1 } else { 2 }, if hand == 0 { 2 } else { 1 }];
    let ys = [goal.y, 1, 0, 2];
    let mut best: Option<(JointFix, f64)> = None;
    let mut seen: HashSet<(i32, i32, i32)> = HashSet::new();
    for &x in &xs {
        for &y in &ys {
            for &d in &dirs {
                if !seen.insert((x, y, d)) {
                    continue;
                }
                let Some(state) = hand_step(prev, CNote { x, y, d }, t, hand, strict) else { continue };
                let risk = match other {
                    Some(o) => {
                        if hand == 0 {
                            cross_risk(state.note(), o.note(), t - o.t)
                        } else {
                            cross_risk(o.note(), state.note(), t - o.t)
                        }
                    }
                    None => 0.0,
                };
                if risk >= 100.0 {
                    continue;
                }
                let shape = 1.1 * (x - goal.x).abs() as f64 + 0.7 * (y - goal.y).abs() as f64 + if d == goal.d { 0.0 } else { 0.8 };
                let score = state.cost + shape * 1.5 + risk;
                if best.as_ref().map(|b| score < b.1).unwrap_or(true) {
                    best = Some((JointFix { state, shape }, score));
                }
            }
        }
    }
    best.map(|b| b.0)
}

pub struct Reconciled {
    pub notes: Vec<PNote>,
    pub adjusted: usize,
    pub dropped: usize,
    pub doubles: usize,
    pub source_preserved: usize,
    pub missing_targets: usize,
    pub tempo_limited: usize,
}

fn reconcile(mut notes: Vec<PNote>, strict: f64) -> Reconciled {
    notes.sort_by(|a, b| a.time.partial_cmp(&b.time).unwrap().then(a.hand.cmp(&b.hand)));
    let mut result = vec![];
    let mut last: [Option<HState>; 2] = [None, None];
    let (mut adjusted, mut dropped, mut preserved, mut doubles) = (0, 0, 0, 0);
    let mut i = 0;
    while i < notes.len() {
        let t = notes[i].time;
        let mut batch = vec![];
        while i < notes.len() && (notes[i].time - t).abs() < 0.001 {
            batch.push(notes[i].clone());
            i += 1;
        }
        let mut staged: Vec<(PNote, HState)> = vec![];
        for n in batch {
            let h = n.hand as usize;
            let p = last[h];
            let other = staged.iter().find(|x| x.0.hand as usize != h).map(|x| x.1).or(last[1 - h]);
            let goal = CNote { x: n.x, y: n.y, d: n.d };
            let mut state = hand_step(p.as_ref(), goal, t, h as i32, strict);
            let risk = match (state, other) {
                (Some(s), Some(o)) => {
                    if h == 0 {
                        cross_risk(s.note(), o.note(), t - o.t)
                    } else {
                        cross_risk(o.note(), s.note(), t - o.t)
                    }
                }
                _ => 0.0,
            };
            if state.is_none() || risk >= 100.0 {
                match joint_repair(goal, p.as_ref(), t, h as i32, other.as_ref(), strict) {
                    None => {
                        dropped += 1;
                        continue;
                    }
                    Some(fix) => {
                        state = Some(fix.state);
                        if fix.shape > 0.01 {
                            adjusted += 1;
                        }
                    }
                }
            }
            let s = state.unwrap();
            let mut out = n;
            out.x = s.x;
            out.y = s.y;
            out.d = s.d;
            staged.push((out, s));
        }
        if staged.len() == 2 {
            doubles += 1;
        }
        for (n, s) in staged {
            last[n.hand as usize] = Some(s);
            if n.source && n.original.map(|o| o.x == n.x && o.y == n.y && o.d == n.d).unwrap_or(false) {
                preserved += 1;
            }
            result.push(n);
        }
    }
    Reconciled { notes: result, adjusted, dropped, doubles, source_preserved: preserved, missing_targets: 0, tempo_limited: 0 }
}

struct PairCand {
    state: HState,
    score: f64,
}

fn pair_candidates(goal: Option<&PNote>, prev: Option<&HState>, time: f64, hand: i32, strict: f64, limit: usize, prefer_all_rows: bool) -> Vec<PairCand> {
    let primary = goal.map(|g| CNote { x: g.x, y: g.y, d: g.d }).unwrap_or_else(|| motif_note("bounce", hand, 0));
    let origin = CNote { x: primary.x.clamp(0, 3), y: primary.y.clamp(0, 2), d: primary.d };
    let home = if hand == 0 { [0, 1, 2] } else { [3, 2, 1] };
    let xs = [origin.x, home[0], home[1], home[2]];
    let ys = [origin.y, 1, if origin.y == 0 { 2 } else { 0 }, if origin.y == 2 { 0 } else { 2 }];
    let parity = prev.map(|p| OPPOSITE[p.d as usize]).unwrap_or(if hand == 0 { 1 } else { 0 });
    let dirs = [origin.d, parity, if hand == 0 { 1 } else { 0 }, if hand == 0 { 0 } else { 1 }, 2, 3, 4, 5, 6, 7];
    let mut out: Vec<PairCand> = vec![];
    let mut seen: HashSet<(i32, i32, i32)> = HashSet::new();
    for &x in &xs {
        for &y in &ys {
            for &d in &dirs {
                if !(0..=8).contains(&d) {
                    continue;
                }
                if !seen.insert((x, y, d)) {
                    continue;
                }
                let Some(state) = hand_step(prev, CNote { x, y, d }, time, hand, strict) else { continue };
                let shape = 1.05 * (x - origin.x).abs() as f64
                    + 0.85 * (y - origin.y).abs() as f64
                    + if d == origin.d { 0.0 } else { 0.65 }
                    + 0.06 * (x as f64 - if hand == 0 { 0.6 } else { 2.4 }).abs();
                out.push(PairCand { state, score: shape * 1.65 + state.cost });
            }
        }
    }
    out.sort_by(|a, b| a.score.partial_cmp(&b.score).unwrap_or(std::cmp::Ordering::Equal));
    if !prefer_all_rows {
        out.truncate(limit);
        return out;
    }
    let key = |c: &PairCand| (c.state.x, c.state.y, c.state.d);
    let take = 4usize.max(limit.saturating_sub(4)).min(out.len());
    let mut selected_idx: Vec<usize> = (0..take).collect();
    let mut chosen: HashSet<(i32, i32, i32)> = selected_idx.iter().map(|&i| key(&out[i])).collect();
    for y in 0..3 {
        if let Some(ai) = out.iter().position(|c| c.state.y == y && !chosen.contains(&key(c)))
            && selected_idx.len() < limit
        {
            chosen.insert(key(&out[ai]));
            selected_idx.push(ai);
        }
    }
    for (i, c) in out.iter().enumerate() {
        if selected_idx.len() >= limit {
            break;
        }
        let k = key(c);
        if !chosen.contains(&k) {
            selected_idx.push(i);
            chosen.insert(k);
        }
    }
    selected_idx.into_iter().map(|i| PairCand { state: out[i].state, score: out[i].score }).collect()
}

fn reconcile_full_doubles(notes: &[PNote], events: &[Ev], strict: f64, lane_balance: f64) -> Reconciled {
    let mut desired: Vec<[Option<PNote>; 2]> = vec![[None, None]; events.len()];
    for n in notes {
        if n.event_index < events.len() && (0..=1).contains(&n.hand) {
            desired[n.event_index][n.hand as usize] = Some(n.clone());
        }
    }
    let mut last: [Option<HState>; 2] = [None, None];
    let mut out = vec![];
    let mut lane = LaneState::new();
    let (mut adjusted, mut missing, mut tempo_limited, mut preserved, mut full_pairs) = (0, 0, 0, 0, 0);
    for i in 0..events.len() {
        let t = events[i].t;
        let goals = &desired[i];
        if goals[0].is_none() || goals[1].is_none() {
            missing += 1;
        }
        let bias = lane.bias(lane_balance);
        let mut best: Option<(HState, HState, f64)> = None;
        for relaxation in [1.0, 0.83] {
            let left = pair_candidates(goals[0].as_ref(), last[0].as_ref(), t, 0, strict * relaxation, 12, lane_balance > 0.0);
            let right = pair_candidates(goals[1].as_ref(), last[1].as_ref(), t, 1, strict * relaxation, 12, lane_balance > 0.0);
            for l in &left {
                for r in &right {
                    let risk = cross_risk(l.state.note(), r.state.note(), 0.0);
                    if risk >= 100.0 {
                        continue;
                    }
                    if let Some(l1) = last[1]
                        && cross_risk(l.state.note(), l1.note(), t - l1.t) >= 100.0
                    {
                        continue;
                    }
                    if let Some(l0) = last[0]
                        && cross_risk(l0.note(), r.state.note(), l0.t - t) >= 100.0
                    {
                        continue;
                    }
                    let mirrored = l.state.y == r.state.y && l.state.d == MIRROR[r.state.d as usize];
                    let same_row = l.state.y == r.state.y;
                    let score = l.score
                        + r.score
                        + risk
                        + if mirrored { 0.24 } else { 0.0 }
                        + if relaxation < 1.0 { 1.3 } else { 0.0 }
                        + bias[l.state.y as usize]
                        + bias[r.state.y as usize]
                        + if same_row { bias[l.state.y as usize].max(0.0) * 0.35 } else { 0.0 };
                    if best.as_ref().map(|b| score < b.2).unwrap_or(true) {
                        best = Some((l.state, r.state, score));
                    }
                }
            }
            if best.is_some() {
                if relaxation < 1.0 {
                    tempo_limited += 1;
                }
                break;
            }
        }
        let emergency = best.is_none();
        let pair = match best {
            Some(b) => [b.0, b.1],
            None => {
                tempo_limited += 1;
                let mk = |p: Option<HState>, hand: i32| HState {
                    x: if hand == 0 { 0 } else { 3 },
                    y: p.map(|p| p.y).unwrap_or(if hand == 0 { 0 } else { 2 }),
                    d: p.map(|p| OPPOSITE[p.d as usize]).unwrap_or(if hand == 0 { 0 } else { 1 }),
                    t,
                    strain: 0.0,
                    cost: 0.0,
                };
                [mk(last[0], 0), mk(last[1], 1)]
            }
        };
        for h in 0..2 {
            let prior = goals[h].as_ref();
            let s = pair[h];
            let changed = prior.map(|p| s.x != p.x || s.y != p.y || s.d != p.d).unwrap_or(false);
            if changed {
                adjusted += 1;
            }
            if prior.map(|p| p.source).unwrap_or(false) && !changed {
                preserved += 1;
            }
            let kind = if emergency {
                Kind::TempoFallback
            } else if changed {
                Kind::JointRepair
            } else {
                prior.and_then(|p| p.kind).unwrap_or(Kind::Motif)
            };
            out.push(PNote {
                event_index: i,
                time: t,
                hand: h as i32,
                x: s.x,
                y: s.y,
                d: s.d,
                source: prior.map(|p| p.source).unwrap_or(false) && !changed,
                original: prior.and_then(|p| p.original),
                kind: Some(kind),
                macro_group: prior.and_then(|p| p.macro_group),
                motif: prior.and_then(|p| p.motif),
            });
            last[h] = Some(s);
            lane.remember(s.y);
        }
        full_pairs += 1;
    }
    Reconciled { notes: out, adjusted, dropped: 0, doubles: full_pairs, source_preserved: preserved, missing_targets: missing, tempo_limited }
}

fn audit(notes: &[PNote], strict: f64) -> usize {
    let mut fails = 0;
    let mut last: [Option<HState>; 2] = [None, None];
    let mut sorted: Vec<&PNote> = notes.iter().collect();
    sorted.sort_by(|a, b| a.time.partial_cmp(&b.time).unwrap().then(a.hand.cmp(&b.hand)));
    for n in sorted {
        let h = n.hand as usize;
        let Some(s) = hand_step(last[h].as_ref(), CNote { x: n.x, y: n.y, d: n.d }, n.time, n.hand, strict) else {
            fails += 1;
            continue;
        };
        if let Some(o) = last[1 - h] {
            let risk = if h == 0 { cross_risk(s.note(), o.note(), n.time - o.t) } else { cross_risk(o.note(), s.note(), n.time - o.t) };
            if risk >= 100.0 {
                fails += 1;
            }
        }
        last[h] = Some(s);
    }
    fails
}

/// Planner statistics (subset of JS `stats` that is serialized).
#[derive(Clone, Debug, Default)]
pub struct PlanStats {
    pub library_count: usize,
    pub macro_sections: usize,
    pub repeated_macro_sections: usize,
    pub motifs: Map<String, Value>,
    pub rhythms: Map<String, Value>,
    pub source_flows: usize,
    pub motif_flows: usize,
    pub matched_phrases: usize,
    pub metrical_grid: Option<Grid>,
    pub metrical_snap_count: usize,
    pub metrical_max_shift_ms: f64,
    pub bar_aligned_phrases: usize,
    pub hand_schedules: [usize; 2],
    pub joint_doubles: usize,
    pub repairs: usize,
    pub dropped: usize,
    pub flow_lengths: Map<String, Value>,
    pub source_geometry_preserved: usize,
    pub audit_violations: usize,
    pub full_double_notes: bool,
    pub tempo_limited: usize,
    pub missing_hand_targets: usize,
    pub adaptive_double_accents_removed: usize,
    pub adaptive_double_accents_added: usize,
    pub solo_balance: Option<SoloBalance>,
    pub density: DensityProfile,
    pub unique_corpus_patterns: usize,
    pub corpus_variety: f64,
    pub lane_balance: f64,
    pub lane_counts: [usize; 3],
    pub local_activity_double_notes_removed: usize,
    pub post_cap_solo_balance: Option<Value>,
}

pub struct CorpusPlan {
    pub notes: Vec<GNote>,
    pub counts: Vec<(u32, usize)>,
    pub stats: PlanStats,
}

fn bump(map: &mut Map<String, Value>, key: &str) {
    let v = map.get(key).and_then(|v| v.as_u64()).unwrap_or(0) + 1;
    map.insert(key.to_string(), Value::from(v));
}

/// scfPlanChoreographyV2
pub fn plan_choreography(a: &PitchAnalysis, grid_v: Option<&Grid>, segments: &[Arc<Segment>], seed: &str, config: &DifficultyConfig, nps_cap: i64) -> anyhow::Result<Option<CorpusPlan>> {
    let lib = &*LIBRARY;
    if lib.count != corpus::EXPECTED_COUNT {
        anyhow::bail!("Incomplete flow corpus: {}", lib.count);
    }
    let mut ev = sc2_events(a, segments);
    if ev.is_empty() {
        return Ok(None);
    }
    let g = grid_v;
    let mut macros = macro_segments(&ev, g);
    let threshold = clamp(adv::number("flow.macroSimilarity", 0.83), 0.65, 0.98);
    let repeated = group_macros(&mut macros, &ev, threshold, seed);
    let strict = clamp(adv::number("flow.wristConservatism", 1.0), 0.75, 1.3);
    let motif_strength = clamp(adv::number("flow.motifStrength", 0.9), 0.0, 1.6);
    let variety = clamp(adv::number("flow.corpusVariety", 0.85), 0.0, 1.0);
    let lane_balance = clamp(adv::number("flow.laneBalance", 1.3), 0.0, 1.5);
    let accent_rate = clamp(adv::number("flow.doubleAccentRate", 0.16), 0.04, 0.42);
    let full_doubles = adv::boolean("flow.fullDoubleNotes", false);
    let mut stats = PlanStats {
        library_count: lib.count,
        macro_sections: macros.len(),
        repeated_macro_sections: repeated,
        metrical_grid: g.cloned(),
        bar_aligned_phrases: macros.iter().filter(|m| m.bar_aligned).count(),
        full_double_notes: full_doubles,
        ..Default::default()
    };
    let mut plans: Vec<Plan> = macros
        .iter()
        .enumerate()
        .map(|(mi, m)| {
            let hs = hash_string(&format!("{seed}|{}", m.group));
            Plan { macro_idx: mi, seed: hs, schedule: assign_schedule(m, &ev, config, hs, accent_rate) }
        })
        .collect();
    if !full_doubles {
        let acc = super::nps::cap_double_accents(&mut plans, &macros, &ev, nps_cap as f64, accent_rate);
        stats.adaptive_double_accents_removed = acc.removed;
        stats.adaptive_double_accents_added = acc.added;
    }
    stats.solo_balance = if full_doubles { None } else { Some(balance_solo_phrases(&mut plans, &macros, &ev)) };
    stats.density = scheduled_density_profile(&mut ev, &plans, g);
    let mut selected: Vec<PNote> = vec![];
    let mut used: Vec<(u32, usize)> = vec![]; // insertion-ordered Map
    let mut sh = PlannerShared { cache: HashMap::new(), usage: HashMap::new(), owners: HashSet::new(), family_usage: HashMap::new(), family_owners: HashSet::new() };
    let mut last: [Option<HState>; 2] = [None, None];
    let mut lanes = [LaneState::new(), LaneState::new()];
    for p in &plans {
        let mi = p.macro_idx;
        macros[mi].hand_motifs = hand_motif_styles(&macros[mi], seed);
        let m = &macros[mi];
        bump(&mut stats.motifs, m.motif);
        bump(&mut stats.rhythms, m.rhythm);
        for h in 0..2 {
            stats.hand_schedules[h] += p.schedule[h].len();
            let planned = plan_hand_in_macro(m, &ev, h as i32, &p.schedule[h], last[h], seed, strict, &mut sh, motif_strength, variety, &mut lanes[h], lane_balance, config, g);
            last[h] = planned.state;
            stats.repairs += planned.repairs;
            stats.source_flows += planned.corpus;
            stats.motif_flows += planned.motif;
            stats.matched_phrases += planned.selected.iter().filter(|s| s.reused).count();
            for mut n in planned.notes {
                n.macro_group = Some(m.group);
                n.motif = Some(m.motif);
                selected.push(n);
            }
            for item in &planned.selected {
                bump(&mut stats.flow_lengths, &item.len.to_string());
                if let Some(e) = item.entry {
                    match used.iter_mut().find(|u| u.0 == e.off) {
                        Some(u) => u.1 += 1,
                        None => used.push((e.off, 1)),
                    }
                }
            }
        }
    }
    let selected_len = selected.len();
    let rec = if full_doubles { reconcile_full_doubles(&selected, &ev, strict, lane_balance) } else { reconcile(selected, strict) };
    stats.joint_doubles = rec.doubles;
    stats.tempo_limited = rec.tempo_limited;
    stats.missing_hand_targets = rec.missing_targets;
    stats.repairs += rec.adjusted;
    stats.dropped = if full_doubles { 0 } else { rec.dropped + (stats.hand_schedules[0] + stats.hand_schedules[1]).saturating_sub(selected_len) };
    stats.source_geometry_preserved = rec.source_preserved;
    stats.unique_corpus_patterns = used.len();
    stats.corpus_variety = variety;
    stats.lane_balance = lane_balance;
    for n in &rec.notes {
        stats.lane_counts[n.y as usize] += 1;
    }
    stats.audit_violations = audit(&rec.notes, strict);
    if stats.audit_violations > 0 && (!full_doubles || stats.tempo_limited == 0) {
        anyhow::bail!("Independent-hand flow audit failed: {}", stats.audit_violations);
    }
    let notes: Vec<GNote> = rec
        .notes
        .iter()
        .map(|n| GNote {
            event_index: n.event_index as i64,
            time: to_fixed_num(n.time, 4),
            line_index: n.x,
            line_layer: n.y,
            type_: n.hand,
            cut_direction: n.d,
            flow_difficulty: config.id.clone(),
            segment: segments.get(n.event_index).cloned(),
            flow_source: n.kind.map(|k| k.as_str()),
            flow_phrase: n.macro_group,
            flow_motif: n.motif,
            flow_speed_pressure: ev.get(n.event_index).map(|e| e.flow_speed_pressure).unwrap_or(0.0),
            ..Default::default()
        })
        .collect();
    if notes.is_empty() {
        return Ok(None);
    }
    if full_doubles && notes.len() != ev.len() * 2 {
        anyhow::bail!("Double note count invariant failed {} != {}", notes.len(), ev.len() * 2);
    }
    Ok(Some(CorpusPlan { notes, counts: used, stats }))
}

pub use HState as HandState;
#[allow(unused)]
fn _unused(_: &Value) {}
