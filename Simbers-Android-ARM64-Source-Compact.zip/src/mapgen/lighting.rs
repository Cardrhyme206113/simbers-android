//! Vanilla DefaultEnvironment lighting (lighting.js).

use super::beatmaps::LightEvent;
use super::select::segment_event_strength;
use crate::analysis::patterns::Segment;
use crate::settings as adv;
use crate::util::{clamp, hash_string, js_round, to_fixed, to_fixed_num};
use std::collections::HashMap;
use std::sync::Arc;

fn light_value(red: bool, style: &str) -> i32 {
    let base = if red { 5 } else { 1 };
    base + match style {
        "static" => 0,
        "flash" => 1,
        "fade" => 2,
        _ => 3,
    }
}

fn z(v: f64) -> f64 {
    if v.is_nan() { 0.0 } else { v }
}

fn is_red(seg: &Segment, _index: usize, section: i64) -> bool {
    let melody_bucket = js_round(clamp(z(seg.melody_value), 0.0, 1.0) * 8.0) as i64;
    let cluster_bucket = seg.cluster as i64;
    (melody_bucket + cluster_bucket + section).abs() % 2 == 1
}

struct Lights {
    duration: f64,
    order: Vec<String>,
    map: HashMap<String, LightEvent>,
    last: HashMap<i32, f64>,
    min_gap: f64,
}

impl Lights {
    fn push(&mut self, time: f64, ty: i32, value: i32, brightness: f64, force: bool) {
        let time = to_fixed_num(clamp(time, 0.0, self.duration), 4);
        if !force
            && let Some(prev) = self.last.get(&ty)
            && time - prev < self.min_gap
        {
            return;
        }
        let ev = LightEvent { time, type_: ty, value, float_value: Some(to_fixed_num(clamp(brightness, 0.0, 1.25), 3)) };
        let key = format!("{}|{ty}", to_fixed(time, 4));
        if !self.map.contains_key(&key) {
            self.order.push(key.clone());
        }
        self.map.insert(key, ev);
        self.last.insert(ty, time);
    }
}

pub fn build(segments: &[Arc<Segment>], duration_in: f64, seed: &str) -> Vec<LightEvent> {
    let duration = 0.1f64.max(if duration_in.is_nan() { 0.0 } else { duration_in });
    let n = |k: &str, d: f64| adv::number(k, d);
    let mut l = Lights { duration, order: vec![], map: HashMap::new(), last: HashMap::new(), min_gap: n("lighting.minimumEventGap", 0.085) };
    for ty in 0..5 {
        l.push(0.0, ty, 0, 0.0, true);
    }
    if segments.is_empty() {
        return l.order.iter().map(|k| l.map[k].clone()).collect();
    }
    let mut last_section: i64 = -1;
    let mut prev_time = segments[0].start;
    let mut strongest_recent = -999.0;
    let mut last_spin = -999.0;
    let mut last_zoom = -999.0;
    let mut last_white = -999.0;
    let spin_cd = n("lighting.ringSpinCooldownSec", 0.42);
    let zoom_cd = n("lighting.ringZoomCooldownSec", 2.2);
    for (i, seg) in segments.iter().enumerate() {
        let time = clamp(z(seg.start), 0.0, duration);
        let next_time = if i + 1 < segments.len() { segments[i + 1].start } else { duration };
        let section = (time / 0.001f64.max(n("lighting.sectionSeconds", 8.0))).floor() as i64;
        let strength = clamp(segment_event_strength(seg), 0.0, 1.0);
        let state = clamp(z(seg.state_change), 0.0, 1.0);
        let beat = clamp(z(seg.beat_strength), 0.0, 1.0);
        let activity = clamp(z(seg.activity), 0.0, 1.0);
        let red = is_red(seg, i, section);
        if section != last_section || state > n("lighting.stateTransitionThreshold", 0.78) {
            let groups = [0, 1, 4];
            for (g, &ty) in groups.iter().enumerate() {
                l.push(
                    time + g as f64 * n("lighting.groupOffsetSec", 0.012),
                    ty,
                    light_value(if g % 2 == 1 { !red } else { red }, "transition"),
                    n("lighting.transitionBrightnessBase", 0.5) + n("lighting.transitionBrightnessStrength", 0.12) * strength,
                    false,
                );
            }
            if time - last_spin > spin_cd {
                l.push(time, 8, 0, 1.0, true);
                last_spin = time;
            }
            if time - last_zoom > zoom_cd {
                l.push(time, 9, 0, 1.0, true);
                last_zoom = time;
            }
            last_section = section;
        }
        let sig = hash_string(&format!("{seed}|{section}|{}|{}", seg.cluster, crate::util::js_num_to_string(js_round(z(seg.melody_value) * 12.0))));
        let main_type = [0, 1, 2, 3, 4][(sig % 5) as usize];
        let mut style = "transition";
        if strength > n("lighting.flashStrengthThreshold", 0.78) && time - strongest_recent > n("lighting.flashCooldownSec", 0.18) {
            style = "flash";
            strongest_recent = time;
        } else if strength > n("lighting.fadeStrengthThreshold", 0.52) || state > n("lighting.fadeStateThreshold", 0.48) || beat > n("lighting.fadeBeatThreshold", 0.58) {
            style = "fade";
        } else if activity > n("lighting.staticActivityThreshold", 0.42) {
            style = "static";
        }
        let brightness = clamp(
            n("lighting.brightnessBase", 0.5) + n("lighting.brightnessStrength", 0.52) * strength + n("lighting.brightnessActivity", 0.14) * activity,
            n("lighting.brightnessMinimum", 0.46),
            n("lighting.brightnessMaximum", 1.18),
        );
        l.push(time, main_type, light_value(red, style), brightness, false);
        let ring = 0.52 * strength + 0.3 * beat + 0.18 * state;
        if ring > n("lighting.ringSpinScoreThreshold", 0.63) && time - last_spin > spin_cd {
            l.push(time, 8, 0, 1.0, true);
            l.push(time, 1, light_value(red, if strength > 0.8 { "flash" } else { "fade" }), 1.22f64.min(brightness + 0.05), true);
            last_spin = time;
        }
        if strength > 0.92 && time - last_white > 0.7 {
            l.push(time + 0.006, 1, 10, 1.24f64.min(brightness + 0.1), true);
            l.push(time + 0.012, 4, 10, 1.24f64.min(brightness + 0.08), true);
            last_white = time;
        }
        if state > n("lighting.ringZoomStateThreshold", 0.88) && time - last_zoom > zoom_cd {
            l.push(time, 9, 0, 1.0, true);
            last_zoom = time;
        }
        if strength > n("lighting.sideStrengthThreshold", 0.42) || beat > n("lighting.sideBeatThreshold", 0.5) {
            let side_type = if (js_round(z(seg.melody_value) * 10.0) as i64 + section) % 2 != 0 { 2 } else { 3 };
            l.push(
                time + 0.012,
                side_type,
                light_value(!red, if strength > n("lighting.sideFlashThreshold", 0.68) { "flash" } else { "fade" }),
                brightness * n("lighting.sideBrightnessScale", 0.88),
                false,
            );
        }
        if strength > n("lighting.strongStrengthThreshold", 0.72) || state > n("lighting.strongStateThreshold", 0.78) {
            l.push(time + 0.024, 4, light_value(red, if strength > n("lighting.strongFlashThreshold", 0.84) { "flash" } else { "fade" }), 1.24f64.min(brightness + n("lighting.strongBrightnessAdd", 0.1)), false);
            l.push(time + 0.036, 0, light_value(!red, "fade"), brightness, false);
        }
        let gap = time - prev_time;
        if gap < n("lighting.rapidGapSec", 0.3) && strength > n("lighting.rapidStrengthThreshold", 0.48) {
            let rapid = if i % 2 == 1 { 2 } else { 3 };
            l.push(
                time + n("lighting.rapidOffsetSec", 0.058),
                rapid,
                light_value(if i % 2 == 1 { red } else { !red }, "fade"),
                n("lighting.rapidBrightnessBase", 0.66) + n("lighting.rapidBrightnessStrength", 0.26) * strength,
                false,
            );
        }
        if next_time - time > n("lighting.quietGapSec", 1.15) && activity < n("lighting.quietActivityThreshold", 0.48) {
            let qt = duration.min(time + n("lighting.quietOffsetMaximum", 0.72).min((next_time - time) * n("lighting.quietOffsetRatio", 0.48)));
            l.push(qt, main_type, 0, 0.0, false);
            l.push(qt + 0.02, if i % 2 == 1 { 2 } else { 3 }, 0, 0.0, false);
        }
        prev_time = time;
    }
    let end = 0f64.max(duration - n("lighting.endPaddingSec", 0.025));
    for ty in 0..5 {
        l.push(end, ty, 0, 0.0, true);
    }
    let mut out: Vec<LightEvent> = l.order.iter().map(|k| l.map[k].clone()).collect();
    out.sort_by(|a, b| a.time.partial_cmp(&b.time).unwrap().then(a.type_.cmp(&b.type_)));
    out
}
