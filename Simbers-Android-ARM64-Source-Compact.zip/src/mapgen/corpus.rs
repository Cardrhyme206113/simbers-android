//! Human flow corpus (corpus.js). The 121,106-phrase pack is embedded.

use crate::analysis::patterns::Segment;
use crate::analysis::spectral::PitchAnalysis;
use crate::util::{jsm, median};
use std::collections::HashMap;
use std::sync::LazyLock;

pub const CORPUS_BIN: &[u8] = include_bytes!("../../assets/flow_corpus.bin");
pub const EXPECTED_COUNT: usize = 121106;

pub const MIRROR: [i32; 9] = [0, 1, 3, 2, 5, 4, 7, 6, 8];
pub const ANGLES: [f64; 9] = [0.0, 180.0, 270.0, 90.0, 315.0, 45.0, 225.0, 135.0, 180.0];
pub const DIRS: [(f64, f64); 9] = [
    (0.0, 1.0),
    (0.0, -1.0),
    (-1.0, 0.0),
    (1.0, 0.0),
    (-0.7071, 0.7071),
    (0.7071, 0.7071),
    (-0.7071, -0.7071),
    (0.7071, -0.7071),
    (0.0, -1.0),
];
pub const OPPOSITE: [i32; 9] = [1, 0, 3, 2, 7, 6, 5, 4, 1];

#[inline]
pub fn angular_error(a: f64, b: f64) -> f64 {
    (((a - b + 540.0) % 360.0) - 180.0).abs()
}

#[derive(Clone, Copy, Debug)]
pub struct CNote {
    pub x: i32,
    pub y: i32,
    pub d: i32,
}

#[inline]
pub fn note_byte(b: u8) -> CNote {
    CNote { x: (b & 3) as i32, y: ((b >> 2) & 3) as i32, d: (b >> 4) as i32 }
}

#[derive(Clone, Debug)]
pub struct Entry {
    pub off: u32,
    pub len: usize,
    pub pop: u8,
    pub wild: f64,
    pub support: f64,
    pub travel: f64,
    pub rank: f64,
    pub family: u32,
    pub genericity: f64,
    pub smooth_phrase: bool,
    pub ease_cost: f64,
    pub diagonal_fraction: f64,
    pub side_travel_per_step: f64,
    pub family_frequency: usize,
}

pub struct Library {
    pub raw: &'static [u8],
    pub by_length: Vec<Vec<Entry>>,
    pub fast_by_length: Vec<Vec<Entry>>,
    pub count: usize,
    pub family_count: usize,
}

fn sign(v: i32) -> i32 {
    v.signum()
}

fn gesture_family(notes: &[CNote], turns: f64) -> u32 {
    let mut contour: i64 = 0;
    for i in 1..=4 {
        let (dx, dy) = match notes.get(i) {
            Some(b) => {
                let a = notes[i - 1];
                (sign(b.x - a.x) + 1, sign(b.y - a.y) + 1)
            }
            None => (1, 1),
        };
        contour = contour * 9 + (dx * 3 + dy) as i64;
    }
    let v = ((notes.len() as i64 / 2) * 6561 + contour) * 6 + (5f64.min((turns / 2.0).floor()) as i64);
    v as u32
}

fn gesture_genericity(notes: &[CNote]) -> f64 {
    let len = notes.len();
    if len < 3 {
        return 0.0;
    }
    let mut two_step = 0usize;
    let mut repeated = 0usize;
    let mut positions = 0u16;
    let mut directions = 0u16;
    for i in 0..len {
        let n = notes[i];
        positions |= 1 << (n.y * 4 + n.x);
        directions |= 1 << n.d;
        if i > 0 && n.x == notes[i - 1].x && n.y == notes[i - 1].y {
            repeated += 1;
        }
        if i > 1 && n.x == notes[i - 2].x && n.y == notes[i - 2].y && n.d == notes[i - 2].d {
            two_step += 1;
        }
    }
    let oscillation = two_step as f64 / (len - 2).max(1) as f64;
    3.5f64.min(
        2.1 * oscillation
            + if len >= 5 && positions.count_ones() <= 2 { 0.75 } else { 0.0 }
            + if len >= 6 && directions.count_ones() <= 2 { 0.4 } else { 0.0 }
            + (0.65 * repeated as f64) / (len - 1) as f64,
    )
}

pub static LIBRARY: LazyLock<Library> = LazyLock::new(load_library);

fn load_library() -> Library {
    let raw = CORPUS_BIN;
    let mut by_length: Vec<Vec<Entry>> = (0..11).map(|_| Vec::new()).collect();
    let mut count = 0;
    let mut family_counts: HashMap<u32, usize> = HashMap::new();
    let mut p = 0usize;
    let mut notes = [CNote { x: 0, y: 0, d: 0 }; 10];
    while p < raw.len() {
        assert!(p + 3 <= raw.len(), "Truncated flow corpus record");
        let off = p;
        let len = raw[p] as usize;
        let pop = raw[p + 1];
        let wild_byte = raw[p + 2];
        p += 3;
        assert!((3..=10).contains(&len) && p + len <= raw.len(), "Invalid flow corpus record");
        let (mut turns, mut row_travel, mut side_travel, mut center) = (0.0f64, 0i32, 0i32, 0i32);
        let (mut diagonal, mut large_side) = (0i32, 0i32);
        for j in 0..len {
            let n = note_byte(raw[p + j]);
            notes[j] = n;
            assert!(n.x <= 3 && n.y <= 2 && n.d <= 8, "Invalid flow note geometry");
            center += if n.x == 1 || n.x == 2 { 1 } else { 0 };
            diagonal += if (4..=7).contains(&n.d) { 1 } else { 0 };
            if j > 0 {
                let pr = notes[j - 1];
                row_travel += (n.y - pr.y).abs();
                side_travel += (n.x - pr.x).abs();
                large_side += 0.max((n.x - pr.x).abs() - 1);
                if n.d != 8 && pr.d != 8 {
                    turns += ((((ANGLES[n.d as usize] - ANGLES[pr.d as usize] + 540.0) % 360.0) - 180.0).abs()) / 180.0;
                }
            }
        }
        let ns = &notes[..len];
        let support = pop as f64 / 255.0;
        let smooth = ns.iter().enumerate().all(|(i, n)| {
            n.d < 8 && n.d != 2 && n.d != 3 && (i == 0 || angular_error(ANGLES[n.d as usize], ANGLES[ns[i - 1].d as usize]) >= 135.0)
        });
        let wild = wild_byte as f64 / 255.0;
        let travel = (row_travel + side_travel) as f64 / (len - 1).max(1) as f64;
        let rank = 18.0 * support - 1.6 * turns - 0.4 * center as f64 + 3.0 * travel;
        let family = gesture_family(ns, turns);
        let genericity = gesture_genericity(ns);
        *family_counts.entry(family).or_insert(0) += 1;
        let ease_cost = (2.2 * diagonal as f64 + 1.3 * side_travel as f64 + 2.9 * large_side as f64) / len as f64;
        by_length[len].push(Entry {
            off: off as u32,
            len,
            pop,
            wild,
            support,
            travel,
            rank,
            family,
            genericity,
            smooth_phrase: smooth,
            ease_cost,
            diagonal_fraction: diagonal as f64 / len as f64,
            side_travel_per_step: side_travel as f64 / (len - 1).max(1) as f64,
            family_frequency: 1,
        });
        count += 1;
        p += len;
    }
    let mut fast: Vec<Vec<Entry>> = (0..11).map(|_| Vec::new()).collect();
    for n in 3..=10 {
        for e in by_length[n].iter_mut() {
            e.family_frequency = *family_counts.get(&e.family).unwrap_or(&1);
        }
        by_length[n].sort_by(|a, b| b.rank.partial_cmp(&a.rank).unwrap().then(a.off.cmp(&b.off)));
        let mut f: Vec<Entry> = by_length[n]
            .iter()
            .filter(|e| e.smooth_phrase && e.diagonal_fraction <= 0.46 && e.side_travel_per_step <= 0.82)
            .cloned()
            .collect();
        f.sort_by(|a, b| {
            a.ease_cost.partial_cmp(&b.ease_cost).unwrap().then(b.support.partial_cmp(&a.support).unwrap()).then(a.off.cmp(&b.off))
        });
        fast[n] = f;
    }
    Library { raw, by_length, fast_by_length: fast, count, family_count: family_counts.len() }
}

pub fn read_source(entry: &Entry, hand: i32) -> Vec<(CNote, bool)> {
    let raw = LIBRARY.raw;
    (0..entry.len)
        .map(|i| {
            let n = note_byte(raw[entry.off as usize + 3 + i]);
            (CNote { x: if hand == 1 { 3 - n.x } else { n.x }, y: n.y, d: if hand == 1 { MIRROR[n.d as usize] } else { n.d } }, true)
        })
        .collect()
}

pub fn scf_cos(a: &[f64], b: &[f64]) -> f64 {
    if a.is_empty() || b.is_empty() {
        return 0.0;
    }
    let (mut s, mut aa, mut bb) = (0.0, 0.0, 0.0);
    for i in 0..a.len().min(b.len()) {
        s += a[i] * b[i];
        aa += a[i] * a[i];
        bb += b[i] * b[i];
    }
    if aa * bb > 1e-10 { 0f64.max(1f64.min(s / (aa * bb).sqrt())) } else { 0.0 }
}

pub fn audio_signature(a: &PitchAnalysis, seg: &Segment) -> Option<Vec<f64>> {
    let bands = a.state_bands.as_ref()?;
    if bands.is_empty() {
        return None;
    }
    let hop = if a.shared_hop == 0 { 256 } else { a.shared_hop } as f64;
    let rate = if a.sample_rate == 0.0 { 22050.0 } else { a.sample_rate };
    let time = seg.start;
    let start = crate::util::js_round(((time + 0.018) * rate) / hop).max(0.0);
    let end = (bands[0].len() as f64).min(crate::util::js_round(((time + 0.12) * rate) / hop));
    let mut out: Vec<f64> = bands
        .iter()
        .map(|arr| {
            let (mut sum, mut n) = (0.0f64, 0usize);
            let mut j = start;
            while j < (start + 1.0).max(end) && (j as usize) < arr.len() {
                sum += (arr[j as usize] as f64).max(0.0);
                n += 1;
                j += 1.0;
            }
            jsm::log1p((sum / n.max(1) as f64) * 10.0)
        })
        .collect();
    let sum = out.iter().fold(0.0, |a, b| a + b * b);
    if sum > 1e-9 {
        let r = sum.sqrt();
        for v in out.iter_mut() {
            *v /= r;
        }
    }
    Some(out)
}

pub fn boundaries(ts: &[f64], sounds: &[Vec<f64>], states: &[f64]) -> Vec<f32> {
    let n = ts.len();
    let mut score = vec![0f32; n + 1];
    if n < 2 {
        return score;
    }
    let gaps: Vec<f64> = (1..n).map(|i| (ts[i] - ts[i - 1]).max(0.01)).collect();
    let mg = median(&gaps);
    let median_gap = if mg == 0.0 || mg.is_nan() { 0.35 } else { mg };
    score[0] = 0.7;
    score[n] = 0.7;
    for i in 1..n {
        let dt = gaps[i - 1];
        let timbre = 1.0 - scf_cos(&sounds[i - 1], &sounds[i]);
        let strength_jump = (states[i] - states[i - 1]).abs();
        let spacing = 0f64.max(1.6f64.min(dt / median_gap - 1.0));
        let v0 = 0f64.max(2.2f64.min(1.3 * timbre + 0.8 * spacing + 0.26 * strength_jump)) as f32;
        score[i] = if dt > 1.45f64.max(median_gap * 2.35) { (v0 as f64 + 1.5) as f32 } else { v0 };
    }
    score
}
