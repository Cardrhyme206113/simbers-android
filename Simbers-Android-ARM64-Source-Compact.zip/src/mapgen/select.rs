//! Intensity-driven event selection (intensity.js, note-patterns.js).

use super::DifficultyConfig;
use super::grid::Grid;
use crate::analysis::patterns::{ActivityTrack, Segment};
use crate::settings as adv;
use crate::util::{js_round, jsm, to_fixed_num};
use std::sync::Arc;

pub fn nps_cap_for_intensity(percent: f64) -> i64 {
    let p = if percent.is_finite() { percent.clamp(10.0, 200.0) } else { 100.0 };
    let v = if p <= 100.0 { 1.0 + (p - 10.0) / 30.0 } else { 4.0 + (p - 100.0) / 20.0 };
    (js_round(v) as i64).clamp(1, 9)
}

pub fn intensity_display_text(percent: f64) -> String {
    format!("{}% · ≤{} NPS", crate::util::js_num_to_string(percent), nps_cap_for_intensity(percent))
}

fn z(v: f64) -> f64 {
    if v.is_nan() { 0.0 } else { v }
}

pub fn segment_event_strength(s: &Segment) -> f64 {
    adv::number("flow.segmentStateWeight", 0.56) * z(s.state_change)
        + adv::number("flow.segmentBeatWeight", 0.29) * z(s.beat_strength)
        + adv::number("flow.segmentActivityWeight", 0.15) * z(s.activity)
}

pub fn filter_by_minimum_gap(segments: &[Arc<Segment>], minimum_gap_ms: f64, duration: f64) -> Vec<Arc<Segment>> {
    let gap = minimum_gap_ms / 1000.0;
    let (w1, w2, w3) = (
        adv::number("flow.segmentStateWeight", 0.56),
        adv::number("flow.segmentBeatWeight", 0.29),
        adv::number("flow.segmentActivityWeight", 0.15),
    );
    let strength = |s: &Segment| w1 * z(s.state_change) + w2 * z(s.beat_strength) + w3 * z(s.activity);
    let mut accepted: Vec<Arc<Segment>> = vec![];
    for s in segments {
        if s.start < 0.2 || s.start >= duration - 0.02 {
            continue;
        }
        match accepted.last() {
            None => accepted.push(s.clone()),
            Some(last) if s.start - last.start >= gap => accepted.push(s.clone()),
            Some(last) => {
                let cur = strength(s);
                let ls = strength(last);
                if cur > ls + 0.0001 || ((cur - ls).abs() <= 0.0001 && s.start < last.start) {
                    *accepted.last_mut().unwrap() = s.clone();
                }
            }
        }
    }
    accepted
}

pub fn quality(s: &Segment) -> f64 {
    let dc = if s.candidate_confidence.is_finite() { s.candidate_confidence } else { z(s.beat_strength) };
    0.46 * dc + 0.31 * z(s.state_change) + 0.15 * z(s.beat_strength) + 0.08 * z(s.activity)
}

fn time_exists(sel: &[Arc<Segment>], t: f64) -> bool {
    sel.iter().any(|s| (s.start - t).abs() <= 0.0025)
}

fn can_insert(sel: &[Arc<Segment>], c: &Segment, gap: f64) -> bool {
    sel.iter().all(|s| (s.start - c.start).abs() >= gap)
}

fn coverage_subset(cands: &[Arc<Segment>], target: usize, gap: f64) -> Vec<Arc<Segment>> {
    if target == 0 || cands.is_empty() {
        return vec![];
    }
    if target >= cands.len() {
        return cands.to_vec();
    }
    let mut selected = vec![cands[0].clone()];
    let last = &cands[cands.len() - 1];
    if target > 1 && (last.start - cands[0].start).abs() >= gap {
        selected.push(last.clone());
    }
    let mut ranked: Vec<Arc<Segment>> = cands[1..cands.len() - 1].to_vec();
    ranked.sort_by(|a, b| quality(b).partial_cmp(&quality(a)).unwrap().then(a.start.partial_cmp(&b.start).unwrap()));
    for c in &ranked {
        if selected.len() >= target {
            break;
        }
        if can_insert(&selected, c, gap) {
            selected.push(c.clone());
        }
    }
    for factor in [0.82, 0.64, 0.48, 0.32] {
        if selected.len() >= target {
            break;
        }
        let relaxed = 0.02f64.max(gap * factor);
        for c in &ranked {
            if selected.len() >= target {
                break;
            }
            if time_exists(&selected, c.start) || !can_insert(&selected, c, relaxed) {
                continue;
            }
            selected.push(c.clone());
        }
    }
    selected.sort_by(|a, b| a.start.partial_cmp(&b.start).unwrap());
    selected.truncate(target);
    selected
}

#[derive(Clone, Debug)]
pub struct Selection {
    pub segments: Vec<Arc<Segment>>,
    pub baseline_count: usize,
    pub target_count: usize,
    pub actual_percent: f64,
    pub target_relative_percent: f64,
    pub fulfillment_percent: f64,
    pub local_activity_removed: usize,
    pub local_activity_quiet_windows: usize,
}

pub fn local_rms(track: &ActivityTrack, center: f64, duration: f64) -> f64 {
    let step = track.step;
    let bins = track.bins as f64;
    let from = 0f64.max((bins - 1.0).min(((center - duration / 2.0) / step).floor()));
    let to = (from + 1.0).max(bins.min(((center + duration / 2.0) / step).ceil()));
    let (f, t) = (from as usize, to as usize);
    0f64.max((track.prefix[t] - track.prefix[f]) / 1f64.max(to - from)).sqrt()
}

pub fn activity_beat_period(grid: Option<&Grid>) -> (f64, f64) {
    if let Some(g) = grid
        && g.confidence >= 0.55
        && g.period >= 0.30
        && g.period <= 0.75
    {
        return (g.period, g.snap_origin);
    }
    (0.5, 0.0)
}

pub fn musical_activity_factor(track: &ActivityTrack, time: f64, period: f64, origin: f64) -> f64 {
    let short = 4.0 * period;
    let long = 8.0 * period;
    let center = origin + (((time - origin) / short).floor() + 0.5) * short;
    let s = local_rms(track, center, short);
    let l = local_rms(track, center, long);
    let ratio = (0.72 * s + 0.28 * l) / track.reference.max(1e-8);
    0.16f64.max(1f64.min(jsm::pow(ratio / 0.57, 0.94)))
}

fn apply_local_activity_gate(track: Option<&ActivityTrack>, grid: Option<&Grid>, mut sel: Selection) -> Selection {
    let Some(track) = track else { return sel };
    if sel.segments.is_empty() {
        return sel;
    }
    let (period, origin) = activity_beat_period(grid);
    let span = period * 4.0;
    let mut groups: Vec<(i64, Vec<Arc<Segment>>)> = vec![];
    for s in &sel.segments {
        let key = ((s.start - origin) / span).floor() as i64;
        match groups.iter_mut().find(|g| g.0 == key) {
            Some(g) => g.1.push(s.clone()),
            None => groups.push((key, vec![s.clone()])),
        }
    }
    let mut kept: Vec<Arc<Segment>> = vec![];
    let (mut reduced, mut quiet) = (0usize, 0usize);
    for (key, items) in groups {
        let time = origin + (key as f64 + 0.5) * span;
        let activity = musical_activity_factor(track, time, period, origin);
        if activity > 0.94 || items.len() < 2 {
            kept.extend(items);
            continue;
        }
        quiet += 1;
        let robust = items
            .iter()
            .filter(|s| (z(s.candidate_confidence) >= 0.68 && z(s.state_change) >= 0.38) || (z(s.local_pulse_contrast) >= 1.65 && z(s.candidate_confidence) >= 0.10))
            .count();
        let extra = 0.2f64.min(0.2 * robust as f64 / items.len().max(1) as f64);
        let wanted = 1usize.max(items.len().min(js_round(items.len() as f64 * 1f64.min(activity + extra)) as usize));
        if wanted >= items.len() {
            kept.extend(items);
            continue;
        }
        let mut picked: Vec<Arc<Segment>> = vec![];
        let mut available = items.clone();
        while picked.len() < wanted && !available.is_empty() {
            let mut winner = 0;
            let mut ws = f64::NEG_INFINITY;
            for (j, c) in available.iter().enumerate() {
                let distance = if picked.is_empty() { span } else { picked.iter().map(|p| (p.start - c.start).abs()).fold(f64::INFINITY, f64::min) };
                let spaced = 1f64.min(distance / 0.11f64.max(span / 3f64.max(wanted as f64)));
                let q = quality(c);
                let accent = 1f64.min(0f64.max((z(c.local_pulse_contrast) - 1.0) / 1.6));
                let score = q * 0.75 + 0.15 * accent + 0.2 * spaced;
                if score > ws {
                    ws = score;
                    winner = j;
                }
            }
            picked.push(available.remove(winner));
        }
        reduced += items.len() - picked.len();
        kept.extend(picked);
    }
    kept.sort_by(|a, b| a.start.partial_cmp(&b.start).unwrap());
    sel.actual_percent = (100.0 * kept.len() as f64) / sel.baseline_count.max(1) as f64;
    sel.fulfillment_percent = (100.0 * kept.len() as f64) / sel.target_count.max(1) as f64;
    sel.local_activity_removed = reduced;
    sel.local_activity_quiet_windows = quiet;
    sel.segments = kept;
    sel
}

pub struct SelectCtx<'a> {
    pub duration: f64,
    pub segments: &'a [Arc<Segment>],
    pub intensity_pool: &'a [Arc<Segment>],
    pub track: Option<&'a ActivityTrack>,
    pub grid: Option<&'a Grid>,
}

pub fn expert_plus_reference(ctx: &SelectCtx) -> Vec<Arc<Segment>> {
    filter_by_minimum_gap(ctx.segments, 90.0, ctx.duration)
}

/// selectSegmentsForIntensity
pub fn select_for_intensity(ctx: &SelectCtx, config: &DifficultyConfig) -> Selection {
    let duration = ctx.duration;
    let reference: Vec<Arc<Segment>> = if config.expert_plus_reference_segments.is_empty() { expert_plus_reference(ctx) } else { config.expert_plus_reference_segments.clone() };
    let reference_count = 1usize.max(if config.expert_plus_reference_count > 0 { config.expert_plus_reference_count } else { reference.len() });
    let target_count = 1usize.max(if config.target_event_count > 0 {
        config.target_event_count
    } else {
        let ip = if config.intensity_percent == 0.0 { 100.0 } else { config.intensity_percent };
        js_round(reference_count as f64 * (ip / 100.0) * super::density_fraction(&config.id).unwrap_or(1.0)) as usize
    });
    let bg = if config.base_minimum_gap_ms == 0.0 { config.minimum_gap_ms } else { config.base_minimum_gap_ms };
    let baseline_gap = 0.02f64.max((if bg == 0.0 || bg.is_nan() { 20.0 } else { bg }) / 1000.0);
    let diff_ref = filter_by_minimum_gap(&reference, baseline_gap * 1000.0, duration);
    let mk = |segments: Vec<Arc<Segment>>, actual: f64, trel: f64, ful: f64| Selection {
        segments,
        baseline_count: reference_count,
        target_count,
        actual_percent: actual,
        target_relative_percent: trel,
        fulfillment_percent: ful,
        local_activity_removed: 0,
        local_activity_quiet_windows: 0,
    };
    if diff_ref.is_empty() {
        return apply_local_activity_gate(ctx.track, ctx.grid, mk(vec![], 0.0, (100.0 * target_count as f64) / reference_count as f64, 0.0));
    }
    if config.id == "expertPlus" && config.intensity_percent == 100.0 && target_count == reference.len() {
        return apply_local_activity_gate(ctx.track, ctx.grid, mk(reference.clone(), 100.0, 100.0, 100.0));
    }
    let mut selected: Vec<Arc<Segment>>;
    if target_count <= diff_ref.len() {
        selected = coverage_subset(&diff_ref, target_count, baseline_gap);
    } else {
        selected = diff_ref.clone();
        let source: &[Arc<Segment>] = if !ctx.intensity_pool.is_empty() { ctx.intensity_pool } else { &reference };
        let mut pool: Vec<Arc<Segment>> = source.iter().filter(|s| s.start >= 0.2 && s.start < duration - 0.02 && !time_exists(&selected, s.start)).cloned().collect();
        let prim = |s: &Segment| if s.default_accepted { 2 } else if s.passed_primary_threshold { 1 } else { 0 };
        pool.sort_by(|a, b| {
            prim(b).cmp(&prim(a)).then(quality(b).partial_cmp(&quality(a)).unwrap()).then(a.start.partial_cmp(&b.start).unwrap())
        });
        let density_vs = 1f64.max(target_count as f64 / reference_count as f64);
        let nominal = 0.02f64.max(baseline_gap / density_vs);
        for gap in [nominal, 0.02f64.max(nominal * 0.72), 0.02f64.max(nominal * 0.5), 0.02] {
            for c in &pool {
                if selected.len() >= target_count {
                    break;
                }
                if time_exists(&selected, c.start) || !can_insert(&selected, c, gap) {
                    continue;
                }
                selected.push(c.clone());
            }
            if selected.len() >= target_count {
                break;
            }
        }
        selected.sort_by(|a, b| a.start.partial_cmp(&b.start).unwrap());
    }
    let actual = (100.0 * selected.len() as f64) / reference_count as f64;
    let tp = (100.0 * target_count as f64) / reference_count as f64;
    let ful = (100.0 * selected.len() as f64) / target_count as f64;
    apply_local_activity_gate(ctx.track, ctx.grid, mk(selected, actual, tp, ful))
}

/// intensityAdjustedConfig
pub fn intensity_adjusted(base: &DifficultyConfig, percent: f64, reference: &[Arc<Segment>]) -> DifficultyConfig {
    let p = percent / 100.0;
    let scale = 0.1f64.max(2f64.min(if p == 0.0 || p.is_nan() { 1.0 } else { p }));
    let frac = super::density_fraction(&base.id).unwrap_or(1.0);
    let target_rel = scale * frac;
    let target_event_count = 1usize.max(js_round(reference.len() as f64 * target_rel) as usize);
    let feature_scale = jsm::pow(scale, 0.18);
    let arc_scale = jsm::pow(scale, 0.1);
    let mut c = base.clone();
    c.intensity_percent = js_round(scale * 100.0);
    c.expert_plus_intensity_percent = js_round(scale * 100.0);
    c.difficulty_density_percent = js_round(frac * 100.0);
    c.target_relative_percent = to_fixed_num(target_rel * 100.0, 1);
    c.expert_plus_reference_count = reference.len();
    c.expert_plus_reference_segments = reference.to_vec();
    c.target_event_count = target_event_count;
    c.base_minimum_gap_ms = base.minimum_gap_ms;
    c.minimum_gap_ms = if base.id == "expertPlus" { 90.0 } else { base.minimum_gap_ms };
    c.arc_every_events = if base.arc_every_events != 0.0 { 3f64.max(js_round(base.arc_every_events / arc_scale)) } else { 0.0 };
    c.bomb_every_events = if base.bomb_every_events != 0.0 { 3f64.max(js_round(base.bomb_every_events / feature_scale)) } else { 0.0 };
    c.wall_every_events = if base.wall_every_events != 0.0 { 4f64.max(js_round(base.wall_every_events / feature_scale)) } else { 0.0 };
    c
}
