//! Dual-hand swept-wrist / recovery guard (dual-hand-trajectory.js).

use super::FeatureOptions;
use super::GNote;
use super::beatmaps::Difficulty;
use super::choreo::{candidates, cross_risk};
use super::corpus::{self, ANGLES, CNote, DIRS, angular_error};
use super::swing::human_flow_audit;
use crate::util::{clamp, js_round, jsm, now_ms, to_fixed, to_fixed_num};
use serde_json::Value;
use std::collections::{HashMap, HashSet};

const SAMPLES: [f64; 5] = [-0.16, -0.08, 0.0, 0.08, 0.16];
const R: f64 = 0.39;

const HUMAN_DOUBLES: [[i32; 6]; 64] = [[1,0,1,2,2,0],[1,2,0,2,0,1],[1,2,0,2,2,0],[1,0,1,2,0,1],[0,1,6,1,0,6],[2,0,7,3,1,7],[1,0,1,3,1,5],[0,1,4,2,0,1],[0,1,4,3,0,1],[1,0,1,3,2,5],[0,0,1,3,1,5],[0,2,0,2,0,1],[0,2,0,1,0,6],[0,2,4,2,0,1],[2,0,7,3,2,0],[0,0,1,2,2,0],[2,0,7,3,1,1],[1,2,0,3,0,1],[1,0,7,2,2,0],[0,0,4,2,0,1],[0,1,1,1,0,6],[0,1,4,3,1,5],[1,2,5,2,0,6],[0,1,6,3,2,5],[1,0,7,2,2,4],[0,2,4,3,1,7],[1,2,0,2,0,6],[1,0,1,3,0,5],[0,1,1,3,1,5],[0,1,4,2,2,0],[1,0,1,3,2,0],[0,2,0,3,2,5],[0,2,4,3,2,5],[1,2,0,3,1,5],[1,0,1,3,1,0],[0,0,1,2,0,1],[1,0,1,3,0,1],[0,2,4,2,2,0],[1,2,0,3,2,5],[0,1,0,2,0,1],[0,1,4,3,1,1],[0,2,0,2,2,0],[0,0,1,0,1,1],[0,1,0,3,1,0],[0,1,1,3,1,1],[0,1,6,3,1,5],[1,0,1,1,1,1],[1,2,0,3,2,0],[2,1,0,2,2,0],[0,1,7,1,0,7],[0,1,4,3,1,7],[0,2,4,3,2,0],[0,1,1,3,2,5],[0,2,4,2,1,1],[0,2,0,2,1,1],[3,0,1,3,1,1],[0,1,1,3,1,0],[2,0,5,3,1,5],[1,2,0,3,1,0],[0,1,6,3,1,7],[1,0,1,3,1,1],[0,2,0,3,2,0],[1,2,5,2,1,5],[1,1,4,2,2,4]];

fn dir(d: i32) -> (f64, f64) {
    DIRS.get(d as usize).copied().unwrap_or(DIRS[0])
}

fn ang(a: i32, b: i32) -> f64 {
    angular_error(ANGLES[a.clamp(0, 8) as usize], ANGLES[b.clamp(0, 8) as usize])
}

struct Pose {
    x: f64,
    y: f64,
    active: bool,
}

fn trace_pose(notes: &[GNote], stream: &[usize], t: f64, cursor: &mut usize, hand: usize) -> Pose {
    let rest = Pose { x: if hand == 1 { 2.32 } else { 0.68 }, y: -0.55, active: false };
    if stream.is_empty() {
        return rest;
    }
    let tm = |k: usize| notes[stream[k]].time;
    while *cursor + 1 < stream.len() && tm(*cursor + 1) <= t {
        *cursor += 1;
    }
    while *cursor > 0 && tm(*cursor) > t {
        *cursor -= 1;
    }
    let i = *cursor;
    let before = (tm(i) <= t).then_some(i);
    let after = if i + 1 < stream.len() { Some(i + 1) } else if before.is_some() { None } else { Some(0) };
    let current = match (before, after) {
        (Some(b), Some(a)) => {
            if t - tm(b) < tm(a) - t { b } else { a }
        }
        (Some(b), None) => b,
        (None, Some(a)) => a,
        _ => return rest,
    };
    let cn = &notes[stream[current]];
    let dist = (t - cn.time).abs();
    let d = dir(cn.cut_direction);
    if dist <= 0.17 {
        let s = clamp((t - cn.time) / 0.17, -1.0, 1.0) * R;
        return Pose { x: cn.line_index as f64 + d.0 * s, y: cn.line_layer as f64 + d.1 * s, active: true };
    }
    if let (Some(b), Some(a)) = (before, after) {
        let (bn, an) = (&notes[stream[b]], &notes[stream[a]]);
        if t > bn.time && t < an.time {
            let available = an.time - bn.time - 0.34;
            let bd = dir(bn.cut_direction);
            let ad = dir(an.cut_direction);
            let (sx, sy) = (bn.line_index as f64 + bd.0 * R, bn.line_layer as f64 + bd.1 * R);
            let (ex, ey) = (an.line_index as f64 - ad.0 * R, an.line_layer as f64 - ad.1 * R);
            let u = if available > 0.01 { clamp((t - bn.time - 0.17) / available, 0.0, 1.0) } else { clamp((t - bn.time) / (an.time - bn.time), 0.0, 1.0) };
            let smooth = u * u * (3.0 - 2.0 * u);
            return Pose { x: sx + smooth * (ex - sx), y: sy + smooth * (ey - sy), active: true };
        }
    }
    if dist > 0.72 {
        return rest;
    }
    let s = if t > cn.time { R } else { -R };
    Pose { x: cn.line_index as f64 + d.0 * s, y: cn.line_layer as f64 + d.1 * s, active: true }
}

fn shape_distance(a: &[i32; 6], b: &[i32; 6]) -> f64 {
    let coord = 0.40 * ((a[0] - b[0]).abs() + (a[1] - b[1]).abs() + (a[3] - b[3]).abs() + (a[4] - b[4]).abs()) as f64;
    let rot = 0.45 * (ang(a[2], b[2]) + ang(a[5], b[5])) / 90.0;
    coord + rot
}

#[derive(Default)]
pub struct AuditResult {
    pub risk: f64,
    pub hotspots: Vec<(f64, f64)>,
}

/// simbersGuardAudit over `idx` (indices into notes).
fn audit(notes: &[GNote], idx: &[usize], from: f64, to: f64) -> AuditResult {
    let mut by_hand: [Vec<usize>; 2] = [vec![], vec![]];
    let mut keys: Vec<String> = vec![];
    let mut batches: HashMap<String, Vec<usize>> = HashMap::new();
    for &i in idx {
        let n = &notes[i];
        if n.type_ != 0 && n.type_ != 1 {
            continue;
        }
        by_hand[n.type_ as usize].push(i);
        let k = to_fixed(n.time, 4);
        batches.entry(k.clone()).or_insert_with(|| {
            keys.push(k);
            vec![]
        }).push(i);
    }
    for h in by_hand.iter_mut() {
        h.sort_by(|&a, &b| notes[a].time.partial_cmp(&notes[b].time).unwrap());
    }
    let mut times: Vec<(f64, &String)> = keys.iter().map(|k| (k.parse::<f64>().unwrap(), k)).collect();
    times.sort_by(|a, b| a.0.partial_cmp(&b.0).unwrap());
    let mut cursor = [0usize; 2];
    let mut out = AuditResult::default();
    for (t, key) in times {
        if t < from || t > to {
            continue;
        }
        let batch = &batches[key];
        if batch.len() != 2 {
            continue;
        }
        let (Some(&ri), Some(&bi)) = (batch.iter().find(|&&i| notes[i].type_ == 0), batch.iter().find(|&&i| notes[i].type_ == 1)) else { continue };
        let (red, blue) = (&notes[ri], &notes[bi]);
        let shape = [red.line_index, red.line_layer, red.cut_direction, blue.line_index, blue.line_layer, blue.cut_direction];
        let proximity = HUMAN_DOUBLES.iter().map(|tp| shape_distance(&shape, tp)).fold(f64::INFINITY, f64::min);
        let mut er = (proximity - 0.42).max(0.0) * 4.0;
        if proximity > 0.42 {
            let mut min_dist = f64::INFINITY;
            for off in SAMPLES {
                let l = trace_pose(notes, &by_hand[0], t + off, &mut cursor[0], 0);
                let r = trace_pose(notes, &by_hand[1], t + off, &mut cursor[1], 1);
                if l.active && r.active {
                    min_dist = min_dist.min(jsm::hypot(l.x - r.x, l.y - r.y));
                }
            }
            if min_dist < 0.30 {
                er += 1.3;
            } else if min_dist < 0.44 {
                er += 0.45;
            }
            if red.line_index > blue.line_index {
                er += 3.0;
            }
        }
        out.risk += er;
        if er >= 1.2 {
            out.hotspots.push((t, er));
        }
    }
    for hand in &by_hand {
        for i in 1..hand.len() {
            let (a, b) = (&notes[hand[i - 1]], &notes[hand[i]]);
            if b.time < from || b.time > to {
                continue;
            }
            let dt = b.time - a.time;
            if dt <= 0.0 || dt >= 1.3 {
                continue;
            }
            let av = dir(a.cut_direction);
            let bv = dir(b.cut_direction);
            let dx = b.line_index as f64 - bv.0 * 0.39 - a.line_index as f64 - av.0 * 0.39;
            let dy = b.line_layer as f64 - bv.1 * 0.39 - a.line_layer as f64 - av.1 * 0.39;
            let speed = jsm::hypot(dx, dy) / 0.05f64.max(dt);
            let safe = if dt < 0.16 {
                32.0
            } else if dt < 0.24 {
                17.5
            } else if dt < 0.34 {
                11.5
            } else if dt < 0.5 {
                8.8
            } else if dt < 0.8 {
                5.7
            } else {
                3.7
            };
            let v = (speed / safe - 1.0).max(0.0) * 5.0;
            if v != 0.0 {
                out.risk += v;
                if v >= 1.2 {
                    out.hotspots.push((b.time, v));
                }
            }
        }
    }
    out
}

type Seq = Vec<CNote>;

fn seq_key(s: &Seq) -> String {
    s.iter().map(|n| format!("{}{}{}", n.x, n.y, n.d)).collect::<Vec<_>>().join("|")
}

fn timing_key(notes: &[GNote], items: &[usize]) -> String {
    (1..items.len()).map(|i| crate::util::js_num_to_string(js_round((notes[items[i]].time - notes[items[i - 1]].time) / 0.09))).collect::<Vec<_>>().join(",")
}

fn flows(notes: &[GNote], items: &[usize], hand: i32, cache: &HashMap<String, Seq>, seed: &str) -> Vec<Seq> {
    let original: Seq = items.iter().map(|&i| CNote { x: notes[i].line_index, y: notes[i].line_layer, d: notes[i].cut_direction }).collect();
    if items.is_empty() {
        return vec![original];
    }
    let mut seen: HashSet<String> = HashSet::new();
    seen.insert(seq_key(&original));
    let mut results = vec![original.clone()];
    let n = items.len();
    let mut add = |seq: Seq, results: &mut Vec<Seq>| {
        if seq.len() != n || seq.iter().any(|c| c.d == 2 || c.d == 3 || c.d > 7) {
            return;
        }
        for j in 1..seq.len() {
            if ang(seq[j].d, seq[j - 1].d) < 135.0 {
                return;
            }
        }
        let k = seq_key(&seq);
        if seen.insert(k) {
            results.push(seq);
        }
    };
    let key = format!("{hand}/{n}/{}", timing_key(notes, items));
    if let Some(c) = cache.get(&key) {
        add(c.clone(), &mut results);
    }
    if (3..=10).contains(&n) {
        for e in candidates(n, &format!("{seed}|{key}"), None, 10, 0.65) {
            let src = corpus::read_source(e, hand);
            if src.len() == n {
                add(src.iter().map(|s| s.0).collect(), &mut results);
            }
            if results.len() >= 11 {
                break;
            }
        }
    }
    for start in [0, 1] {
        for lane in if hand != 0 { [3, 2] } else { [0, 1] } {
            add((0..n).map(|j| { let d = ((start + j) % 2) as i32; CNote { x: lane, y: if d == 0 { 0 } else { 2 }, d } }).collect(), &mut results);
            add((0..n).map(|j| { let d = ((start + j) % 2) as i32; CNote { x: lane, y: if d == 0 { 1 } else { 2 }, d } }).collect(), &mut results);
        }
    }
    let min_x = original.iter().map(|c| c.x).min().unwrap();
    let max_x = original.iter().map(|c| c.x).max().unwrap();
    for delta in if hand == 0 { [-2, -1, 1] } else { [2, 1, -1] } {
        if min_x + delta < 0 || max_x + delta > 3 {
            continue;
        }
        add(original.iter().map(|c| CNote { x: c.x + delta, ..*c }).collect(), &mut results);
    }
    results
}

fn valid_region(notes: &[GNote], hand_order: &[Vec<usize>; 2], from: f64, to: f64) -> bool {
    for order in hand_order {
        let mut prev: Option<i32> = None;
        for &i in order {
            let d = notes[i].cut_direction;
            if d == 2 || d == 3 || d > 7 {
                return false;
            }
            if let Some(p) = prev
                && ang(d, p) < 135.0
            {
                return false;
            }
            prev = Some(d);
        }
    }
    let mut batch: HashMap<String, Vec<usize>> = HashMap::new();
    for (i, n) in notes.iter().enumerate() {
        if n.time >= from && n.time <= to {
            batch.entry(to_fixed(n.time, 4)).or_default().push(i);
        }
    }
    for pair in batch.values() {
        if pair.len() != 2 {
            continue;
        }
        let l = pair.iter().find(|&&i| notes[i].type_ == 0);
        let r = pair.iter().find(|&&i| notes[i].type_ == 1);
        if let (Some(&l), Some(&r)) = (l, r) {
            let (l, r) = (&notes[l], &notes[r]);
            if l.line_index >= r.line_index
                || cross_risk(CNote { x: l.line_index, y: l.line_layer, d: l.cut_direction }, CNote { x: r.line_index, y: r.line_layer, d: r.cut_direction }, 0.0) >= 100.0
            {
                return false;
            }
        }
    }
    true
}

#[derive(Clone, Debug, Default)]
pub struct GuardMetrics {
    pub evaluated: usize,
    pub flagged: usize,
    pub repaired_phrases: usize,
    pub moved_notes: usize,
    pub changed_arrows: usize,
    pub risk_before: f64,
    pub risk_after: f64,
    pub unresolved: usize,
    pub elapsed_ms: f64,
}

fn set_seq(notes: &mut [GNote], items: &[usize], seq: &Seq) {
    for (k, &i) in items.iter().enumerate() {
        notes[i].line_index = seq[k].x;
        notes[i].line_layer = seq[k].y;
        notes[i].cut_direction = seq[k].d;
    }
}

pub fn run_physical_flow_guard(
    diffs: &mut [Difficulty],
    features: Option<FeatureOptions>,
    seed: &str,
    check: &dyn Fn() -> anyhow::Result<()>,
    progress: &mut dyn FnMut(f64, &str),
) -> anyhow::Result<GuardMetrics> {
    let started = now_ms();
    let mut m = GuardMetrics::default();
    let mut cache: HashMap<String, Seq> = HashMap::new();
    let count = diffs.len();
    for (di, diff) in diffs.iter_mut().enumerate() {
        check()?;
        let all: Vec<usize> = (0..diff.source_notes.len()).collect();
        let before = audit(&diff.source_notes, &all, f64::NEG_INFINITY, f64::INFINITY);
        m.evaluated += diff.source_notes.len();
        m.flagged += before.hotspots.len();
        m.risk_before += before.risk;
        let budget = 18usize.min(5usize.max((diff.source_notes.len() as f64 * 0.023).ceil() as usize));
        let mut hand_order: [Vec<usize>; 2] = [vec![], vec![]];
        for h in 0..2 {
            hand_order[h] = all.iter().copied().filter(|&i| diff.source_notes[i].type_ == h as i32).collect();
            hand_order[h].sort_by(|&a, &b| diff.source_notes[a].time.partial_cmp(&diff.source_notes[b].time).unwrap());
        }
        let mut repaired_here = 0usize;
        let mut sweep = 0;
        while sweep < 3 && repaired_here < budget {
            let notes = &mut diff.source_notes;
            let mut hotspots = audit(notes, &all, f64::NEG_INFINITY, f64::INFINITY).hotspots;
            hotspots.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap());
            let mut processed: Vec<f64> = vec![];
            let mut repaired_sweep = 0;
            for (center, _) in hotspots {
                check()?;
                if repaired_here >= budget {
                    break;
                }
                if processed.iter().any(|t| (t - center).abs() < 0.9) {
                    continue;
                }
                let near: [Vec<usize>; 2] = [0, 1].map(|h| {
                    all.iter().copied().filter(|&i| notes[i].type_ == h && notes[i].time >= center - 0.59 && notes[i].time <= center + 0.73).take(6).collect()
                });
                if near[0].is_empty() && near[1].is_empty() {
                    continue;
                }
                let times = near.iter().flatten().map(|&i| notes[i].time);
                let from = times.clone().fold(f64::INFINITY, f64::min);
                let to = times.fold(f64::NEG_INFINITY, f64::max);
                let scope: Vec<usize> = all.iter().copied().filter(|&i| notes[i].time >= from - 0.75 && notes[i].time <= to + 0.75).collect();
                let baseline = audit(notes, &scope, from - 0.22, to + 0.22).risk;
                if baseline < 1.2 {
                    processed.push(center);
                    continue;
                }
                let original: [Seq; 2] = [0, 1].map(|h| near[h].iter().map(|&i| CNote { x: notes[i].line_index, y: notes[i].line_layer, d: notes[i].cut_direction }).collect());
                let cseed = format!("{seed}|{}|{}", diff.config.id, crate::util::js_num_to_string(js_round(center * 5.0)));
                let cands: [Vec<Seq>; 2] = [flows(notes, &near[0], 0, &cache, &cseed), flows(notes, &near[1], 1, &cache, &cseed)];
                let mut best: (f64, f64, Option<[Seq; 2]>) = (baseline, baseline, None); // (risk, score, seq)
                for left in &cands[0] {
                    for right in &cands[1] {
                        set_seq(notes, &near[0], left);
                        set_seq(notes, &near[1], right);
                        if !valid_region(notes, &hand_order, from, to) {
                            continue;
                        }
                        let risk = audit(notes, &scope, from - 0.22, to + 0.22).risk;
                        let mut penalty = 0.0;
                        for (h, seq) in [left, right].iter().enumerate() {
                            for (i, n) in seq.iter().enumerate() {
                                let o = original[h][i];
                                penalty += (if o.d != n.d { 0.20 } else { 0.0 }) + (if o.x != n.x { 0.13 } else { 0.0 }) + (if o.y != n.y { 0.11 } else { 0.0 });
                            }
                        }
                        let score = risk + penalty;
                        if score < best.1 - 0.025 {
                            best = (risk, score, Some([left.clone(), right.clone()]));
                        }
                    }
                }
                set_seq(notes, &near[0], &original[0]);
                set_seq(notes, &near[1], &original[1]);
                processed.push(center);
                if let Some(seq) = best.2
                    && best.0 < baseline - 0.65
                    && best.0 <= baseline * 0.68
                {
                    for h in 0..2 {
                        for i in 0..near[h].len() {
                            let (o, n) = (original[h][i], seq[h][i]);
                            if o.d != n.d {
                                m.changed_arrows += 1;
                            }
                            if o.x != n.x || o.y != n.y {
                                m.moved_notes += 1;
                            }
                        }
                    }
                    set_seq(notes, &near[0], &seq[0]);
                    set_seq(notes, &near[1], &seq[1]);
                    repaired_here += 1;
                    repaired_sweep += 1;
                    m.repaired_phrases += 1;
                    for h in 0..2 {
                        if !near[h].is_empty() {
                            cache.insert(format!("{h}/{}/{}", near[h].len(), timing_key(notes, &near[h])), seq[h].clone());
                        }
                    }
                }
            }
            if repaired_sweep == 0 {
                break;
            }
            sweep += 1;
        }
        // Emergency same-cell separation.
        let notes = &mut diff.source_notes;
        let mut emergency = 0usize;
        let mut order: Vec<String> = vec![];
        let mut grouped: HashMap<String, Vec<usize>> = HashMap::new();
        for (i, n) in notes.iter().enumerate() {
            let k = to_fixed(n.time, 4);
            grouped.entry(k.clone()).or_insert_with(|| {
                order.push(k);
                vec![]
            }).push(i);
        }
        for k in &order {
            let pair = &grouped[k];
            if pair.len() != 2 {
                continue;
            }
            let (Some(&li), Some(&ri)) = (pair.iter().find(|&&i| notes[i].type_ == 0), pair.iter().find(|&&i| notes[i].type_ == 1)) else { continue };
            let (l, r) = (notes[li].clone(), notes[ri].clone());
            if l.line_index != r.line_index || l.line_layer != r.line_layer {
                continue;
            }
            let mut best: Option<(i32, i32, i32, i32, i32)> = None;
            for lx in [l.line_index, 0, 1] {
                for rx in [r.line_index, 3, 2] {
                    for ly in [l.line_layer, 0, 1, 2] {
                        for ry in [r.line_layer, 0, 1, 2] {
                            if (lx == rx && ly == ry) || lx > rx {
                                continue;
                            }
                            if cross_risk(CNote { x: lx, y: ly, d: l.cut_direction }, CNote { x: rx, y: ry, d: r.cut_direction }, 0.0) >= 100.0 {
                                continue;
                            }
                            let cost = 5 * ((lx - l.line_index).abs() + (rx - r.line_index).abs()) + 6 * ((ly - l.line_layer).abs() + (ry - r.line_layer).abs());
                            if best.map(|b| cost < b.4).unwrap_or(true) {
                                best = Some((lx, rx, ly, ry, cost));
                            }
                        }
                    }
                }
            }
            let Some((lx, rx, ly, ry, _)) = best else { continue };
            if l.line_index != lx || l.line_layer != ly {
                m.moved_notes += 1;
            }
            if r.line_index != rx || r.line_layer != ry {
                m.moved_notes += 1;
            }
            notes[li].line_index = lx;
            notes[li].line_layer = ly;
            notes[ri].line_index = rx;
            notes[ri].line_layer = ry;
            emergency += 1;
        }
        let after = audit(notes, &all, f64::NEG_INFINITY, f64::INFINITY);
        m.risk_after += after.risk;
        m.unresolved += after.hotspots.len();
        if human_flow_audit(notes, false) > 0 {
            log::warn!("HAND FLOW FAILURE {} {}", diff.config.label, m.repaired_phrases);
            anyhow::bail!("Physical pass introduced invalid return swings");
        }
        diff.sync_color_notes(true)?;
        if repaired_here > 0 || emergency > 0 {
            let f = features.unwrap_or(FeatureOptions { bombs: false, walls: false, arcs: false, bot_optimizer: false });
            let arcs = if f.arcs { super::arcs::build(&diff.source_notes, &diff.config) } else { vec![] };
            let pseed = format!("{seed}|physical-flow");
            let bombs = if f.bombs { super::bombs::build_bombs(&diff.source_notes, &arcs, &diff.config, &pseed) } else { vec![] };
            let walls = if f.walls { super::bombs::build_walls(&diff.source_notes, &arcs, &bombs, &diff.config, &pseed) } else { vec![] };
            diff.arc_count = arcs.len();
            diff.bomb_count = bombs.len();
            diff.wall_count = walls.len();
            diff.beatmap.sliders = arcs;
            let mut all_notes: Vec<_> = diff.beatmap.notes.iter().filter(|n| n.type_ == 0 || n.type_ == 1).cloned().collect();
            all_notes.extend(bombs);
            all_notes.sort_by(|a, b| a.time.partial_cmp(&b.time).unwrap().then(a.type_.cmp(&b.type_)));
            diff.beatmap.notes = all_notes;
            diff.beatmap.obstacles = walls;
        }
        let cd = &mut diff.beatmap.custom_data;
        cd.insert("_physicalFlowAlgorithm".into(), Value::from("dual-hand swept-wrist/recovery proxy; whole-phrase replacements"));
        cd.insert("_physicalFlowFlagged".into(), Value::from(before.hotspots.len()));
        cd.insert("_physicalFlowRepairedPhrases".into(), Value::from(repaired_here));
        cd.insert("_physicalFlowRiskBefore".into(), crate::util::jnum(to_fixed_num(before.risk, 2)));
        cd.insert("_physicalFlowRiskAfter".into(), crate::util::jnum(to_fixed_num(after.risk, 2)));
        cd.insert("_physicalFlowUnresolved".into(), Value::from(after.hotspots.len()));
        cd.insert("_physicalFlowEmergencySeparations".into(), Value::from(emergency));
        progress((di + 1) as f64 / count as f64, &format!("Hand-path check · {} · {repaired_here} phrases repaired", diff.config.label));
    }
    m.elapsed_ms = now_ms() - started;
    Ok(m)
}
