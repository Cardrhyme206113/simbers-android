//! Beatmap assembly and characteristic variants (beatmaps.js).

use super::choreo::{self, PlanStats};
use super::grid::{self, Grid};
use super::select::{self, SelectCtx};
use super::{DifficultyConfig, FeatureOptions, GNote};
use crate::analysis::patterns::{Patterns, Segment};
use crate::analysis::spectral::PitchAnalysis;
use crate::util::{clamp, hash_string, jnum, js_round, jsm, now_ms, to_fixed_num};
use serde_json::{Map, Value, json};
use std::collections::{BTreeMap, HashMap, HashSet};
use std::sync::Arc;

#[derive(Clone, Debug, PartialEq)]
pub struct MapNote {
    pub time: f64,
    pub line_index: i32,
    pub line_layer: i32,
    pub type_: i32,
    pub cut_direction: i32,
}

#[derive(Clone, Debug)]
pub struct Slider {
    pub color_type: i32,
    pub head_time: f64,
    pub head_line_index: i32,
    pub head_line_layer: i32,
    pub head_cut_direction: i32,
    pub head_mult: f64,
    pub tail_time: f64,
    pub tail_line_index: i32,
    pub tail_line_layer: i32,
    pub tail_cut_direction: i32,
    pub tail_mult: f64,
    pub mid_anchor_mode: i32,
}

#[derive(Clone, Debug)]
pub struct Obstacle {
    pub type_: i32,
    pub time: f64,
    pub duration: f64,
    pub line_index: i32,
    pub width: i32,
}

#[derive(Clone, Debug)]
pub struct LightEvent {
    pub time: f64,
    pub type_: i32,
    pub value: i32,
    pub float_value: Option<f64>,
}

#[derive(Clone, Debug, Default)]
pub struct Beatmap {
    pub notes: Vec<MapNote>,
    pub obstacles: Vec<Obstacle>,
    pub sliders: Vec<Slider>,
    pub events: Arc<Vec<LightEvent>>,
    pub custom_data: Map<String, Value>,
}

impl MapNote {
    pub fn to_json(&self) -> Value {
        json!({"_time": jnum(self.time), "_lineIndex": self.line_index, "_lineLayer": self.line_layer, "_type": self.type_, "_cutDirection": self.cut_direction})
    }
}

impl Slider {
    pub fn to_json(&self) -> Value {
        json!({
            "_colorType": self.color_type, "_headTime": jnum(self.head_time), "_headLineIndex": self.head_line_index,
            "_headLineLayer": self.head_line_layer, "_headCutDirection": self.head_cut_direction,
            "_headControlPointLengthMultiplier": jnum(self.head_mult), "_tailTime": jnum(self.tail_time),
            "_tailLineIndex": self.tail_line_index, "_tailLineLayer": self.tail_line_layer,
            "_tailCutDirection": self.tail_cut_direction, "_tailControlPointLengthMultiplier": jnum(self.tail_mult),
            "_sliderMidAnchorMode": self.mid_anchor_mode,
        })
    }
}

impl Obstacle {
    pub fn to_json(&self) -> Value {
        json!({"_type": self.type_, "_time": jnum(self.time), "_duration": jnum(self.duration), "_lineIndex": self.line_index, "_width": self.width})
    }
}

impl LightEvent {
    pub fn to_json(&self) -> Value {
        let mut m = Map::new();
        m.insert("_time".into(), jnum(self.time));
        m.insert("_type".into(), Value::from(self.type_));
        m.insert("_value".into(), Value::from(self.value));
        if let Some(f) = self.float_value {
            m.insert("_floatValue".into(), jnum(f));
        }
        Value::Object(m)
    }
}

impl Beatmap {
    pub fn to_json(&self) -> Value {
        json!({
            "_version": "2.6.0",
            "_notes": self.notes.iter().map(|n| n.to_json()).collect::<Vec<_>>(),
            "_obstacles": self.obstacles.iter().map(|n| n.to_json()).collect::<Vec<_>>(),
            "_sliders": self.sliders.iter().map(|n| n.to_json()).collect::<Vec<_>>(),
            "_events": self.events.iter().map(|n| n.to_json()).collect::<Vec<_>>(),
            "_waypoints": [],
            "_specialEventsKeywordFilters": {"_keywords": []},
            "_customData": Value::Object(self.custom_data.clone()),
        })
    }
}

#[derive(Clone, Debug, Default)]
pub struct Difficulty {
    pub config: DifficultyConfig,
    pub characteristic: String,
    pub filename: String,
    pub beatmap: Beatmap,
    pub note_count: usize,
    pub event_count: usize,
    pub bomb_count: usize,
    pub wall_count: usize,
    pub arc_count: usize,
    pub nps: f64,
    pub active_duration: f64,
    pub intensity_baseline_events: usize,
    pub intensity_target_events: usize,
    pub intensity_actual_events: usize,
    pub intensity_actual_percent: f64,
    pub target_relative_percent: f64,
    pub intensity_fulfillment_percent: f64,
    pub difficulty_density_percent: f64,
    pub used_flow_ids: Vec<String>,
    pub flow_tier_counts: Value,
    pub rotation_event_count: usize,
    pub stats: Option<Arc<PlanStats>>,
    pub source_notes: Vec<GNote>,
}

impl Difficulty {
    /// Copy source-note geometry back into the colour notes of the beatmap
    /// (same order is an invariant of the pipeline).
    pub fn sync_color_notes(&mut self, positions: bool) -> anyhow::Result<()> {
        let color: Vec<usize> = (0..self.beatmap.notes.len()).filter(|&i| matches!(self.beatmap.notes[i].type_, 0 | 1)).collect();
        if color.len() != self.source_notes.len() {
            anyhow::bail!(if positions { "Physical pass note count mismatch" } else { "Bot pass: note count mismatch" });
        }
        for (k, &i) in color.iter().enumerate() {
            let s = &self.source_notes[k];
            let n = &mut self.beatmap.notes[i];
            n.cut_direction = s.cut_direction;
            if positions {
                n.line_index = s.line_index;
                n.line_layer = s.line_layer;
            }
        }
        Ok(())
    }

    pub fn used_flow_count(&self) -> usize {
        self.used_flow_ids.len()
    }
}

/// Everything generation reads from the analysis `result`.
pub struct GenInput<'a> {
    pub analysis: &'a PitchAnalysis,
    pub patterns: &'a Patterns,
    pub grid: Option<&'a Grid>,
    pub duration: f64,
    pub nps_cap: i64,
    pub timing: &'a dyn Fn(&str, f64),
}

impl<'a> GenInput<'a> {
    pub fn select_ctx(&self) -> SelectCtx<'_> {
        SelectCtx {
            duration: self.duration,
            segments: &self.patterns.segments,
            intensity_pool: &self.patterns.intensity_pool,
            track: self.patterns.local_activity_track.as_ref(),
            grid: self.grid,
        }
    }
}

pub fn grid_for_patterns(p: &Patterns) -> Option<Grid> {
    let rows: Vec<(f64, f64)> = p.segments.iter().map(|s| (s.start, s.beat_strength)).collect();
    grid::infer(&rows)
}

fn z(v: f64) -> f64 {
    if v.is_nan() { 0.0 } else { v }
}

#[derive(Clone, Debug)]
pub struct Section {
    pub peak: usize,
    pub start: usize,
    pub end: usize,
    pub score: f64,
    pub hand: u32,
}

fn notation_importance(s: &Segment, p: Option<&Segment>, n: Option<&Segment>) -> f64 {
    let mv = z(s.melody_value);
    let jump = (mv - p.map(|x| z(x.melody_value)).unwrap_or(0.0)).abs().max((mv - n.map(|x| z(x.melody_value)).unwrap_or(0.0)).abs());
    clamp(0.4 * z(s.state_change) + 0.28 * z(s.beat_strength) + 0.18 * z(s.activity) + 0.14 * clamp(jump / 0.45, 0.0, 1.0), 0.0, 1.0)
}

pub fn notation_sections(segments: &[Option<Arc<Segment>>], config: &DifficultyConfig, seed: &str) -> Vec<Section> {
    if segments.len() < 6 {
        return vec![];
    }
    let (threshold, cooldown) = match config.id.as_str() {
        "expertPlus" => (0.62, 11usize),
        "expert" => (0.65, 13),
        "hard" => (0.68, 15),
        "medium" => (0.71, 17),
        _ => (0.74, 19),
    };
    let empty = Segment::default();
    let get = |i: usize| -> &Segment { segments[i].as_deref().unwrap_or(&empty) };
    let scores: Vec<f64> = (0..segments.len())
        .map(|i| notation_importance(get(i), if i > 0 { Some(get(i - 1)) } else { None }, if i + 1 < segments.len() { Some(get(i + 1)) } else { None }))
        .collect();
    let mut cands: Vec<(usize, f64)> = vec![];
    for i in 2..segments.len() - 2 {
        let s = scores[i];
        if s < threshold || s < scores[i - 1] || s < scores[i + 1] {
            continue;
        }
        cands.push((i, s));
    }
    cands.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap().then(a.0.cmp(&b.0)));
    let target = 1usize.max((segments.len() as f64 / (cooldown as f64 * 2.2)).ceil() as usize);
    let mut chosen: Vec<Section> = vec![];
    for (index, score) in cands {
        if chosen.iter().any(|c| (c.peak as i64 - index as i64).unsigned_abs() < cooldown as u64) {
            continue;
        }
        let span = clamp(js_round(4.0 + (score - threshold) * 10.0), 4.0, 8.0) as usize;
        let start = index.saturating_sub(1);
        let end = segments.len().min(start + span);
        chosen.push(Section { peak: index, start, end, score, hand: 0 });
        if chosen.len() >= target {
            break;
        }
    }
    chosen.sort_by_key(|c| c.start);
    let mut hand = hash_string(&format!("{seed}|{}|single-saber-first-hand", config.id)) % 2;
    for c in chosen.iter_mut() {
        c.hand = hand;
        hand = 1 - hand;
    }
    chosen
}

fn section_lookup(sections: &[Section], len: usize) -> Vec<Option<usize>> {
    let mut l = vec![None; len];
    for (k, s) in sections.iter().enumerate() {
        for slot in l.iter_mut().take(s.end).skip(s.start) {
            *slot = Some(k);
        }
    }
    l
}

fn gate_quiet_doubles(notes: Vec<GNote>, input: &GenInput) -> (Vec<GNote>, usize) {
    let Some(track) = input.patterns.local_activity_track.as_ref() else { return (notes, 0) };
    if notes.len() < 2 {
        return (notes, 0);
    }
    let (period, origin) = select::activity_beat_period(input.grid);
    let span = 4.0 * period;
    let mut windows: Vec<(i64, Vec<(usize, usize)>)> = vec![];
    let mut i = 0;
    while i + 1 < notes.len() {
        let (a, b) = (&notes[i], &notes[i + 1]);
        if (a.time - b.time).abs() > 0.001 || a.type_ == b.type_ {
            i += 1;
            continue;
        }
        let key = ((a.time - origin) / span).floor() as i64;
        match windows.iter_mut().find(|w| w.0 == key) {
            Some(w) => w.1.push((i, i + 1)),
            None => windows.push((key, vec![(i, i + 1)])),
        }
        i += 2;
    }
    let mut removed: HashSet<usize> = HashSet::new();
    let mut side = 0;
    for (key, pairs) in &windows {
        let factor = select::musical_activity_factor(track, origin + (*key as f64 + 0.5) * span, period, origin);
        let keep = js_round(pairs.len() as f64 * if factor >= 0.82 { 1.0 } else { jsm::pow(factor / 0.82, 0.9) }) as i64;
        let thin = pairs.len() as i64 - keep;
        if thin <= 0 {
            continue;
        }
        for j in 0..thin {
            let at = (pairs.len() - 1).min((((j as f64 + 0.5) * pairs.len() as f64) / thin as f64).floor() as usize);
            let pair = pairs[at];
            removed.insert(if notes[pair.0].type_ == side { pair.1 } else { pair.0 });
            side ^= 1;
        }
    }
    let n = removed.len();
    (notes.into_iter().enumerate().filter(|(i, _)| !removed.contains(i)).map(|x| x.1).collect(), n)
}

fn to_map_note(n: &GNote, type_override: Option<i32>) -> MapNote {
    MapNote { time: to_fixed_num(n.time, 4), line_index: n.line_index, line_layer: n.line_layer, type_: type_override.unwrap_or(n.type_), cut_direction: n.cut_direction }
}

fn opt<T: Into<Value>>(v: Option<T>) -> Value {
    v.map(Into::into).unwrap_or(Value::Null)
}

pub struct GenOptions {
    pub characteristic: &'static str,
    pub lawless_level: f64,
}

pub fn build_beatmap(input: &GenInput, seed: &str, config: &DifficultyConfig, lights: Arc<Vec<LightEvent>>, features: FeatureOptions, gopts: &GenOptions) -> anyhow::Result<Difficulty> {
    if input.patterns.segments.is_empty() {
        anyhow::bail!("No beat events were detected.");
    }
    let sel = select::select_for_intensity(&input.select_ctx(), config);
    let segments = &sel.segments;
    if segments.is_empty() {
        anyhow::bail!("{} produced no usable beat events.", config.label);
    }
    let flow_start = now_ms();
    let plan = choreo::plan_choreography(input.analysis, input.grid, segments, seed, config, input.nps_cap)?;
    let Some(plan) = plan.filter(|p| !p.notes.is_empty()) else { anyhow::bail!("The v2 planner produced no usable notes.") };
    let mut stats = plan.stats;
    let flow_ids: Vec<String> = plan.counts.iter().map(|(id, _)| format!("corpus_{id}")).collect();
    let corpus_half = plan.notes.len() as f64 / 2.0;
    (input.timing)("mapFlowPlanning", now_ms() - flow_start);
    let mut generated = plan.notes.clone();
    generated.sort_by(|a, b| a.time.partial_cmp(&b.time).unwrap().then(a.type_.cmp(&b.type_)));
    generated = super::nps::limit_note_density(generated, input.nps_cap);
    let (g, quiet_reduced) = gate_quiet_doubles(generated, input);
    generated = g;
    stats.local_activity_double_notes_removed = quiet_reduced;
    let post = super::nps::balance_culled_solo_hands(generated, &plan.notes);
    stats.post_cap_solo_balance = Some(post.to_json());
    generated = post.notes;
    let lawless = gopts.characteristic == "Lawless";
    let swing = if lawless {
        super::swing::SwingFix::default()
    } else {
        let (n, f) = super::swing::enforce(&generated, false)?;
        generated = n;
        f
    };
    if !lawless {
        let mut batches: Vec<(f64, Vec<usize>)> = vec![];
        for (i, n) in generated.iter().enumerate() {
            match batches.last_mut() {
                Some(l) if (n.time - l.0).abs() < 0.001 => l.1.push(i),
                _ => batches.push((n.time, vec![i])),
            }
        }
        let mut clocks: Vec<f64> = batches.iter().map(|b| b.0).collect();
        let (count, max_shift) = grid::snap_events(&mut clocks, input.grid);
        for (k, b) in batches.iter().enumerate() {
            if (b.0 - clocks[k]).abs() < 0.0002 {
                continue;
            }
            for &i in &b.1 {
                generated[i].time = to_fixed_num(clocks[k], 4);
            }
        }
        stats.metrical_snap_count = count;
        stats.metrical_max_shift_ms = max_shift;
    }
    let color: Vec<MapNote> = generated.iter().map(|n| to_map_note(n, None)).collect();
    let t0 = now_ms();
    let sliders = if features.arcs { super::arcs::build(&generated, config) } else { vec![] };
    (input.timing)("mapArcs", now_ms() - t0);
    let t0 = now_ms();
    let bombs = if features.bombs { super::bombs::build_bombs(&generated, &sliders, config, seed) } else { vec![] };
    (input.timing)("mapBombs", now_ms() - t0);
    let t0 = now_ms();
    let obstacles = if features.walls { super::bombs::build_walls(&generated, &sliders, &bombs, config, seed) } else { vec![] };
    (input.timing)("mapWalls", now_ms() - t0);
    let mut notes: Vec<MapNote> = color.clone();
    notes.extend(bombs.iter().cloned());
    notes.sort_by(|a, b| a.time.partial_cmp(&b.time).unwrap().then(a.type_.cmp(&b.type_)));
    let active_start = generated.first().map(|n| n.time).unwrap_or(0.0);
    let active_end = generated.last().map(|n| n.time).unwrap_or(input.duration);
    let active_duration = 1f64.max(active_end - active_start);
    let nps = color.len() as f64 / active_duration;
    let red = generated.iter().filter(|n| n.type_ == 0).count();
    let blue = generated.iter().filter(|n| n.type_ == 1).count();
    let num_or = |v: f64, d: f64| if v == 0.0 || v.is_nan() { d } else { v };
    let mut cd = Map::new();
    let mut put = |k: &str, v: Value| {
        cd.insert(k.to_string(), v);
    };
    put("_generator", "Beat Signature Natural Arc Multi-Difficulty HTML".into());
    put("_difficultyLabel", config.label.clone().into());
    put("_expertPlusIntensityPercent", jnum(js_round(num_or(config.expert_plus_intensity_percent, 100.0))));
    put("_difficultyDensityPercent", jnum(js_round(num_or(config.difficulty_density_percent, 100.0))));
    put("_targetRelativeToExpertPlusDefaultPercent", jnum(to_fixed_num(sel.target_relative_percent, 1)));
    put("_actualRelativeToExpertPlusDefaultPercent", jnum(to_fixed_num(sel.actual_percent, 1)));
    put("_generationIntensityBaselineEvents", sel.baseline_count.into());
    put("_generationIntensityTargetEvents", sel.target_count.into());
    put("_generationIntensityActualEvents", segments.len().into());
    put("_generationTargetFulfillmentPercent", jnum(to_fixed_num(sel.fulfillment_percent, 1)));
    put("_localActivityEventRemovals", sel.local_activity_removed.into());
    put("_localActivityQuietWindows", sel.local_activity_quiet_windows.into());
    put("_localActivityQuietDoubleRemovals", quiet_reduced.into());
    put("_minimumEventGapMs", jnum(config.minimum_gap_ms));
    put("_arcWindow", json!([jnum(config.arc_min_gap), jnum(config.arc_max_gap)]));
    put("_arcEveryEvents", jnum(if features.arcs { config.arc_every_events } else { 0.0 }));
    put("_arcAlgorithm", (if features.arcs { "movement+timing+melody continuity" } else { "disabled" }).into());
    put("_bombAlgorithm", (if features.bombs && config.bomb_every_events != 0.0 { "strong attack + follow-through space + next-note safety" } else { "disabled" }).into());
    put("_bombEveryEvents", jnum(if features.bombs { config.bomb_every_events } else { 0.0 }));
    put(
        "_wallAlgorithm",
        (if features.walls && config.wall_every_events != 0.0 { "single-lane left/right side walls only; strong accent + open gap + arc/bomb safety" } else { "disabled" }).into(),
    );
    put("_wallEveryEvents", jnum(if features.walls { config.wall_every_events } else { 0.0 }));
    put("_characteristic", gopts.characteristic.into());
    put("_lawlessIntensityPercent", jnum(js_round(gopts.lawless_level * 100.0)));
    put("_lawlessDifficultyRule", "Easy 20%, Normal 40%, Hard 60%, Expert 80%, Expert+ 100%".into());
    put("_lightingAlgorithm", "beat strength + default environment red/blue palette".into());
    put("_lightingCompatibility", "Info 2.0 + V2 events + DefaultEnvironment".into());
    put("_lightingEventCount", lights.len().into());
    put("_flowWeights", json!({"easy": jnum(config.weights[0]), "medium": jnum(config.weights[1]), "hard": jnum(config.weights[2])}));
    put("_flowPatternCount", stats.library_count.into());
    put("_flowEngine", "human-phrase-reuse-beam-v6".into());
    put(
        "_swingContinuityRule",
        "Each hand: 135–180 degree return swings (no 90-degree turns or horizontal arrows); independent hands may share direction; Lawless exempt".into(),
    );
    put("_swingContinuityDirectionCorrections", swing.changed_directions.into());
    put("_swingCrossHandDirectionCorrections", swing.cross_hand_corrections.into());
    put("_swingCrossHandPositionCorrections", swing.cross_hand_position_corrections.into());
    put("_swingContinuityPositionCorrections", swing.changed_positions.into());
    put("_swingContinuityEmergencySteps", swing.emergency_steps.into());
    put("_flowPhraseCount", stats.macro_sections.into());
    put("_flowCorpusPhraseCount", stats.source_flows.into());
    put("_flowRepeatedPhraseGroups", stats.repeated_macro_sections.into());
    put("_flowReusedPhrases", stats.matched_phrases.into());
    put("_flowPhraseReuseRule", "cadence-keyed 3–10-note reuse; complete smooth human-corpus phrases prioritized".into());
    put("_flowDensityAdaptation", "completed 3-10-note phrases selected with 4/8-beat local NPS; no individual-arrow density rewrite".into());
    put("_flowDensity4BeatPeakNps", jnum(stats.density.peak4));
    put("_flowDensity8BeatPeakNps", jnum(stats.density.peak8));
    put("_flowDensityAdaptedEvents", stats.density.adapted_events.into());
    put("_flowPlannerBeamWidth", 3.into());
    put("_flowMetricalGrid", opt(stats.metrical_grid.as_ref().map(|g| g.to_json())));
    put("_flowGridSnappedNotes", stats.metrical_snap_count.into());
    put("_flowGridMaximumShiftMs", jnum(stats.metrical_max_shift_ms));
    put("_flowBarAlignedPhrases", stats.bar_aligned_phrases.into());
    put("_flowAdjustedNotes", stats.repairs.into());
    put("_flowMacroMotifs", Value::Object(stats.motifs.clone()));
    put("_flowHandRhythms", Value::Object(stats.rhythms.clone()));
    put("_flowPerHandScheduleCounts", json!(stats.hand_schedules));
    put("_flowSoloBalance", opt(stats.solo_balance.as_ref().map(|s| s.to_json())));
    put("_flowPostCapSoloBalance", opt(stats.post_cap_solo_balance.clone()));
    put("_flowPostCapHandCounts", json!([red, blue]));
    put("_flowJointDoubles", stats.joint_doubles.into());
    put("_flowAdaptiveDoubleAccentsRemoved", stats.adaptive_double_accents_removed.into());
    put("_flowAdaptiveDoubleAccentsAdded", stats.adaptive_double_accents_added.into());
    put("_flowFullDoubleNotes", stats.full_double_notes.into());
    put("_flowTempoLimitedBeats", stats.tempo_limited.into());
    put("_flowReconstructedHandTargets", stats.missing_hand_targets.into());
    put("_flowCorpusGeometryPreserved", stats.source_geometry_preserved.into());
    put("_flowUniqueCorpusPatterns", stats.unique_corpus_patterns.into());
    put("_flowCorpusVariety", jnum(stats.corpus_variety));
    put("_flowLaneBalance", jnum(stats.lane_balance));
    put("_flowLaneCounts", json!(stats.lane_counts));
    put("_flowMotifSequences", stats.motif_flows.into());
    put("_flowUnplayableEventsSkipped", stats.dropped.into());
    put("_flowSafetyAuditViolations", stats.audit_violations.into());
    put("_flowPhraseLengths", Value::Object(stats.flow_lengths.clone()));
    put(
        "_flowSafetyModel",
        "independent hand timelines, approximate joint swing clearance, alternation/parity, reach and accumulated wrist-strain proxy; not physically validated".into(),
    );
    let event_count = generated.iter().map(|n| n.event_index).collect::<HashSet<_>>().len();
    Ok(Difficulty {
        config: config.clone(),
        characteristic: gopts.characteristic.to_string(),
        filename: config.filename.clone(),
        note_count: color.len(),
        event_count,
        bomb_count: bombs.len(),
        wall_count: obstacles.len(),
        arc_count: sliders.len(),
        beatmap: Beatmap { notes, obstacles, sliders, events: lights, custom_data: cd },
        nps,
        active_duration,
        intensity_baseline_events: sel.baseline_count,
        intensity_target_events: sel.target_count,
        intensity_actual_events: segments.len(),
        intensity_actual_percent: sel.actual_percent,
        target_relative_percent: sel.target_relative_percent,
        intensity_fulfillment_percent: sel.fulfillment_percent,
        difficulty_density_percent: config.difficulty_density_percent,
        used_flow_ids: flow_ids,
        flow_tier_counts: json!({"easy": 0, "medium": 0, "hard": 0, "corpus": jnum(corpus_half)}),
        rotation_event_count: 0,
        stats: Some(Arc::new(stats)),
        source_notes: generated,
    })
}

pub fn filename_for_characteristic(config: &DifficultyConfig, ch: &str) -> String {
    if ch == "Standard" {
        return config.filename.clone();
    }
    let lower = config.filename.to_lowercase();
    if lower.ends_with("standard.dat") {
        let cut = config.filename.len() - "standard.dat".len();
        return format!("{}{ch}.dat", &config.filename[..cut]);
    }
    format!("{}{ch}.dat", config.difficulty)
}

pub fn build_lawless(input: &GenInput, seed: &str, config: &DifficultyConfig, lights: Arc<Vec<LightEvent>>, features: FeatureOptions) -> anyhow::Result<Difficulty> {
    let level = super::lawless_level(&config.id).unwrap_or(0.2);
    let mut b = build_beatmap(input, &format!("{seed}|lawless|{}", config.id), config, lights, features, &GenOptions { characteristic: "Lawless", lawless_level: level })?;
    b.filename = filename_for_characteristic(config, "Lawless");
    b.characteristic = "Lawless".into();
    let cd = &mut b.beatmap.custom_data;
    cd.insert("_characteristic".into(), "Lawless".into());
    cd.insert("_lawlessIntensityPercent".into(), jnum(js_round(level * 100.0)));
    cd.insert("_lawlessSelectionMethod".into(), "direction pairs chosen progressively farther from ergonomic minimum".into());
    Ok(b)
}

pub fn make_no_arrows(standard: &Difficulty) -> Difficulty {
    let mut d = standard.clone();
    for n in d.beatmap.notes.iter_mut() {
        if n.type_ == 0 || n.type_ == 1 {
            n.cut_direction = 8;
        }
    }
    for s in d.beatmap.sliders.iter_mut() {
        s.head_cut_direction = 8;
        s.tail_cut_direction = 8;
    }
    let cd = &mut d.beatmap.custom_data;
    cd.insert("_characteristic".into(), "NoArrows".into());
    cd.insert("_dotNoteAlgorithm".into(), "all color notes are directionless".into());
    cd.insert("_singleSaberAlgorithm".into(), "disabled".into());
    d.characteristic = "NoArrows".into();
    d.filename = filename_for_characteristic(&d.config, "NoArrows");
    for n in d.source_notes.iter_mut() {
        n.cut_direction = 8;
    }
    d
}

fn by_event(notes: &[GNote]) -> BTreeMap<i64, Vec<usize>> {
    let mut m: BTreeMap<i64, Vec<usize>> = BTreeMap::new();
    for (i, n) in notes.iter().enumerate() {
        m.entry(n.event_index).or_default().push(i);
    }
    m
}

pub fn build_one_saber(standard: &Difficulty, seed: &str, lights: Arc<Vec<LightEvent>>, features: FeatureOptions) -> anyhow::Result<Difficulty> {
    let config = &standard.config;
    let src = &standard.source_notes;
    let be = by_event(src);
    let indices: Vec<i64> = be.keys().copied().collect();
    let segments: Vec<Option<Arc<Segment>>> = indices.iter().map(|i| src[be[i][0]].segment.clone()).collect();
    let sections = notation_sections(&segments, config, seed);
    let lookup = section_lookup(&sections, segments.len());
    let mut generated: Vec<GNote> = vec![];
    let mut source_hand = (hash_string(&format!("{seed}|{}|one-saber-first-side", config.id)) % 2) as i32;
    let mut active_peak: Option<usize> = None;
    for (li, ei) in indices.iter().enumerate() {
        let section = lookup[li].map(|k| &sections[k]);
        match section {
            Some(s) if Some(s.peak) != active_peak => {
                source_hand = s.hand as i32;
                active_peak = Some(s.peak);
            }
            None => active_peak = None,
            _ => {}
        }
        let ev = &be[ei];
        let si = ev.iter().copied().find(|&i| src[i].type_ == source_hand).unwrap_or(ev[0]);
        let mut n = src[si].clone();
        n.event_index = li as i64;
        n.type_ = 0;
        n.one_saber_source_hand = Some(source_hand);
        n.notation_section = section.map(|s| s.peak);
        generated.push(n);
    }
    let (generated, fix) = super::swing::enforce(&generated, true)?;
    let color: Vec<MapNote> = generated.iter().map(|n| to_map_note(n, Some(0))).collect();
    let sliders = if features.arcs { super::arcs::build(&generated, config) } else { vec![] };
    let bombs = if features.bombs { super::bombs::build_bombs(&generated, &sliders, config, seed) } else { vec![] };
    let obstacles = if features.walls { super::bombs::build_walls(&generated, &sliders, &bombs, config, seed) } else { vec![] };
    let mut notes = color.clone();
    notes.extend(bombs.iter().cloned());
    notes.sort_by(|a, b| a.time.partial_cmp(&b.time).unwrap().then(a.type_.cmp(&b.type_)));
    let active_start = generated.first().map(|n| n.time).unwrap_or(0.0);
    let active_end = generated.last().map(|n| n.time).unwrap_or(0.0);
    let active_duration = 1f64.max(active_end - active_start);
    let mut cd = standard.beatmap.custom_data.clone();
    cd.insert("_characteristic".into(), "OneSaber".into());
    cd.insert("_dotNoteAlgorithm".into(), "disabled".into());
    cd.insert("_singleSaberSections".into(), sections.len().into());
    cd.insert("_singleSaberParityCorrections".into(), fix.changed_directions.into());
    cd.insert("_singleSaberPositionCorrections".into(), fix.changed_positions.into());
    cd.insert("_singleSaberEmergencySteps".into(), fix.emergency_steps.into());
    cd.insert("_singleSaberAlgorithm".into(), "one saber switches between left-side and right-side source patterns at musically important sections".into());
    Ok(Difficulty {
        config: config.clone(),
        characteristic: "OneSaber".into(),
        filename: filename_for_characteristic(config, "OneSaber"),
        note_count: color.len(),
        event_count: indices.len(),
        bomb_count: bombs.len(),
        wall_count: obstacles.len(),
        arc_count: sliders.len(),
        nps: color.len() as f64 / active_duration,
        active_duration,
        beatmap: Beatmap { notes, obstacles, sliders, events: lights, custom_data: cd },
        used_flow_ids: standard.used_flow_ids.clone(),
        flow_tier_counts: standard.flow_tier_counts.clone(),
        source_notes: generated,
        ..Default::default()
    })
}

fn rotation_value(direction: i32, degrees: i32) -> i32 {
    if direction < 0 {
        if degrees == 30 { 2 } else { 3 }
    } else if degrees == 30 {
        5
    } else {
        4
    }
}

pub fn build_rotation(standard: &Difficulty, seed: &str, ch: &str) -> Difficulty {
    let config = &standard.config;
    let src = &standard.source_notes;
    let be = by_event(src);
    let indices: Vec<i64> = be.keys().copied().collect();
    let segments: Vec<Option<Arc<Segment>>> = indices.iter().map(|i| src[be[i][0]].segment.clone()).collect();
    let sections = notation_sections(&segments, config, &format!("{seed}|{ch}|rotation-sections"));
    let mut rot: Vec<LightEvent> = vec![];
    let mut cumulative = 0i32;
    let mut spin = if hash_string(&format!("{seed}|{}|{ch}|direction", config.id)) % 2 == 1 { 1 } else { -1 };
    let mut prev_melody: Option<f64> = None;
    for s in &sections {
        if indices.is_empty() {
            break;
        }
        let li = s.peak.min(indices.len() - 1);
        let Some(&si) = be.get(&indices[li]).and_then(|v| v.first()) else { continue };
        let source = &src[si];
        let melody = source.segment.as_ref().map(|x| z(x.melody_value)).unwrap_or(0.0);
        let delta = prev_melody.map(|p| melody - p).unwrap_or(0.0);
        prev_melody = Some(melody);
        let degrees = if s.score >= 0.82 { 30 } else { 15 };
        let direction = if ch == "90Degree" {
            let mut d = if delta.abs() >= 0.08 {
                if delta >= 0.0 { 1 } else { -1 }
            } else if s.hand != 0 {
                1
            } else {
                -1
            };
            if cumulative + d * degrees > 45 || cumulative + d * degrees < -45 {
                d = -d;
            }
            d
        } else {
            if delta.abs() >= 0.32 {
                spin = if delta >= 0.0 { 1 } else { -1 };
            }
            spin
        };
        rot.push(LightEvent { time: to_fixed_num(source.time, 4), type_: 15, value: rotation_value(direction, degrees), float_value: None });
        cumulative += direction * degrees;
    }
    let mut d = standard.clone();
    let mut events: Vec<LightEvent> = d.beatmap.events.iter().cloned().collect();
    events.extend(rot.iter().cloned());
    events.sort_by(|a, b| a.time.partial_cmp(&b.time).unwrap().then(a.type_.cmp(&b.type_)).then(a.value.cmp(&b.value)));
    d.beatmap.events = Arc::new(events);
    let cd = &mut d.beatmap.custom_data;
    cd.insert("_characteristic".into(), ch.into());
    cd.insert("_rotationEventCount".into(), rot.len().into());
    cd.insert("_rotationAlgorithm".into(), "late 15/30 degree rotations at the same major song changes used for OneSaber hand switches".into());
    cd.insert("_rotationRange".into(), (if ch == "90Degree" { "clamped to -45..45 degrees" } else { "continuous 360-degree rotation" }).into());
    d.characteristic = ch.into();
    d.filename = filename_for_characteristic(config, ch);
    d.rotation_event_count = rot.len();
    d
}

#[allow(unused)]
fn _unused(_: HashMap<u8, u8>) {}
