//! Late swing-continuity constraint (swing-continuity.js).

use super::GNote;
use super::choreo::{HState, cross_risk, hand_step};
use super::corpus::{ANGLES, CNote, DIRS, OPPOSITE, angular_error};
use crate::util::clamp;
use std::collections::{HashMap, HashSet};
use std::rc::Rc;

#[derive(Default, Clone, Debug)]
pub struct SwingFix {
    pub changed_directions: usize,
    pub changed_positions: usize,
    pub emergency_steps: usize,
    pub cross_hand_corrections: usize,
    pub cross_hand_position_corrections: usize,
}

#[inline]
fn angular(a: i32, b: i32) -> f64 {
    angular_error(ANGLES[a as usize], ANGLES[b as usize])
}

fn resolve_cross_hand(notes: &mut [GNote]) -> usize {
    let mut order: Vec<usize> = (0..notes.len()).filter(|&i| notes[i].type_ == 0 || notes[i].type_ == 1).collect();
    order.sort_by(|&a, &b| {
        notes[a].time.partial_cmp(&notes[b].time).unwrap().then(notes[a].type_.cmp(&notes[b].type_)).then(a.cmp(&b))
    });
    let mut recent: [Vec<(usize, f64)>; 2] = [vec![], vec![]];
    let mut moved = 0;
    for idx in order {
        let nt = notes[idx].type_ as usize;
        let ntime = notes[idx].time;
        let other_hand = 1 - nt;
        recent[other_hand].retain(|item| ntime - item.1 <= 0.17 + 1e-7);
        let items = recent[other_hand].clone();
        for (oi, _) in items {
            let (ri, bi) = if nt == 0 { (idx, oi) } else { (oi, idx) };
            let dt = notes[idx].time - notes[oi].time;
            let (red, blue) = (notes[ri].clone(), notes[bi].clone());
            if red.line_index < blue.line_index
                && cross_risk(
                    CNote { x: red.line_index, y: red.line_layer, d: red.cut_direction },
                    CNote { x: blue.line_index, y: blue.line_layer, d: blue.cut_direction },
                    dt,
                ) < 100.0
            {
                continue;
            }
            let mut best: Option<(i32, i32, i32, i32, i32)> = None;
            for rx in [red.line_index, 0, 1] {
                for bx in [blue.line_index, 3, 2] {
                    if rx >= bx || rx < 0 || bx > 3 {
                        continue;
                    }
                    for ry in [red.line_layer, 0, 1, 2] {
                        for by in [blue.line_layer, 0, 1, 2] {
                            if cross_risk(CNote { x: rx, y: ry, d: red.cut_direction }, CNote { x: bx, y: by, d: blue.cut_direction }, dt) >= 100.0 {
                                continue;
                            }
                            let cost = 5 * ((rx - red.line_index).abs() + (bx - blue.line_index).abs()) + 6 * ((ry - red.line_layer).abs() + (by - blue.line_layer).abs());
                            // stable sort by cost => first minimal in insertion order
                            if best.map(|b| cost < b.4).unwrap_or(true) {
                                best = Some((rx, bx, ry, by, cost));
                            }
                        }
                    }
                }
            }
            let Some((rx, bx, ry, by, _)) = best else { continue };
            if red.line_index != rx || red.line_layer != ry {
                moved += 1;
            }
            if blue.line_index != bx || blue.line_layer != by {
                moved += 1;
            }
            notes[ri].line_index = rx;
            notes[ri].line_layer = ry;
            notes[bi].line_index = bx;
            notes[bi].line_layer = by;
        }
        recent[nt].push((idx, ntime));
    }
    moved
}

pub fn human_flow_audit(notes: &[GNote], one_saber: bool) -> usize {
    let mut prev: [Option<i32>; 2] = [None, None];
    let mut bad = 0;
    let mut sorted: Vec<&GNote> = notes.iter().collect();
    sorted.sort_by(|a, b| a.time.partial_cmp(&b.time).unwrap().then(a.type_.cmp(&b.type_)));
    for n in sorted {
        if n.type_ != 0 && n.type_ != 1 {
            continue;
        }
        let hand = if one_saber { 0 } else { n.type_ as usize };
        if n.cut_direction == 2 || n.cut_direction == 3 || n.cut_direction > 7 {
            bad += 1;
        }
        if let Some(p) = prev[hand]
            && angular_error(ANGLES[n.cut_direction.clamp(0, 8) as usize], ANGLES[p.clamp(0, 8) as usize]) < 135.0
        {
            bad += 1;
        }
        prev[hand] = Some(n.cut_direction);
    }
    bad
}

struct Node {
    score: f64,
    state: Option<HState>,
    parent: Option<Rc<Node>>,
    choice: Option<(usize, i32, i32, i32)>,
}

pub fn enforce(notes: &[GNote], one_saber: bool) -> anyhow::Result<(Vec<GNote>, SwingFix)> {
    let beam_width = if one_saber { 16 } else { 8 };
    let groups: Vec<Vec<usize>> = if one_saber {
        vec![(0..notes.len()).filter(|&i| notes[i].type_ == 0).collect()]
    } else {
        (0..2).map(|h| (0..notes.len()).filter(|&i| notes[i].type_ == h).collect()).collect()
    };
    let mut emergency = 0usize;
    let mut resolved: Vec<GNote> = vec![];
    let mut prepared: HashMap<usize, GNote> = HashMap::new();
    for (hand, group) in groups.iter().enumerate() {
        let mut seq = group.clone();
        seq.sort_by(|&a, &b| notes[a].time.partial_cmp(&notes[b].time).unwrap().then(a.cmp(&b)));
        let mut beam: Vec<Rc<Node>> = vec![Rc::new(Node { score: 0.0, state: None, parent: None, choice: None })];
        for &item in &seq {
            let orig = &notes[item];
            let (gx, gy, od, t) = (orig.line_index, orig.line_layer, orig.cut_direction, orig.time);
            let nearby_red: Vec<&GNote> = if !one_saber && hand == 1 { resolved.iter().filter(|o| (o.time - t).abs() <= 0.17).collect() } else { vec![] };
            let mut expanded: Vec<Node> = vec![];
            let speed = clamp(if orig.flow_speed_pressure.is_nan() { 0.0 } else { orig.flow_speed_pressure }, 0.0, 1.0);
            for prev in &beam {
                let mut positions: Vec<(i32, i32)> = vec![(gx, gy)];
                if let Some(p) = prev.state {
                    if !one_saber {
                        positions.extend_from_slice(&[(0.max(gx - 1), gy), (3.min(gx + 1), gy), (gx, 0.max(gy - 1)), (gx, 2.min(gy + 1))]);
                    } else {
                        positions.extend_from_slice(&[
                            (p.x, gy),
                            (p.x, p.y),
                            (0.max(gx - 1), gy),
                            (3.min(gx + 1), gy),
                            (gx, 0.max(gy - 1)),
                            (gx, 2.min(gy + 1)),
                            (0.max(p.x - 1), gy),
                            (3.min(p.x + 1), gy),
                        ]);
                    }
                }
                let mut visited: HashSet<(i32, i32)> = HashSet::new();
                for (x, y) in positions {
                    if !(0..=3).contains(&x) || !(0..=2).contains(&y) {
                        continue;
                    }
                    if !visited.insert((x, y)) {
                        continue;
                    }
                    for d in 0..8 {
                        if d == 2 || d == 3 {
                            continue;
                        }
                        if let Some(ps) = prev.state
                            && angular(d, OPPOSITE[ps.d as usize]) > 45.0
                        {
                            continue;
                        }
                        let Some(state) = hand_step(prev.state.as_ref(), CNote { x, y, d }, t, hand as i32, if one_saber { 0.8 } else { 1.0 }) else { continue };
                        if !one_saber && hand == 1 && nearby_red.iter().any(|o| cross_risk(CNote { x: o.line_index, y: o.line_layer, d: o.cut_direction }, state.note(), o.time - t) >= 100.0) {
                            continue;
                        }
                        let offset_angle = if od < 8 { angular(d, od) } else { 0.0 };
                        let direction_penalty = if d == od { 0.0 } else { 1.4 + offset_angle * 0.035 };
                        let movement_scale = 1.0 - 0.22 * speed;
                        let movement_penalty = movement_scale * (if one_saber { 3.7 } else { 5.0 } * (x - gx).abs() as f64 + if one_saber { 4.0 } else { 5.7 } * (y - gy).abs() as f64);
                        let edge = (if y == 2 && DIRS[d as usize].1 > 0.3 { 0.38 } else { 0.0 }) + (if y == 0 && DIRS[d as usize].1 < -0.3 { 0.28 } else { 0.0 });
                        let dx = prev.state.map(|p| (x - p.x).abs()).unwrap_or(0) as f64;
                        let ease = speed * ((if d >= 4 { 2.6 } else { 0.0 }) + 1.1 * dx + 1.7 * (dx - 1.0).max(0.0));
                        let score = prev.score + direction_penalty + movement_penalty + edge + ease + 0.46 * state.cost;
                        expanded.push(Node { score, state: Some(state), parent: Some(prev.clone()), choice: Some((item, x, y, d)) });
                    }
                }
            }
            if expanded.is_empty() {
                emergency += 1;
                expanded = beam
                    .iter()
                    .map(|prev| {
                        let p = prev.state;
                        let d = match p {
                            Some(p) => OPPOSITE[p.d as usize],
                            None => {
                                if od < 8 { od } else { 1 }
                            }
                        };
                        let x = if one_saber && p.is_some() { p.unwrap().x } else { gx };
                        let y = if one_saber && p.is_some() { p.unwrap().y } else { gy };
                        Node { score: prev.score + 40.0, state: Some(HState { x, y, d, t, strain: 0.0, cost: 0.0 }), parent: Some(prev.clone()), choice: Some((item, x, y, d)) }
                    })
                    .collect();
            }
            expanded.sort_by(|a, b| a.score.partial_cmp(&b.score).unwrap_or(std::cmp::Ordering::Equal));
            let mut seen: HashSet<(i32, i32, i32)> = HashSet::new();
            let mut next = vec![];
            for c in expanded {
                let s = c.state.unwrap();
                if !seen.insert((s.x, s.y, s.d)) {
                    continue;
                }
                next.push(Rc::new(c));
                if next.len() >= beam_width {
                    break;
                }
            }
            beam = next;
        }
        let mut w = beam.first().cloned();
        while let Some(node) = w {
            let Some((item, x, y, d)) = node.choice else { break };
            let mut n = notes[item].clone();
            n.line_index = x;
            n.line_layer = y;
            n.cut_direction = d;
            prepared.insert(item, n);
            w = node.parent.clone();
        }
        if !one_saber && hand == 0 {
            resolved = seq.iter().map(|&i| prepared.get(&i).cloned().unwrap_or_else(|| notes[i].clone())).collect();
        }
    }
    let mut output: Vec<GNote> = (0..notes.len()).map(|i| prepared.remove(&i).unwrap_or_else(|| notes[i].clone())).collect();
    for group in &groups {
        let mut seq = group.clone();
        seq.sort_by(|&a, &b| notes[a].time.partial_cmp(&notes[b].time).unwrap().then(a.cmp(&b)));
        let mut previous: Option<i32> = None;
        for i in seq {
            let cd = output[i].cut_direction;
            if cd == 2 || cd == 3 || cd > 7 || previous.map(|p| angular(cd.clamp(0, 8), OPPOSITE[p as usize]) > 45.0).unwrap_or(false) {
                output[i].cut_direction = previous.map(|p| OPPOSITE[p as usize]).unwrap_or(1);
                emergency += 1;
            }
            previous = Some(output[i].cut_direction);
        }
    }
    let cross_moved = if one_saber { 0 } else { resolve_cross_hand(&mut output) };
    let violations = human_flow_audit(&output, one_saber);
    if violations > 0 {
        anyhow::bail!("Return-swing validation failed ({violations} bad transitions)");
    }
    let changed_directions = output.iter().zip(notes).filter(|(o, n)| o.cut_direction != n.cut_direction).count();
    let changed_positions = output.iter().zip(notes).filter(|(o, n)| o.line_index != n.line_index || o.line_layer != n.line_layer).count();
    Ok((output, SwingFix { changed_directions, changed_positions, emergency_steps: emergency, cross_hand_corrections: 0, cross_hand_position_corrections: cross_moved }))
}
