//! Cancellation, progress reporting and the timing profiler (diagnostics.js).

use crate::util::{js_num_to_string, now_ms, to_fixed};
use parking_lot::Mutex;
use serde_json::{Map, Value};
use std::sync::Arc;
use std::sync::atomic::{AtomicBool, Ordering};

#[derive(Debug, Clone)]
pub struct Canceled;
impl std::fmt::Display for Canceled {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str("AbortError")
    }
}
impl std::error::Error for Canceled {}

pub fn is_abort(e: &anyhow::Error) -> bool {
    e.downcast_ref::<Canceled>().is_some()
}

pub type ProgressFn = Arc<dyn Fn(f64, Option<String>) + Send + Sync>;

#[derive(Clone)]
pub struct Job {
    pub cancel: Arc<AtomicBool>,
    pub progress: ProgressFn,
    pub timing: Arc<Mutex<Option<TimingProfile>>>,
    /// timingMapInstrumentationActive
    pub map_instrumentation: Arc<AtomicBool>,
}

impl Job {
    pub fn new(progress: ProgressFn, timing: Arc<Mutex<Option<TimingProfile>>>) -> Self {
        Job { cancel: Arc::new(AtomicBool::new(false)), progress, timing, map_instrumentation: Arc::new(AtomicBool::new(false)) }
    }
    pub fn detached() -> Self {
        Job::new(Arc::new(|_, _| {}), Arc::new(Mutex::new(None)))
    }
    #[inline]
    pub fn canceled(&self) -> bool {
        self.cancel.load(Ordering::Relaxed)
    }
    #[inline]
    pub fn check(&self) -> anyhow::Result<()> {
        if self.canceled() { Err(Canceled.into()) } else { Ok(()) }
    }
    pub fn set_progress(&self, v: f64, text: impl Into<String>) {
        if !self.canceled() {
            (self.progress)(v, Some(text.into()));
        }
    }
    pub fn stage(&self, name: &str, ms: f64) {
        if let Some(p) = self.timing.lock().as_mut() {
            p.stages.insert(name.to_string(), ms.max(0.0));
        }
    }
    pub fn accumulate(&self, name: &str, ms: f64) {
        if !self.map_instrumentation.load(Ordering::Relaxed) {
            return;
        }
        if let Some(p) = self.timing.lock().as_mut() {
            *p.stages.entry(name.to_string()).or_insert(0.0) += ms.max(0.0);
        }
    }
    pub fn note(&self, name: &str, value: impl Into<Value>) {
        if let Some(p) = self.timing.lock().as_mut() {
            p.notes.insert(name.to_string(), value.into());
        }
    }
    pub fn instrumenting(&self) -> bool {
        self.map_instrumentation.load(Ordering::Relaxed)
    }
}

pub const FOREGROUND_STAGES: &[(&str, &str)] = &[
    ("decodeAudio", "Audio decode"),
    ("resampleInputs", "Input resampling"),
    ("sharedFftFrontend", "Shared/unified FFT · pitch & attacks"),
    ("pitchTracking", "Pitch tracking / Viterbi"),
    ("foregroundSelection", "Foreground selection"),
    ("attackResample", "V2 input resampling"),
    ("attackFft", "V2 FFT (workers + merge)"),
    ("beatDetection", "Onset / beat selection"),
    ("eventSignatures", "Event signatures"),
    ("similarityAllPairs", "All-pairs similarity"),
    ("similarityPost", "Similarity clustering / pool"),
    ("mapLighting", "Map lighting"),
    ("mapGeneration", "Map generation"),
    ("highlightsVorbisEncode", "Highlights Ogg Vorbis encode"),
    ("coverGeneration", "Cover image"),
    ("previewPayload", "Viewer payload"),
];
pub const MAP_STAGES: &[(&str, &str)] = &[
    ("mapFlowPlanning", "Flow / corpus planner"),
    ("botSecondPass", "8-bot robustness pass"),
    ("mapArcs", "Arcs"),
    ("mapBombs", "Bombs"),
    ("mapWalls", "Walls"),
];
pub const EXPORT_STAGES: &[(&str, &str)] = &[("oggEncode", "Audio encoding"), ("zipPackage", "ZIP serialization")];

#[derive(Clone, Debug)]
pub struct TimingProfile {
    pub version: String,
    pub detector_mode: String,
    pub song: String,
    pub duration_sec: f64,
    pub hardware_threads: usize,
    pub started_at: f64,
    pub started_utc: String,
    pub stages: indexmap_lite::OrderedMap,
    pub notes: Map<String, Value>,
    pub preview_ready_ms: Option<f64>,
    pub package_ready_ms: Option<f64>,
    pub error: Option<String>,
}

/// Tiny insertion-ordered f64 map (JS object semantics for stage names).
pub mod indexmap_lite {
    #[derive(Clone, Debug, Default)]
    pub struct OrderedMap(pub Vec<(String, f64)>);
    impl OrderedMap {
        pub fn get(&self, k: &str) -> Option<f64> {
            self.0.iter().find(|(n, _)| n == k).map(|(_, v)| *v)
        }
        pub fn insert(&mut self, k: String, v: f64) {
            if let Some(slot) = self.0.iter_mut().find(|(n, _)| *n == k) {
                slot.1 = v;
            } else {
                self.0.push((k, v));
            }
        }
        pub fn entry(&mut self, k: String) -> &mut f64 {
            if let Some(i) = self.0.iter().position(|(n, _)| *n == k) {
                return &mut self.0[i].1;
            }
            self.0.push((k, 0.0));
            &mut self.0.last_mut().unwrap().1
        }
    }
    pub trait OrInsert {
        fn or_insert(self, v: f64) -> Self;
    }
    impl OrInsert for &mut f64 {
        fn or_insert(self, _v: f64) -> Self {
            self
        }
    }
}
use indexmap_lite::OrInsert as _;

pub fn iso_now() -> String {
    // new Date().toISOString()
    let ms = crate::util::date_now_ms() as i64;
    let secs = ms.div_euclid(1000);
    let millis = ms.rem_euclid(1000);
    let days = secs.div_euclid(86400);
    let rem = secs.rem_euclid(86400);
    let (h, m, s) = (rem / 3600, (rem % 3600) / 60, rem % 60);
    // civil from days (Howard Hinnant)
    let z = days + 719468;
    let era = z.div_euclid(146097);
    let doe = z - era * 146097;
    let yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
    let y = yoe + era * 400;
    let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    let mp = (5 * doy + 2) / 153;
    let d = doy - (153 * mp + 2) / 5 + 1;
    let mo = if mp < 10 { mp + 3 } else { mp - 9 };
    let y = if mo <= 2 { y + 1 } else { y };
    format!("{y:04}-{mo:02}-{d:02}T{h:02}:{m:02}:{s:02}.{millis:03}Z")
}

impl TimingProfile {
    pub fn new(song: &str, duration: f64) -> Self {
        TimingProfile {
            version: "v0.9.7".into(),
            detector_mode: "v2".into(),
            song: if song.is_empty() { "(unknown)".into() } else { song.into() },
            duration_sec: duration,
            hardware_threads: std::thread::available_parallelism().map(|n| n.get()).unwrap_or(0),
            started_at: now_ms(),
            started_utc: iso_now(),
            stages: Default::default(),
            notes: Map::new(),
            preview_ready_ms: None,
            package_ready_ms: None,
            error: None,
        }
    }

    pub fn accounted_foreground(&self) -> f64 {
        FOREGROUND_STAGES.iter().map(|(k, _)| self.stages.get(k).unwrap_or(0.0)).sum()
    }

    pub fn note_str(&self, key: &str) -> Option<String> {
        self.notes.get(key).map(js_value_string)
    }

    pub fn to_json(&self) -> Value {
        let mut stages = Map::new();
        for (k, v) in &self.stages.0 {
            stages.insert(k.clone(), crate::util::jnum(*v));
        }
        serde_json::json!({
            "version": self.version, "detectorMode": self.detector_mode, "song": self.song,
            "durationSec": crate::util::jnum(self.duration_sec), "hardwareThreads": self.hardware_threads,
            "startedAt": crate::util::jnum(self.started_at), "startedUtc": self.started_utc,
            "stages": stages, "notes": self.notes,
            "previewReadyMs": self.preview_ready_ms.map(crate::util::jnum),
            "packageReadyMs": self.package_ready_ms.map(crate::util::jnum),
            "error": self.error,
        })
    }
}

pub fn js_value_string(v: &Value) -> String {
    match v {
        Value::String(s) => s.clone(),
        Value::Number(n) => n.as_i64().map(|i| i.to_string()).unwrap_or_else(|| js_num_to_string(n.as_f64().unwrap_or(0.0))),
        Value::Bool(b) => b.to_string(),
        Value::Null => "null".into(),
        other => crate::util::json::stringify(other),
    }
}

pub fn format_ms(v: Option<f64>) -> String {
    match v {
        Some(x) if x.is_finite() => format!("{} ms", to_fixed(x, 1)),
        _ => "pending".into(),
    }
}

fn pad_end(s: &str, n: usize) -> String {
    let len = s.encode_utf16().count();
    if len >= n { s.to_string() } else { format!("{s}{}", " ".repeat(n - len)) }
}

/// formatTimingProfiler()
pub fn format_profile(p: Option<&TimingProfile>) -> String {
    let Some(p) = p else { return "No timing profile yet. Create a map first.".into() };
    let s = &p.stages;
    let mut lines = vec![
        format!("Simbers Generation Profiler — {}", p.version),
        format!("Detector: {}", p.detector_mode.to_uppercase()),
        format!("Song: {} ({} s)", p.song, to_fixed(p.duration_sec, 2)),
        format!(
            "Hardware threads: {}; V2 workers: {}",
            p.hardware_threads,
            p.note_str("onsetWorkers").unwrap_or_else(|| "—".into())
        ),
        format!("Started: {}", p.started_utc),
        String::new(),
        "TIME TO PREVIEW (wall-clock)".into(),
        format!("Preview ready: {}", format_ms(p.preview_ready_ms)),
    ];
    for (key, label) in FOREGROUND_STAGES {
        lines.push(format!("{} {}", pad_end(label, 30), format_ms(s.get(key))));
    }
    if let Some(pr) = p.preview_ready_ms {
        lines.push(format!("Browser / unclassified overhead: {}", format_ms(Some((pr - p.accounted_foreground()).max(0.0)))));
    }
    lines.push(String::new());
    lines.push("MAP GENERATION SUBSTAGES (already included above)".into());
    for (key, label) in MAP_STAGES {
        lines.push(format!("{} {}", pad_end(label, 30), format_ms(s.get(key))));
    }
    if let Some(mg) = s.get("mapGeneration") {
        let classified: f64 = MAP_STAGES.iter().map(|(k, _)| s.get(k).unwrap_or(0.0)).sum();
        lines.push(format!("Selections / conversions / other: {}", format_ms(Some((mg - classified).max(0.0)))));
    }
    lines.push(String::new());
    lines.push("BACKGROUND EXPORT (separate from preview)".into());
    for (key, label) in EXPORT_STAGES {
        lines.push(format!("{} {}", pad_end(label, 30), format_ms(s.get(key))));
    }
    lines.push(format!("ZIP ready (since start): {}", format_ms(p.package_ready_ms)));
    lines.push(String::new());
    lines.push("NOTES".into());
    for (k, v) in &p.notes {
        lines.push(format!("{k}: {}", js_value_string(v)));
    }
    if let Some(e) = &p.error {
        lines.push(format!("ERROR: {e}"));
    }
    lines.push(String::new());
    lines.push("Timings include browser scheduling and worker communication; figures are not CPU-only times.".into());
    lines.join("\n")
}

/// Top-4 stage bars + "Other steps" (refreshTimingProfiler).
pub fn summary_bars(p: &TimingProfile) -> (Vec<(String, f64)>, f64) {
    let preview_base = p.preview_ready_ms.unwrap_or_else(|| p.accounted_foreground()).max(1.0);
    let mut ranked: Vec<(&str, &str, f64)> = FOREGROUND_STAGES
        .iter()
        .filter_map(|(k, l)| p.stages.get(k).filter(|v| v.is_finite() && *v > 0.0).map(|v| (*k, *l, v)))
        .collect();
    ranked.sort_by(|a, b| b.2.partial_cmp(&a.2).unwrap_or(std::cmp::Ordering::Equal));
    let mut top: Vec<(String, f64)> = ranked.iter().take(4).map(|(_, l, v)| (l.to_string(), *v)).collect();
    let accounted: f64 = ranked.iter().map(|r| r.2).sum();
    let other = (ranked.iter().skip(4).map(|r| r.2).sum::<f64>()
        + p.preview_ready_ms.map(|pr| (pr - accounted).max(0.0)).unwrap_or(0.0))
    .max(0.0);
    if other > 0.05 {
        top.push(("Other steps".into(), other));
    }
    (top, preview_base)
}
