//! import/youtube.js + simbersYoutubeSquareCover (export/metadata.js).
//!
//! Native differences:
//! - Search and download run through the built-in yt-dlp (see `ytdlp`), a local
//!   background process, instead of public Invidious mirrors behind a CORS proxy.
//!   That removes the rate-limited third-party API and the 403s it caused.
//! - The audio stream is the AAC one (~128 kbps, decoded natively by symphonia);
//!   Opus/WebM is only a fallback (decoded through ffmpeg when present).
//! - Thumbnails and covers come straight from YouTube's image CDN.

pub mod ytdlp;

use anyhow::{Context, Result, bail, ensure};
use serde_json::Value;
use std::ffi::OsString;
use std::io::Read;
use std::path::{Path, PathBuf};
use std::time::{Duration, Instant};

pub const MAX_BYTES: u64 = 256 * 1024 * 1024;
/// Rows on the results page (the original showed Invidious' top 9).
const SEARCH_RESULTS: usize = 9;
/// yt-dlp player clients: visionos first (its streams need no JS challenge and
/// carry no ad wait), then yt-dlp's own defaults as the fallback.
const PLAYER_CLIENTS: &str = "visionos,default";
/// AAC audio-only, else the progressive MP4 (AAC track), else any audio.
const FORMAT: &str = "ba[ext=m4a]/b[ext=mp4]/ba/b";

#[derive(Clone, Debug)]
pub struct Hit {
    pub id: String,
    pub title: String,
    pub author: String,
    pub length: f64,
}

/// importFile.simbersYoutubeSource
#[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
pub struct Source {
    pub id: String,
    pub title: String,
    pub author: String,
}

pub struct Imported {
    pub path: PathBuf,
    pub source: Source,
    pub detected: String,
    pub report: String,
}

/// A failed import: user-facing message plus the diagnostics report.
#[derive(Debug)]
pub struct Failure {
    pub message: String,
    pub report: String,
}

impl std::fmt::Display for Failure {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(&self.message)
    }
}

impl std::error::Error for Failure {}

pub type Cancel<'a> = &'a dyn Fn() -> bool;

fn agent(timeout_ms: u64, family: ureq::config::IpFamily) -> ureq::Agent {
    ureq::Agent::config_builder().timeout_global(Some(Duration::from_millis(timeout_ms))).ip_family(family).user_agent("Mozilla/5.0 SimplifiedSabers").build().into()
}

/// Attempts alternate between IPv4 only and both families: a broken IPv6 route
/// to Google (common, and it only fails after a timeout or a TLS reset) must not
/// sink the request, and IPv6-only networks still get through on the retry.
fn ip_args(attempt: u32) -> Vec<OsString> {
    if attempt % 2 == 1 { vec!["--force-ipv4".into()] } else { vec![] }
}

/// duration(n)
pub fn duration_text(n: f64) -> String {
    let n = if n.is_finite() { n.floor().max(0.0) as u64 } else { 0 };
    if n >= 3600 { format!("{}:{:02}:{:02}", n / 3600, (n / 60) % 60, n % 60) } else { format!("{}:{:02}", n / 60, n % 60) }
}

/// bytes(n)
pub fn bytes_text(n: f64) -> String {
    if !n.is_finite() || n <= 0.0 {
        return "unknown size".into();
    }
    if n >= 1048576.0 { format!("{} MiB", crate::util::to_fixed(n / 1048576.0, 1)) } else { format!("{} KiB", crate::util::js_round(n / 1024.0)) }
}

/// cleanName(v)
pub fn clean_name(v: &str) -> String {
    let v = if v.is_empty() { "YouTube audio" } else { v };
    let replaced: String = v.chars().map(|c| if r#"\/:*?"<>|"#.contains(c) || (c as u32) < 0x20 { '_' } else { c }).collect();
    let collapsed = replaced.split_whitespace().collect::<Vec<_>>().join(" ");
    // .slice(0, 150) counts UTF-16 code units
    let mut out = String::new();
    let mut units = 0;
    for c in collapsed.chars() {
        units += c.len_utf16();
        if units > 150 {
            break;
        }
        out.push(c);
    }
    if out.is_empty() { "YouTube audio".into() } else { out }
}

fn valid_id(x: &str) -> bool {
    x.len() == 11 && x.bytes().all(|b| b.is_ascii_alphanumeric() || b == b'_' || b == b'-')
}

/// ytId(v): video id from a YouTube URL, or None.
pub fn yt_id(v: &str) -> Option<String> {
    let v = v.trim();
    let rest = v.strip_prefix("https://").or_else(|| v.strip_prefix("http://"))?;
    let (host_port, tail) = match rest.find(['/', '?', '#']) {
        Some(i) => (&rest[..i], &rest[i..]),
        None => (rest, ""),
    };
    let host = host_port.rsplit('@').next()?.split(':').next()?.to_lowercase();
    let host = host.strip_prefix("www.").unwrap_or(&host).to_string();
    let path_end = tail.find(['?', '#']).unwrap_or(tail.len());
    let path = &tail[..path_end];
    let query = tail[path_end..].strip_prefix('?').map(|q| q.split('#').next().unwrap_or("")).unwrap_or("");
    if host == "youtu.be" {
        let seg = path.split('/').nth(1).unwrap_or("");
        return if seg.len() >= 11 && valid_id(&seg[..11]) { Some(seg[..11].to_string()) } else { None };
    }
    if ["youtube.com", "m.youtube.com", "music.youtube.com", "youtube-nocookie.com"].contains(&host.as_str()) {
        let from_query = query.split('&').find_map(|kv| {
            let (k, val) = kv.split_once('=').unwrap_or((kv, ""));
            (k == "v").then(|| percent_decode(val))
        });
        let x = from_query.or_else(|| {
            for pre in ["/shorts/", "/embed/", "/live/"] {
                if let Some(r) = path.strip_prefix(pre) {
                    if r.len() >= 11 && valid_id(&r[..11]) {
                        return Some(r[..11].to_string());
                    }
                }
            }
            None
        })?;
        return valid_id(&x).then_some(x);
    }
    None
}

fn percent_decode(s: &str) -> String {
    let b = s.as_bytes();
    let mut out = Vec::with_capacity(b.len());
    let mut i = 0;
    while i < b.len() {
        if b[i] == b'%' && i + 2 < b.len() {
            if let Ok(v) = u8::from_str_radix(&s[i + 1..i + 3], 16) {
                out.push(v);
                i += 3;
                continue;
            }
        }
        out.push(if b[i] == b'+' { b' ' } else { b[i] });
        i += 1;
    }
    String::from_utf8_lossy(&out).into_owned()
}

/// First non-empty string among `keys` (numbers are stringified).
fn text_of(v: Option<&Value>, keys: &[&str]) -> String {
    let Some(v) = v else { return String::new() };
    keys.iter()
        .find_map(|k| match v.get(*k) {
            Some(Value::String(s)) if !s.is_empty() => Some(s.clone()),
            Some(Value::Number(n)) => Some(n.to_string()),
            _ => None,
        })
        .unwrap_or_default()
}

/// search(): a direct video URL short-circuits, otherwise yt-dlp's YouTube search.
pub fn search(input: &str, cancel: Cancel) -> Result<Vec<Hit>> {
    let input = input.trim();
    if input.is_empty() {
        return Ok(vec![]);
    }
    if let Some(id) = yt_id(input) {
        return Ok(vec![Hit { title: format!("YouTube video {id}"), id, author: "Direct URL".into(), length: 0.0 }]);
    }
    let lower = input.to_lowercase();
    if lower.starts_with("http://") || lower.starts_with("https://") {
        bail!("Only YouTube video URLs are supported.");
    }
    let tools = ytdlp::prepare()?;
    // A few spare results: live streams and premieres are skipped.
    let query: Vec<OsString> = vec!["--flat-playlist".into(), "--dump-single-json".into(), "--".into(), format!("ytsearch{}:{input}", SEARCH_RESULTS + 3).into()];
    let mut attempt = 0;
    loop {
        attempt += 1;
        let args: Vec<OsString> = ip_args(attempt).into_iter().chain(query.iter().cloned()).collect();
        let run = ytdlp::run(&tools, &args, cancel, Duration::from_secs(90), &mut |_, _| {})?;
        if run.success {
            let body = run.stdout.iter().find(|l| l.starts_with('{')).context("yt-dlp returned no search results")?;
            let json: Value = serde_json::from_str(body).context("yt-dlp returned unreadable search results")?;
            return Ok(parse_search(&json));
        }
        let err = ytdlp::error_text(&run);
        if attempt < 2 && ytdlp::transient(&err) && ytdlp::pause(Duration::from_millis(800), cancel) {
            continue;
        }
        if cancel() {
            bail!("Cancelled");
        }
        bail!("YouTube search failed. {}", ytdlp::friendly(&err));
    }
}

fn parse_search(data: &Value) -> Vec<Hit> {
    data.get("entries")
        .and_then(Value::as_array)
        .into_iter()
        .flatten()
        .filter(|v| v.get("id").and_then(Value::as_str).is_some_and(valid_id))
        .filter(|v| !matches!(v.get("live_status").and_then(Value::as_str), Some("is_live" | "is_upcoming")))
        .take(SEARCH_RESULTS)
        .map(|v| Hit {
            id: v["id"].as_str().unwrap_or_default().to_string(),
            title: text_of(Some(v), &["title"]),
            author: text_of(Some(v), &["channel", "uploader"]),
            length: v.get("duration").and_then(Value::as_f64).unwrap_or(0.0),
        })
        .collect()
}

/// inspectAudioFile: identify the container from its header.
pub fn sniff(b: &[u8]) -> (Option<&'static str>, String) {
    let ascii = |s: &[u8]| b.len() >= s.len() && &b[..s.len()] == s;
    if b.len() >= 12 && &b[4..8] == b"ftyp" {
        return (Some("m4a"), "MP4/M4A (ftyp)".into());
    }
    if ascii(&[0x1a, 0x45, 0xdf, 0xa3]) {
        return (Some("webm"), "WebM/Matroska (EBML)".into());
    }
    if ascii(b"OggS") {
        return (Some("ogg"), "Ogg".into());
    }
    if ascii(b"ID3") || (b.len() >= 2 && b[0] == 0xff && (b[1] & 0xe0) == 0xe0 && (b[1] & 0x06) != 0) {
        if b.len() >= 2 && b[0] == 0xff && (b[1] & 0xf6) == 0xf0 {
            return (Some("aac"), "AAC (ADTS)".into());
        }
        return (Some("mp3"), "MP3".into());
    }
    if ascii(b"fLaC") {
        return (Some("flac"), "FLAC".into());
    }
    if ascii(b"RIFF") && b.len() >= 12 && &b[8..12] == b"WAVE" {
        return (Some("wav"), "WAV".into());
    }
    let head = &b[..b.len().min(64)];
    if !head.is_empty() && head.iter().all(|&c| c == b'\t' || c == b'\n' || c == b'\r' || (0x20..0x7f).contains(&c)) {
        return (None, "text; not a normal audio header".into());
    }
    (None, "unknown".into())
}

/// What the diagnostics report needs from one import.
#[derive(Default)]
struct Diag {
    attempts: u32,
    network: &'static str,
    runtime: String,
    messages: Vec<String>,
    meta: Option<Value>,
    detected: String,
    file: Option<(String, u64)>,
}

impl Diag {
    fn report(&self, id: &str, started: Instant, error: Option<&str>) -> String {
        let m = self.meta.as_ref();
        let runtime = if self.runtime.is_empty() { "not needed" } else { &self.runtime };
        let mut out = format!("Simbers YouTube audio diagnostics\nVideo ID: {id}\nBackend: yt-dlp {} (built-in) · JS runtime: {runtime}\n", ytdlp::YTDLP_VERSION);
        if m.is_some() {
            let abr = m.and_then(|m| m.get("abr")).and_then(Value::as_f64).map(|a| format!("{} kbps", crate::util::js_round(a))).unwrap_or_else(|| "bitrate unknown".into());
            out += &format!("Reported format: {} · {} / {} · {abr}\n", text_of(m, &["format_id"]), text_of(m, &["ext"]), text_of(m, &["acodec"]));
            let advertised = text_of(m, &["filesize", "filesize_approx"]);
            out += &format!("Advertised file bytes: {}\n", if advertised.is_empty() { "(unknown)" } else { &advertised });
        }
        if !self.detected.is_empty() {
            out += &format!("Detected header: {}\n", self.detected);
        }
        if let Some((name, size)) = &self.file {
            out += &format!("Selected filename: {name}\nFile size: {size} bytes ({})\n", bytes_text(*size as f64));
        }
        out += &format!("Attempts: {} · Network: {} · Time: {:.1} s\nTransfer: yt-dlp\n", self.attempts, self.network, started.elapsed().as_secs_f64());
        if let Some(e) = error {
            out += &format!("Error: {e}\n");
        }
        if !self.messages.is_empty() {
            out += "yt-dlp messages:\n";
            for line in self.messages.iter().take(12) {
                out += &format!("  {line}\n");
            }
        }
        out.trim_end().to_string()
    }
}

/// Status line for one line of yt-dlp output.
fn describe(line: &str) -> Option<String> {
    if let Some(rest) = line.strip_prefix("[simbers] ") {
        let f: Vec<Option<f64>> = rest.split_whitespace().map(|x| x.parse().ok()).collect();
        let done = f.first().copied().flatten()?;
        let total = f.get(1).copied().flatten().or(f.get(2).copied().flatten()).filter(|t| *t > 0.0);
        return Some(match total {
            Some(t) => format!("Downloading audio · {} / {}", bytes_text(done), bytes_text(t)),
            None => format!("Downloading audio · {}", bytes_text(done)),
        });
    }
    if line.contains("Extracting URL") {
        return Some("Contacting YouTube…".into());
    }
    if line.contains("player API JSON") {
        return Some("Requesting audio streams…".into());
    }
    if let Some(rt) = line.split("Solving JS challenges using ").nth(1) {
        return Some(format!("Solving YouTube's player challenge ({})…", rt.trim()));
    }
    if line.contains("Downloading 1 format(s)") {
        return Some("Starting download…".into());
    }
    if line.contains("as required by the site") {
        return Some(match line.split_whitespace().find_map(|w| w.parse::<f64>().ok()) {
            Some(s) => format!("Waiting {} s before downloading, as YouTube requires…", crate::util::js_round(s)),
            None => "Waiting before downloading, as YouTube requires…".into(),
        });
    }
    None
}

fn find_media(dir: &Path, id: &str) -> Option<PathBuf> {
    std::fs::read_dir(dir).ok()?.flatten().map(|e| e.path()).find(|p| {
        p.is_file() && p.file_stem().and_then(|s| s.to_str()) == Some(id) && !matches!(p.extension().and_then(|e| e.to_str()), Some("jsonl" | "txt"))
    })
}

/// choose(v) + importToMap's file handling: downloads the audio with the
/// built-in yt-dlp and returns the saved file.
pub fn import(hit: &Hit, cancel: Cancel, status: &mut dyn FnMut(String)) -> Result<Imported, Failure> {
    let started = Instant::now();
    let mut diag = Diag::default();
    match import_inner(hit, cancel, status, &mut diag) {
        Ok(mut imp) => {
            imp.report = diag.report(&hit.id, started, None);
            Ok(imp)
        }
        Err(e) => {
            // Partial download of a failed or cancelled run (the job kill has
            // already released its file handles).
            let _ = std::fs::remove_dir_all(work_dir());
            let message = e.to_string();
            let report = diag.report(&hit.id, started, Some(&message));
            Err(Failure { message, report })
        }
    }
}

fn download_dir() -> PathBuf {
    std::env::temp_dir().join("SimplifiedSabers").join("youtube")
}

/// Per-process scratch folder for yt-dlp's output.
fn work_dir() -> PathBuf {
    download_dir().join(format!(".yt-dlp-{}", std::process::id()))
}

/// Drops scratch folders left behind by instances that were killed mid-download.
fn remove_stale_work_dirs() {
    let Ok(rd) = std::fs::read_dir(download_dir()) else { return };
    let mine = work_dir();
    for e in rd.flatten() {
        let old = e.metadata().and_then(|m| m.modified()).ok().and_then(|t| t.elapsed().ok()).is_some_and(|age| age > Duration::from_secs(3600));
        if e.file_name().to_string_lossy().starts_with(".yt-dlp-") && e.path() != mine && old {
            let _ = std::fs::remove_dir_all(e.path());
        }
    }
}

fn import_inner(hit: &Hit, cancel: Cancel, status: &mut dyn FnMut(String), diag: &mut Diag) -> Result<Imported> {
    if !ytdlp::is_ready() {
        status("Preparing the built-in yt-dlp…".into());
    }
    let tools = ytdlp::prepare()?;
    remove_stale_work_dirs();
    let dir = download_dir();
    let work = work_dir();
    let meta_file = work.join("meta.jsonl");
    let path_file = work.join("path.txt");
    let mut base: Vec<OsString> = vec![
        "--no-playlist".into(),
        "--extractor-args".into(),
        format!("youtube:player_client={PLAYER_CLIENTS};skip=hls,translated_subs").into(),
        "-f".into(),
        FORMAT.into(),
        "--fixup".into(),
        "never".into(),
        "--no-part".into(),
        "--no-mtime".into(),
        "--force-overwrites".into(),
        "--max-filesize".into(),
        format!("{}M", MAX_BYTES >> 20).into(),
        "--newline".into(),
        "--progress-template".into(),
        "download:[simbers] %(progress.downloaded_bytes)s %(progress.total_bytes)s %(progress.total_bytes_estimate)s".into(),
        "--print-to-file".into(),
        "before_dl:%(.{id,title,channel,uploader,duration,format_id,ext,acodec,abr,filesize,filesize_approx})j".into(),
        meta_file.clone().into_os_string(),
        "--print-to-file".into(),
        "after_move:%(filepath)s".into(),
        path_file.clone().into_os_string(),
        "-P".into(),
        work.clone().into_os_string(),
        "-o".into(),
        "%(id)s.%(ext)s".into(),
    ];
    base.extend(["--".into(), format!("https://www.youtube.com/watch?v={}", hit.id).into()]);
    let downloaded = loop {
        diag.attempts += 1;
        let args: Vec<OsString> = ip_args(diag.attempts).into_iter().chain(base.iter().cloned()).collect();
        diag.network = if diag.attempts % 2 == 1 { "IPv4" } else { "IPv4 + IPv6" };
        let _ = std::fs::remove_dir_all(&work);
        std::fs::create_dir_all(&work).with_context(|| format!("Couldn't create {}", work.display()))?;
        status(if diag.attempts == 1 { "Contacting YouTube…".into() } else { format!("Connection dropped · retrying ({}/3)…", diag.attempts) });
        let mut on_line = |s: ytdlp::Stream, line: &str| {
            if s == ytdlp::Stream::Err {
                if (line.starts_with("WARNING:") || line.starts_with("ERROR:")) && !diag.messages.iter().any(|m| m == line) {
                    diag.messages.push(line.to_string());
                }
                return;
            }
            if let Some(rt) = line.split("Solving JS challenges using ").nth(1) {
                diag.runtime = rt.trim().to_string();
            }
            if let Some(t) = describe(line) {
                status(t);
            }
        };
        let run = ytdlp::run(&tools, &args, cancel, Duration::from_secs(20 * 60), &mut on_line)?;
        if run.success {
            let saved = std::fs::read_to_string(&path_file).ok().map(|s| PathBuf::from(s.trim())).filter(|p| p.is_file()).or_else(|| find_media(&work, &hit.id));
            if let Some(p) = saved {
                break p;
            }
            if run.stdout.iter().any(|l| l.contains("max-filesize")) {
                bail!("Audio is larger than {}", bytes_text(MAX_BYTES as f64));
            }
            bail!("yt-dlp finished without saving an audio file");
        }
        let err = ytdlp::error_text(&run);
        if diag.attempts < 3 && ytdlp::transient(&err) && ytdlp::pause(Duration::from_secs(1), cancel) {
            continue;
        }
        if cancel() {
            bail!("Cancelled");
        }
        bail!(ytdlp::friendly(&err));
    };
    diag.meta = std::fs::read_to_string(&meta_file).ok().and_then(|s| s.lines().rev().find_map(|l| serde_json::from_str(l).ok()));
    let meta = diag.meta.clone();
    let meta = meta.as_ref();
    let title = Some(text_of(meta, &["title"])).filter(|t| !t.is_empty()).unwrap_or_else(|| hit.title.clone());
    let author = if hit.author.is_empty() || hit.author == "Direct URL" { text_of(meta, &["channel", "uploader"]) } else { hit.author.clone() };
    let mut head = [0u8; 64];
    let n = std::fs::File::open(&downloaded)?.read(&mut head)?;
    let (sniffed, detected) = sniff(&head[..n]);
    diag.detected = detected.clone();
    if detected.contains("text; not a normal audio header") {
        bail!("Download contains a text/error page, not an audio file.");
    }
    let reported = text_of(meta, &["ext"]);
    let reported = if reported.is_empty() { downloaded.extension().and_then(|e| e.to_str()).unwrap_or("").to_lowercase() } else { reported };
    let advertised = match reported.as_str() {
        "m4a" | "mp4" => "m4a",
        "webm" => "webm",
        "ogg" => "ogg",
        "opus" => "opus",
        "mp3" => "mp3",
        "aac" => "aac",
        _ => "webm",
    };
    let ext = sniffed.unwrap_or(advertised);
    if sniffed.is_some_and(|s| s != advertised) {
        status(format!("yt-dlp said {} but file header is {}. Using detected format.", advertised.to_uppercase(), ext.to_uppercase()));
    }
    let path = dir.join(format!("{}.{ext}", clean_name(&title)));
    let _ = std::fs::remove_file(&path);
    if std::fs::rename(&downloaded, &path).is_err() {
        std::fs::copy(&downloaded, &path).with_context(|| format!("Couldn't save {}", path.display()))?;
    }
    let _ = std::fs::remove_dir_all(&work);
    let size = std::fs::metadata(&path)?.len();
    ensure!(size > 0, "Empty audio file");
    diag.file = Some((path.file_name().and_then(|n| n.to_str()).unwrap_or("").to_string(), size));
    status(format!("Audio ready · {}. Creating Beat Saber map…", bytes_text(size as f64)));
    let title = if title.is_empty() { clean_name(&hit.id) } else { title };
    Ok(Imported { path, source: Source { id: hit.id.clone(), title, author: if author.is_empty() { "Unknown".into() } else { author } }, detected, report: String::new() })
}

/// Thumbnail URL used in result rows.
pub fn thumb_url(id: &str) -> String {
    format!("https://i.ytimg.com/vi/{id}/mqdefault.jpg")
}

/// Fetch an image with the same acceptance rules as the cover code: IPv4 first
/// (see `ip_args`), then any family, then YouTube's alternate image host.
pub fn fetch_image(url: &str, timeout_ms: u64) -> Option<Vec<u8>> {
    use ureq::config::IpFamily;
    let alt = url.replacen("://i.ytimg.com/", "://img.youtube.com/", 1);
    let mut attempts = vec![(url, IpFamily::Ipv4Only), (url, IpFamily::Any)];
    if alt != url {
        attempts.push((alt.as_str(), IpFamily::Ipv4Only));
    }
    for (target, family) in attempts {
        let Ok(mut res) = agent(timeout_ms, family).get(target).call() else { continue };
        let ty = res.headers().get("content-type").and_then(|v| v.to_str().ok()).unwrap_or("").to_lowercase();
        if !ty.is_empty() && !ty.starts_with("image/") {
            return None;
        }
        let Ok(b) = res.body_mut().with_config().limit(4 * 1024 * 1024 + 1).read_to_vec() else { continue };
        return (b.len() >= 1000 && b.len() <= 4 * 1024 * 1024).then_some(b);
    }
    None
}

/// JPEG → RGBA (width, height, pixels).
pub fn decode_jpeg(b: &[u8]) -> Option<(u32, u32, Vec<u8>)> {
    use zune_core::colorspace::ColorSpace;
    use zune_core::options::DecoderOptions;
    let opts = DecoderOptions::default().jpeg_set_out_colorspace(ColorSpace::RGBA);
    let mut d = zune_jpeg::JpegDecoder::new_with_options(zune_core::bytestream::ZCursor::new(b), opts);
    let px = d.decode().ok()?;
    let info = d.info()?;
    Some((info.width as u32, info.height as u32, px))
}

/// simbersYoutubeSquareCover: 512×512 center crop of hqdefault/mqdefault.
pub fn square_cover(meta: &Source) -> Result<Vec<u8>> {
    if !valid_id(&meta.id) {
        bail!("Invalid YouTube video ID for cover");
    }
    let mut art = None;
    for q in ["hqdefault", "mqdefault"] {
        if let Some(b) = fetch_image(&format!("https://i.ytimg.com/vi/{}/{q}.jpg", meta.id), 4500) {
            if let Some((w, h, px)) = decode_jpeg(&b) {
                if w >= 240 && h >= 135 {
                    art = Some((w, h, px));
                    break;
                }
            }
        }
    }
    let Some((w, h, px)) = art else { bail!("Thumbnail not accessible from YouTube") };
    let src = tiny_skia::Pixmap::from_vec(px, tiny_skia::IntSize::from_wh(w, h).unwrap()).ok_or_else(|| anyhow::anyhow!("bad thumbnail"))?;
    let size = 512.0f32;
    let edge = w.min(h) as f32;
    let (sx, sy) = ((w as f32 - edge) / 2.0, (h as f32 - edge) / 2.0);
    let mut dst = tiny_skia::Pixmap::new(512, 512).unwrap();
    dst.fill(tiny_skia::Color::BLACK);
    let scale = size / edge;
    let paint = tiny_skia::PixmapPaint { quality: tiny_skia::FilterQuality::Bilinear, ..Default::default() };
    dst.draw_pixmap(0, 0, src.as_ref(), &paint, tiny_skia::Transform::from_scale(scale, scale).pre_translate(-sx, -sy), None);
    Ok(dst.encode_png()?)
}

#[cfg(test)]
mod tests {
    #[test]
    fn jpeg_crop() {
        let Ok(p) = std::env::var("SIMBERS_TEST_JPEG") else { return };
        let b = std::fs::read(&p).unwrap();
        let (w, h, px) = super::decode_jpeg(&b).expect("decode");
        assert_eq!(px.len(), (w * h * 4) as usize);
        assert!(w >= 240 && h >= 135);
        let yt = super::yt_id("https://youtu.be/r1PPckDMMSg?t=3").unwrap();
        assert_eq!(yt, "r1PPckDMMSg");
        assert_eq!(super::yt_id("https://www.youtube.com/watch?v=r1PPckDMMSg&list=x").as_deref(), Some("r1PPckDMMSg"));
        assert_eq!(super::yt_id("https://youtube.com/shorts/r1PPckDMMSg").as_deref(), Some("r1PPckDMMSg"));
        assert_eq!(super::yt_id("https://example.com/watch?v=r1PPckDMMSg"), None);
    }

    #[test]
    fn search_and_status_parsing() {
        let json: serde_json::Value = serde_json::from_str(
            r#"{"entries":[{"id":"LhhLcbr9Jqg","title":"Kıvırcık Ali - Felek","channel":"Seyhan Müzik","duration":225.0},
                {"id":"live0000000","title":"Live","channel":"X","duration":null,"live_status":"is_live"},
                {"id":"bad","title":"Bad id"},
                {"id":"VDZ-39lm98A","title":"Felek","uploader":"Kıvırcık Ali - Topic","duration":225}]}"#,
        )
        .unwrap();
        let hits = super::parse_search(&json);
        assert_eq!(hits.len(), 2);
        assert_eq!(hits[0].author, "Seyhan Müzik");
        assert_eq!(hits[1].author, "Kıvırcık Ali - Topic");
        assert_eq!(hits[1].length, 225.0);
        assert_eq!(super::describe("[simbers] 1048576 3640327 NA").as_deref(), Some("Downloading audio · 1.0 MiB / 3.5 MiB"));
        assert_eq!(super::describe("[simbers] 2048 NA 4194304").as_deref(), Some("Downloading audio · 2 KiB / 4.0 MiB"));
        assert_eq!(super::describe("[youtube] [jsc:node] Solving JS challenges using node").as_deref(), Some("Solving YouTube's player challenge (node)…"));
        assert!(super::describe("[download] Sleeping 3.00 seconds as required by the site...").unwrap().contains("3 s"));
        assert!(super::describe("[youtube] Sleeping 0.50 seconds ...").is_none());
    }
}
