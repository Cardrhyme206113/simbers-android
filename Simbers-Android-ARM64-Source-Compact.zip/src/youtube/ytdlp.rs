//! Built-in yt-dlp backend.
//!
//! The official Windows build of yt-dlp (one-folder PyInstaller bundle, which
//! starts in ~0.4 s instead of ~2 s for the one-file exe) and QuickJS-NG (the JS
//! runtime yt-dlp needs for YouTube's player challenges) are compiled into the
//! executable (`vendor/yt-dlp/`) and unpacked once into
//! `%LOCALAPPDATA%\SimplifiedSabers\tools\yt-dlp-<version>`. A Deno or Node ≥ 22
//! found on PATH is preferred by yt-dlp itself because it solves the challenge
//! ~3× faster; the bundled QuickJS covers every other machine.
//!
//! Every call runs yt-dlp as a hidden background process inside a Job Object, so
//! cancelling (or closing the app) kills yt-dlp together with its JS runtime.

use super::Cancel;
use anyhow::{Context, Result, bail, ensure};
use std::ffi::OsString;
use std::io::{BufRead, BufReader};
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};
use std::sync::mpsc;
use std::time::{Duration, Instant};

pub const YTDLP_VERSION: &str = "2026.10.26";
pub const QJS_VERSION: &str = "0.18.0";

#[cfg(windows)]
static YTDLP_ZIP: &[u8] = include_bytes!(concat!(env!("CARGO_MANIFEST_DIR"), "/vendor/yt-dlp/yt-dlp_win.zip"));
#[cfg(windows)]
static QJS_EXE: &[u8] = include_bytes!(concat!(env!("CARGO_MANIFEST_DIR"), "/vendor/yt-dlp/qjs.exe"));

#[derive(Clone, Debug)]
pub struct Tools {
    pub ytdlp: PathBuf,
    pub qjs: Option<PathBuf>,
    pub cache: PathBuf,
}

static TOOLS: std::sync::Mutex<Option<Tools>> = std::sync::Mutex::new(None);

fn tools_root() -> PathBuf {
    dirs::data_local_dir().or_else(dirs::data_dir).unwrap_or_else(|| PathBuf::from(".")).join("SimplifiedSabers").join("tools")
}

/// True once the tools are unpacked in this session (no first-run delay left).
pub fn is_ready() -> bool {
    TOOLS.lock().map(|g| g.is_some()).unwrap_or(false)
}

/// Unpacks the embedded tools on first use. Idempotent and thread-safe:
/// concurrent callers wait for the first one.
pub fn prepare() -> Result<Tools> {
    let mut guard = TOOLS.lock().unwrap_or_else(|e| e.into_inner());
    if let Some(t) = guard.as_ref().filter(|t| t.ytdlp.is_file()) {
        return Ok(t.clone());
    }
    let tools = unpack()?;
    *guard = Some(tools.clone());
    Ok(tools)
}

#[cfg(windows)]
fn unpack() -> Result<Tools> {
    const MARKER: &str = ".simbers-complete";
    let root = tools_root();
    let name = format!("yt-dlp-{YTDLP_VERSION}");
    let dir = root.join(&name);
    let fingerprint = format!("yt-dlp {YTDLP_VERSION} ({} bytes) + QuickJS-NG {QJS_VERSION} ({} bytes)", YTDLP_ZIP.len(), QJS_EXE.len());
    let valid = |d: &Path| {
        std::fs::read_to_string(d.join(MARKER)).is_ok_and(|s| s == fingerprint) && d.join("yt-dlp.exe").is_file() && d.join("qjs.exe").is_file() && d.join("_internal").is_dir()
    };
    let tools_in = |d: &Path| Tools { ytdlp: d.join("yt-dlp.exe"), qjs: Some(d.join("qjs.exe")), cache: root.join("cache") };
    if valid(&dir) {
        return Ok(tools_in(&dir));
    }
    std::fs::create_dir_all(&root).with_context(|| format!("Couldn't create {}", root.display()))?;
    let tmp = root.join(format!(".{name}.partial-{}", std::process::id()));
    let _ = std::fs::remove_dir_all(&tmp);
    let unpacked = (|| -> Result<()> {
        std::fs::create_dir_all(&tmp)?;
        extract_zip(YTDLP_ZIP, &tmp)?;
        std::fs::write(tmp.join("qjs.exe"), QJS_EXE)?;
        std::fs::write(tmp.join(MARKER), &fingerprint)?;
        Ok(())
    })();
    if let Err(e) = unpacked {
        let _ = std::fs::remove_dir_all(&tmp);
        return Err(e.context("Couldn't unpack the built-in yt-dlp"));
    }
    if dir.exists() {
        let _ = std::fs::remove_dir_all(&dir);
    }
    let result = if std::fs::rename(&tmp, &dir).is_ok() {
        tools_in(&dir)
    } else if valid(&dir) {
        // Another instance finished first.
        let _ = std::fs::remove_dir_all(&tmp);
        tools_in(&dir)
    } else {
        // The old folder is locked (a yt-dlp from another instance is running):
        // use the fresh copy where it is for this session.
        log::warn!("[Simbers YouTube] couldn't move yt-dlp into {}; using {}", dir.display(), tmp.display());
        return Ok(tools_in(&tmp));
    };
    cleanup(&root, &name);
    Ok(result)
}

/// Best effort: drops other yt-dlp versions and abandoned partial unpacks.
#[cfg(windows)]
fn cleanup(root: &Path, keep: &str) {
    let Ok(rd) = std::fs::read_dir(root) else { return };
    for e in rd.flatten() {
        let n = e.file_name().to_string_lossy().into_owned();
        let old_version = n.starts_with("yt-dlp-") && n != keep;
        let stale_partial = n.starts_with(".yt-dlp-")
            && n.contains(".partial-")
            && e.metadata().and_then(|m| m.modified()).ok().and_then(|t| t.elapsed().ok()).is_some_and(|age| age > Duration::from_secs(600));
        if old_version || stale_partial {
            let _ = std::fs::remove_dir_all(e.path());
        }
    }
}

/// Non-Windows builds don't embed anything: use a yt-dlp from PATH.
#[cfg(not(windows))]
fn unpack() -> Result<Tools> {
    let exe = std::env::var_os("PATH")
        .and_then(|paths| std::env::split_paths(&paths).map(|d| d.join("yt-dlp")).find(|p| p.is_file()))
        .ok_or_else(|| anyhow::anyhow!("yt-dlp was not found on PATH"))?;
    Ok(Tools { ytdlp: exe, qjs: None, cache: tools_root().join("cache") })
}

/// Minimal ZIP reader for the embedded archive (stored/deflate, no ZIP64),
/// CRC-checked, entries unpacked in parallel.
#[cfg_attr(not(windows), allow(dead_code))]
fn extract_zip(data: &[u8], dest: &Path) -> Result<()> {
    use rayon::prelude::*;
    struct Entry {
        name: String,
        method: usize,
        crc: u32,
        csize: usize,
        size: usize,
        local: usize,
    }
    let rd16 = |i: usize| -> Result<usize> { data.get(i..i + 2).map(|b| u16::from_le_bytes([b[0], b[1]]) as usize).context("truncated zip") };
    let rd32 = |i: usize| -> Result<usize> { data.get(i..i + 4).map(|b| u32::from_le_bytes([b[0], b[1], b[2], b[3]]) as usize).context("truncated zip") };
    let sig = |i: usize, s: u32| data.get(i..i + 4) == Some(&s.to_le_bytes()[..]);
    let lo = data.len().saturating_sub(22 + 0xffff);
    let eocd = (lo..=data.len().saturating_sub(22)).rev().find(|&i| sig(i, 0x0605_4b50)).context("not a zip archive")?;
    let count = rd16(eocd + 10)?;
    let mut p = rd32(eocd + 16)?;
    let mut entries = Vec::with_capacity(count);
    for _ in 0..count {
        ensure!(sig(p, 0x0201_4b50), "corrupt zip directory");
        let (flags, method) = (rd16(p + 8)?, rd16(p + 10)?);
        let (crc, csize, size) = (rd32(p + 16)? as u32, rd32(p + 20)?, rd32(p + 24)?);
        let (n, x, c) = (rd16(p + 28)?, rd16(p + 30)?, rd16(p + 32)?);
        let local = rd32(p + 42)?;
        let name = String::from_utf8_lossy(data.get(p + 46..p + 46 + n).context("truncated zip")?).into_owned();
        ensure!(flags & 1 == 0, "encrypted zip entry {name}");
        ensure!(csize != 0xffff_ffff && size != 0xffff_ffff && local != 0xffff_ffff, "ZIP64 entry {name} is not supported");
        entries.push(Entry { name, method, crc, csize, size, local });
        p += 46 + n + x + c;
    }
    entries.par_iter().try_for_each(|e| -> Result<()> {
        let rel = safe_relative(&e.name).with_context(|| format!("unsafe path in zip: {}", e.name))?;
        let out = dest.join(rel);
        if e.name.ends_with('/') {
            std::fs::create_dir_all(&out)?;
            return Ok(());
        }
        ensure!(sig(e.local, 0x0403_4b50), "corrupt zip entry {}", e.name);
        let start = e.local + 30 + rd16(e.local + 26)? + rd16(e.local + 28)?;
        let raw = data.get(start..start + e.csize).context("truncated zip")?;
        let bytes = match e.method {
            0 => raw.to_vec(),
            8 => miniz_oxide::inflate::decompress_to_vec_with_limit(raw, e.size).map_err(|err| anyhow::anyhow!("couldn't inflate {}: {err:?}", e.name))?,
            m => bail!("unsupported zip method {m} for {}", e.name),
        };
        ensure!(bytes.len() == e.size && crate::export::crc32(&bytes) == e.crc, "checksum mismatch for {}", e.name);
        if let Some(parent) = out.parent() {
            std::fs::create_dir_all(parent)?;
        }
        std::fs::write(&out, &bytes).with_context(|| format!("Couldn't write {}", out.display()))
    })
}

/// Zip entry name → relative path; rejects `..` and drive/stream syntax.
#[cfg_attr(not(windows), allow(dead_code))]
fn safe_relative(name: &str) -> Option<PathBuf> {
    let mut out = PathBuf::new();
    for part in name.split(['/', '\\']) {
        match part {
            "" | "." => {}
            ".." => return None,
            p if p.contains(':') => return None,
            p => out.push(p),
        }
    }
    (!out.as_os_str().is_empty()).then_some(out)
}

// ------------------------------------------------------------------ process

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Stream {
    Out,
    Err,
}

pub struct Finished {
    pub success: bool,
    pub code: Option<i32>,
    pub stdout: Vec<String>,
    pub stderr: Vec<String>,
}

/// Options shared by every call: no user config, our own cache, patient
/// retries (some networks reset TLS sessions to Google hosts at random), and
/// the JS runtimes in yt-dlp's priority order deno > node > quickjs.
fn base_args(t: &Tools) -> Vec<OsString> {
    let mut a: Vec<OsString> = [
        "--ignore-config",
        "--socket-timeout",
        "20",
        "--extractor-retries",
        "6",
        "--retry-sleep",
        "extractor:exp=0.5:4",
        "--retries",
        "10",
        "--retry-sleep",
        "http:exp=0.5:4",
        "--js-runtimes",
        "node",
    ]
    .into_iter()
    .map(OsString::from)
    .collect();
    if let Some(q) = &t.qjs {
        let mut spec = OsString::from("quickjs:");
        spec.push(q);
        a.extend([OsString::from("--js-runtimes"), spec]);
    }
    a.extend([OsString::from("--cache-dir"), t.cache.clone().into_os_string()]);
    a
}

/// Runs yt-dlp hidden, streaming its output lines to `on_line`. Cancel and
/// timeout kill the whole process tree.
pub fn run(tools: &Tools, args: &[OsString], cancel: Cancel, timeout: Duration, on_line: &mut dyn FnMut(Stream, &str)) -> Result<Finished> {
    let mut cmd = Command::new(&tools.ytdlp);
    cmd.args(base_args(tools)).args(args).env("PYTHONIOENCODING", "utf-8").env("PYTHONUTF8", "1").stdin(Stdio::null()).stdout(Stdio::piped()).stderr(Stdio::piped());
    #[cfg(windows)]
    {
        use std::os::windows::process::CommandExt;
        const CREATE_NO_WINDOW: u32 = 0x0800_0000;
        cmd.creation_flags(CREATE_NO_WINDOW);
    }
    let mut child = cmd.spawn().with_context(|| format!("Couldn't start yt-dlp ({})", tools.ytdlp.display()))?;
    let job = KillGroup::attach(&child);
    let (tx, rx) = mpsc::channel::<(Stream, String)>();
    let mut readers = vec![];
    if let Some(out) = child.stdout.take() {
        let tx = tx.clone();
        readers.push(std::thread::spawn(move || read_lines(out, Stream::Out, tx)));
    }
    if let Some(err) = child.stderr.take() {
        let tx = tx.clone();
        readers.push(std::thread::spawn(move || read_lines(err, Stream::Err, tx)));
    }
    drop(tx);
    let started = Instant::now();
    let (mut stdout, mut stderr) = (vec![], vec![]);
    loop {
        match rx.recv_timeout(Duration::from_millis(100)) {
            Ok((s, line)) => {
                on_line(s, &line);
                match s {
                    Stream::Out => stdout.push(line),
                    Stream::Err => stderr.push(line),
                }
            }
            Err(mpsc::RecvTimeoutError::Timeout) => {
                let stop = if cancel() {
                    Some("Cancelled")
                } else if started.elapsed() > timeout {
                    Some("yt-dlp didn't finish in time")
                } else {
                    None
                };
                if let Some(reason) = stop {
                    job.kill(&mut child);
                    let _ = child.wait();
                    bail!(reason);
                }
            }
            Err(mpsc::RecvTimeoutError::Disconnected) => break,
        }
    }
    let status = child.wait()?;
    for r in readers {
        let _ = r.join();
    }
    Ok(Finished { success: status.success(), code: status.code(), stdout, stderr })
}

fn read_lines(r: impl std::io::Read, s: Stream, tx: mpsc::Sender<(Stream, String)>) {
    let mut r = BufReader::new(r);
    let mut buf = Vec::new();
    loop {
        buf.clear();
        match r.read_until(b'\n', &mut buf) {
            Ok(0) | Err(_) => break,
            Ok(_) => {
                let line = String::from_utf8_lossy(&buf).trim_end_matches(['\r', '\n']).to_string();
                if tx.send((s, line)).is_err() {
                    break;
                }
            }
        }
    }
}

/// Sleeps up to `d`, returning early (false) when cancelled.
pub fn pause(d: Duration, cancel: Cancel) -> bool {
    let end = Instant::now() + d;
    while Instant::now() < end {
        if cancel() {
            return false;
        }
        std::thread::sleep(Duration::from_millis(50));
    }
    !cancel()
}

// ------------------------------------------------------------------- errors

/// The most relevant error line of a failed run, without yt-dlp's prefixes.
pub fn error_text(run: &Finished) -> String {
    let line = run.stderr.iter().rev().find(|l| l.starts_with("ERROR:")).or_else(|| run.stderr.iter().rev().find(|l| !l.trim().is_empty()));
    let Some(line) = line else {
        return format!("yt-dlp stopped (exit code {})", run.code.map(|c| c.to_string()).unwrap_or_else(|| "?".into()));
    };
    let mut s = line.trim().trim_start_matches("ERROR:").trim();
    // "[youtube] <id>: message"
    if let Some(rest) = s.strip_prefix('[').and_then(|r| r.split_once("] ")).map(|(_, r)| r) {
        s = rest;
        if let Some((id, msg)) = s.split_once(": ") {
            if id.len() == 11 && !id.contains(' ') {
                s = msg;
            }
        }
    }
    s.to_string()
}

fn has_any(s: &str, needles: &[&str]) -> bool {
    needles.iter().any(|n| s.contains(n))
}

fn bot_check(e: &str) -> bool {
    e.contains("not a bot")
}

/// Network-level failures that a fresh run usually gets past.
pub fn transient(e: &str) -> bool {
    !bot_check(e)
        && !e.contains("HTTP Error 429")
        && has_any(e, &[
            "Unable to download",
            "SSL",
            "timed out",
            "Connection",
            "connection",
            "getaddrinfo",
            "Temporary failure",
            "HTTP Error 5",
            "HTTP Error 403",
            "Remote end closed",
            "IncompleteRead",
            "page needs to be reloaded",
            "Got error",
        ])
}

/// User-facing wording for yt-dlp failures.
pub fn friendly(e: &str) -> String {
    let short: String = e.chars().take(300).collect();
    if bot_check(e) {
        "YouTube wants this network to confirm it isn't a bot (too many requests in a short time). Wait a few minutes, then try again.".into()
    } else if e.contains("HTTP Error 429") {
        "YouTube is rate-limiting this network (HTTP 429). Wait a few minutes, then try again.".into()
    } else if has_any(e, &["confirm your age", "age-restricted", "inappropriate for some users"]) {
        "This video is age-restricted; YouTube only serves it to signed-in accounts. Try another upload.".into()
    } else if e.contains("Private video") {
        "This video is private.".into()
    } else if e.contains("Requested format is not available") {
        "YouTube didn't offer a downloadable audio stream for this video. Try another upload.".into()
    } else if transient(e) {
        format!("Couldn't reach YouTube: {short}")
    } else {
        short
    }
}

// ------------------------------------------------------------- kill group

#[cfg(windows)]
mod job {
    use std::ffi::c_void;

    #[repr(C)]
    struct BasicLimit {
        per_process_user_time_limit: i64,
        per_job_user_time_limit: i64,
        limit_flags: u32,
        minimum_working_set_size: usize,
        maximum_working_set_size: usize,
        active_process_limit: u32,
        affinity: usize,
        priority_class: u32,
        scheduling_class: u32,
    }

    /// JOBOBJECT_EXTENDED_LIMIT_INFORMATION
    #[repr(C)]
    struct ExtendedLimit {
        basic: BasicLimit,
        io_counters: [u64; 6],
        process_memory_limit: usize,
        job_memory_limit: usize,
        peak_process_memory_used: usize,
        peak_job_memory_used: usize,
    }

    const JOB_OBJECT_EXTENDED_LIMIT_INFORMATION: i32 = 9;
    const JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE: u32 = 0x2000;

    unsafe extern "system" {
        fn CreateJobObjectW(attributes: *const c_void, name: *const u16) -> *mut c_void;
        fn SetInformationJobObject(job: *mut c_void, class: i32, info: *const c_void, len: u32) -> i32;
        fn AssignProcessToJobObject(job: *mut c_void, process: *mut c_void) -> i32;
        fn TerminateJobObject(job: *mut c_void, exit_code: u32) -> i32;
        fn CloseHandle(handle: *mut c_void) -> i32;
    }

    /// A Job Object holding yt-dlp and everything it spawns. Dropping it (or the
    /// app exiting) kills whatever is still running.
    pub struct KillGroup(*mut c_void);

    impl KillGroup {
        pub fn attach(child: &std::process::Child) -> KillGroup {
            use std::os::windows::io::AsRawHandle;
            // SAFETY: plain Win32 calls on handles we own; `info` outlives the call.
            unsafe {
                let job = CreateJobObjectW(std::ptr::null(), std::ptr::null());
                if job.is_null() {
                    return KillGroup(job);
                }
                let mut info: ExtendedLimit = std::mem::zeroed();
                info.basic.limit_flags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE;
                let ok = SetInformationJobObject(job, JOB_OBJECT_EXTENDED_LIMIT_INFORMATION, &info as *const ExtendedLimit as *const c_void, std::mem::size_of::<ExtendedLimit>() as u32) != 0
                    && AssignProcessToJobObject(job, child.as_raw_handle()) != 0;
                if !ok {
                    CloseHandle(job);
                    return KillGroup(std::ptr::null_mut());
                }
                KillGroup(job)
            }
        }

        pub fn kill(&self, child: &mut std::process::Child) {
            // SAFETY: the handle is valid while `self` lives.
            if !self.0.is_null() && unsafe { TerminateJobObject(self.0, 1) } != 0 {
                return;
            }
            let _ = child.kill();
        }
    }

    impl Drop for KillGroup {
        fn drop(&mut self) {
            if !self.0.is_null() {
                // SAFETY: closing the handle we created exactly once.
                unsafe { CloseHandle(self.0) };
            }
        }
    }
}

#[cfg(windows)]
use job::KillGroup;

#[cfg(not(windows))]
struct KillGroup;

#[cfg(not(windows))]
impl KillGroup {
    fn attach(_: &std::process::Child) -> KillGroup {
        KillGroup
    }
    fn kill(&self, child: &mut std::process::Child) {
        let _ = child.kill();
    }
}

#[cfg(test)]
mod tests {
    #[test]
    fn errors() {
        let run = super::Finished {
            success: false,
            code: Some(1),
            stdout: vec![],
            stderr: vec![
                "WARNING: [youtube] [SSL: INVALID_SESSION_ID] invalid session id (_ssl.c:1085). Retrying (1/6)...".into(),
                "ERROR: [youtube] LhhLcbr9Jqg: Sign in to confirm you\u{2019}re not a bot. Use --cookies-from-browser".into(),
            ],
        };
        let e = super::error_text(&run);
        assert!(e.starts_with("Sign in to confirm"));
        assert!(!super::transient(&e));
        assert!(super::friendly(&e).contains("isn't a bot"));
        assert!(super::transient("Unable to download API page: [SSL: INVALID_SESSION_ID] invalid session id (_ssl.c:1085)"));
        assert_eq!(super::safe_relative("_internal/python314.dll").unwrap(), std::path::PathBuf::from("_internal").join("python314.dll"));
        assert!(super::safe_relative("../evil.exe").is_none());
        assert!(super::safe_relative("C:/evil.exe").is_none());
    }
}
