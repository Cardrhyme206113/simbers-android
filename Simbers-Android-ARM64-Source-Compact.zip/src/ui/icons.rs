//! The page's inline SVG icons, verbatim, rasterized with resvg and cached as
//! textures. Stroke icons are rendered white and tinted at paint time
//! (CSS `stroke: currentColor`).

use eframe::egui::{self, Color32, Painter, Rect, TextureHandle, TextureOptions};
use std::collections::HashMap;

#[derive(Clone, Copy, PartialEq, Eq, Hash, Debug)]
pub enum Icon {
    Brand,
    Drop,
    Trash,
    Search,
    Bomb,
    Walls,
    Arcs,
    Bot,
    Gear,
    Music,
    Open,
    Download,
    Reprocess,
    Delete,
}

fn source(icon: Icon) -> (&'static str, &'static str, f32) {
    // (viewBox, body, stroke-width)
    match icon {
        Icon::Brand => ("50 62 145 126", "", 0.0),
        Icon::Drop => ("0 0 24 24", r#"<path d="M12 16V3m-5 5 5-5 5 5"/><path d="M4 15v4a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-4"/>"#, 1.8),
        Icon::Trash | Icon::Delete => ("0 0 24 24", r#"<path d="M4 7h16M10 4h4M6 7l1 13h10l1-13M10 11v5M14 11v5"/>"#, 2.0),
        Icon::Search => ("0 0 24 24", r#"<circle cx="10.8" cy="10.8" r="6.3"/><path d="m15.5 15.5 5.1 5.1"/>"#, 2.0),
        Icon::Bomb => ("0 0 48 48", r#"<circle cx="19.5" cy="29" r="12.5"/><rect x="27" y="14" width="8" height="7" rx="1.5" transform="rotate(-45 31 17.5)"/><path d="M34 14c3-4 6-4 9-7M43 7l3-3m-3 3 4 1m-4-1 1 4"/>"#, 2.0),
        Icon::Walls => ("0 0 48 48", r#"<rect x="10" y="9" width="28" height="30" rx="3"/><path d="M10 20h28M10 30h28M19 9v11M29 20v10M19 30v9"/>"#, 2.0),
        Icon::Arcs => ("0 0 48 48", r#"<rect x="7" y="28" width="9" height="9" rx="2"/><rect x="32" y="11" width="9" height="9" rx="2"/><path d="M14 30C19 17 25 14 34 17"/>"#, 2.0),
        Icon::Bot => ("0 0 48 48", r#"<rect x="10" y="16" width="28" height="23" rx="5"/><path d="M24 16V9m-4 0h8M14 10l-3-3m23 3 3-3M8 28H4m40 0h-4"/><circle cx="18" cy="26" r="2.5"/><circle cx="30" cy="26" r="2.5"/><path d="M18 34h12"/>"#, 2.0),
        Icon::Gear => ("0 0 24 24", r#"<path d="M9.7 2.8h4.6l.7 2.2c.5.2 1 .5 1.5.9l2.2-.5 2.3 4-1.6 1.7v1.8l1.6 1.7-2.3 4-2.2-.5c-.5.4-1 .7-1.5.9l-.7 2.2H9.7L9 19c-.5-.2-1-.5-1.5-.9l-2.2.5-2.3-4 1.6-1.7v-1.8L3 9.4l2.3-4 2.2.5c.5-.4 1-.7 1.5-.9l.7-2.2z"/><circle cx="12" cy="12" r="3.2"/>"#, 1.8),
        Icon::Music => ("0 0 24 24", r#"<rect x="3" y="3" width="18" height="18" rx="3"/><path d="M10 8v9a2 2 0 1 1-2-2c1 0 2 .45 2 1V9l7-2v8a2 2 0 1 1-2-2c1 0 2 .45 2 1"/>"#, 1.5),
        Icon::Open => ("0 0 24 24", r#"<rect x="3" y="4" width="18" height="16" rx="2"/><path d="m10 8 6 4-6 4z"/>"#, 2.0),
        Icon::Download => ("0 0 24 24", r#"<path d="M12 3v12m-4-4 4 4 4-4M4 18v3h16v-3"/>"#, 2.0),
        Icon::Reprocess => ("0 0 24 24", r#"<path d="M3 11a9 9 0 1 1 2.4 6.1M3 4v7h7"/>"#, 2.0),
    }
}

const BRAND: &str = r##"<svg xmlns="http://www.w3.org/2000/svg" viewBox="50 62 145 126"><defs><filter id="r" x="-40%" y="-80%" width="180%" height="260%" color-interpolation-filters="sRGB"><feGaussianBlur stdDeviation="11" result="blur"/><feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge></filter><filter id="b" x="-40%" y="-80%" width="180%" height="260%" color-interpolation-filters="sRGB"><feGaussianBlur stdDeviation="11" result="blur"/><feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs><g transform="translate(128 128) rotate(-35.523383)"><rect x="-70" y="-19" width="140" height="18" fill="#ff496f" filter="url(#r)"/></g><g transform="translate(128 128) rotate(35.523383)"><rect x="-70" y="1" width="140" height="18" fill="#4e9fff" filter="url(#b)"/></g></svg>"##;

fn svg(icon: Icon) -> String {
    if icon == Icon::Brand {
        return BRAND.to_string();
    }
    let (vb, body, sw) = source(icon);
    format!(r##"<svg xmlns="http://www.w3.org/2000/svg" viewBox="{vb}" fill="none" stroke="#fff" stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round">{body}</svg>"##)
}

fn rasterize(icon: Icon, w: u32, h: u32) -> Option<egui::ColorImage> {
    let tree = resvg::usvg::Tree::from_str(&svg(icon), &resvg::usvg::Options::default()).ok()?;
    let mut pm = resvg::tiny_skia::Pixmap::new(w.max(1), h.max(1))?;
    let size = tree.size();
    let tf = resvg::tiny_skia::Transform::from_scale(w as f32 / size.width(), h as f32 / size.height());
    resvg::render(&tree, tf, &mut pm.as_mut());
    Some(egui::ColorImage::from_rgba_premultiplied([w as usize, h as usize], pm.data()))
}

#[derive(Default)]
pub struct Icons {
    cache: HashMap<(Icon, u32, u32), Option<TextureHandle>>,
}

impl Icons {
    /// Paints `icon` filling `rect` (CSS px), tinted with `color`.
    pub fn paint(&mut self, ctx: &egui::Context, p: &Painter, icon: Icon, rect: Rect, color: Color32) {
        let ppp = ctx.pixels_per_point();
        let (w, h) = ((rect.width() * ppp).round() as u32, (rect.height() * ppp).round() as u32);
        let tex = self.cache.entry((icon, w, h)).or_insert_with(|| rasterize(icon, w, h).map(|img| ctx.load_texture(format!("icon-{icon:?}-{w}x{h}"), img, TextureOptions::LINEAR)));
        if let Some(t) = tex {
            p.image(t.id(), rect, Rect::from_min_max(egui::pos2(0.0, 0.0), egui::pos2(1.0, 1.0)), color);
        }
    }
}
