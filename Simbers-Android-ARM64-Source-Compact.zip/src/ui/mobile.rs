//! Small-screen Android layout; the desktop layout and rendering engine are unchanged.
//! Uses the exact same App state, history, pipeline, viewer, and settings.
use super::{App, Overlay};
use super::theme;
use eframe::egui::{self, Color32, Rect, RichText, Ui};

pub fn show(app: &mut App, ui: &mut Ui, rect: Rect) {
    if app.viewer_fullscreen && app.viewer.has_map() {
        super::viewer_ui::show(app, ui, rect);
        // Explicit close control even where desktop viewer toolbar overflows.
        egui::Area::new(egui::Id::new("android-viewer-return"))
            .fixed_pos(rect.min + egui::vec2(12.0, 10.0))
            .order(egui::Order::Foreground)
            .show(ui.ctx(), |ui| {
                if ui.add(egui::Button::new("← Maps").fill(theme::SECONDARY)).clicked() {
                    app.viewer_fullscreen = false;
                }
            });
        return;
    }
    ui.spacing_mut().item_spacing = egui::vec2(9.0, 10.0);
    ui.spacing_mut().button_padding = egui::vec2(12.0, 9.0);
    egui::ScrollArea::vertical().auto_shrink([false, false]).show(ui, |ui| {
        ui.set_min_width((rect.width() - 24.0).max(180.0));
        ui.add_space(12.0);
        ui.horizontal(|ui| {
            ui.heading(RichText::new("SIMPLIFIED SABERS").strong().color(Color32::WHITE));
            ui.label(RichText::new(super::VERSION).color(theme::MUTED));
        });
        ui.add_space(6.0);
        if app.overlay == Overlay::Settings {
            settings(app, ui);
            return;
        }
        ui.horizontal_wrapped(|ui| {
            if ui.button("Import audio / ZIP").clicked() { app.pick_file(); }
            if ui.add_enabled(app.analyze_enabled && !app.busy(), egui::Button::new(app.analyze_label)).clicked() { app.run_analysis(); }
            if ui.button("Clear").clicked() { app.back(); }
        });

        ui.group(|ui| {
            ui.label(RichText::new("MAP OPTIONS").strong().color(theme::MUTED));
            ui.horizontal_wrapped(|ui| {
                ui.checkbox(&mut app.features.bombs, "Bombs");
                ui.checkbox(&mut app.features.walls, "Walls");
                ui.checkbox(&mut app.features.arcs, "Arcs");
                ui.checkbox(&mut app.features.bot_optimizer, "8-bot");
            });
            let old = app.intensity;
            let result = ui.add_enabled(!app.busy(), egui::Slider::new(&mut app.intensity, 10.0..=200.0).step_by(5.0).text("Intensity %"));
            if (old - app.intensity).abs() > f64::EPSILON && result.drag_stopped() {
                app.intensity_released();
            }
        });
        ui.horizontal_wrapped(|ui| {
            if ui.button("Settings").clicked() { app.overlay = Overlay::Settings; }
            if ui.add_enabled(app.map_zip.is_some(), egui::Button::new("Export ZIP")).clicked() { app.export_map(); }
            if ui.add_enabled(app.map_zip.is_some(), egui::Button::new("Export replay")).clicked() { app.export_replay(); }
        });
        ui.group(|ui| {
            ui.label(RichText::new("STATUS").strong().color(theme::MUTED));
            ui.label(&app.status);
            ui.add(egui::ProgressBar::new(app.progress.clamp(0.0, 1.0) as f32).show_percentage());
        });
        if app.viewer.has_map() {
            ui.group(|ui| {
                ui.horizontal_wrapped(|ui| {
                    ui.heading("Viewer");
                    if ui.button("Open fullscreen").clicked() { app.viewer_fullscreen = true; }
                    if ui.button("Import BSOR").clicked() { app.import_replay(None); }
                });
                ui.label("Maps render using the original GPU viewer. Tap Open fullscreen to inspect the chart.");
            });
        }
        if app.long_ask.is_some() {
            ui.group(|ui| {
                ui.label(RichText::new("LONG AUDIO").strong());
                ui.label("Choose which section to process:");
                ui.horizontal_wrapped(|ui| {
                    if ui.button("Full song").clicked() { app.answer_long_song(Some(crate::pipeline::LongSongMode::Full)); }
                    if ui.button("Highlights").clicked() { app.answer_long_song(Some(crate::pipeline::LongSongMode::Highlights)); }
                    if ui.button("First section").clicked() { app.answer_long_song(Some(crate::pipeline::LongSongMode::Clip)); }
                    if ui.button("Cancel").clicked() { app.answer_long_song(None); }
                });
            });
        }
        ui.add_space(4.0);
        ui.horizontal(|ui| {
            ui.heading("Past Jobs");
            if ui.small_button("Refresh").clicked() { app.refresh_jobs(); }
        });
        if app.jobs_loading { ui.spinner(); }
        if let Some((notice, _)) = &app.jobs_notice { ui.label(notice); }
        for job in app.jobs.clone() {
            ui.group(|ui| {
                ui.label(RichText::new(&job.name).strong());
                ui.label(RichText::new(format!("{} · {}", crate::storage::history::duration_text(job.duration), crate::storage::history::size_text(job.zip_size as f64))).small().color(theme::MUTED));
                ui.horizontal_wrapped(|ui| {
                    if ui.small_button("Open").clicked() { app.job_open(&job); }
                    if ui.small_button("Export").clicked() { app.job_download(&job); }
                    if ui.small_button("Reprocess").clicked() { app.job_reprocess(&job); }
                    if ui.small_button("Delete").clicked() { app.job_delete(job.id.clone()); }
                });
            });
        }
        ui.add_space(32.0);
    });
}

fn settings(app: &mut App, ui: &mut Ui) {
    ui.horizontal(|ui| {
        if ui.button("← Back").clicked() { app.overlay = Overlay::None; }
        ui.heading("Settings");
    });
    ui.label("Audio quality and viewer mode; full desktop advanced settings are unchanged.");
    let mut bitrate = crate::settings::number("audio.bitrateKbps", 80.0);
    if ui.add(egui::Slider::new(&mut bitrate, 16.0..=128.0).step_by(16.0).text("Audio kbps")).changed() {
        crate::settings::set("audio.bitrateKbps", serde_json::json!(bitrate));
        crate::settings::save();
    }
    let mut mode = crate::settings::get_str("audio.processingMode", "normal");
    ui.horizontal_wrapped(|ui| {
        ui.label("Processing:");
        for (value, label) in [("normal", "Normal"), ("high", "High")] {
            if ui.selectable_label(mode == value, label).clicked() {
                mode = value.into();
                crate::settings::set("audio.processingMode", serde_json::json!(value));
                crate::settings::save();
            }
        }
    });
    if app.viewer.has_map() {
        ui.horizontal_wrapped(|ui| {
            if ui.button("Map view").clicked() { app.viewer.set_replay_visible(false); }
            if ui.button("HMD replay").clicked() { app.viewer.set_replay_visible(true); }
        });
    }
    ui.label(RichText::new("YouTube / yt-dlp import is disabled only in this Android build.").color(theme::MUTED));
}
