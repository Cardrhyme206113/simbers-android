//! `.app > .card` (wide viewport, side-by-side): the map creator column with
//! Past Jobs inline below it, and the viewer shell on the right.
//! Every box uses the geometry measured from the original page.

use super::icons::Icon;
use super::theme::{self, Txt, W, rgba};
use super::widgets::{self, ButtonStyle};
use super::{App, Overlay};
use crate::storage::history::{self, JobRecord};
use eframe::egui::{self, Align2, Color32, Rect, Sense, Ui, pos2, vec2};

const X0: f32 = 13.0;
const CW: f32 = 399.0;

pub fn show(app: &mut App, ui: &mut Ui, full: Rect) {
    let o = full.min;
    let r = |x: f32, y: f32, w: f32, h: f32| Rect::from_min_size(pos2(o.x + x, o.y + y), vec2(w, h));
    let p = ui.painter().clone();
    let ctx = ui.ctx().clone();

    // ---- title row
    let brand = r(19.0, 12.0, 34.0, 34.0);
    app.icons.paint(&ctx, &p, Icon::Brand, Rect::from_center_size(brand.center(), vec2(34.0, 34.0 * 126.0 / 145.0)), Color32::WHITE);
    theme::text(&p, pos2(o.x + 65.0, o.y + 29.5), Align2::LEFT_CENTER, "SIMPLIFIED SABERS", Txt::new(W::Black, 27.0, Color32::WHITE).ls(-0.54));
    let vr = r(354.0, 18.0, 58.0, 22.0);
    theme::boxed(&p, vr, 4.0, Color32::from_rgb(22, 22, 22), 1.0, rgba(255, 255, 255, 0.16));
    theme::text(&p, vr.center(), Align2::CENTER_CENTER, &super::VERSION.to_uppercase(), Txt::new(W::MonoBold, 12.0, theme::MUTED).ls(0.42));
    ui.interact(vr, ui.scope_id().with("ver"), Sense::hover()).on_hover_text(super::VERSION_TITLE);

    // ---- actions
    let busy = app.busy();
    if widgets::button(ui, &mut app.icons, "upload", r(X0, 54.0, 115.0, 42.0), "Upload File", None, ButtonStyle::outline(10.0), true).on_hover_text("Upload audio for generation or an existing Beat Saber ZIP for replay").clicked() {
        app.pick_file();
    }
    if widgets::button(ui, &mut app.icons, "analyze", r(136.0, 54.0, 111.0, 42.0), app.analyze_label, None, ButtonStyle::primary(10.0), app.analyze_enabled && !busy).clicked() {
        app.run_analysis();
    }
    let export_rect = r(254.0, 54.0, 105.0, 42.0);
    if widgets::button(ui, &mut app.icons, "export", export_rect, "Export", None, ButtonStyle::secondary(10.0), true).clicked() {
        app.export_open = !app.export_open;
    }
    if widgets::button(ui, &mut app.icons, "back", r(368.0, 54.0, 44.0, 42.0), "×", None, ButtonStyle::secondary(21.0), true).on_hover_text("Cancel current task / clear map").clicked() {
        app.back();
    }

    // ---- utility: YouTube search form
    let q = r(X0, 104.0, 360.0, 34.0);
    if app.overlay != Overlay::YouTube {
        search_form(app, ui, q, r(378.0, 104.0, 34.0, 34.0), 10.0);
    }

    // ---- feature toggles
    let toggles = [(Icon::Bomb, "Bombs"), (Icon::Walls, "Walls"), (Icon::Arcs, "Arcs"), (Icon::Bot, "8-bot swing optimization · second generation pass")];
    let tw = 94.0;
    let gap = (CW - 4.0 * tw) / 3.0;
    for (i, (icon, title)) in toggles.iter().enumerate() {
        let rect = r(X0 + i as f32 * (tw + gap), 146.0, tw, 42.0);
        let on = match i {
            0 => app.features.bombs,
            1 => app.features.walls,
            2 => app.features.arcs,
            _ => app.features.bot_optimizer,
        };
        let enabled = !busy;
        let resp = widgets::interact(ui, ("toggle", i), rect, enabled).on_hover_text(*title);
        let op = if enabled { 1.0 } else { 0.38 };
        let (fill, border, color) = if on { (theme::PRIMARY, theme::PRIMARY, Color32::WHITE) } else { (Color32::TRANSPARENT, theme::BORDER, theme::MUTED) };
        theme::boxed(&p, rect, 4.0, theme::fade(fill, op), 2.0, theme::fade(border, op));
        app.icons.paint(&ctx, &p, *icon, Rect::from_center_size(rect.center(), vec2(20.0, 20.0)), theme::fade(color, op));
        if resp.has_focus() {
            theme::focus_ring(&p, rect, 4.0);
        }
        if resp.clicked() {
            let f = &mut app.features;
            match i {
                0 => f.bombs = !f.bombs,
                1 => f.walls = !f.walls,
                2 => f.arcs = !f.arcs,
                _ => f.bot_optimizer = !f.bot_optimizer,
            }
            if app.output.is_some() {
                app.status = "Map objects changed. Select Create Map to rebuild.".into();
                app.analyze_label = "Create Map";
            }
        }
    }

    // ---- intensity row
    let gear = Txt::new(W::Black, 11.0, Color32::from_rgb(0xee, 0xee, 0xee));
    if widgets::button(ui, &mut app.icons, "settings", r(X0, 196.0, 34.0, 34.0), "", Some((Icon::Gear, 16.0)), ButtonStyle::outline(11.0).with(Color32::from_rgb(17, 17, 17), Color32::from_rgb(30, 30, 30), 2.0, theme::BORDER).text(gear), true).on_hover_text("settings").clicked() {
        app.overlay = Overlay::Settings;
    }
    let ic = r(53.0, 196.0, 359.0, 34.0);
    theme::boxed(&p, ic, 4.0, Color32::from_rgb(17, 17, 17), 2.0, theme::BORDER);
    theme::text(&p, pos2(o.x + 63.0, ic.center().y), Align2::LEFT_CENTER, "INTENSITY", Txt::new(W::Black, 10.0, theme::MUTED).ls(0.55));
    let value = crate::mapgen::select::intensity_display_text(app.intensity).to_uppercase();
    theme::text(&p, pos2(o.x + 402.0, ic.center().y), Align2::RIGHT_CENTER, &value, Txt::new(W::Black, 10.0, Color32::WHITE));
    intensity_slider(app, ui, r(130.0, 201.0, 193.0, 24.0), busy);

    // ---- status bar
    status_bar(app, ui, r(X0, 233.0, CW, 42.0));

    // ---- Past Jobs (inline)
    past_jobs(app, ui, Rect::from_min_max(pos2(o.x + X0, o.y + 283.0), pos2(o.x + X0 + 401.0, full.max.y - 12.0)));

    // ---- viewer shell
    let viewer = Rect::from_min_max(pos2(o.x + 443.0, o.y + 26.0), pos2(full.max.x - 16.0, full.max.y - 25.0));
    if !app.viewer_fullscreen {
        super::viewer_ui::show(app, ui, viewer);
    }

    // ---- export popover (portalled above everything else in the card)
    if app.export_open {
        export_popover(app, ui, export_rect);
    }
}

pub fn search_form(app: &mut App, ui: &mut Ui, q: Rect, btn: Rect, size: f32) {
    let p = ui.painter().clone();
    let focused = ui.memory(|m| m.has_focus(egui::Id::new("yt-query")));
    let fill = if size > 10.0 { Color32::from_rgb(17, 18, 22) } else { Color32::from_rgb(21, 21, 21) };
    theme::boxed(&p, q, 4.0, fill, 2.0, if focused { theme::PRIMARY } else { theme::BORDER });
    let t = Txt::new(W::Black, size, Color32::from_rgb(241, 241, 241)).ls(0.25);
    let inner = Rect::from_min_max(pos2(q.min.x + if size > 10.0 { 13.0 } else { 10.0 }, q.min.y + 2.0), pos2(q.max.x - 8.0, q.max.y - 2.0));
    let resp = widgets::text_field_ex(ui, "yt-query", inner, &mut app.yt.query, t, "SEARCH YOUTUBE OR PASTE LINK…", Color32::from_rgb(0x9a, 0x9a, 0x9a), 240, true);
    let enter = resp.lost_focus() && ui.input(|i| i.key_pressed(egui::Key::Enter));
    let st = ButtonStyle::outline(10.0).with(Color32::from_rgb(23, 23, 23), Color32::from_rgb(36, 36, 36), 2.0, theme::BORDER);
    let go = widgets::button(ui, &mut app.icons, "yt-search", btn, "", Some((Icon::Search, 16.0)), st, !app.yt.searching).on_hover_text("Search YouTube (Enter)").clicked();
    if enter || go {
        app.yt_search();
    }
}

fn intensity_slider(app: &mut App, ui: &mut Ui, rect: Rect, busy: bool) {
    let id = ui.scope_id().with("intensity");
    let enabled = !busy;
    let resp = ui.interact(rect, id, if enabled { Sense::click_and_drag() } else { Sense::hover() }).on_hover_text("One combined density control: 10% targets at most 1 NPS, 100% targets 4 NPS, and 200% targets 9 NPS. Existing detected attacks and difficulty ratios are preserved. Changes apply when you release the slider.");
    let (min, max, step) = (10.0, 200.0, 5.0);
    let thumb_w = 14.0;
    let span = rect.width() - thumb_w;
    if let Some(pos) = resp.interact_pointer_pos().filter(|_| resp.dragged() || resp.clicked() || resp.drag_started()) {
        let t = ((pos.x - rect.min.x - thumb_w / 2.0) / span).clamp(0.0, 1.0) as f64;
        app.intensity = (((min + t * (max - min)) / step).round() * step).clamp(min, max);
    }
    if resp.has_focus() {
        let (l, rr) = ui.input(|i| (i.key_pressed(egui::Key::ArrowLeft) || i.key_pressed(egui::Key::ArrowDown), i.key_pressed(egui::Key::ArrowRight) || i.key_pressed(egui::Key::ArrowUp)));
        if l || rr {
            app.intensity = (app.intensity + if rr { step } else { -step }).clamp(min, max);
            app.intensity_released();
        }
    }
    if resp.drag_stopped() || resp.clicked() {
        app.intensity_released();
    }
    let p = ui.painter();
    let op = if enabled { 1.0 } else { 0.42 };
    let track = Rect::from_center_size(rect.center(), vec2(rect.width(), 4.0));
    p.rect_filled(track, 2.0, theme::fade(Color32::from_rgb(0x35, 0x35, 0x35), op));
    let t = ((app.intensity - min) / (max - min)) as f32;
    let thumb = Rect::from_center_size(pos2(rect.min.x + thumb_w / 2.0 + t * span, rect.center().y), vec2(thumb_w, 18.0));
    theme::boxed(p, thumb, 2.0, theme::fade(theme::PRIMARY, op), 2.0, theme::fade(Color32::WHITE, op));
    if resp.has_focus() {
        theme::focus_ring(p, thumb, 2.0);
    }
}

fn status_bar(app: &mut App, ui: &mut Ui, rect: Rect) {
    let p = ui.painter();
    theme::boxed(p, rect, 4.0, Color32::from_rgb(23, 23, 23), 0.0, Color32::TRANSPARENT);
    let inner = rect.shrink(2.0);
    p.rect_filled(inner, 0.0, Color32::from_rgb(0x10, 0x10, 0x10));
    let now = crate::util::now_ms();
    if let Some(since) = app.decoding_since {
        // .isDecodingAudio: full-width animated gradient sweep (1.65 s period).
        let phase = ((now / 1650.0) % 1.0) as f32;
        let stops = [(0.0, (0x15, 0x36, 0x5a)), (0.3, (0x20, 0x63, 0xaa)), (0.5, (0x33, 0x8b, 0xdf)), (0.7, (0x20, 0x63, 0xaa)), (1.0, (0x15, 0x36, 0x5a))];
        let n = 64;
        for i in 0..n {
            let x0 = inner.min.x + inner.width() * i as f32 / n as f32;
            let x1 = inner.min.x + inner.width() * (i + 1) as f32 / n as f32;
            // background-size 200%: position u in [0,1) of the gradient.
            let u = ((i as f32 + 0.5) / n as f32 * 0.5 + phase) % 1.0;
            let mut c = stops[0].1;
            for w in stops.windows(2) {
                if u >= w[0].0 && u <= w[1].0 {
                    let k = (u - w[0].0) / (w[1].0 - w[0].0);
                    let l = |a: u8, b: u8| (a as f32 + (b as f32 - a as f32) * k) as u8;
                    c = (l(w[0].1.0, w[1].1.0), l(w[0].1.1, w[1].1.1), l(w[0].1.2, w[1].1.2));
                }
            }
            p.rect_filled(Rect::from_min_max(pos2(x0, inner.min.y), pos2(x1 + 0.5, inner.max.y)), 0.0, Color32::from_rgb(c.0, c.1, c.2));
        }
        let secs = ((now - since) / 1000.0).floor();
        if secs >= 1.0 && app.status.starts_with("Checking audio duration") || app.status.starts_with("Decoding audio") {
            app.status = format!("Decoding audio… {secs}s elapsed");
        }
    } else if app.progress > 0.0 {
        let w = inner.width() * app.progress as f32;
        p.rect_filled(Rect::from_min_size(inner.min, vec2(w, inner.height())), 0.0, theme::PRIMARY);
    }
    p.rect_stroke(rect, 4.0, egui::Stroke::new(2.0, theme::BORDER), egui::StrokeKind::Inside);
    let t = Txt::new(W::MonoBold, 12.0, Color32::WHITE).ls(0.6);
    let label = app.status.to_uppercase();
    let max_w = inner.width() - 24.0;
    let clip = p.with_clip_rect(inner);
    // .statusMultiline: wrap long messages into two balanced lines.
    if theme::measure(&clip, &label, t).x > max_w {
        let t2 = Txt::new(W::MonoBold, 11.0, Color32::WHITE).ls(0.55);
        shadowed(&clip, inner.center(), &label, t2, max_w, true);
    } else {
        shadowed(&clip, inner.center(), &label, t, max_w, false);
    }
}

fn shadowed(p: &egui::Painter, c: egui::Pos2, s: &str, t: Txt, wrap: f32, multi: bool) {
    let sh = t.color(rgba(0, 0, 0, 0.95));
    if multi {
        theme::text_wrapped(p, c + vec2(0.0, 1.0), Align2::CENTER_CENTER, s, sh, wrap);
        theme::text_wrapped(p, c, Align2::CENTER_CENTER, s, t, wrap);
    } else {
        theme::text(p, c + vec2(0.0, 1.0), Align2::CENTER_CENTER, s, sh);
        theme::text(p, c, Align2::CENTER_CENTER, s, t);
    }
}

fn export_popover(app: &mut App, ui: &mut Ui, anchor: Rect) {
    let w = 176.0;
    let rect = Rect::from_min_size(pos2(anchor.max.x - w, anchor.max.y + 6.0), vec2(w, 6.0 + 38.0 + 5.0 + 38.0 + 6.0));
    let layer = egui::LayerId::new(egui::Order::Foreground, egui::Id::new("export-pop"));
    let p = ui.ctx().layer_painter(layer);
    p.rect_filled(rect.translate(vec2(0.0, 8.0)).expand(4.0), 8.0, rgba(0, 0, 0, 0.25));
    theme::boxed(&p, rect, 4.0, Color32::from_rgb(0x1b, 0x1b, 0x1b), 1.0, Color32::from_rgb(0x45, 0x45, 0x45));
    let mut child = ui.new_child(egui::UiBuilder::new().layer_id(layer).max_rect(rect));
    let st = ButtonStyle::primary(11.0).with(Color32::from_rgb(0x29, 0x29, 0x29), Color32::from_rgb(0x39, 0x39, 0x39), 1.0, Color32::TRANSPARENT).text(Txt::new(W::Black, 11.0, Color32::from_rgb(0xf1, 0xf1, 0xf1)));
    let mut st_h = st;
    st_h.hover_border = Color32::from_rgb(0x54, 0x54, 0x54);
    st_h.radius = 3.0;
    let b1 = Rect::from_min_size(rect.min + vec2(6.0, 6.0), vec2(w - 12.0, 38.0));
    let b2 = b1.translate(vec2(0.0, 43.0));
    if widgets::button(&mut child, &mut app.icons, "exp-map", b1, "Export Map", None, st_h, app.map_zip.is_some()).clicked() {
        app.export_map();
    }
    if widgets::button(&mut child, &mut app.icons, "exp-bsor", b2, "Export Replay", None, st_h, true).on_hover_text("Export a simulated BSOR replay from this map").clicked() {
        app.export_replay();
    }
    // Click outside closes (document pointerdown listener).
    if ui.input(|i| i.pointer.any_pressed()) {
        if let Some(pos) = ui.input(|i| i.pointer.interact_pos()) {
            if !rect.contains(pos) && !anchor.contains(pos) {
                app.export_open = false;
            }
        }
    }
    if ui.input(|i| i.key_pressed(egui::Key::Escape)) {
        app.export_open = false;
    }
}

// ------------------------------------------------------------------ Past Jobs

fn past_jobs(app: &mut App, ui: &mut Ui, area: Rect) {
    let p = ui.painter().clone();
    let ox = area.min.x;
    let oy = area.min.y;
    theme::text(&p, pos2(ox, oy + 9.0), Align2::LEFT_TOP, "SIMPLIFIED SABERS", Txt::new(W::MonoBold, 8.0, theme::PRIMARY).ls(0.96));
    let h = theme::text(&p, pos2(ox, oy + 20.0), Align2::LEFT_TOP, "PAST JOBS", Txt::new(W::Black, 16.0, Color32::WHITE).ls(-0.32));
    theme::text(&p, pos2(h.max.x + 10.0, h.max.y - 1.0), Align2::LEFT_BOTTOM, "LAST 25", Txt::new(W::MonoBold, 10.0, Color32::from_rgb(136, 142, 153)).ls(0.4));
    let clear = Rect::from_min_size(pos2(ox + 313.0, oy + 8.0), vec2(87.0, 29.0));
    let cst = ButtonStyle::header(9.0);
    if widgets::button(ui, &mut app.icons, "jobs-clear", clear, "Clear all", Some((Icon::Trash, 13.0)), cst, !app.jobs.is_empty()).on_hover_text("Clear all saved maps").clicked() {
        app.jobs_clear();
    }
    let mut y = oy + 50.0;
    if let Some((msg, err)) = app.jobs_notice.clone() {
        let t = Txt::new(W::Semibold, 11.0, if err { Color32::from_rgb(0xff, 0x9a, 0x9a) } else { theme::MUTED });
        let r = theme::text_wrapped(&p, pos2(ox, y), Align2::LEFT_TOP, &msg, t, 401.0);
        y = r.max.y + 8.0;
    }
    let list = Rect::from_min_max(pos2(ox, y), area.max);
    let mut child = ui.new_child(egui::UiBuilder::new().max_rect(list).layout(egui::Layout::top_down(egui::Align::Min)));
    egui::ScrollArea::vertical().id_salt("jobs-scroll").auto_shrink([false, false]).show(&mut child, |ui| {
        ui.spacing_mut().item_spacing = vec2(0.0, 7.0);
        let pending = app.pending_job.clone();
        let jobs = app.jobs.clone();
        if pending.is_none() && jobs.is_empty() {
            empty_state(app, ui, app.jobs_loading);
            return;
        }
        if let Some(pj) = &pending {
            let values = vec![
                pj.stage.clone(),
                format!("{} AUDIO", history::size_text(pj.audio_size as f64)),
                history::duration_text(pj.duration),
                local_time(pj.created_at),
            ];
            card(app, ui, &pj.name, &values, None, &pj.id);
        }
        for job in jobs.iter().filter(|j| pending.as_ref().is_none_or(|p| p.id != j.id)) {
            let values = vec![
                job.nps.map(|n| format!("EXPERT+ {} NPS", crate::util::to_fixed(n, 2))).unwrap_or_default(),
                format!("{} ZIP", history::size_text(job.zip_size as f64)),
                format!("{} AUDIO", history::size_text(job.audio_size as f64)),
                job.note_count.map(|n| format!("{n} NOTES")).unwrap_or_default(),
                history::duration_text(job.duration),
                local_time(job.created_at),
            ];
            card(app, ui, if job.name.is_empty() { "Untitled map" } else { &job.name }, &values, Some(job), &job.id);
        }
    });
}

fn empty_state(app: &mut App, ui: &mut Ui, loading: bool) {
    let w = ui.available_width();
    let (rect, _) = ui.allocate_exact_size(vec2(w, 160.0), Sense::hover());
    let p = ui.painter();
    let ctx = ui.ctx().clone();
    let icon = Rect::from_center_size(pos2(rect.center().x, rect.min.y + 40.0), vec2(36.0, 36.0));
    app.icons.paint(&ctx, p, Icon::Music, icon, theme::fade(Color32::from_rgb(0x6f, 0x8f, 0xc0), 0.85));
    let head = if loading { "Loading saved maps…" } else { "No maps generated yet" };
    let hr = theme::text(p, pos2(rect.center().x, icon.max.y + 14.0), Align2::CENTER_TOP, head, Txt::new(W::Black, 17.0, Color32::from_rgb(0xf4, 0xf4, 0xf4)));
    let sub = if loading { "Opening your map archive" } else { "Once you generate a map, you'll find it here to open, download or reprocess." };
    theme::text_wrapped(p, pos2(rect.center().x, hr.max.y + 9.0), Align2::CENTER_TOP, sub, Txt::new(W::Regular, 12.0, Color32::from_rgb(0x99, 0x9d, 0xa6)), 380.0);
}

fn local_time(epoch_ms: f64) -> String {
    crate::util::local_datetime_text(epoch_ms)
}

/// `.pastJobsCard`
fn card(app: &mut App, ui: &mut Ui, title: &str, values: &[String], job: Option<&JobRecord>, id: &str) {
    let w = ui.available_width().min(401.0);
    let meta_t = Txt::new(W::MonoBold, 9.0, Color32::from_rgb(153, 157, 166));
    let inner_w = w - 20.0;
    // flex-wrap layout of meta spans (gap 1px 8px, 14px line boxes)
    let p0 = ui.painter().clone();
    let mut lines: Vec<Vec<(String, f32)>> = vec![vec![]];
    let mut lx = 0.0;
    for v in values.iter().filter(|v| !v.is_empty()) {
        let vw = theme::measure(&p0, v, meta_t).x;
        if lx > 0.0 && lx + vw > inner_w {
            lines.push(vec![]);
            lx = 0.0;
        }
        lines.last_mut().unwrap().push((v.clone(), lx));
        lx += vw + 8.0;
    }
    let meta_h = lines.len() as f32 * 14.0 + (lines.len() as f32 - 1.0).max(0.0);
    let h = 1.0 + 9.0 + 14.0 + 4.0 + meta_h + 7.0 + 63.0 + 9.0 + 1.0;
    let (rect, _) = ui.allocate_exact_size(vec2(w, h), Sense::hover());
    let p = ui.painter().clone();
    let generating = job.is_none();
    theme::boxed(&p, rect, 4.0, theme::BG_PANEL, 1.0, if generating { rgba(0, 123, 255, 0.55) } else { rgba(255, 255, 255, 0.12) });
    let x = rect.min.x + 10.0;
    let mut y = rect.min.y + 10.0;
    let tt = Txt::new(W::Black, 12.0, Color32::WHITE);
    let name = theme::ellipsize(&p, title, tt, inner_w);
    theme::text(&p, pos2(x, y + 7.0), Align2::LEFT_CENTER, &name, tt);
    y += 18.0;
    for line in &lines {
        for (v, dx) in line {
            theme::text(&p, pos2(x + dx, y + 7.0), Align2::LEFT_CENTER, v, meta_t);
        }
        y += 15.0;
    }
    y += 6.0;
    let bw = (inner_w - 5.0) / 2.0;
    let base = ButtonStyle::header(9.0).text(Txt::new(W::Black, 9.0, Color32::WHITE).ls(0.135));
    let open = base.with(theme::PRIMARY, theme::PRIMARY_HOVER, 1.0, theme::PRIMARY);
    let dl = base.with(Color32::from_rgb(32, 32, 34), Color32::from_rgb(44, 44, 47), 1.0, Color32::from_rgb(69, 69, 69)).text(Txt::new(W::Black, 9.0, Color32::from_rgb(233, 233, 233)).ls(0.135));
    let del = base.with(Color32::TRANSPARENT, rgba(255, 255, 255, 0.05), 1.0, Color32::from_rgb(69, 69, 69)).text(Txt::new(W::Black, 9.0, Color32::from_rgb(197, 197, 197)).ls(0.135));
    let cells = [
        (Rect::from_min_size(pos2(x, y), vec2(bw, 29.0)), "Open Map", Icon::Open, open),
        (Rect::from_min_size(pos2(x + bw + 5.0, y), vec2(bw, 29.0)), "Download", Icon::Download, dl),
        (Rect::from_min_size(pos2(x, y + 34.0), vec2(bw, 29.0)), "Reprocess", Icon::Reprocess, dl),
        (Rect::from_min_size(pos2(x + bw + 5.0, y + 34.0), vec2(bw, 29.0)), "Delete", Icon::Delete, del),
    ];
    for (i, (r, label, icon, st)) in cells.into_iter().enumerate() {
        let resp = widgets::button(ui, &mut app.icons, &format!("job-{id}-{i}"), r, label, Some((icon, 13.0)), st, !generating);
        let resp = if generating { resp.on_hover_text("Available when the map ZIP and archive are ready") } else { resp.on_hover_text(label) };
        if resp.clicked() {
            if let Some(j) = job {
                let j = j.clone();
                match i {
                    0 => app.job_open(&j),
                    1 => app.job_download(&j),
                    2 => app.job_reprocess(&j),
                    _ => app.job_delete(j.id.clone()),
                }
            }
        }
    }
}

// ----------------------------------------------------------------- viewer

pub(crate) fn decode_png(b: &[u8]) -> Option<egui::ColorImage> {
    let dec = png::Decoder::new(std::io::Cursor::new(b));
    let mut reader = dec.read_info().ok()?;
    let mut buf = vec![0; reader.output_buffer_size()?];
    let info = reader.next_frame(&mut buf).ok()?;
    let (w, h) = (info.width as usize, info.height as usize);
    let data = &buf[..info.buffer_size()];
    let rgba: Vec<u8> = match info.color_type {
        png::ColorType::Rgba => data.to_vec(),
        png::ColorType::Rgb => data.chunks_exact(3).flat_map(|c| [c[0], c[1], c[2], 255]).collect(),
        png::ColorType::Grayscale => data.iter().flat_map(|&g| [g, g, g, 255]).collect(),
        png::ColorType::GrayscaleAlpha => data.chunks_exact(2).flat_map(|c| [c[0], c[0], c[0], c[1]]).collect(),
        _ => return None,
    };
    Some(egui::ColorImage::from_rgba_unmultiplied([w, h], &rgba))
}
