//! Absolute-positioned controls drawn to the original CSS boxes.

use super::icons::{Icon, Icons};
use super::theme::{self, Txt, W};
use eframe::egui::{self, Align2, Color32, Rect, Response, Sense, Ui};

#[derive(Clone, Copy)]
pub struct ButtonStyle {
    pub fill: Color32,
    pub hover_fill: Color32,
    pub border: f32,
    pub border_color: Color32,
    pub hover_border: Color32,
    pub radius: f32,
    pub text: Txt,
    pub disabled_opacity: f32,
}

impl ButtonStyle {
    /// `button` (primary)
    pub const fn primary(size: f32) -> Self {
        ButtonStyle {
            fill: theme::PRIMARY,
            hover_fill: theme::PRIMARY_HOVER,
            border: 0.0,
            border_color: Color32::TRANSPARENT,
            hover_border: Color32::TRANSPARENT,
            radius: 4.0,
            text: Txt::new(W::Bold, size, Color32::WHITE),
            disabled_opacity: 0.42,
        }
    }
    pub const fn secondary(size: f32) -> Self {
        let mut s = Self::primary(size);
        s.fill = theme::SECONDARY;
        s.hover_fill = theme::SECONDARY_HOVER;
        s
    }
    /// `.uploadButton`
    pub const fn outline(size: f32) -> Self {
        ButtonStyle {
            fill: Color32::TRANSPARENT,
            hover_fill: theme::rgba(255, 255, 255, 0.05),
            border: 2.0,
            border_color: theme::BORDER,
            hover_border: Color32::from_rgb(0x66, 0x66, 0x66),
            radius: 4.0,
            text: Txt::new(W::Bold, size, Color32::WHITE),
            disabled_opacity: 0.42,
        }
    }
    /// `.advancedHeaderButton` / `.replaySettingsActions button`
    pub const fn header(size: f32) -> Self {
        ButtonStyle {
            fill: Color32::from_rgb(0x24, 0x24, 0x24),
            hover_fill: Color32::from_rgb(0x30, 0x30, 0x30),
            border: 1.0,
            border_color: Color32::from_rgb(0x44, 0x44, 0x44),
            hover_border: Color32::from_rgb(0x66, 0x66, 0x66),
            radius: 4.0,
            text: Txt::new(W::Bold, size, Color32::WHITE),
            disabled_opacity: 0.35,
        }
    }
    pub const fn with(mut self, fill: Color32, hover: Color32, border: f32, border_color: Color32) -> Self {
        self.fill = fill;
        self.hover_fill = hover;
        self.border = border;
        self.border_color = border_color;
        self.hover_border = border_color;
        self
    }
    pub const fn text(mut self, t: Txt) -> Self {
        self.text = t;
        self
    }
}

pub fn interact(ui: &mut Ui, id: impl std::hash::Hash + std::fmt::Debug, rect: Rect, enabled: bool) -> Response {
    let id = ui.scope_id().with(id);
    let sense = if enabled { Sense::click() } else { Sense::hover() };
    let r = ui.interact(rect, id, sense);
    if enabled && r.hovered() {
        ui.ctx().set_cursor_icon(egui::CursorIcon::PointingHand);
    } else if !enabled && r.hovered() {
        ui.ctx().set_cursor_icon(egui::CursorIcon::NotAllowed);
    }
    r
}

/// Paints a button; `label` is drawn uppercase like the CSS (`text-transform: uppercase`).
pub fn button(ui: &mut Ui, icons: &mut Icons, id: &str, rect: Rect, label: &str, icon: Option<(Icon, f32)>, style: ButtonStyle, enabled: bool) -> Response {
    let resp = interact(ui, id, rect, enabled);
    let p = ui.painter().clone();
    let hovered = enabled && resp.hovered();
    let op = if enabled { 1.0 } else { style.disabled_opacity };
    let fill = if hovered { style.hover_fill } else { style.fill };
    let border = if hovered { style.hover_border } else { style.border_color };
    theme::boxed(&p, rect, style.radius, theme::fade(fill, op), style.border, theme::fade(border, op));
    let text = style.text.color(theme::fade(style.text.color, op));
    let upper = label.to_uppercase();
    let tw = if upper.is_empty() { 0.0 } else { theme::measure(&p, &upper, text).x };
    let (isz, gap) = icon.map(|(_, s)| (s, if upper.is_empty() { 0.0 } else { 5.0 })).unwrap_or((0.0, 0.0));
    let total = isz + gap + tw;
    let mut x = rect.center().x - total / 2.0;
    if let Some((ic, s)) = icon {
        let r = Rect::from_center_size(egui::pos2(x + s / 2.0, rect.center().y), egui::vec2(s, s));
        icons.paint(ui.ctx(), &p, ic, r, text.color);
        x += s + gap;
    }
    if !upper.is_empty() {
        theme::text(&p, egui::pos2(x, rect.center().y), Align2::LEFT_CENTER, &upper, text);
    }
    if resp.has_focus() {
        theme::focus_ring(&p, rect, style.radius);
    }
    resp
}

/// Single-line text field drawn without egui's frame (inside a painted box).
pub fn text_field(ui: &mut Ui, id: &str, rect: Rect, value: &mut String, t: Txt, hint: &str, hint_color: Color32, max_len: usize) -> Response {
    text_field_ex(ui, id, rect, value, t, hint, hint_color, max_len, false)
}

/// `uppercase`: CSS `text-transform: uppercase` on the displayed text only (the value keeps its case).
pub fn text_field_ex(ui: &mut Ui, id: &str, rect: Rect, value: &mut String, t: Txt, hint: &str, hint_color: Color32, max_len: usize, uppercase: bool) -> Response {
    let mut child = ui.new_child(egui::UiBuilder::new().max_rect(rect).layout(egui::Layout::left_to_right(egui::Align::Center)));
    let font = theme::font(t.w, t.size);
    let edit = egui::TextEdit::singleline(value)
        .id(egui::Id::new(id))
        .frame(egui::Frame::NONE)
        .font(font.clone())
        .text_color(t.color)
        .char_limit(max_len)
        .desired_width(rect.width())
        .vertical_align(egui::Align::Center)
        .hint_text(egui::RichText::new(hint).font(font).color(hint_color));
    let mut layouter = move |ui: &Ui, buf: &dyn egui::TextBuffer, wrap: f32| {
        // Per-char uppercase that keeps char count identical (cursor positions stay valid).
        let shown: String = buf.as_str().chars().map(|c| { let mut u = c.to_uppercase(); match (u.next(), u.next()) { (Some(x), None) => x, _ => c } }).collect();
        let mut job = t.job(&shown, wrap);
        job.wrap.max_width = f32::INFINITY;
        ui.fonts_mut(|f| f.layout_job(job))
    };
    let edit = if uppercase { edit.layouter(&mut layouter) } else { edit };
    child.add_sized(rect.size(), edit)
}
