//! Full-screen pages and dialogs: Settings (#advancedSettingsOverlay),
//! YouTube search (#simbersMusicResults), the long-song dialog and the
//! drop overlay.

use super::icons::Icon;
use super::theme::{self, Txt, W, rgba};
use super::widgets::{self, ButtonStyle};
use super::{App, Kind, Overlay};
use crate::pipeline::LongSongMode;
use crate::settings;
use eframe::egui::{self, Align2, Color32, Rect, Sense, Ui, pos2, vec2};
use serde_json::Value;

fn modal_layer(ui: &mut Ui, rect: Rect, name: &str, order: egui::Order) -> Ui {
    let layer = egui::LayerId::new(order, egui::Id::new(name));
    let child = ui.new_child(egui::UiBuilder::new().layer_id(layer).max_rect(rect).id_salt(name));
    // Block interaction with what is underneath.
    child.interact(rect, egui::Id::new((name, "blocker")), Sense::click_and_drag());
    child
}

// ------------------------------------------------------------------ Settings

enum Control {
    Number { min: f64, max: f64, step: f64 },
    BoolSelect(&'static [(&'static str, &'static str)]),
    Select(&'static [(&'static str, &'static str)]),
    NumSelect(&'static [(f64, &'static str)]),
    Range { min: f64, max: f64, step: f64, percent: bool, unit: &'static str },
    Switch,
    ReplayMode,
    ReplayActions,
}

struct Field {
    key: &'static str,
    label: &'static str,
    desc: &'static [(&'static str, bool)],
    control: Control,
    depends: Option<(&'static str, bool)>,
}

struct Section {
    title: &'static str,
    desc: &'static str,
    reset: Option<&'static str>,
    fields: &'static [Field],
    note: Option<&'static str>,
}

macro_rules! plain {
    ($s:expr) => {
        &[($s, false)]
    };
}

const SECTIONS: &[Section] = &[
    Section {
        title: "Generation style",
        desc: "Choose the hand pattern. The same V2 algorithm handles both styles.",
        reset: Some("flow"),
        fields: &[
            Field {
                key: "flow.fullDoubleNotes",
                label: "Saber rhythm",
                desc: &[("Alternating hands", true), (" uses mostly one saber per beat and occasionally both on musical accents. ", false), ("Double notes", true), (" plans both on every beat; if the NPS cap removes doubles, the surviving solos alternate between hands in complete phrases.", false)],
                control: Control::BoolSelect(&[("false", "Mostly one saber · occasional both"), ("true", "Both sabers on every beat")]),
                depends: None,
            },
            Field {
                key: "flow.doubleAccentRate",
                label: "Occasional two-saber accents",
                desc: plain!("Base frequency for occasional two-saber accents. The Intensity slider automatically raises or lowers the NPS ceiling, and doubles adapt to the available room."),
                control: Control::Range { min: 0.04, max: 0.42, step: 0.02, percent: true, unit: "" },
                depends: Some(("flow.fullDoubleNotes", false)),
            },
        ],
        note: None,
    },
    Section {
        title: "Rhythm & notes",
        desc: "Core detection controls, without exposing the low-level FFT internals.",
        reset: Some("detector"),
        fields: &[
            Field { key: "detector.sensitivity", label: "Detection sensitivity", desc: plain!("Higher values detect more subtle rhythmic activity."), control: Control::Number { min: 0.5, max: 2.0, step: 0.05 }, depends: None },
            Field { key: "detector.minimumGapMs", label: "Minimum note spacing", desc: plain!("Minimum time between detected events, in milliseconds."), control: Control::Number { min: 10.0, max: 100.0, step: 5.0 }, depends: None },
            Field { key: "detector.targetEventDensity", label: "Target rhythmic density", desc: plain!("Scales automatic event recovery in quieter passages."), control: Control::Number { min: 0.5, max: 2.0, step: 0.05 }, depends: None },
        ],
        note: None,
    },
    Section {
        title: "Choreography",
        desc: "High-impact flow tuning; original planner and motion constraints remain intact.",
        reset: Some("flow"),
        fields: &[
            Field { key: "flow.wristConservatism", label: "Wrist safety", desc: plain!("Higher values favor physically comfortable cuts."), control: Control::Number { min: 0.75, max: 1.3, step: 0.05 }, depends: None },
            Field { key: "flow.motifStrength", label: "Choreography motif strength", desc: plain!("How strongly repeated musical phrases follow repeatable movement patterns."), control: Control::Number { min: 0.0, max: 1.6, step: 0.05 }, depends: None },
            Field { key: "flow.corpusVariety", label: "Flow variety", desc: plain!("How much source choreography variation the planner may select."), control: Control::Number { min: 0.0, max: 1.0, step: 0.05 }, depends: None },
            Field { key: "flow.laneBalance", label: "Lane balance", desc: plain!("Discourages overusing individual lanes."), control: Control::Number { min: 0.0, max: 1.5, step: 0.05 }, depends: None },
            Field { key: "flow.macroSimilarity", label: "Phrase reuse similarity", desc: plain!("How closely musical phrases must match to reuse choreographed flow."), control: Control::Number { min: 0.65, max: 0.98, step: 0.01 }, depends: None },
        ],
        note: None,
    },
    Section {
        title: "Automation",
        desc: "All six Beat Saber characteristics are included automatically.",
        reset: None,
        fields: &[
            Field { key: "output.autoPreview", label: "Open preview automatically", desc: plain!("Show the generated map when ready."), control: Control::Switch, depends: None },
            Field { key: "output.autoGenerateOnDrop", label: "Auto-create on drop", desc: plain!("Generate immediately when audio is dropped."), control: Control::Switch, depends: None },
        ],
        note: None,
    },
    Section {
        title: "Audio & Encoding",
        desc: "Choose the exported song quality and channel count.",
        reset: Some("audio"),
        fields: &[
            Field { key: "audio.highlightsMinutes", label: "Optional highlights / clip length", desc: plain!("Set the length used for Highlights Edit and First X Minutes."), control: Control::NumSelect(&[(10.0, "10 minutes"), (12.0, "12 minutes (default)"), (15.0, "15 minutes")]), depends: None },
            Field { key: "audio.processingMode", label: "Processing quality", desc: plain!("Normal: one shared 22 kHz FFT and 22 kHz stereo export. High quality: original dual FFT analysis and 32 kHz stereo export."), control: Control::Select(&[("normal", "Normal · faster"), ("high", "High quality · original")]), depends: None },
            Field { key: "audio.bitrateKbps", label: "Audio quality", desc: plain!("Approximate Vorbis VBR quality preset, not an exact output bitrate. Only untrimmed Ogg Vorbis may be reused; Opus is transcoded for Beat Saber."), control: Control::Range { min: 16.0, max: 128.0, step: 16.0, percent: false, unit: " kbps" }, depends: None },
            Field { key: "audio.channels", label: "Output channels", desc: plain!("Stereo keeps left and right audio separate. Mono uses one channel."), control: Control::NumSelect(&[(2.0, "Stereo"), (1.0, "Mono")]), depends: None },
        ],
        note: None,
    },
    Section {
        title: "Replay & BSOR",
        desc: "Control the existing Simbers viewer. Switching modes does not reload the scene or restart the song.",
        reset: None,
        fields: &[
            Field { key: "", label: "Viewer mode", desc: plain!("Replay uses first-person HMD POV. Map uses the original map camera."), control: Control::ReplayMode, depends: None },
            Field { key: "", label: "Replay file", desc: plain!("Export a simulated BSOR from the current map, or import a recorded BSOR for comparison. Upload File also accepts existing Beat Saber ZIPs."), control: Control::ReplayActions, depends: None },
        ],
        note: Some("Generated scores are estimates, not verified Beat Saber collisions. Importing a recording does not change the loaded map."),
    },
];

fn value_text(v: &Value) -> String {
    match v {
        Value::Number(n) => crate::util::js_num_to_string(n.as_f64().unwrap_or(0.0)),
        Value::Bool(b) => b.to_string(),
        Value::String(s) => s.clone(),
        _ => String::new(),
    }
}

pub fn settings(app: &mut App, ui: &mut Ui, rect: Rect) {
    let mut ui = modal_layer(ui, rect, "settings", egui::Order::Middle);
    let ui = &mut ui;
    let p = ui.painter().clone();
    p.rect_filled(rect, 0.0, Color32::from_rgb(0x15, 0x15, 0x17));
    // header
    let header = Rect::from_min_size(rect.min, vec2(rect.width(), 64.0));
    p.rect_filled(header, 0.0, Color32::from_rgb(0x12, 0x12, 0x14));
    p.line_segment([pos2(rect.min.x, header.max.y), pos2(rect.max.x, header.max.y)], egui::Stroke::new(1.0, rgba(255, 255, 255, 0.1)));
    theme::text(&p, pos2(rect.min.x + 14.0, rect.min.y + 12.0), Align2::LEFT_TOP, "SIMPLIFIED SABERS", Txt::new(W::MonoBold, 8.0, theme::PRIMARY).ls(0.96));
    theme::text(&p, pos2(rect.min.x + 14.0, rect.min.y + 24.0), Align2::LEFT_TOP, "SETTINGS", Txt::new(W::Black, 28.0, Color32::WHITE).ls(-0.56));
    let close = Rect::from_min_size(pos2(rect.max.x - 54.0, rect.min.y + 15.0), vec2(42.0, 34.0));
    let reset_all = Rect::from_min_size(pos2(close.min.x - 83.0, rect.min.y + 15.0), vec2(75.0, 34.0));
    if widgets::button(ui, &mut app.icons, "adv-reset-all", reset_all, "Reset all", None, ButtonStyle::header(10.0), true).clicked() {
        settings::reset_all();
        settings::save();
        settings::apply_runtime();
        app.settings_edit.clear();
    }
    let close_st = ButtonStyle::header(18.0).text(Txt::new(W::Regular, 20.0, Color32::WHITE));
    if widgets::button(ui, &mut app.icons, "adv-close", close, "×", None, close_st, true).on_hover_text("Close settings").clicked() || ui.input(|i| i.key_pressed(egui::Key::Escape)) {
        app.overlay = Overlay::None;
        return;
    }
    let body = Rect::from_min_max(pos2(rect.min.x, header.max.y + 1.0), rect.max);
    let content_w = 814.0f32.min(body.width() - 32.0);
    let cx = body.center().x - content_w / 2.0;
    let mut child = ui.new_child(egui::UiBuilder::new().max_rect(body).layout(egui::Layout::top_down(egui::Align::Min)));
    egui::ScrollArea::vertical().id_salt("adv-scroll").auto_shrink([false, false]).show(&mut child, |ui| {
        let (top, _) = ui.allocate_exact_size(vec2(body.width(), 16.0), Sense::hover());
        let _ = top;
        for (si, sec) in SECTIONS.iter().enumerate() {
            section(app, ui, cx, content_w, si, sec);
        }
        timings_section(app, ui, cx, content_w);
        ui.allocate_exact_size(vec2(body.width(), 40.0), Sense::hover());
    });
}

fn section(app: &mut App, ui: &mut Ui, cx: f32, w: f32, si: usize, sec: &Section) {
    let (hr, _) = ui.allocate_exact_size(vec2(ui.available_width(), 66.0), Sense::hover());
    let p = ui.painter().clone();
    theme::text(&p, pos2(cx, hr.min.y), Align2::LEFT_TOP, &sec.title.to_uppercase(), Txt::new(W::Bold, 20.0, Color32::WHITE).ls(-0.4));
    theme::text_wrapped(&p, pos2(cx, hr.min.y + 26.0), Align2::LEFT_TOP, sec.desc, Txt::new(W::Regular, 11.0, Color32::from_rgb(146, 146, 146)), w - 130.0);
    if let Some(cat) = sec.reset {
        let r = Rect::from_min_size(pos2(cx + w - 104.0, hr.min.y + 3.0), vec2(104.0, 34.0));
        let st = ButtonStyle::header(10.0).with(Color32::from_rgb(32, 32, 32), Color32::from_rgb(44, 44, 44), 1.0, Color32::from_rgb(68, 68, 68)).text(Txt::new(W::Bold, 10.0, Color32::from_rgb(221, 221, 221)));
        if widgets::button(ui, &mut app.icons, &format!("reset-{si}"), r, "Reset category", None, st, true).clicked() {
            settings::reset_path(&settings::category_path(cat));
            settings::save();
            settings::apply_runtime();
            app.settings_edit.clear();
        }
    }
    p.line_segment([pos2(cx, hr.max.y - 14.0), pos2(cx + w, hr.max.y - 14.0)], egui::Stroke::new(1.0, rgba(255, 255, 255, 0.1)));
    for (fi, f) in sec.fields.iter().enumerate() {
        if let Some((dep, want)) = f.depends {
            if settings::boolean(dep, false) != want {
                continue;
            }
        }
        field(app, ui, cx, w, (si, fi), f);
    }
    if let Some(note) = sec.note {
        let (r, _) = ui.allocate_exact_size(vec2(ui.available_width(), 30.0), Sense::hover());
        theme::text_wrapped(ui.painter(), pos2(cx, r.min.y + 6.0), Align2::LEFT_TOP, note, Txt::new(W::Regular, 10.0, Color32::from_rgb(133, 133, 133)), w);
    }
    ui.allocate_exact_size(vec2(ui.available_width(), 22.0), Sense::hover());
}

fn field(app: &mut App, ui: &mut Ui, cx: f32, w: f32, key: (usize, usize), f: &Field) {
    let text_w = w - 22.0 - 230.0 - 14.0;
    let p0 = ui.painter().clone();
    // measure description height
    let mut job = egui::text::LayoutJob::default();
    for (s, bold) in f.desc {
        job.append(s, 0.0, egui::TextFormat { font_id: theme::font(if *bold { W::Bold } else { W::Regular }, 10.0), color: if *bold { Color32::from_rgb(0xcf, 0xcf, 0xcf) } else { Color32::from_rgb(133, 133, 133) }, ..Default::default() });
    }
    job.wrap.max_width = text_w;
    let g = p0.layout_job(job);
    let h = (18.0 + 4.0 + g.size().y + 18.0).max(56.0);
    let (row, _) = ui.allocate_exact_size(vec2(ui.available_width(), h), Sense::hover());
    let rect = Rect::from_min_size(pos2(cx, row.min.y), vec2(w, h - 6.0));
    let p = ui.painter().clone();
    theme::boxed(&p, rect, 4.0, rgba(20, 20, 22, 0.46), 1.0, rgba(255, 255, 255, 0.12));
    theme::text(&p, pos2(rect.min.x + 12.0, rect.min.y + 10.0), Align2::LEFT_TOP, f.label, Txt::new(W::Black, 12.0, Color32::from_rgb(242, 242, 242)));
    p.galley(pos2(rect.min.x + 12.0, rect.min.y + 27.0), g, Color32::WHITE);
    let ctl = Rect::from_min_size(pos2(rect.max.x - 12.0 - 230.0, rect.center().y - 17.0), vec2(230.0, 34.0));
    let input_fill = rgba(5, 5, 6, 0.48);
    let input_border = rgba(255, 255, 255, 0.18);
    let mono = Txt::new(W::MonoBold, 11.0, Color32::WHITE);
    let id = format!("adv-{}-{}", key.0, key.1);
    match &f.control {
        Control::Number { min, max, step } => {
            theme::boxed(&p, ctl, 3.0, input_fill, 1.0, input_border);
            let cur = settings::get(f.key).map(|v| value_text(&v)).unwrap_or_default();
            let buf = app.settings_edit.entry(f.key.to_string()).or_insert_with(|| cur.clone());
            let inner = ctl.shrink2(vec2(9.0, 2.0));
            let resp = widgets::text_field(ui, &id, inner, buf, mono, "", theme::MUTED, 16);
            if resp.has_focus() {
                let (up, down) = ui.input(|i| (i.key_pressed(egui::Key::ArrowUp), i.key_pressed(egui::Key::ArrowDown)));
                if up || down {
                    let v: f64 = buf.replace(',', ".").parse().unwrap_or(*min);
                    let n = ((v + if up { *step } else { -*step }).clamp(*min, *max) / step).round() * step;
                    *buf = crate::util::js_num_to_string((n * 1e6).round() / 1e6);
                    let n = (n * 1e6).round() / 1e6;
                    settings::set(f.key, Value::from(n));
                    settings::save();
                    settings::apply_runtime();
                }
            }
            if resp.lost_focus() {
                match buf.replace(',', ".").trim().parse::<f64>() {
                    Ok(v) if v.is_finite() => {
                        let v = v.clamp(*min, *max);
                        settings::set(f.key, Value::from(v));
                        settings::save();
                        settings::apply_runtime();
                        *buf = crate::util::js_num_to_string(v);
                    }
                    _ => *buf = cur,
                }
            }
        }
        Control::BoolSelect(opts) => {
            let cur = settings::boolean(f.key, false).to_string();
            if let Some(v) = select(app, ui, &id, ctl, opts.iter().map(|(v, l)| (v.to_string(), *l)).collect(), &cur) {
                settings::set(f.key, Value::Bool(v == "true"));
                settings::save();
                settings::apply_runtime();
            }
        }
        Control::Select(opts) => {
            let cur = settings::get_str(f.key, opts[0].0);
            if let Some(v) = select(app, ui, &id, ctl, opts.iter().map(|(v, l)| (v.to_string(), *l)).collect(), &cur) {
                settings::set(f.key, Value::String(v));
                settings::save();
                settings::apply_runtime();
            }
        }
        Control::NumSelect(opts) => {
            let cur = crate::util::js_num_to_string(settings::number(f.key, opts[0].0));
            if let Some(v) = select(app, ui, &id, ctl, opts.iter().map(|(v, l)| (crate::util::js_num_to_string(*v), *l)).collect(), &cur) {
                settings::set(f.key, Value::from(v.parse::<f64>().unwrap_or(opts[0].0)));
                settings::save();
                settings::apply_runtime();
            }
        }
        Control::Range { min, max, step, percent, unit } => {
            let track = Rect::from_min_size(ctl.min + vec2(0.0, 3.0), vec2(150.0, 28.0));
            let out = Rect::from_min_size(pos2(ctl.max.x - 72.0, ctl.min.y + 1.0), vec2(72.0, 32.0));
            let mut v = settings::number(f.key, *min);
            let resp = ui.interact(track, ui.scope_id().with(&id), Sense::click_and_drag());
            if let Some(pos) = resp.interact_pointer_pos().filter(|_| resp.dragged() || resp.clicked() || resp.drag_started()) {
                let t = ((pos.x - track.min.x - 7.0) / (track.width() - 14.0)).clamp(0.0, 1.0) as f64;
                v = ((min + t * (max - min) - min) / step).round() * step + min;
                v = (v * 1e6).round() / 1e6;
                settings::set(f.key, Value::from(v));
            }
            if resp.drag_stopped() || resp.clicked() {
                settings::save();
                settings::apply_runtime();
            }
            let tr = Rect::from_center_size(track.center(), vec2(track.width(), 4.0));
            p.rect_filled(tr, 2.0, Color32::from_rgb(0x35, 0x35, 0x35));
            let t = ((v - min) / (max - min)).clamp(0.0, 1.0) as f32;
            let thumb = Rect::from_center_size(pos2(track.min.x + 7.0 + t * (track.width() - 14.0), track.center().y), vec2(14.0, 18.0));
            theme::boxed(&p, thumb, 2.0, theme::PRIMARY, 2.0, Color32::WHITE);
            theme::boxed(&p, out, 3.0, input_fill, 1.0, input_border);
            let label = if *percent { format!("{}%", crate::util::js_round(v * 100.0)) } else { format!("{}{}", crate::util::js_num_to_string(v), unit) };
            theme::text(&p, out.center(), Align2::CENTER_CENTER, &label, Txt::new(W::MonoBold, 10.0, Color32::WHITE));
        }
        Control::Switch => {
            let sw = Rect::from_min_size(pos2(ctl.max.x - 52.0, ctl.center().y - 14.0), vec2(52.0, 28.0));
            let on = settings::boolean(f.key, f.key == "output.autoPreview");
            let resp = widgets::interact(ui, &id, sw, true);
            theme::boxed(&p, sw, 3.0, if on { theme::PRIMARY } else { input_fill }, 1.0, if on { theme::PRIMARY } else { input_border });
            let knob = Rect::from_min_size(pos2(if on { sw.max.x - 24.0 } else { sw.min.x + 4.0 }, sw.min.y + 4.0), vec2(20.0, 20.0));
            p.rect_filled(knob, 2.0, Color32::WHITE);
            if resp.has_focus() {
                theme::focus_ring(&p, sw, 3.0);
            }
            if resp.clicked() {
                settings::set(f.key, Value::Bool(!on));
                settings::save();
                settings::apply_runtime();
            }
        }
        Control::ReplayMode => {
            let cur = if app.viewer.replay_visible { "replay" } else { "map" };
            if let Some(v) = select(app, ui, &id, ctl, vec![("replay".into(), "Replay · HMD POV"), ("map".into(), "Map · Original camera")], cur) {
                app.viewer.set_replay_visible(v == "replay");
            }
        }
        Control::ReplayActions => {
            let b1 = Rect::from_min_size(pos2(ctl.max.x - 130.0 - 8.0 - 150.0, ctl.min.y), vec2(130.0, 34.0));
            let b2 = Rect::from_min_size(pos2(ctl.max.x - 150.0, ctl.min.y), vec2(150.0, 34.0));
            let st = ButtonStyle::header(10.0);
            if widgets::button(ui, &mut app.icons, "rp-import", b1, "Import BSOR", None, st, true).clicked() {
                app.import_replay(None);
            }
            if widgets::button(ui, &mut app.icons, "rp-export", b2, "Export simulated BSOR", None, st, true).clicked() {
                app.export_replay();
            }
        }
    }
}

/// `<select class="advInput">` drawn as the original box with a native-like dropdown.
fn select(app: &mut App, ui: &mut Ui, id: &str, rect: Rect, opts: Vec<(String, &str)>, cur: &str) -> Option<String> {
    let _ = &app;
    let p = ui.painter().clone();
    let resp = widgets::interact(ui, id, rect, true);
    theme::boxed(&p, rect, 3.0, rgba(5, 5, 6, 0.48), 1.0, if resp.hovered() { rgba(255, 255, 255, 0.32) } else { rgba(255, 255, 255, 0.18) });
    let label = opts.iter().find(|(v, _)| v == cur).map(|(_, l)| *l).unwrap_or(opts[0].1);
    let t = Txt::new(W::MonoBold, 11.0, Color32::WHITE);
    let clip = p.with_clip_rect(rect.shrink(1.0));
    let shown = theme::ellipsize(&clip, label, t, rect.width() - 34.0);
    theme::text(&clip, pos2(rect.min.x + 9.0, rect.center().y), Align2::LEFT_CENTER, &shown, t);
    // chevron
    let c = pos2(rect.max.x - 14.0, rect.center().y);
    p.line_segment([c + vec2(-4.0, -2.0), c + vec2(0.0, 2.0)], egui::Stroke::new(1.5, theme::MUTED));
    p.line_segment([c + vec2(0.0, 2.0), c + vec2(4.0, -2.0)], egui::Stroke::new(1.5, theme::MUTED));
    if resp.has_focus() {
        theme::focus_ring(&p, rect, 3.0);
    }
    let popup_id = egui::Id::new((id, "popup"));
    let mut out = None;
    let open = egui::Popup::is_id_open(ui.ctx(), popup_id);
    if resp.clicked() {
        egui::Popup::toggle_id(ui.ctx(), popup_id);
    }
    if open || resp.clicked() {
        egui::Popup::from_response(&resp).id(popup_id).width(rect.width()).close_behavior(egui::PopupCloseBehavior::CloseOnClick).show(|ui| {
            ui.set_min_width(rect.width() - 12.0);
            for (v, l) in &opts {
                let sel = v == cur;
                if ui.add(egui::Button::selectable(sel, egui::RichText::new(*l).font(theme::font(W::MonoBold, 11.0)).color(Color32::WHITE))).clicked() {
                    out = Some(v.clone());
                }
            }
        });
    }
    out
}

fn timings_section(app: &mut App, ui: &mut Ui, cx: f32, w: f32) {
    let (hr, _) = ui.allocate_exact_size(vec2(ui.available_width(), 66.0), Sense::hover());
    let p = ui.painter().clone();
    theme::text(&p, pos2(cx, hr.min.y), Align2::LEFT_TOP, "GENERATION TIMINGS", Txt::new(W::Bold, 20.0, Color32::WHITE).ls(-0.4));
    theme::text(&p, pos2(cx, hr.min.y + 26.0), Align2::LEFT_TOP, "Total duration and the slowest steps, without nested duration charts.", Txt::new(W::Regular, 11.0, Color32::from_rgb(146, 146, 146)));
    p.line_segment([pos2(cx, hr.max.y - 14.0), pos2(cx + w, hr.max.y - 14.0)], egui::Stroke::new(1.0, rgba(255, 255, 255, 0.1)));
    let prof = app.last_profile.clone();
    let fmt = |v: Option<f64>| crate::job::format_ms(v);
    let song = prof.as_ref().map(|p| crate::storage::history::duration_text(p.duration_sec)).filter(|s| !s.is_empty()).unwrap_or_else(|| "—".into());
    let preview = prof.as_ref().and_then(|p| p.preview_ready_ms);
    let zip = prof.as_ref().and_then(|p| p.package_ready_ms);
    let metrics = [("Song", song), ("Preview ready", if preview.is_some() { fmt(preview) } else { "—".into() }), ("ZIP ready", if zip.is_some() { fmt(zip) } else { "—".into() })];
    let (mr, _) = ui.allocate_exact_size(vec2(ui.available_width(), 70.0), Sense::hover());
    let mw = (w - 2.0 * 8.0) / 3.0;
    for (i, (k, v)) in metrics.iter().enumerate() {
        let r = Rect::from_min_size(pos2(cx + i as f32 * (mw + 8.0), mr.min.y), vec2(mw, 61.0));
        theme::boxed(&p, r, 7.0, Color32::from_rgb(25, 27, 31), 1.0, Color32::from_rgb(50, 53, 58));
        theme::text(&p, r.min + vec2(12.0, 10.0), Align2::LEFT_TOP, k, Txt::new(W::Semibold, 11.0, Color32::from_rgb(0x9a, 0xa3, 0xad)));
        theme::text(&p, r.min + vec2(12.0, 28.0), Align2::LEFT_TOP, v, Txt::new(W::Black, 15.0, Color32::from_rgb(239, 243, 250)));
    }
    let (hh, _) = ui.allocate_exact_size(vec2(ui.available_width(), 24.0), Sense::hover());
    let r = theme::text(&p, pos2(cx, hh.min.y + 4.0), Align2::LEFT_TOP, "SLOWEST GENERATION STEPS", Txt::new(W::Black, 11.0, Color32::from_rgb(224, 230, 237)).ls(0.385));
    let note = if prof.is_some() { "" } else { "Create a map to measure" };
    theme::text(&p, pos2(r.max.x + 8.0, r.max.y), Align2::LEFT_BOTTOM, note, Txt::new(W::Regular, 10.0, theme::MUTED));
    if let Some(pr) = &prof {
        let (bars, total) = crate::job::summary_bars(pr);
        for (name, ms) in bars.iter().take(6) {
            let (br, _) = ui.allocate_exact_size(vec2(ui.available_width(), 22.0), Sense::hover());
            theme::text(&p, pos2(cx, br.center().y), Align2::LEFT_CENTER, name, Txt::new(W::Semibold, 11.0, Color32::from_rgb(216, 223, 232)));
            let bx = cx + 220.0;
            let bwid = w - 220.0 - 80.0;
            let track = Rect::from_min_size(pos2(bx, br.center().y - 4.0), vec2(bwid, 8.0));
            p.rect_filled(track, 4.0, Color32::from_rgb(36, 39, 44));
            let frac = if total > 0.0 { (ms / total).clamp(0.0, 1.0) as f32 } else { 0.0 };
            p.rect_filled(Rect::from_min_size(track.min, vec2(bwid * frac, 8.0)), 4.0, theme::PRIMARY);
            theme::text(&p, pos2(cx + w, br.center().y), Align2::RIGHT_CENTER, &fmt(Some(*ms)), Txt::new(W::MonoBold, 10.0, Color32::from_rgb(216, 223, 232)));
        }
    }
    let (hint, _) = ui.allocate_exact_size(vec2(ui.available_width(), 26.0), Sense::hover());
    let state = if prof.as_ref().and_then(|p| p.package_ready_ms).is_some() || app.map_zip.is_some() { "ZIP ready" } else { "Not started" };
    theme::text(&p, pos2(cx, hint.min.y + 8.0), Align2::LEFT_TOP, &format!("Relative to preview time. ZIP export runs separately. {state}."), Txt::new(W::Regular, 10.0, theme::MUTED));
    // Detailed report
    let report = crate::job::format_profile(prof.as_ref());
    let (tr, _) = ui.allocate_exact_size(vec2(ui.available_width(), 44.0), Sense::hover());
    let copy = Rect::from_min_size(pos2(cx, tr.min.y + 6.0), vec2(120.0, 34.0));
    if widgets::button(ui, &mut app.icons, "timing-copy", copy, "Copy report", None, ButtonStyle::header(10.0), prof.is_some()).clicked() {
        ui.ctx().copy_text(report.clone());
        app.settings_status = "Timing report copied.".into();
    }
    let json = Rect::from_min_size(pos2(cx + 128.0, tr.min.y + 6.0), vec2(120.0, 34.0));
    if widgets::button(ui, &mut app.icons, "timing-json", json, "Export JSON", None, ButtonStyle::header(10.0), prof.is_some()).clicked() {
        if let Some(pr) = &prof {
            let _ = crate::platform::save_bytes("simbers-timing-profile.json", &serde_json::to_vec_pretty(&pr.to_json()).unwrap_or_default());
        }
    }
    if !app.settings_status.is_empty() {
        theme::text(&p, pos2(json.max.x + 12.0, json.center().y), Align2::LEFT_CENTER, &app.settings_status, Txt::new(W::Semibold, 10.0, theme::MUTED));
    }
    let lines = report.lines().count().max(3) as f32;
    let (box_r, _) = ui.allocate_exact_size(vec2(ui.available_width(), (lines * 13.0 + 20.0).min(320.0)), Sense::hover());
    let rr = Rect::from_min_size(pos2(cx, box_r.min.y), vec2(w, box_r.height() - 4.0));
    theme::boxed(&p, rr, 3.0, rgba(5, 5, 6, 0.48), 1.0, rgba(255, 255, 255, 0.18));
    let text = if prof.is_some() { report } else { "No timing profile yet. Create a map first.".into() };
    let clip = p.with_clip_rect(rr.shrink(1.0));
    theme::text_wrapped(&clip, rr.min + vec2(10.0, 8.0), Align2::LEFT_TOP, &text, Txt::new(W::Mono, 10.5, Color32::from_rgb(0xd0, 0xd0, 0xd0)), w - 20.0);
}

// ------------------------------------------------------------------ YouTube

pub fn youtube(app: &mut App, ui: &mut Ui, rect: Rect) {
    let mut ui = modal_layer(ui, rect, "youtube", egui::Order::Middle);
    let ui = &mut ui;
    let p = ui.painter().clone();
    p.rect_filled(rect, 0.0, Color32::from_rgb(17, 18, 20));
    let top = Rect::from_min_size(rect.min, vec2(rect.width(), 142.0));
    p.rect_filled(top, 0.0, Color32::from_rgb(26, 27, 29));
    let cw = 1000.0f32.min(rect.width() - 32.0);
    let cx = rect.center().x - cw / 2.0;
    theme::text(&p, pos2(cx, rect.min.y + 24.0), Align2::LEFT_TOP, "SIMPLIFIED SABERS / AUDIO IMPORT", Txt::new(W::MonoBold, 9.0, Color32::from_rgb(139, 145, 153)).ls(0.63));
    theme::text(&p, pos2(cx, rect.min.y + 43.0), Align2::LEFT_TOP, "SEARCH YOUTUBE", Txt::new(W::Black, 30.0, Color32::from_rgb(242, 243, 245)).ls(-0.75));
    let close = Rect::from_min_size(pos2(cx + cw - 38.0, rect.min.y + 27.0), vec2(38.0, 34.0));
    let cst = ButtonStyle::header(18.0).with(Color32::from_rgb(34, 36, 40), Color32::from_rgb(46, 49, 54), 1.0, Color32::from_rgb(65, 68, 73)).text(Txt::new(W::Regular, 20.0, Color32::from_rgb(214, 215, 217)));
    if widgets::button(ui, &mut app.icons, "yt-close", close, "×", None, cst, true).on_hover_text("Back to map creator").clicked() || ui.input(|i| i.key_pressed(egui::Key::Escape)) {
        app.overlay = Overlay::None;
        if app.yt.searching {
            if let Some(c) = app.yt.cancel.take() {
                c.store(true, std::sync::atomic::Ordering::Relaxed);
            }
            app.yt.searching = false;
        }
        return;
    }
    // search dock (the form is moved here while the page is open)
    let q = Rect::from_min_size(pos2(cx, rect.min.y + 85.0), vec2(cw - 56.0, 44.0));
    let b = Rect::from_min_size(pos2(cx + cw - 48.0, rect.min.y + 85.0), vec2(48.0, 44.0));
    super::main_view::search_form(app, ui, q, b, 12.0);
    // results head
    let head = Rect::from_min_size(pos2(rect.min.x, rect.min.y + 142.0), vec2(rect.width(), 42.0));
    p.rect_filled(head, 0.0, Color32::from_rgb(25, 26, 28));
    theme::text(&p, pos2(cx, head.center().y), Align2::LEFT_CENTER, &app.yt.title.to_uppercase(), Txt::new(W::MonoBold, 11.0, Color32::from_rgb(236, 236, 236)).ls(0.385));
    theme::text(&p, pos2(cx + cw, head.center().y), Align2::RIGHT_CENTER, "SELECT A TRACK TO IMPORT", Txt::new(W::MonoBold, 9.0, Color32::from_rgb(125, 134, 142)).ls(0.36));
    // footer / status
    let footer_on = app.yt.busy || app.yt.retry || (!app.yt.last_report.is_empty() && app.yt.kind == Kind::Error);
    let status_h = 40.0;
    let footer_h = if footer_on { 52.0 } else { 0.0 };
    let status = Rect::from_min_size(pos2(rect.min.x, rect.max.y - status_h - footer_h), vec2(rect.width(), status_h));
    let list = Rect::from_min_max(pos2(rect.min.x, head.max.y), pos2(rect.max.x, status.min.y));
    results_list(app, ui, list, cx, cw);
    let sc = match app.yt.kind {
        Kind::Error => Color32::from_rgb(0xff, 0x9a, 0x9a),
        Kind::Warning => Color32::from_rgb(244, 197, 116),
        Kind::Success => Color32::from_rgb(0x8f, 0xe3, 0xa8),
        Kind::Info => Color32::from_rgb(182, 198, 213),
    };
    p.rect_filled(status, 0.0, Color32::from_rgb(24, 26, 30));
    let clip = p.with_clip_rect(status);
    let st = Txt::new(W::Semibold, 11.0, sc);
    let s = theme::ellipsize(&clip, &app.yt.status, st, cw);
    theme::text(&clip, pos2(cx, status.center().y), Align2::LEFT_CENTER, &s, st);
    if footer_on {
        let f = Rect::from_min_size(pos2(rect.min.x, status.max.y), vec2(rect.width(), footer_h));
        p.rect_filled(f, 0.0, Color32::from_rgb(24, 26, 30));
        let mut x = cx;
        let st = ButtonStyle::header(10.0);
        let mut btn = |ui: &mut Ui, app: &mut App, id: &str, label: &str, w: f32| {
            let r = Rect::from_min_size(pos2(x, f.min.y + 8.0), vec2(w, 34.0));
            x += w + 8.0;
            widgets::button(ui, &mut app.icons, id, r, label, None, st, true).clicked()
        };
        if app.yt.busy && btn(ui, app, "yt-cancel", "Cancel download", 150.0) {
            app.yt_cancel();
        }
        if app.yt.retry && !app.yt.busy && btn(ui, app, "yt-retry", "Retry download", 140.0) {
            if let Some(h) = app.yt.last_hit.clone() {
                app.yt_choose(h);
            }
        }
        if !app.yt.busy && app.yt.last_raw.is_some() && btn(ui, app, "yt-raw", "Save raw audio", 140.0) {
            if let Some(src) = app.yt.last_raw.clone() {
                let name = src.file_name().and_then(|n| n.to_str()).unwrap_or("audio").to_string();
                if let Ok(bytes) = std::fs::read(src) {
                    let _ = crate::platform::save_bytes(&name, &bytes);
                }
            }
        }
        if !app.yt.busy && !app.yt.last_report.is_empty() && btn(ui, app, "yt-report", "Copy report", 120.0) {
            ui.ctx().copy_text(app.yt.last_report.clone());
        }
    }
}

fn results_list(app: &mut App, ui: &mut Ui, list: Rect, cx: f32, cw: f32) {
    let p = ui.painter().clone();
    if app.yt.searching {
        let c = list.center();
        // spinner
        let t = ui.input(|i| i.time) as f32;
        let r = 14.0;
        let center = pos2(c.x, c.y - 40.0);
        p.circle_stroke(center, r, egui::Stroke::new(3.0, rgba(255, 255, 255, 0.12)));
        let a0 = t * 5.0;
        let pts: Vec<egui::Pos2> = (0..=16).map(|i| {
            let a = a0 + i as f32 / 16.0 * 1.6;
            center + vec2(a.cos(), a.sin()) * r
        }).collect();
        p.add(egui::Shape::line(pts, egui::Stroke::new(3.0, theme::PRIMARY)));
        theme::text(&p, pos2(c.x, c.y - 10.0), Align2::CENTER_TOP, "SEARCHING YOUTUBE", Txt::new(W::MonoBold, 12.0, Color32::from_rgb(236, 236, 236)).ls(0.5));
        let slow = crate::util::now_ms() - app.yt.search_started > 5000.0;
        let msg = if slow { "YouTube is slow to answer. Still searching…" } else { "Searching with the built-in yt-dlp…" };
        theme::text(&p, pos2(c.x, c.y + 10.0), Align2::CENTER_TOP, msg, Txt::new(W::Semibold, 11.0, theme::MUTED));
        return;
    }
    if app.yt.failed || (app.yt.hits.is_empty() && app.yt.title.starts_with("TOP RESULTS")) {
        let msg = if app.yt.failed { "Search unavailable. Please retry your search." } else { "No matches. Try another search." };
        theme::text(&p, pos2(cx, list.min.y + 24.0), Align2::LEFT_TOP, msg, Txt::new(W::Semibold, 11.0, Color32::from_rgb(182, 198, 213)));
        return;
    }
    let hits = app.yt.hits.clone();
    let mut child = ui.new_child(egui::UiBuilder::new().max_rect(list).layout(egui::Layout::top_down(egui::Align::Min)));
    egui::ScrollArea::vertical().id_salt("yt-scroll").auto_shrink([false, false]).show(&mut child, |ui| {
        let colw = (cw - 8.0) / 2.0;
        let rows = hits.len().div_ceil(2);
        let (area, _) = ui.allocate_exact_size(vec2(list.width(), 12.0 + rows as f32 * 83.0 + 24.0), Sense::hover());
        for (i, h) in hits.iter().enumerate() {
            let (row, col) = (i / 2, i % 2);
            let r = Rect::from_min_size(pos2(cx + col as f32 * (colw + 8.0), area.min.y + 12.0 + row as f32 * 83.0), vec2(colw, 75.0));
            let enabled = !app.yt.busy;
            let resp = widgets::interact(ui, ("yt-hit", i), r, enabled);
            let p = ui.painter().clone();
            let hover = enabled && resp.hovered();
            let active = app.yt.busy && app.yt.last_hit.as_ref().is_some_and(|x| x.id == h.id);
            theme::boxed(&p, r, 4.0, if hover { Color32::from_rgb(34, 36, 40) } else { Color32::from_rgb(27, 28, 31) }, 1.0, if active || hover { theme::PRIMARY } else { Color32::from_rgb(48, 51, 56) });
            let img = Rect::from_min_size(r.min + vec2(11.0, 9.0), vec2(100.0, 57.0));
            app.want_thumb(&h.id);
            match app.yt.thumbs.get(&h.id) {
                Some(Some(t)) => {
                    // object-fit: cover (thumbnails are 4:3 with letterbox bars)
                    let [tw, th] = t.size();
                    let (tw, th) = (tw as f32, th as f32);
                    let target = 100.0 / 57.0;
                    let uv = if tw / th > target { let w = th * target / tw; Rect::from_min_max(pos2((1.0 - w) / 2.0, 0.0), pos2((1.0 + w) / 2.0, 1.0)) } else { let hh = tw / target / th; Rect::from_min_max(pos2(0.0, (1.0 - hh) / 2.0), pos2(1.0, (1.0 + hh) / 2.0)) };
                    p.image(t.id(), img, uv, Color32::WHITE);
                }
                _ => {
                    p.rect_filled(img, 3.0, Color32::from_rgb(0x2a, 0x2c, 0x30));
                }
            }
            let tx = img.max.x + 12.0;
            let tw = r.max.x - 11.0 - tx;
            let tt = Txt::new(W::Black, 12.0, Color32::from_rgb(238, 238, 238));
            let title = if h.title.is_empty() { format!("YouTube {}", h.id) } else { h.title.clone() };
            let t = theme::ellipsize(&p, &title, tt, tw);
            theme::text(&p, pos2(tx, r.center().y - 8.0), Align2::LEFT_CENTER, &t, tt);
            let meta = format!("{} · {}", if h.author.is_empty() { "YouTube" } else { &h.author }, if h.length > 0.0 { crate::youtube::duration_text(h.length) } else { "unknown duration".into() });
            let mt = Txt::new(W::Semibold, 10.0, Color32::from_rgb(153, 153, 153));
            let m = theme::ellipsize(&p, &meta, mt, tw);
            theme::text(&p, pos2(tx, r.center().y + 10.0), Align2::LEFT_CENTER, &m, mt);
            if resp.has_focus() {
                theme::focus_ring(&p, r, 4.0);
            }
            if resp.clicked() {
                app.yt_choose(h.clone());
            }
        }
    });
}

// -------------------------------------------------------------- long song

pub fn long_song(app: &mut App, ui: &mut Ui, rect: Rect) {
    let Some(ask) = &app.long_ask else { return };
    let duration = ask.duration;
    let mut ui = modal_layer(ui, rect, "long-song", egui::Order::Foreground);
    let ui = &mut ui;
    let p = ui.painter().clone();
    p.rect_filled(rect, 0.0, rgba(0, 0, 0, 0.74));
    let minutes = settings::number("audio.highlightsMinutes", 12.0);
    let desc = "Process the complete song, or optionally make a shorter highlights edit or beginning-only clip.";
    let cw = 355.0;
    let desc_t = Txt::new(W::Regular, 12.0, Color32::from_rgb(0xb0, 0xb0, 0xb0));
    let dg = p.layout_job(desc_t.job(desc, cw - 34.0));
    let h = 17.0 + 23.0 + 8.0 + dg.size().y + 13.0 + 4.0 * 40.0 + 3.0 * 7.0 + 15.0;
    let card = Rect::from_center_size(rect.center(), vec2(cw, h));
    p.rect_filled(card.translate(vec2(0.0, 12.0)).expand(10.0), 14.0, rgba(0, 0, 0, 0.3));
    theme::boxed(&p, card, 4.0, theme::BG_PANEL, 2.0, theme::BORDER);
    let title = format!("LONG AUDIO · {}", crate::youtube::duration_text(duration));
    theme::text(&p, card.min + vec2(17.0, 17.0), Align2::LEFT_TOP, &title, Txt::new(W::Black, 19.0, Color32::WHITE));
    let dy = card.min.y + 17.0 + 23.0 + 8.0;
    p.galley(pos2(card.min.x + 17.0, dy), dg.clone(), desc_t.color);
    let mut y = dy + dg.size().y + 13.0;
    let base = ButtonStyle::outline(12.0).with(Color32::from_rgb(0x17, 0x17, 0x17), Color32::from_rgb(0x24, 0x24, 0x24), 2.0, theme::BORDER).text(Txt::new(W::Black, 12.0, Color32::WHITE));
    let mut base = base;
    base.hover_border = Color32::from_rgb(0x77, 0x77, 0x77);
    let mut prim = base.with(theme::PRIMARY, theme::PRIMARY_HOVER, 2.0, theme::PRIMARY);
    prim.hover_border = theme::PRIMARY_HOVER;
    let clip_label = format!("First {} minutes", crate::util::js_num_to_string(minutes));
    let choices: [(&str, &str, Option<Option<LongSongMode>>, widgets::ButtonStyle); 4] = [
        ("ls-full", "Full song", Some(Some(LongSongMode::Full)), prim),
        ("ls-hl", "Highlights Edit", Some(Some(LongSongMode::Highlights)), base),
        ("ls-clip", &clip_label, Some(Some(LongSongMode::Clip)), base),
        ("ls-cancel", "Cancel", Some(None), base),
    ];
    let mut picked = None;
    for (id, label, choice, st) in choices {
        let r = Rect::from_min_size(pos2(card.min.x + 17.0, y), vec2(cw - 34.0, 40.0));
        if widgets::button(ui, &mut app.icons, id, r, label, None, st, true).clicked() {
            picked = choice;
        }
        y += 47.0;
    }
    if ui.input(|i| i.key_pressed(egui::Key::Escape)) {
        picked = Some(None);
    }
    if let Some(c) = picked {
        app.answer_long_song(c);
    }
}

// ----------------------------------------------------------------- drop

pub fn drop_overlay(app: &mut App, ui: &mut Ui, rect: Rect) {
    let layer = egui::LayerId::new(egui::Order::Tooltip, egui::Id::new("drop"));
    let p = ui.ctx().layer_painter(layer);
    p.rect_filled(rect, 0.0, rgba(12, 12, 14, 0.86));
    let w = 560.0f32.min(rect.width() - 64.0);
    let hint = Rect::from_center_size(rect.center(), vec2(w, 190.0));
    p.rect_filled(hint, 4.0, theme::BG_PANEL);
    // dashed 2px primary border
    let pts = [hint.left_top(), hint.right_top(), hint.right_bottom(), hint.left_bottom(), hint.left_top()];
    for s in pts.windows(2) {
        p.add(egui::Shape::dashed_line(&[s[0], s[1]], egui::Stroke::new(2.0, theme::PRIMARY), 6.0, 4.0));
    }
    let ic = Rect::from_center_size(pos2(hint.center().x, hint.min.y + 52.0), vec2(52.0, 52.0));
    theme::boxed(&p, ic, 4.0, Color32::from_rgb(0x17, 0x17, 0x17), 2.0, theme::BORDER);
    app.icons.paint(ui.ctx(), &p, Icon::Drop, Rect::from_center_size(ic.center(), vec2(28.0, 28.0)), theme::PRIMARY);
    theme::text(&p, pos2(hint.center().x, ic.max.y + 14.0), Align2::CENTER_TOP, "DROP A SONG OR MAP", Txt::new(W::Black, 24.0, Color32::WHITE).ls(0.36));
    theme::text_wrapped(&p, pos2(hint.center().x, ic.max.y + 50.0), Align2::CENTER_TOP, "Audio generates a new map · Beat Saber ZIP opens directly in the viewer", Txt::new(W::Semibold, 12.0, theme::MUTED), 410.0);
}
