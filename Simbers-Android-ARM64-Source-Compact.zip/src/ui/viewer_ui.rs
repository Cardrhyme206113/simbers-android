//! egui chrome of the native viewer: stage (wgpu texture), map HUD, zoom reset,
//! fullscreen, FPS overlay, 360 compass and the player dock. Geometry and
//! colors follow the viewer CSS (measured in Chromium at 821x749).

use super::theme::{self, rgba, Txt, W};
use super::widgets;
use super::App;
use crate::viewer::map::{characteristic_label, compact_stat, difficulty_label};
use crate::viewer::state::{is_360, USER_ZOOM_DEFAULT, USER_ZOOM_MAX, USER_ZOOM_MIN};
use crate::viewer::Quality;
use eframe::egui;
use egui::{pos2, vec2, Align2, Color32, Rect, Stroke, Ui};

const DOCK_H: f32 = 88.0;
const FIELD_BORDER: Color32 = Color32::from_rgb(0x3b, 0x3b, 0x3b);
const FIELD_BORDER_HOVER: Color32 = Color32::from_rgb(0x50, 0x50, 0x50);
const FIELD_BG: Color32 = Color32::from_rgb(0x12, 0x12, 0x12);
const LABEL: Color32 = Color32::from_rgb(0x8f, 0x8f, 0x8f);

const QUALITIES: [(Quality, &str); 6] = [
    (Quality::Low, "Low"),
    (Quality::Medium, "Medium"),
    (Quality::High, "High"),
    (Quality::VeryHigh, "Very High"),
    (Quality::Ultra, "Ultra"),
    (Quality::Native, "Native"),
];

fn format_time(v: f64) -> String {
    let total = if v.is_finite() { v.max(0.0).floor() as u64 } else { 0 };
    format!("{}:{:02}", total / 60, total % 60)
}

pub fn show(app: &mut App, ui: &mut Ui, rect: Rect) {
    let p = ui.painter().clone();
    p.rect_filled(rect, 0.0, theme::BG_PANEL);
    if !app.viewer.has_map() {
        return;
    }
    let ctx = ui.ctx().clone();
    let viewport = Rect::from_min_max(rect.min, pos2(rect.max.x, rect.max.y - DOCK_H));
    let dock = Rect::from_min_max(pos2(rect.min.x, viewport.max.y), rect.max);

    // ---- stage
    let default_env = crate::viewer::scene::uses_default_environment(&app.viewer.mode);
    if let Some(rs) = app.wgpu.clone() {
        let dpr = ctx.pixels_per_point() as f64;
        app.viewer.frame(&rs, viewport.width() as f64, viewport.height() as f64, dpr);
    }
    let pv = p.with_clip_rect(viewport);
    if app.viewer.await_first_pose {
        // body.cyber-replay-mode.cyber-await-first-pose: no intermediate Map frame.
        pv.rect_filled(viewport, 0.0, Color32::from_rgb(5, 6, 9));
        ctx.request_repaint_after(std::time::Duration::from_millis(30));
        dock_ui(app, ui, dock);
        return;
    }
    if app.viewer.replay_pending() {
        ctx.request_repaint_after(std::time::Duration::from_millis(30));
    }
    if default_env {
        pv.rect_filled(viewport, 0.0, Color32::from_rgb(1, 2, 7));
    } else {
        // .viewerViewport inset box-shadows and the ::before/::after light washes
        // (visible through the transparent canvas outside DefaultEnvironment).
        pv.rect_stroke(viewport, 0.0, Stroke::new(2.0, rgba(0, 0, 0, 0.18)), egui::StrokeKind::Inside);
        pv.rect_stroke(viewport, 0.0, Stroke::new(1.0, rgba(255, 255, 255, 0.14)), egui::StrokeKind::Inside);
        let (lc, lp, rc, rp) = app.viewer.glow();
        for (c, pulse) in [(lc, lp), (rc, rp)] {
            let a = (0.22 * pulse).clamp(0.0, 1.0) as f32;
            if a > 0.0 {
                let u = |v: f32| (v * 255.0).round().clamp(0.0, 255.0) as u8;
                pv.rect_filled(viewport, 0.0, Color32::from_rgba_unmultiplied(u(c[0]), u(c[1]), u(c[2]), u(a)));
            }
        }
    }
    if let Some(tex) = app.viewer.texture_id() {
        pv.image(tex, viewport, Rect::from_min_max(pos2(0.0, 0.0), pos2(1.0, 1.0)), Color32::WHITE);
    }
    if app.viewer.playing() {
        ctx.request_repaint();
    } else if app.viewer.audio_loading {
        ctx.request_repaint_after(std::time::Duration::from_millis(50));
    }

    // Wheel zoom over the stage.
    let stage_resp = ui.interact(viewport, ui.id().with("viewer-stage"), egui::Sense::click());
    if stage_resp.hovered() {
        let h = viewport.height();
        let mut dy = 0.0f64;
        ctx.input(|i| {
            for e in &i.events {
                if let egui::Event::MouseWheel { unit, delta, .. } = e {
                    dy += match unit {
                        egui::MouseWheelUnit::Line => -delta.y as f64 * 100.0,
                        egui::MouseWheelUnit::Point => -delta.y as f64,
                        egui::MouseWheelUnit::Page => -delta.y as f64 * h as f64,
                    };
                }
            }
        });
        if dy != 0.0 {
            set_zoom(app, app.viewer.user_zoom * (-dy.clamp(-120.0, 120.0) * 0.002).exp());
        }
    }

    map_hud(app, ui, &pv, viewport);
    corner_buttons(app, ui, &pv, viewport);
    if is_360(&app.viewer.mode) {
        compass(&pv, viewport, app.viewer.camera_yaw());
    }
    if !app.viewer.fps_text.is_empty() {
        let t = Txt::new(W::Bold, 8.0, rgba(255, 255, 255, 0.78));
        let sz = theme::measure(&pv, &app.viewer.fps_text, t);
        let r = Rect::from_min_size(pos2(viewport.min.x + 7.0, viewport.max.y - 7.0 - (sz.y + 6.0)), vec2((sz.x + 10.0).max(44.0), sz.y + 6.0));
        theme::boxed(&pv, r, 4.0, rgba(3, 5, 9, 0.54), 1.0, rgba(255, 255, 255, 0.11));
        theme::text(&pv, pos2(r.min.x + 5.0, r.center().y), Align2::LEFT_CENTER, &app.viewer.fps_text, t);
    }

    dock_ui(app, ui, dock);
}

fn set_zoom(app: &mut App, v: f64) {
    let z = (if v.is_finite() { v } else { 1.0 }).clamp(USER_ZOOM_MIN, USER_ZOOM_MAX);
    if (z - app.viewer.user_zoom).abs() < 0.001 {
        return;
    }
    app.viewer.user_zoom = z;
    app.viewer.needs_redraw = true;
}

fn map_hud(app: &mut App, ui: &mut Ui, p: &egui::Painter, vp: Rect) {
    let Some(e) = &app.viewer.embedded else { return };
    if app.viewer.active.as_ref().is_none_or(|a| a.is_empty_visuals()) {
        return;
    }
    let info = &e.info;
    let title = if info.song_name.is_empty() { "Untitled map".to_string() } else { info.song_name.clone() };
    let mapper = if !info.level_author.is_empty() && info.level_author != "Unknown" { info.level_author.as_str() } else { "" };
    let artist = if !info.song_author.is_empty() && info.song_author != "Unknown" { info.song_author.as_str() } else { "" };
    let author = if !mapper.is_empty() {
        format!("{}mapped by {mapper}", if artist.is_empty() { String::new() } else { format!("{artist} · ") })
    } else if !artist.is_empty() {
        artist.to_string()
    } else {
        "Unknown author".into()
    };
    let nps = &app.viewer.nps;
    let stats = [("NPS", compact_stat(nps.overall), 9.0), ("4B", compact_stat(nps.p4), 8.0), ("8B", compact_stat(nps.p8), 8.0), ("16B", compact_stat(nps.p16), 8.0)];

    let t_title = Txt::new(W::Black, 12.0, Color32::WHITE);
    let t_author = Txt::new(W::Semibold, 8.0, rgba(255, 255, 255, 0.66));
    let max_w = 360f32.min(vp.width() - 68.0);
    let text_max = (max_w - 6.0 - 46.0 - 8.0 - 8.0 - 2.0).max(10.0);
    // Shrink-to-fit width like the flex box (content width, capped).
    let mut stats_w = 0.0;
    for (i, (k, v, s)) in stats.iter().enumerate() {
        stats_w += theme::measure(p, &format!("{k} "), Txt::new(W::Bold, *s, rgba(255, 255, 255, 0.76))).x + theme::measure(p, v, Txt::new(W::Black, *s, Color32::WHITE)).x;
        if i < 3 {
            stats_w += 7.0;
        }
    }
    let content = theme::measure(p, &title, t_title).x.max(theme::measure(p, &author, t_author).x).max(stats_w).min(text_max);
    let w = 6.0 + 46.0 + 8.0 + content + 8.0 + 2.0;
    let r = Rect::from_min_size(vp.min + vec2(10.0, 10.0), vec2(w, 60.0));
    theme::boxed(p, r, 6.0, rgba(8, 8, 10, 0.58), 1.0, rgba(255, 255, 255, 0.14));
    let cover = Rect::from_min_size(r.min + vec2(7.0, 7.0), vec2(46.0, 46.0));
    let key = format!("viewer-cover-{}", app.generation);
    if !app.covers.contains_key(&key) {
        let tex = app.viewer.cover.as_ref().and_then(|b| super::main_view::decode_png(b)).map(|img| ui.ctx().load_texture(key.clone(), img, egui::TextureOptions::LINEAR));
        app.covers.insert(key.clone(), tex);
    }
    theme::boxed(p, cover, 4.0, rgba(255, 255, 255, 0.07), 1.0, rgba(255, 255, 255, 0.12));
    match app.covers.get(&key) {
        Some(Some(t)) => {
            let inner = cover.shrink(1.0);
            egui::Image::new((t.id(), inner.size())).corner_radius(3.0).paint_at(ui, inner);
        }
        _ => {
            theme::text(p, cover.center(), Align2::CENTER_CENTER, "♪", Txt::new(W::Black, 20.0, rgba(255, 255, 255, 0.46)));
        }
    }
    let x = cover.max.x + 8.0;
    let tw = r.max.x - 8.0 - x;
    let title_s = theme::ellipsize(p, &title, t_title.ls(0.06), tw);
    theme::text(p, pos2(x, r.min.y + 9.6), Align2::LEFT_TOP, &title_s, t_title.ls(0.06));
    let author_s = theme::ellipsize(p, &author, t_author, tw);
    theme::text(p, pos2(x, r.min.y + 25.4), Align2::LEFT_TOP, &author_s, t_author);
    let mut sx = x;
    let base = r.min.y + 49.0;
    let clip = p.with_clip_rect(Rect::from_min_max(pos2(x, r.min.y), pos2(r.max.x - 8.0, r.max.y)));
    for (k, v, s) in stats {
        let lt = Txt::new(W::Bold, s, rgba(255, 255, 255, 0.76));
        let vt = Txt::new(W::Black, s, Color32::WHITE);
        let a = theme::text(&clip, pos2(sx, base), Align2::LEFT_BOTTOM, &format!("{k} "), lt);
        let b = theme::text(&clip, pos2(a.max.x, base), Align2::LEFT_BOTTOM, &v, vt);
        sx = b.max.x + 7.0;
    }
}

fn corner_buttons(app: &mut App, ui: &mut Ui, p: &egui::Painter, vp: Rect) {
    // Fullscreen
    let fr = Rect::from_min_size(pos2(vp.max.x - 8.0 - 38.0, vp.min.y + 8.0), vec2(38.0, 38.0));
    let resp = widgets::interact(ui, "viewer-fs", fr, true).on_hover_text(if app.viewer_fullscreen { "Exit fullscreen" } else { "Fullscreen" });
    let hov = resp.hovered();
    let op = if hov { 1.0 } else { 0.82 };
    let fill = if hov { rgba(18, 18, 18, 0.78) } else { rgba(12, 12, 12, 0.58) };
    let border = if hov { rgba(255, 255, 255, 0.34) } else { rgba(255, 255, 255, 0.2) };
    let r = if resp.is_pointer_button_down_on() { fr.shrink(0.76) } else { fr };
    theme::boxed(p, r, 6.0, theme::fade(fill, op), 1.0, theme::fade(border, op));
    let s = 21.0 / 24.0;
    let o = r.center() - vec2(10.5, 10.5);
    let pt = |x: f32, y: f32| o + vec2(x * s, y * s);
    let st = Stroke::new(1.8 * s, theme::fade(Color32::WHITE, op));
    let paths: &[&[(f32, f32)]] = if app.viewer_fullscreen {
        &[&[(9.0, 4.0), (9.0, 9.0), (4.0, 9.0)], &[(15.0, 4.0), (15.0, 9.0), (20.0, 9.0)], &[(20.0, 15.0), (15.0, 15.0), (15.0, 20.0)], &[(4.0, 15.0), (9.0, 15.0), (9.0, 20.0)]]
    } else {
        &[&[(8.5, 4.0), (4.0, 4.0), (4.0, 8.5)], &[(15.5, 4.0), (20.0, 4.0), (20.0, 8.5)], &[(20.0, 15.5), (20.0, 20.0), (15.5, 20.0)], &[(8.5, 20.0), (4.0, 20.0), (4.0, 15.5)]]
    };
    for path in paths {
        let pts: Vec<_> = path.iter().map(|(x, y)| pt(*x, *y)).collect();
        p.add(egui::Shape::line(pts, st));
    }
    if resp.clicked() {
        app.viewer_fullscreen = !app.viewer_fullscreen;
        ui.ctx().send_viewport_cmd(egui::ViewportCommand::Fullscreen(app.viewer_fullscreen));
    }
    if app.viewer_fullscreen && ui.input(|i| i.key_pressed(egui::Key::Escape)) && !app.speed_open {
        app.viewer_fullscreen = false;
        ui.ctx().send_viewport_cmd(egui::ViewportCommand::Fullscreen(false));
    }

    // Zoom reset (visible only when zoomed)
    let z = app.viewer.user_zoom;
    let visible = (z - USER_ZOOM_DEFAULT).abs() > 0.015;
    let anim = ui.ctx().animate_bool_with_time(ui.id().with("zoom-vis"), visible, 0.15);
    if anim > 0.0 {
        let label = format!("{z:.2}×");
        let t = Txt::new(W::Bold, 11.0, Color32::WHITE);
        let w = (theme::measure(p, &label, t).x + 16.0).max(43.0);
        let zr = Rect::from_min_size(pos2(vp.max.x - 8.0 - w, vp.min.y + 53.0), vec2(w, 28.0));
        let op = anim * 0.9;
        theme::boxed(p, zr, 5.0, theme::fade(rgba(12, 12, 12, 0.7), op), 1.0, theme::fade(rgba(255, 255, 255, 0.25), op));
        theme::text(p, zr.center(), Align2::CENTER_CENTER, &label, t.color(theme::fade(Color32::WHITE, op)));
        if visible && widgets::interact(ui, "viewer-zoom-reset", zr, true).clicked() {
            set_zoom(app, USER_ZOOM_DEFAULT);
        }
    }
}

fn compass(p: &egui::Painter, vp: Rect, yaw_deg: f64) {
    let c = pos2(vp.max.x - 10.0 - 39.0, vp.center().y);
    p.circle(c, 39.0, rgba(7, 8, 10, 0.54), Stroke::new(1.0, rgba(255, 255, 255, 0.22)));
    for k in 0..12 {
        let a = (k as f32 * 30.0).to_radians();
        let d = vec2(a.sin(), -a.cos());
        p.line_segment([c + d * 31.0, c + d * 38.0], Stroke::new(1.0, rgba(255, 255, 255, 0.18)));
    }
    p.circle_stroke(c, 30.5, Stroke::new(1.0, rgba(255, 255, 255, 0.1)));
    let a = (yaw_deg as f32).to_radians();
    let d = vec2(a.sin(), -a.cos());
    let n = 12;
    for i in 0..n {
        let t0 = i as f32 / n as f32;
        let t1 = (i + 1) as f32 / n as f32;
        let alpha = 0.28 + (0.96 - 0.28) * t1;
        p.line_segment([c + d * (29.0 * t0), c + d * (29.0 * t1)], Stroke::new(2.0, rgba(255, 255, 255, alpha)));
    }
    p.circle_filled(c + d * 29.0, 3.0, Color32::WHITE);
    p.circle_filled(c, 5.0, rgba(0, 0, 0, 0.35));
    p.circle_filled(c, 3.0, Color32::WHITE);
    theme::text(p, pos2(c.x, c.y + 39.0 - 8.0), Align2::CENTER_BOTTOM, "VIEW", Txt::new(W::Black, 6.0, rgba(255, 255, 255, 0.5)).ls(0.48));
}

/// Native `<select class="playerControl">` look with an egui popup list.
fn select(ui: &mut Ui, id: &str, rect: Rect, opts: &[(String, String)], cur: &str) -> Option<String> {
    let p = ui.painter().clone();
    let resp = widgets::interact(ui, id, rect, !opts.is_empty());
    theme::boxed(&p, rect, 4.0, FIELD_BG, 2.0, if resp.hovered() { FIELD_BORDER_HOVER } else { FIELD_BORDER });
    let label = opts.iter().find(|(v, _)| v == cur).map(|(_, l)| l.as_str()).unwrap_or("");
    let t = Txt::new(W::Semibold, 11.0, Color32::WHITE);
    let clip = p.with_clip_rect(rect.shrink(2.0));
    let shown = theme::ellipsize(&clip, label, t, rect.width() - 34.0);
    theme::text(&clip, pos2(rect.min.x + 10.0, rect.center().y), Align2::LEFT_CENTER, &shown, t);
    let c = pos2(rect.max.x - 10.5, rect.center().y);
    let st = Stroke::new(1.6, Color32::WHITE);
    p.line_segment([c + vec2(-4.5, -2.2), c + vec2(0.0, 2.3)], st);
    p.line_segment([c + vec2(0.0, 2.3), c + vec2(4.5, -2.2)], st);
    if resp.has_focus() {
        theme::boxed(&p, rect, 4.0, Color32::TRANSPARENT, 2.0, theme::PRIMARY);
    }
    let popup_id = egui::Id::new((id, "viewer-popup"));
    let mut out = None;
    if resp.clicked() {
        egui::Popup::toggle_id(ui.ctx(), popup_id);
    }
    if egui::Popup::is_id_open(ui.ctx(), popup_id) || resp.clicked() {
        egui::Popup::from_response(&resp).id(popup_id).width(rect.width()).close_behavior(egui::PopupCloseBehavior::CloseOnClick).show(|ui| {
            ui.set_min_width(rect.width() - 12.0);
            for (v, l) in opts {
                if ui.add(egui::Button::selectable(v == cur, egui::RichText::new(l).font(theme::font(W::Semibold, 11.0)).color(Color32::WHITE))).clicked() {
                    out = Some(v.clone());
                }
            }
        });
    }
    out
}

fn dock_ui(app: &mut App, ui: &mut Ui, dock: Rect) {
    let p = ui.painter().clone();
    p.rect_filled(dock, 0.0, theme::BG_PANEL);
    let x0 = dock.min.x + 12.0;
    let w = dock.width() - 24.0;
    let gap = 8.0;
    let frs = [1.25f32, 1.25, 0.725, 1.0];
    let unit = (w - 36.0 - gap * 4.0) / frs.iter().sum::<f32>();
    let top = dock.min.y + 7.0;
    let mut x = x0;
    let mut cols = [Rect::NOTHING; 4];
    for (i, f) in frs.iter().enumerate() {
        cols[i] = Rect::from_min_size(pos2(x, top), vec2(unit * f, 44.0));
        x += unit * f + gap;
    }
    let lt = Txt::new(W::Bold, 9.0, LABEL).ls(0.405);
    for (i, l) in ["MODE", "DIFFICULTY", "SPEED", "GRAPHICS"].iter().enumerate() {
        theme::text(&p, cols[i].min, Align2::LEFT_TOP, l, lt);
    }
    let field = |r: Rect| Rect::from_min_size(pos2(r.min.x, r.min.y + 12.0), vec2(r.width(), 32.0));

    let modes: Vec<(String, String)> = app.viewer.modes().into_iter().map(|m| (m.clone(), characteristic_label(&m))).collect();
    let cur_mode = app.viewer.mode.clone();
    if let Some(m) = select(ui, "viewer-mode", field(cols[0]), &modes, &cur_mode) {
        if m != cur_mode {
            app.viewer.set_mode(&m);
        }
    }
    let diffs: Vec<(String, String)> = app.viewer.difficulties().into_iter().map(|d| (d.clone(), difficulty_label(&d).to_string())).collect();
    let cur_diff = app.viewer.difficulty.clone();
    if let Some(d) = select(ui, "viewer-diff", field(cols[1]), &diffs, &cur_diff) {
        if d != cur_diff {
            app.viewer.select_difficulty(&d);
        }
    }
    // Speed toggle + popover
    let sr = field(cols[2]);
    let resp = widgets::interact(ui, "viewer-speed", sr, true);
    let open = app.speed_open;
    let (bg, bd) = if open { (Color32::from_rgb(0x15, 0x1d, 0x27), theme::PRIMARY) } else { (FIELD_BG, if resp.hovered() { FIELD_BORDER_HOVER } else { FIELD_BORDER }) };
    if open {
        p.rect_stroke(sr.expand(2.0), 6.0, Stroke::new(2.0, rgba(0, 123, 255, 0.16)), egui::StrokeKind::Inside);
    }
    theme::boxed(&p, sr, 4.0, bg, 2.0, bd);
    let rate = app.viewer.player.rate();
    theme::text(&p, sr.center(), Align2::CENTER_CENTER, &format!("{rate:.2}×"), Txt::new(W::Semibold, 11.0, Color32::WHITE));
    if resp.clicked() {
        app.speed_open = !app.speed_open;
    }
    if app.speed_open {
        speed_popover(app, ui, sr);
    }
    let qopts: Vec<(String, String)> = QUALITIES.iter().map(|(q, l)| (format!("{q:?}"), l.to_string())).collect();
    let cur_q = format!("{:?}", app.viewer.quality);
    if let Some(q) = select(ui, "viewer-quality", field(cols[3]), &qopts, &cur_q) {
        if let Some((qq, _)) = QUALITIES.iter().find(|(qq, _)| format!("{qq:?}") == q) {
            app.viewer.set_quality(*qq);
        }
    }
    // Play / pause
    let pr = Rect::from_min_size(pos2(dock.max.x - 12.0 - 36.0, top + 44.0 - 36.0), vec2(36.0, 36.0));
    let presp = widgets::interact(ui, "viewer-play", pr, true).on_hover_text(if app.viewer.playing() { "Pause" } else { "Play" });
    let playing = app.viewer.playing();
    let (fill, border) = match (playing, presp.hovered()) {
        (true, false) => (Color32::from_rgb(0xba, 0x29, 0x29), Color32::from_rgb(0xe0, 0x46, 0x46)),
        (true, true) => (Color32::from_rgb(0xcb, 0x34, 0x34), Color32::from_rgb(0xef, 0x5a, 0x5a)),
        (false, false) => (Color32::from_rgb(0x17, 0x94, 0x47), Color32::from_rgb(0x2b, 0xbf, 0x65)),
        (false, true) => (Color32::from_rgb(0x20, 0xa9, 0x56), Color32::from_rgb(0x36, 0xd1, 0x74)),
    };
    let pr2 = if presp.is_pointer_button_down_on() { pr.shrink(0.72) } else { pr };
    theme::boxed(&p, pr2, 4.0, fill, 2.0, border);
    let s = 21.0 / 24.0;
    let o = pr2.center() - vec2(10.5, 10.5);
    let pt = |x: f32, y: f32| o + vec2(x * s, y * s);
    if playing {
        for x in [6.4f32, 13.4] {
            p.rect_filled(Rect::from_min_size(pt(x, 5.0), vec2(4.2 * s, 14.0 * s)), 1.0 * s, Color32::WHITE);
        }
    } else {
        p.add(egui::Shape::convex_polygon(vec![pt(7.5, 4.8), pt(19.0, 12.0), pt(7.5, 19.2)], Color32::WHITE, Stroke::NONE));
    }
    if presp.clicked() || (ui.input(|i| i.key_pressed(egui::Key::Space)) && ui.ctx().memory(|m| m.focused().is_none()) && app.overlay_is_none()) {
        if !playing && app.viewer.max_playback.is_finite() && app.viewer.current_time() >= app.viewer.max_playback - 0.02 {
            app.viewer.seek(0.0);
        }
        app.viewer.toggle_play();
    }

    // ---- timeline
    let row = Rect::from_min_size(pos2(x0, dock.min.y + 59.0), vec2(w, 22.0));
    let dur = app.viewer.duration().min(app.viewer.max_playback);
    let t = app.viewer.current_time();
    let time_s = format!("{} / {}", format_time(t), format_time(dur));
    let tt = Txt::new(W::Black, 9.0, Color32::from_rgb(0xd8, 0xd8, 0xd8));
    let time_w = theme::measure(&p, &time_s, tt).x.max(70.0);
    let lg = Txt::new(W::Bold, 8.0, theme::MUTED);
    let lw_left = 12.0 + theme::measure(&p, "LEFT", lg).x;
    let lw_right = 12.0 + theme::measure(&p, "RIGHT", lg).x;
    let legend_w = lw_left + 8.0 + lw_right;
    let legend_x = row.max.x - legend_w;
    let time_r = Rect::from_min_max(pos2(legend_x - 9.0 - time_w, row.min.y), pos2(legend_x - 9.0, row.max.y));
    theme::text(&p, pos2(time_r.max.x, row.center().y), Align2::RIGHT_CENTER, &time_s, tt);
    let lc = crate::viewer::map::css_rgb01(&app.viewer.left_css);
    let rc = crate::viewer::map::css_rgb01(&app.viewer.right_css);
    let c32 = |c: [f32; 3]| Color32::from_rgb((c[0] * 255.0).round() as u8, (c[1] * 255.0).round() as u8, (c[2] * 255.0).round() as u8);
    let mut lx = legend_x;
    for (label, col, lw) in [("LEFT", c32(lc), lw_left), ("RIGHT", c32(rc), lw_right)] {
        p.rect_filled(Rect::from_min_size(pos2(lx, row.center().y - 4.0), vec2(8.0, 8.0)), 1.0, col);
        theme::text(&p, pos2(lx + 12.0, row.center().y), Align2::LEFT_CENTER, label, lg);
        lx += lw + 8.0;
    }
    let seek_r = Rect::from_min_max(pos2(row.min.x, row.center().y - 8.0), pos2(time_r.min.x - 9.0, row.center().y + 8.0));
    // Highlights cut ticks
    if dur > 0.0 {
        for c in &app.viewer.highlights_cuts {
            let fx = seek_r.min.x + 8.0 + (seek_r.width() - 16.0) * (*c / dur) as f32;
            p.line_segment([pos2(fx, seek_r.min.y - 1.0), pos2(fx, seek_r.max.y + 1.0)], Stroke::new(1.0, rgba(255, 210, 90, 0.7)));
        }
    }
    let frac = if dur > 0.0 { (t / dur).clamp(0.0, 1.0) as f32 } else { 0.0 };
    let sresp = ui.interact(seek_r, ui.id().with("viewer-seek"), egui::Sense::click_and_drag());
    if sresp.hovered() {
        ui.ctx().set_cursor_icon(egui::CursorIcon::PointingHand);
    }
    if (sresp.dragged() || sresp.clicked()) && dur > 0.0 {
        if let Some(pos) = sresp.interact_pointer_pos() {
            let f = ((pos.x - seek_r.min.x - 8.0) / (seek_r.width() - 16.0)).clamp(0.0, 1.0) as f64;
            let v = (f * 1000.0).round() / 1000.0;
            app.viewer.seek((v * dur).clamp(0.0, app.viewer.max_playback));
        }
    }
    range_track(&p, seek_r, frac);
}

/// Chromium `<input type=range>` with accent-color #007bff.
fn range_track(p: &egui::Painter, r: Rect, frac: f32) {
    let accent = Color32::from_rgb(5, 122, 248);
    let track = Rect::from_min_max(pos2(r.min.x, r.center().y - 4.0), pos2(r.max.x, r.center().y + 4.0));
    let thumb_x = r.min.x + 8.0 + (r.width() - 16.0) * frac;
    p.rect_filled(track, 4.0, Color32::from_rgb(0xef, 0xef, 0xef));
    p.rect_stroke(track, 4.0, Stroke::new(1.0, Color32::from_rgb(0xb2, 0xb2, 0xb2)), egui::StrokeKind::Inside);
    p.rect_filled(Rect::from_min_max(track.min, pos2(thumb_x, track.max.y)), 4.0, accent);
    p.circle_filled(pos2(thumb_x, r.center().y), 8.0, accent);
}

fn speed_popover(app: &mut App, ui: &mut Ui, anchor: Rect) {
    let screen = ui.ctx().content_rect();
    let w = 260f32.min(screen.width() - 16.0);
    let h = 9.0 + 12.0 + 6.0 + 16.0 + 3.0 + 7.0 + 8.0 + 4.0;
    let left = (anchor.max.x - w).min(screen.max.x - w - 8.0).max(8.0);
    let mut top = anchor.min.y - h - 7.0;
    if top < 8.0 {
        top = (screen.max.y - h - 8.0).min(anchor.max.y + 7.0);
    }
    let rect = Rect::from_min_size(pos2(left, top.max(8.0)), vec2(w, h));
    let layer = egui::LayerId::new(egui::Order::Foreground, egui::Id::new("viewer-speed-pop"));
    let p = ui.ctx().layer_painter(layer);
    p.rect_filled(rect.translate(vec2(0.0, 10.0)).expand(6.0), 10.0, rgba(0, 0, 0, 0.22));
    theme::boxed(&p, rect, 6.0, Color32::from_rgb(0x10, 0x10, 0x10), 2.0, theme::BORDER);
    let rate = app.viewer.player.rate();
    let inner = rect.shrink2(vec2(10.0, 9.0));
    theme::text(&p, pos2(inner.min.x, inner.min.y + 6.0), Align2::LEFT_CENTER, "PLAYBACK SPEED", Txt::new(W::Bold, 9.0, theme::MUTED).ls(0.225));
    theme::text(&p, pos2(inner.max.x, inner.min.y + 6.0), Align2::RIGHT_CENTER, &format!("{rate:.2}×"), Txt::new(W::Bold, 10.0, Color32::WHITE));
    let rr = Rect::from_min_size(pos2(inner.min.x, inner.min.y + 18.0), vec2(inner.width(), 16.0));
    let child = ui.new_child(egui::UiBuilder::new().layer_id(layer).max_rect(rect));
    let resp = child.interact(rr, child.id().with("viewer-speed-range"), egui::Sense::click_and_drag());
    if let Some(pos) = resp.interact_pointer_pos().filter(|_| resp.dragged() || resp.clicked()) {
        let f = ((pos.x - rr.min.x - 8.0) / (rr.width() - 16.0)).clamp(0.0, 1.0) as f64;
        let v = ((0.5 + f * 1.5) / 0.05).round() * 0.05;
        app.viewer.set_speed(v);
    }
    let frac = ((app.viewer.player.rate() - 0.5) / 1.5) as f32;
    range_track(&p, rr, frac);
    let tk = Txt::new(W::Bold, 7.0, Color32::from_rgb(0x73, 0x73, 0x73));
    let ty = rr.max.y + 3.0;
    let ticks = ["0.5×", "1×", "1.5×", "2×"];
    for (i, s) in ticks.iter().enumerate() {
        let (x, a) = match i {
            0 => (rr.min.x, Align2::LEFT_TOP),
            3 => (rr.max.x, Align2::RIGHT_TOP),
            _ => {
                // justify-content: space-between
                let widths: Vec<f32> = ticks.iter().map(|t| theme::measure(&p, t, tk).x).collect();
                let free = (rr.width() - widths.iter().sum::<f32>()) / 3.0;
                let mut x = rr.min.x;
                for wv in widths.iter().take(i) {
                    x += wv + free;
                }
                (x, Align2::LEFT_TOP)
            }
        };
        theme::text(&p, pos2(x, ty), a, s, tk);
    }
    // Outside click / Escape closes.
    if ui.input(|i| i.pointer.any_pressed()) {
        if let Some(pos) = ui.input(|i| i.pointer.interact_pos()) {
            if !rect.contains(pos) && !anchor.contains(pos) {
                app.speed_open = false;
            }
        }
    }
    if ui.input(|i| i.key_pressed(egui::Key::Escape)) {
        app.speed_open = false;
    }
}
