//! Native UI (eframe/egui): a 1:1 port of the main page — map creator card,
//! Past Jobs, Settings, YouTube import and the long-song dialog.
//! Layout and copy follow ref/main.html; heavy work runs on worker threads.
#![allow(deprecated)]

mod icons;
mod main_view;
#[cfg(target_os = "android")]
mod mobile;
mod pages;
mod theme;
mod viewer_ui;
mod widgets;

use crate::audio::Decoded;
use crate::job::{self, Job, TimingProfile};
use crate::mapgen::FeatureOptions;
use crate::payload::ViewerPayload;
use crate::pipeline::{self, LongSongMode, RunOptions, RunOutput};
use crate::storage::history::{self, JobRecord};
use crate::youtube;
use eframe::egui;
use parking_lot::Mutex;
use std::path::PathBuf;
use std::sync::Arc;
use std::sync::atomic::Ordering;
use std::sync::mpsc::{Receiver, Sender, channel};

pub const VERSION: &str = "v0.9.7";
pub const VERSION_TITLE: &str = "Simbers V6 — Release v0.9.7";

/// Supported audio extensions (SIMBERS_AUDIO_EXTENSIONS + the file input accept list).
pub const AUDIO_EXTS: &[&str] = &["mp3", "mp2", "mpeg", "mpga", "wav", "wave", "flac", "ogg", "oga", "opus", "aac", "m4a", "mp4", "webm", "weba", "aif", "aiff", "alac", "wma", "ape"];

#[cfg(target_os = "android")]
pub fn run_android(android_app: winit::platform::android::activity::AndroidApp) -> anyhow::Result<()> {
    let options = eframe::NativeOptions {
        android_app: Some(android_app),
        ..Default::default()
    };
    eframe::run_native("Simplified Sabers", options, Box::new(|cc| Ok(Box::new(App::new(cc, None)))))
        .map_err(|e| anyhow::anyhow!("{e}"))
}

#[cfg(not(target_os = "android"))]
pub fn run(initial: Option<PathBuf>) -> anyhow::Result<()> {
    hide_own_console();
    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default().with_title("Simbers7 — Beat Saber Map Generator").with_inner_size([1280.0, 800.0]).with_min_inner_size([900.0, 600.0]).with_drag_and_drop(true),
        ..Default::default()
    };
    eframe::run_native("Simplified Sabers", options, Box::new(move |cc| Ok(Box::new(App::new(cc, initial))))).map_err(|e| anyhow::anyhow!("{e}"))
}

/// When started from Explorer the process owns a fresh console window; release it
/// (a console shared with a terminal, i.e. CLI use, is left alone).
#[cfg(windows)]
fn hide_own_console() {
    unsafe extern "system" {
        fn GetConsoleProcessList(list: *mut u32, count: u32) -> u32;
        fn FreeConsole() -> i32;
    }
    let mut ids = [0u32; 4];
    unsafe {
        if GetConsoleProcessList(ids.as_mut_ptr(), 4) == 1 {
            FreeConsole();
        }
    }
}
#[cfg(not(windows))]
fn hide_own_console() {}

pub(crate) enum Msg {
    Progress { generation: u64, value: f64, text: Option<String> },
    Decoded { generation: u64, path: PathBuf, result: Result<Arc<(Decoded, Vec<u8>)>, String> },
    Built { generation: u64, result: Result<Box<RunOutput>, String> },
    Saved { result: Result<(), String> },
    History(Result<Vec<JobRecord>, String>),
    ZipOpened { name: String, result: Result<(Box<ViewerPayload>, Vec<u8>), String> },
    YtSearch { token: u64, result: Result<Vec<youtube::Hit>, String> },
    YtStatus { token: u64, text: String, kind: Kind },
    YtImported { token: u64, result: Result<youtube::Imported, youtube::Failure> },
    Thumb { id: String, image: Option<egui::ColorImage> },
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub(crate) enum Kind {
    Info,
    Warning,
    Error,
    Success,
}

#[derive(Clone, Copy, PartialEq, Eq)]
pub(crate) enum Overlay {
    None,
    Settings,
    YouTube,
}

/// The selected source audio (sourceBlob) plus its decoded PCM once probed.
pub(crate) struct Source {
    pub path: PathBuf,
    pub name: String,
    pub size: u64,
    pub decoded: Option<Arc<(Decoded, Vec<u8>)>>,
    pub youtube: Option<youtube::Source>,
}

pub(crate) struct LongSongAsk {
    pub generation: u64,
    pub path: PathBuf,
    pub duration: f64,
    pub decoded: Arc<(Decoded, Vec<u8>)>,
    pub youtube: Option<youtube::Source>,
    pub auto_generate: bool,
}

pub(crate) struct YtState {
    pub query: String,
    pub title: String,
    pub status: String,
    pub kind: Kind,
    pub hits: Vec<youtube::Hit>,
    pub searching: bool,
    pub busy: bool,
    pub failed: bool,
    pub token: u64,
    pub cancel: Option<Arc<std::sync::atomic::AtomicBool>>,
    pub thumbs: std::collections::HashMap<String, Option<egui::TextureHandle>>,
    /// Thumbnail fetches started per video (a failed one is retried once).
    pub thumb_tries: std::collections::HashMap<String, u8>,
    pub last_hit: Option<youtube::Hit>,
    pub last_report: String,
    pub last_raw: Option<PathBuf>,
    /// The last import failed and can be retried.
    pub retry: bool,
    pub search_started: f64,
}

impl Default for YtState {
    fn default() -> Self {
        YtState {
            query: String::new(),
            title: "YouTube search".into(),
            status: "Press Enter or Search to load results. No requests while typing.".into(),
            kind: Kind::Info,
            hits: vec![],
            searching: false,
            busy: false,
            failed: false,
            token: 0,
            cancel: None,
            thumbs: Default::default(),
            thumb_tries: Default::default(),
            last_hit: None,
            last_report: String::new(),
            last_raw: None,
            retry: false,
            search_started: 0.0,
        }
    }
}

pub(crate) struct App {
    pub tx: Sender<Msg>,
    rx: Receiver<Msg>,
    pub ctx: egui::Context,
    pub icons: icons::Icons,

    // main card state
    pub status: String,
    pub progress: f64,
    pub decoding_since: Option<f64>,
    pub analyze_label: &'static str,
    pub analyze_enabled: bool,
    pub features: FeatureOptions,
    pub intensity: f64,
    pub applied_intensity: f64,
    pub export_open: bool,
    /// simbersBSORExportPending: waiting for the simulated replay before saving.
    bsor_pending: Option<u64>,

    pub generation: u64,
    pub running: Option<Job>,
    pub source: Option<Source>,
    pub long_song_mode: LongSongMode,
    pub long_ask: Option<LongSongAsk>,
    pub output: Option<Box<RunOutput>>,
    pub map_zip: Option<(Vec<u8>, String)>,
    pub payload: Option<Box<ViewerPayload>>,
    pub viewer: crate::viewer::state::Viewer,
    pub wgpu: Option<eframe::egui_wgpu::RenderState>,
    pub viewer_fullscreen: bool,
    pub speed_open: bool,
    viewer_source: Option<PathBuf>,
    pub external_map: bool,
    pub timing: Arc<Mutex<Option<TimingProfile>>>,
    pub last_profile: Option<TimingProfile>,
    pub pending_job: Option<history::PendingJob>,

    // Past Jobs
    pub jobs: Vec<JobRecord>,
    pub jobs_loading: bool,
    pub jobs_notice: Option<(String, bool)>,
    pub covers: std::collections::HashMap<String, Option<egui::TextureHandle>>,

    pub overlay: Overlay,
    pub yt: YtState,
    pub settings_edit: std::collections::HashMap<String, String>,
    pub settings_status: String,
    pub drag_hover: bool,
    pub yt_pending_source: Option<youtube::Source>,
    pub auto_generate_pending: bool,
    pub reprocess_note: Option<String>,
}

impl App {
    fn new(cc: &eframe::CreationContext, initial: Option<PathBuf>) -> Self {
        theme::install_fonts(&cc.egui_ctx);
        let mut style = (*cc.egui_ctx.global_style()).clone();
        style.visuals = egui::Visuals::dark();
        style.visuals.panel_fill = theme::BG_PANEL;
        style.visuals.window_fill = theme::BG_PANEL;
        style.visuals.extreme_bg_color = theme::BG_DARK;
        style.visuals.selection.bg_fill = theme::PRIMARY;
        style.visuals.text_cursor.stroke.color = egui::Color32::WHITE;
        style.interaction.selectable_labels = false;
        cc.egui_ctx.set_global_style(style);
        crate::settings::apply_runtime();
        let (tx, rx) = channel();
        let mut app = App {
            tx,
            rx,
            ctx: cc.egui_ctx.clone(),
            icons: Default::default(),
            status: "Offline built-in viewer ready.".into(),
            progress: 0.0,
            decoding_since: None,
            analyze_label: "Create Map",
            analyze_enabled: false,
            features: FeatureOptions { bombs: true, walls: true, arcs: true, bot_optimizer: true },
            intensity: 100.0,
            applied_intensity: 100.0,
            export_open: false,
            bsor_pending: None,
            generation: 0,
            running: None,
            source: None,
            long_song_mode: LongSongMode::Full,
            long_ask: None,
            output: None,
            map_zip: None,
            payload: None,
            viewer: crate::viewer::state::Viewer::new(),
            wgpu: None,
            viewer_fullscreen: false,
            speed_open: false,
            viewer_source: None,
            external_map: false,
            timing: Arc::new(Mutex::new(None)),
            last_profile: None,
            pending_job: None,
            jobs: vec![],
            jobs_loading: true,
            jobs_notice: None,
            covers: Default::default(),
            overlay: Overlay::None,
            yt: YtState::default(),
            settings_edit: Default::default(),
            settings_status: String::new(),
            drag_hover: false,
            yt_pending_source: None,
            auto_generate_pending: false,
            reprocess_note: None,
        };
        app.refresh_jobs();
        // Unpack the built-in yt-dlp in the background (a no-op after the first run).
        #[cfg(not(target_os = "android"))]
        std::thread::spawn(|| {
            if let Err(e) = youtube::ytdlp::prepare() {
                log::warn!("[Simbers YouTube] {e:#}");
            }
        });
        if let Some(p) = initial {
            app.open_path(p, false);
        }
        app
    }

    pub fn spawn(&self, f: impl FnOnce(Sender<Msg>) + Send + 'static) {
        let tx = self.tx.clone();
        let ctx = self.ctx.clone();
        std::thread::spawn(move || {
            f(tx);
            ctx.request_repaint();
        });
    }

    fn send_progress_fn(&self, generation: u64) -> job::ProgressFn {
        let tx = self.tx.clone();
        let ctx = self.ctx.clone();
        Arc::new(move |value, text| {
            let _ = tx.send(Msg::Progress { generation, value, text });
            ctx.request_repaint();
        })
    }

    pub fn set_progress(&mut self, v: f64, text: impl Into<String>) {
        self.progress = v.clamp(0.0, 1.0);
        let t = text.into();
        if !t.is_empty() {
            self.status = t;
        }
    }

    pub fn busy(&self) -> bool {
        self.running.is_some()
    }

    // ---------------------------------------------------------------- source

    /// simbersSelectAudioFile: probe duration (decode), ask about long songs, set source.
    pub fn select_audio(&mut self, path: PathBuf, youtube: Option<youtube::Source>, auto_generate: bool) {
        let name = path.file_name().and_then(|n| n.to_str()).unwrap_or("").to_string();
        let ext = path.extension().and_then(|e| e.to_str()).unwrap_or("").to_ascii_lowercase();
        if !AUDIO_EXTS.contains(&ext.as_str()) {
            self.status = "Choose an audio file: MP3, FLAC, WAV, OGG, AAC, M4A or another supported format.".into();
            return;
        }
        self.cancel_running();
        self.generation += 1;
        let generation = self.generation;
        self.pending_job = None;
        self.analyze_enabled = false;
        self.status = "Checking audio duration…".into();
        self.decoding_since = Some(crate::util::now_ms());
        let job = Job::new(Arc::new(|_, _| {}), Arc::new(Mutex::new(None)));
        let p = path.clone();
        let _ = name;
        self.spawn(move |tx| {
            let result = pipeline::decode(&p, &job).map(Arc::new).map_err(|e| e.to_string());
            let _ = tx.send(Msg::Decoded { generation, path: p, result });
        });
        self.long_ask = None;
        self.yt_pending_source = youtube;
        self.auto_generate_pending = auto_generate;
    }

    fn on_decoded(&mut self, generation: u64, path: PathBuf, result: Result<Arc<(Decoded, Vec<u8>)>, String>) {
        if generation != self.generation {
            return;
        }
        self.decoding_since = None;
        let youtube = self.yt_pending_source.take();
        let auto = std::mem::take(&mut self.auto_generate_pending);
        let decoded = match result {
            Ok(d) => d,
            Err(e) => {
                self.status = format!("Build failed: {e}");
                self.analyze_enabled = self.source.is_some();
                if youtube.is_some() {
                    self.yt_label(format!("Song selection was cancelled or replaced."), Kind::Error);
                    self.yt.busy = false;
                }
                return;
            }
        };
        let duration = decoded.0.duration();
        if duration.is_finite() && duration > crate::audio::highlights::selected_song_limit() {
            self.long_ask = Some(LongSongAsk { generation, path, duration, decoded, youtube, auto_generate: auto });
            return;
        }
        self.long_song_mode = LongSongMode::Full;
        self.set_source(path, Some(decoded), youtube);
        if auto {
            self.run_analysis();
        }
    }

    pub fn answer_long_song(&mut self, choice: Option<LongSongMode>) {
        let Some(ask) = self.long_ask.take() else { return };
        if ask.generation != self.generation {
            return;
        }
        let Some(mode) = choice else {
            self.analyze_enabled = self.source.is_some();
            self.status = if self.source.is_some() { "Previous song is still selected.".into() } else { "Song selection canceled.".into() };
            if ask.youtube.is_some() {
                self.yt_fail("Song selection was cancelled or replaced.");
            }
            return;
        };
        self.long_song_mode = mode;
        self.set_source(ask.path, Some(ask.decoded), ask.youtube);
        let minutes = crate::settings::number("audio.highlightsMinutes", 12.0);
        self.status = match mode {
            LongSongMode::Clip => format!("First {} minutes selected.", crate::util::js_num_to_string(minutes)),
            LongSongMode::Highlights => "Highlights Edit selected · full-song scan, shorter mapped audio.".into(),
            LongSongMode::Full => "Full song selected; processing may take longer.".into(),
        };
        if ask.auto_generate {
            self.run_analysis();
        }
    }

    /// setSource
    fn set_source(&mut self, path: PathBuf, decoded: Option<Arc<(Decoded, Vec<u8>)>>, youtube: Option<youtube::Source>) {
        self.external_map = false;
        self.output = None;
        self.map_zip = None;
        self.payload = None;
        self.viewer.clear();
        self.viewer_source = None;
        self.pending_job = None;
        let name = path.file_name().and_then(|n| n.to_str()).unwrap_or("").to_string();
        let size = decoded.as_ref().map(|d| d.1.len() as u64).or_else(|| std::fs::metadata(&path).ok().map(|m| m.len())).unwrap_or(0);
        self.source = Some(Source { path, name: name.clone(), size, decoded, youtube });
        self.analyze_label = "Create Map";
        self.analyze_enabled = true;
        self.status = if name.is_empty() { "Audio loaded.".into() } else { name };
        self.progress = 0.0;
    }

    // ------------------------------------------------------------ generation

    /// runAnalysis
    pub fn run_analysis(&mut self) {
        if self.analyze_label == "Open Map" && self.payload.is_some() {
            // launchLocalViewer(): reopen the cached payload.
            if !self.viewer.has_map() {
                if let Some(pl) = self.payload.take() {
                    self.set_payload_fresh(pl);
                }
            }
            return;
        }
        if self.source.is_none() {
            return;
        }
        self.cancel_running();
        let src = self.source.as_ref().unwrap();
        self.generation += 1;
        let generation = self.generation;
        let path = src.path.clone();
        let decoded = src.decoded.clone();
        let youtube = src.youtube.clone();
        let size = src.size;
        let timing = Arc::new(Mutex::new(Some(TimingProfile::new(&crate::export::safe_base_name(&src.name), decoded.as_ref().map(|d| d.0.duration()).unwrap_or(0.0)))));
        self.timing = timing.clone();
        let job = Job::new(self.send_progress_fn(generation), timing);
        self.running = Some(job.clone());
        self.analyze_enabled = false;
        self.analyze_label = "Create Map";
        self.output = None;
        self.map_zip = None;
        self.payload = None;
        let src_name = src.name.clone();
        self.set_progress(0.0, "Reading audio…");
        self.pending_job = Some(history::PendingJob {
            id: history::new_id(),
            generation_id: generation,
            name: crate::export::safe_base_name(&src_name),
            created_at: crate::util::epoch_ms(),
            audio_size: size,
            stage: "Generating map…".into(),
            cover: None,
            duration: decoded.as_ref().map(|d| d.0.duration()).unwrap_or(0.0),
        });
        let opts = RunOptions { intensity: self.intensity, features: self.features, mode: self.long_song_mode, youtube };
        self.applied_intensity = self.intensity;
        self.spawn(move |tx| {
            let r = (|| {
                let (dec, bytes) = match decoded {
                    Some(d) => (d.0.clone(), d.1.clone()),
                    None => pipeline::decode(&path, &job)?,
                };
                pipeline::run_decoded(&path, dec, bytes, &opts, &job)
            })();
            let result = match r {
                Ok(o) => Ok(Box::new(o)),
                Err(e) if job::is_abort(&e) || job.canceled() => Err(String::from("AbortError")),
                Err(e) => Err(e.to_string()),
            };
            let _ = tx.send(Msg::Built { generation, result });
        });
    }

    fn on_built(&mut self, generation: u64, result: Result<Box<RunOutput>, String>) {
        if generation != self.generation {
            return;
        }
        self.running = None;
        for c in [&mut self.analyze_enabled] {
            *c = true;
        }
        self.last_profile = self.timing.lock().clone();
        match result {
            Ok(out) => {
                let payload = pipeline::viewer_payload(&out);
                let zip_name = format!("{}_SimplifiedSabers.zip", if out.built.song_name.is_empty() { "Generated" } else { &out.built.song_name });
                self.map_zip = Some((out.zip.clone(), zip_name));
                self.set_payload(Box::new(payload));
                self.analyze_label = "Open Map";
                self.set_progress(1.0, "Preview ready · ZIP ready");
                // Past Jobs archive (pastJobsEnqueueSave).
                if let Some(src) = &self.source {
                    let rec = pipeline::history_record(&out, &src.path, src.size, self.applied_intensity, src.youtube.as_ref(), self.pending_job.as_ref().map(|p| p.created_at).unwrap_or_else(crate::util::epoch_ms));
                    let zip = out.zip.clone();
                    let audio = src.decoded.as_ref().map(|d| d.1.clone()).or_else(|| std::fs::read(&src.path).ok()).unwrap_or_default();
                    let cover = out.built.cover.clone();
                    self.spawn(move |tx| {
                        let result = history::save(history::SaveInput { record: rec, zip: &zip, audio: &audio, cover: &cover }).map_err(|e| e.to_string());
                        let _ = tx.send(Msg::Saved { result });
                    });
                }
                self.output = Some(out);
                if self.yt.busy {
                    self.yt.busy = false;
                    self.overlay = if self.overlay == Overlay::YouTube { Overlay::None } else { self.overlay };
                }
            }
            Err(e) if e == "AbortError" => {
                self.pending_job = None;
                self.set_progress(0.0, "Map generation canceled.");
            }
            Err(e) => {
                self.pending_job = None;
                if let Some(p) = self.timing.lock().as_mut() {
                    p.error = Some(e.clone());
                }
                self.last_profile = self.timing.lock().clone();
                self.status = format!("Build failed: {e}");
                self.analyze_label = "Try Again";
                if self.yt.busy {
                    self.yt_fail(&self.status.clone());
                }
            }
        }
    }

    pub fn cancel_running(&mut self) {
        if let Some(j) = self.running.take() {
            j.cancel.store(true, Ordering::Relaxed);
        }
        self.pending_job = None;
    }

    /// viewerBack (×): cancel the current task, or clear the map.
    pub fn back(&mut self) {
        if self.running.is_some() || self.decoding_since.is_some() {
            self.cancel_running();
            self.generation += 1;
            self.decoding_since = None;
            self.set_progress(0.0, "Map generation canceled.");
            self.analyze_enabled = self.source.is_some();
            return;
        }
        self.generation += 1;
        self.output = None;
        self.map_zip = None;
        self.payload = None;
        self.viewer.clear();
        self.viewer_source = None;
        self.external_map = false;
        self.analyze_label = "Create Map";
        self.analyze_enabled = self.source.is_some();
        self.progress = 0.0;
        self.status = if self.source.is_some() { "Map cleared. Ready to create again.".into() } else { "Ready. Select a song file.".into() };
    }

    /// Intensity release with an existing map: rebuild with the cached decode.
    /// postLocalPayload / postLocalMapUpdate: an intensity re-run of the same
    /// source only swaps the maps and keeps playback.
    fn set_payload(&mut self, pl: Box<ViewerPayload>) {
        let src = self.source.as_ref().map(|s| s.path.clone());
        if self.viewer.has_map() && src.is_some() && src == self.viewer_source && !self.external_map {
            self.viewer.update_maps(&pl);
        } else {
            self.viewer.load(&pl);
        }
        self.viewer_source = src;
        self.payload = Some(pl);
    }

    fn set_payload_fresh(&mut self, pl: Box<ViewerPayload>) {
        self.viewer.load(&pl);
        self.viewer_source = self.source.as_ref().map(|s| s.path.clone());
        self.payload = Some(pl);
    }

    pub fn overlay_is_none(&self) -> bool {
        matches!(self.overlay, Overlay::None) && self.long_ask.is_none()
    }

    pub fn intensity_released(&mut self) {
        let percent = self.intensity;
        if (percent - self.applied_intensity).abs() < 0.5 || self.source.is_none() || self.external_map {
            return;
        }
        if self.output.is_some() {
            self.status = format!("Updating intensity {}% · NPS {}…", percent as i64, npsCap(percent));
            self.analyze_label = "Create Map";
            self.run_analysis();
            self.status = format!("Updating intensity {}% · NPS {}…", percent as i64, npsCap(percent));
        }
    }

    pub fn export_map(&mut self) {
        self.export_open = false;
        let Some((zip, name)) = self.map_zip.clone() else {
            self.status = "Create a map before exporting.".into();
            return;
        };
        match crate::platform::save_bytes(&name, &zip) {
            Ok(Some(path)) => self.status = format!("Saved {}", path.file_name().and_then(|n| n.to_str()).unwrap_or(&name)),
            Ok(None) => self.status = "Choose export destination…".into(),
            Err(e) => self.status = format!("Export failed: {e}"),
        }
    }

    /// simbersExportCurrentBSOR(): switch to Replay, wait for the simulated pose
    /// track of the current chart, then save it as a .bsor file.
    pub fn export_replay(&mut self) {
        self.export_open = false;
        if self.map_zip.is_none() {
            self.status = "Upload a map ZIP or create a map before exporting BSOR.".into();
            return;
        }
        self.status = "Preparing map and simulated replay for BSOR export…".into();
        self.viewer.set_replay_visible(true);
        if !self.viewer.simulated_ready() && !self.viewer.replay_pending() {
            self.viewer.request_replay();
        }
        self.bsor_pending = Some(self.generation);
    }

    fn pump_bsor_export(&mut self) {
        let Some(epoch) = self.bsor_pending else { return };
        if epoch != self.generation {
            self.bsor_pending = None;
            return;
        }
        if self.viewer.replay_pending() {
            return;
        }
        self.bsor_pending = None;
        let Some((zip, _)) = self.map_zip.clone() else {
            self.status = "BSOR export failed: Map ZIP is unavailable for replay export.".into();
            return;
        };
        match self.viewer.export_bsor(&zip) {
            Ok((name, bytes)) => {
                match crate::platform::save_bytes(&name, &bytes) {
                    Ok(Some(path)) => self.status = format!("Simulated BSOR exported · {}", path.file_name().and_then(|n| n.to_str()).unwrap_or(&name)),
                    Ok(None) => self.status = "Choose BSOR export destination…".into(),
                    Err(e) => self.status = format!("BSOR export failed: {e}"),
                }
            }
            Err(e) => self.status = format!("BSOR export failed: {e}"),
        }
    }

    /// Import BSOR (Advanced settings / dropped .bsor).
    pub fn import_replay(&mut self, path: Option<PathBuf>) {
        let Some(path) = path.or_else(crate::platform::pick_file) else { return };
        let bytes = match std::fs::read(&path) {
            Ok(b) => b,
            Err(e) => {
                self.status = format!("Replay: {e}");
                return;
            }
        };
        let hash = self.map_zip.as_ref().and_then(|(z, _)| crate::viewer::bsor::map_hash(z).ok());
        match self.viewer.import_external(&bytes, hash.as_deref()) {
            Ok(msg) => self.status = msg,
            Err(e) => self.status = format!("Replay: {e}"),
        }
    }

    pub fn pick_file(&mut self) {
        if let Some(p) = crate::platform::pick_file() {
            self.open_path(p, false);
        }
    }

    /// Routes a picked/dropped file: ZIP → viewer import, audio → generation.
    pub fn open_path(&mut self, p: PathBuf, from_drop: bool) {
        let ext = p.extension().and_then(|e| e.to_str()).unwrap_or("").to_ascii_lowercase();
        if ext == "zip" {
            self.open_map_zip(p);
        } else if ext == "bsor" {
            self.import_replay(Some(p));
        } else {
            let auto = from_drop && crate::settings::boolean("output.autoGenerateOnDrop", false);
            self.select_audio(p, None, auto);
        }
    }

    /// simbersOpenMapZip: imported maps are read-only.
    fn open_map_zip(&mut self, p: PathBuf) {
        self.cancel_running();
        self.generation += 1;
        let name = p.file_name().and_then(|n| n.to_str()).unwrap_or("map.zip").to_string();
        self.status = format!("Opening {name}…");
        self.spawn(move |tx| {
            let result = std::fs::read(&p).map_err(|e| e.to_string()).and_then(|b| crate::payload::from_zip(&b, None, None).map(|pl| (Box::new(pl), b)).map_err(|e| e.to_string()));
            let _ = tx.send(Msg::ZipOpened { name, result });
        });
    }

    // ------------------------------------------------------------- Past Jobs

    pub fn refresh_jobs(&mut self) {
        self.jobs_loading = true;
        self.spawn(|tx| {
            let _ = tx.send(Msg::History(history::read_all().map_err(|e| e.to_string())));
        });
    }

    pub fn job_open(&mut self, job: &JobRecord) {
        match history::viewer_payload(job) {
            Ok(pl) => {
                self.cancel_running();
                self.generation += 1;
                if let Ok(zip) = history::read_zip(&job.id) {
                    self.map_zip = Some((zip, job.zip_name.clone()));
                }
                match history::materialize_audio(job) {
                    Ok(path) => {
                        let size = job.audio_size;
                        let youtube = job.youtube_source.clone().and_then(|v| serde_json::from_value(v).ok());
                        self.source = Some(Source { name: job.audio_name.clone(), path, size, decoded: None, youtube });
                    }
                    Err(_) => self.source = None,
                }
                self.set_payload_fresh(Box::new(pl));
                self.output = None;
                self.applied_intensity = job.intensity;
                self.analyze_label = "Open Map";
                self.analyze_enabled = true;
                self.set_progress(1.0, format!("Loaded {} from Past Jobs.", job.name));
            }
            Err(e) => self.jobs_notice = Some((format!("Could not open map: {e}"), true)),
        }
    }

    pub fn job_download(&mut self, job: &JobRecord) {
        match history::read_zip(&job.id) {
            Ok(zip) => {
                if let Err(e) = crate::platform::save_bytes(&job.zip_name, &zip) {
                    self.jobs_notice = Some((format!("Download failed: {e}"), true));
                }
            }
            Err(_) => self.jobs_notice = Some(("The ZIP for this job is unavailable.".into(), true)),
        }
    }

    pub fn job_reprocess(&mut self, job: &JobRecord) {
        match history::materialize_audio(job) {
            Ok(path) => {
                let youtube = job.youtube_source.clone().and_then(|v| serde_json::from_value(v).ok());
                self.select_audio(path, youtube, false);
                self.reprocess_note = Some(job.audio_name.clone());
            }
            Err(_) => self.jobs_notice = Some(("This job has no archived source audio.".into(), true)),
        }
    }

    pub fn job_delete(&mut self, id: String) {
        match history::delete(&id) {
            Ok(()) => self.refresh_jobs(),
            Err(e) => self.jobs_notice = Some((format!("Cannot delete map: {e}"), true)),
        }
    }

    pub fn jobs_clear(&mut self) {
        match history::clear() {
            Ok(()) => self.refresh_jobs(),
            Err(e) => self.jobs_notice = Some((format!("Cannot clear maps: {e}"), true)),
        }
    }

    // --------------------------------------------------------------- YouTube

    pub fn yt_label(&mut self, text: String, kind: Kind) {
        if kind == Kind::Error {
            self.status = format!("YouTube import: {text}");
        }
        self.yt.status = text;
        self.yt.kind = kind;
    }

    fn yt_fail(&mut self, msg: &str) {
        self.yt.busy = false;
        self.yt.title = "IMPORT FAILED".into();
        self.yt_label(msg.to_string(), Kind::Error);
        self.yt.retry = self.yt.last_hit.is_some();
    }

    pub fn yt_search(&mut self) {
        #[cfg(target_os = "android")]
        {
            self.yt_fail("YouTube importing is disabled in this Android build.");
            return;
        }
        let input = self.yt.query.trim().to_string();
        if input.is_empty() || self.yt.busy {
            return;
        }
        if let Some(c) = self.yt.cancel.take() {
            c.store(true, Ordering::Relaxed);
        }
        self.yt.token += 1;
        let token = self.yt.token;
        self.overlay = Overlay::YouTube;
        self.yt.title = "SEARCHING YOUTUBE".into();
        self.yt.searching = true;
        self.yt.failed = false;
        self.yt.hits.clear();
        self.yt.retry = false;
        self.yt.search_started = crate::util::now_ms();
        self.yt_label("Searching YouTube…".into(), Kind::Info);
        let cancel = Arc::new(std::sync::atomic::AtomicBool::new(false));
        self.yt.cancel = Some(cancel.clone());
        self.spawn(move |tx| {
            let c = || cancel.load(Ordering::Relaxed);
            let result = youtube::search(&input, &c).map_err(|e| e.to_string());
            let _ = tx.send(Msg::YtSearch { token, result });
        });
    }

    pub fn yt_choose(&mut self, hit: youtube::Hit) {
        if self.yt.busy {
            return;
        }
        if let Some(c) = self.yt.cancel.take() {
            c.store(true, Ordering::Relaxed);
        }
        self.yt.token += 1;
        let token = self.yt.token;
        self.yt.busy = true;
        self.yt.retry = false;
        self.yt.last_raw = None;
        self.yt.last_report.clear();
        self.yt.last_hit = Some(hit.clone());
        self.yt.title = "IMPORTING AUDIO".into();
        self.yt_label("Finding the audio stream closest to 128 kbps…".into(), Kind::Info);
        let cancel = Arc::new(std::sync::atomic::AtomicBool::new(false));
        self.yt.cancel = Some(cancel.clone());
        let ctx = self.ctx.clone();
        self.spawn(move |tx| {
            let c = || cancel.load(Ordering::Relaxed);
            let tx2 = tx.clone();
            let mut status = move |m: String| {
                let _ = tx2.send(Msg::YtStatus { token, text: m, kind: Kind::Info });
                ctx.request_repaint();
            };
            let result = youtube::import(&hit, &c, &mut status);
            let _ = tx.send(Msg::YtImported { token, result });
        });
    }

    pub fn yt_cancel(&mut self) {
        if let Some(c) = self.yt.cancel.take() {
            c.store(true, Ordering::Relaxed);
        }
        self.yt.token += 1;
        self.yt.busy = false;
        self.yt.searching = false;
        self.yt.title = "IMPORT CANCELED".into();
        self.yt_label("Download canceled.".into(), Kind::Warning);
    }

    fn want_thumb(&mut self, id: &str) {
        if self.yt.thumbs.contains_key(id) {
            return;
        }
        let tries = self.yt.thumb_tries.entry(id.to_string()).or_insert(0);
        if *tries >= 2 {
            return;
        }
        *tries += 1;
        self.yt.thumbs.insert(id.to_string(), None);
        let id = id.to_string();
        self.spawn(move |tx| {
            // decode_jpeg already yields RGBA.
            let image = youtube::fetch_image(&youtube::thumb_url(&id), 8000)
                .and_then(|b| youtube::decode_jpeg(&b))
                .filter(|(w, h, rgba)| rgba.len() == *w as usize * *h as usize * 4)
                .map(|(w, h, rgba)| egui::ColorImage::from_rgba_unmultiplied([w as usize, h as usize], &rgba));
            let _ = tx.send(Msg::Thumb { id, image });
        });
    }

    // ------------------------------------------------------------- messages

    fn pump(&mut self) {
        while let Ok(msg) = self.rx.try_recv() {
            match msg {
                Msg::Progress { generation, value, text } => {
                    if generation == self.generation && self.running.is_some() {
                        self.progress = value.clamp(0.0, 1.0);
                        if let Some(t) = text {
                            if let Some(p) = &mut self.pending_job {
                                p.stage = t.clone();
                            }
                            self.status = t;
                        }
                    }
                }
                Msg::Decoded { generation, path, result } => self.on_decoded(generation, path, result),
                Msg::Built { generation, result } => self.on_built(generation, result),
                Msg::Saved { result } => {
                    self.pending_job = None;
                    match result {
                        Ok(()) => self.jobs_notice = None,
                        Err(e) => self.jobs_notice = Some((format!("Couldn't save this map to Past Jobs: {e}"), true)),
                    }
                    self.refresh_jobs();
                }
                Msg::History(r) => {
                    self.jobs_loading = false;
                    match r {
                        Ok(j) => self.jobs = j,
                        Err(e) => {
                            self.jobs.clear();
                            self.jobs_notice = Some((format!("Map history couldn't be loaded: {e}"), true));
                        }
                    }
                }
                Msg::ZipOpened { name, result } => match result {
                    Ok((pl, bytes)) => {
                        self.external_map = true;
                        self.output = None;
                        self.map_zip = Some((bytes, name.clone()));
                        self.set_payload_fresh(pl);
                        self.analyze_label = "Open Map";
                        self.analyze_enabled = true;
                        self.status = format!("Imported map (read-only): {name} · preparing simulated replay");
                    }
                    Err(e) => self.status = format!("Map ZIP could not be opened: {e}"),
                },
                Msg::YtSearch { token, result } => {
                    if token != self.yt.token {
                        continue;
                    }
                    self.yt.searching = false;
                    self.yt.cancel = None;
                    match result {
                        Ok(hits) => {
                            self.yt.title = format!("TOP RESULTS · {}", hits.len());
                            let msg = if hits.is_empty() { "No results. Try a more specific query." } else { "Select a result to download ~128 kbps audio and create its map." };
                            self.yt.hits = hits;
                            self.yt_label(msg.into(), Kind::Info);
                        }
                        Err(e) => {
                            self.yt.failed = true;
                            self.yt.title = "SEARCH FAILED".into();
                            self.yt_label(e.chars().take(430).collect(), Kind::Error);
                        }
                    }
                }
                Msg::YtStatus { token, text, kind } => {
                    if token == self.yt.token {
                        self.yt_label(text, kind);
                    }
                }
                Msg::YtImported { token, result } => {
                    if token != self.yt.token {
                        continue;
                    }
                    self.yt.cancel = None;
                    match result {
                        Ok(imp) => {
                            self.yt.last_report = imp.report.clone();
                            self.yt.last_raw = Some(imp.path.clone());
                            self.yt_label(format!("Audio ready · {}. Creating Beat Saber map…", youtube::bytes_text(std::fs::metadata(&imp.path).map(|m| m.len() as f64).unwrap_or(0.0))), Kind::Success);
                            self.status = "YouTube audio ready · generating map…".into();
                            self.select_audio(imp.path, Some(imp.source), true);
                            self.status = "YouTube audio ready · generating map…".into();
                        }
                        Err(f) if f.message.contains("Cancel") => {}
                        Err(f) => {
                            self.yt.last_report = f.report;
                            self.yt_fail(&f.message);
                        }
                    }
                }
                Msg::Thumb { id, image } => match image {
                    Some(img) => {
                        let tex = self.ctx.load_texture(format!("yt-{id}"), img, egui::TextureOptions::LINEAR);
                        self.yt.thumbs.insert(id, Some(tex));
                    }
                    // Not cached: the next frame asks again while tries remain.
                    None => {
                        self.yt.thumbs.remove(&id);
                    }
                },
            }
        }
    }
}

#[allow(non_snake_case)]
pub(crate) fn npsCap(percent: f64) -> i64 {
    crate::mapgen::select::nps_cap_for_intensity(percent)
}

impl eframe::App for App {
    fn ui(&mut self, ui: &mut egui::Ui, frame: &mut eframe::Frame) {
        if self.wgpu.is_none() {
            self.wgpu = frame.wgpu_render_state().cloned();
        }
        self.pump();
        #[cfg(target_os = "android")]
        {
            for event in crate::platform::take_events() {
                match event {
                    crate::platform::FileEvent::Opened(path) => self.open_path(path, false),
                    crate::platform::FileEvent::Notice(message) => self.status = message,
                }
            }
            ui.ctx().request_repaint_after(std::time::Duration::from_millis(200));
        }
        self.pump_bsor_export();
        let ctx = ui.ctx().clone();
        // Drag & drop (file-drop-bridge.js)
        let (hovering, dropped) = ctx.input(|i| (!i.raw.hovered_files.is_empty(), i.raw.dropped_files.clone()));
        self.drag_hover = hovering;
        if let Some(f) = dropped.first().map(|f| f.path().to_path_buf()) {
            self.overlay = Overlay::None;
            self.open_path(f, true);
        }
        if self.decoding_since.is_some() || self.running.is_some() || self.yt.searching || self.yt.busy {
            ctx.request_repaint_after(std::time::Duration::from_millis(100));
        }
        let rect = ui.max_rect();
        ui.painter().rect_filled(rect, 0.0, theme::BG_PANEL);
        #[cfg(target_os = "android")]
        {
            mobile::show(self, ui, rect);
            return;
        }
        #[cfg(not(target_os = "android"))]
        main_view::show(self, ui, rect);
        if self.viewer_fullscreen && self.viewer.has_map() {
            viewer_ui::show(self, ui, rect);
        }
        match self.overlay {
            Overlay::Settings => pages::settings(self, ui, rect),
            Overlay::YouTube => pages::youtube(self, ui, rect),
            Overlay::None => {}
        }
        if self.long_ask.is_some() {
            pages::long_song(self, ui, rect);
        }
        if self.drag_hover {
            pages::drop_overlay(self, ui, rect);
        }
    }
}
