//! Original CSS tokens (css/tokens.css + computed styles) and font setup.
//! Sizes are CSS pixels = egui points, measured from the original page at 1280×800.

use eframe::egui::{self, Align2, Color32, FontFamily, FontId, Painter, Pos2, Rect, Stroke, StrokeKind, text::LayoutJob};
use std::sync::Arc;

pub const BG_DARK: Color32 = Color32::from_rgb(0x12, 0x12, 0x12);
pub const BG_PANEL: Color32 = Color32::from_rgb(0x1e, 0x1e, 0x1e);
pub const MUTED: Color32 = Color32::from_rgb(0x9a, 0x9a, 0x9a);
pub const PRIMARY: Color32 = Color32::from_rgb(0x00, 0x7b, 0xff);
pub const PRIMARY_HOVER: Color32 = Color32::from_rgb(0x00, 0x67, 0xd8);
pub const SECONDARY: Color32 = Color32::from_rgb(0x3f, 0x46, 0x4d);
pub const SECONDARY_HOVER: Color32 = Color32::from_rgb(0x58, 0x61, 0x6a);
pub const BORDER: Color32 = Color32::from_rgb(0x33, 0x33, 0x33);

pub const fn rgba(r: u8, g: u8, b: u8, a: f32) -> Color32 {
    Color32::from_rgba_unmultiplied_const(r, g, b, (a * 255.0) as u8)
}

/// Font weights available on Windows (Segoe UI 400/600/700/900, Consolas 400/700).
/// CSS weight matching: 550-650 → 600, 700 → 700, 750+ → 900.
#[derive(Clone, Copy, PartialEq, Eq)]
pub enum W {
    Regular,
    Semibold,
    Bold,
    Black,
    Mono,
    MonoBold,
}

impl W {
    fn family(self) -> FontFamily {
        FontFamily::Name(
            match self {
                W::Regular => "ui",
                W::Semibold => "ui-semibold",
                W::Bold => "ui-bold",
                W::Black => "ui-black",
                W::Mono => "mono",
                W::MonoBold => "mono-bold",
            }
            .into(),
        )
    }
}

pub fn font(w: W, size: f32) -> FontId {
    FontId::new(size, w.family())
}

pub fn install_fonts(ctx: &egui::Context) {
    let mut defs = egui::FontDefinitions::default();
    #[cfg(target_os = "android")]
    let dir = std::path::PathBuf::from("/system/fonts");
    #[cfg(not(target_os = "android"))]
    let dir = std::env::var("WINDIR").map(|w| std::path::PathBuf::from(w).join("Fonts")).unwrap_or_else(|_| "C:/Windows/Fonts".into());
    #[cfg(target_os = "android")]
    let files: [(&str, &[&str]); 6] = [
        ("ui", &["Roboto-Regular.ttf"]),
        ("ui-semibold", &["Roboto-Medium.ttf", "Roboto-Regular.ttf"]),
        ("ui-bold", &["Roboto-Bold.ttf"]),
        ("ui-black", &["Roboto-Black.ttf", "Roboto-Bold.ttf"]),
        ("mono", &["DroidSansMono.ttf", "RobotoMono-Regular.ttf"]),
        ("mono-bold", &["DroidSansMono.ttf", "RobotoMono-Bold.ttf"]),
    ];
    #[cfg(not(target_os = "android"))]
    let files: [(&str, &[&str]); 6] = [
        ("ui", &["segoeui.ttf"]),
        ("ui-semibold", &["seguisb.ttf", "segoeui.ttf"]),
        ("ui-bold", &["segoeuib.ttf", "segoeui.ttf"]),
        ("ui-black", &["seguibl.ttf", "segoeuib.ttf"]),
        ("mono", &["consola.ttf"]),
        ("mono-bold", &["consolab.ttf", "consola.ttf"]),
    ];
    // Symbol fallback for glyphs such as ≤ · × … that Segoe UI may lack.
    let symbol = ["seguisym.ttf"].iter().find_map(|f| std::fs::read(dir.join(f)).ok());
    if let Some(b) = symbol {
        defs.font_data.insert("symbol".into(), Arc::new(egui::FontData::from_owned(b)));
    }
    let builtin: Vec<String> = defs.families.get(&FontFamily::Proportional).cloned().unwrap_or_default();
    for (name, candidates) in files {
        let mut chain = vec![];
        if let Some(bytes) = candidates.iter().find_map(|f| std::fs::read(dir.join(f)).ok()) {
            defs.font_data.insert(name.into(), Arc::new(egui::FontData::from_owned(bytes)));
            chain.push(name.to_string());
        }
        if defs.font_data.contains_key("symbol") {
            chain.push("symbol".into());
        }
        chain.extend(builtin.iter().cloned());
        defs.families.insert(FontFamily::Name(name.into()), chain.clone());
        if name == "ui" {
            defs.families.insert(FontFamily::Proportional, chain);
        } else if name == "mono" {
            let mut m = chain;
            m.extend(defs.families.get(&FontFamily::Monospace).cloned().unwrap_or_default());
            defs.families.insert(FontFamily::Monospace, m);
        }
    }
    ctx.set_fonts(defs);
}

/// One text style: weight, CSS px size, color, CSS letter-spacing in px.
#[derive(Clone, Copy)]
pub struct Txt {
    pub w: W,
    pub size: f32,
    pub color: Color32,
    pub ls: f32,
}

impl Txt {
    pub const fn new(w: W, size: f32, color: Color32) -> Self {
        Self { w, size, color, ls: 0.0 }
    }
    pub const fn ls(mut self, ls: f32) -> Self {
        self.ls = ls;
        self
    }
    pub const fn color(mut self, c: Color32) -> Self {
        self.color = c;
        self
    }
    pub fn job(&self, text: &str, wrap: f32) -> LayoutJob {
        let mut job = LayoutJob::default();
        job.append(text, 0.0, egui::TextFormat { font_id: font(self.w, self.size), color: self.color, extra_letter_spacing: self.ls, ..Default::default() });
        job.wrap.max_width = wrap;
        job
    }
    pub fn job_centered(&self, text: &str, wrap: f32) -> LayoutJob {
        let mut j = self.job(text, wrap);
        j.halign = egui::Align::Center;
        j
    }
}

/// Paints single-line (or wrapped, when `wrap` is finite) text anchored at `pos`.
pub fn text(p: &Painter, pos: Pos2, anchor: Align2, s: &str, t: Txt) -> Rect {
    text_wrapped(p, pos, anchor, s, t, f32::INFINITY)
}

pub fn text_wrapped(p: &Painter, pos: Pos2, anchor: Align2, s: &str, t: Txt, wrap: f32) -> Rect {
    let job = if anchor.x() == egui::Align::Center && wrap.is_finite() { t.job_centered(s, wrap) } else { t.job(s, wrap) };
    let g = p.layout_job(job);
    let mut size = g.size();
    if t.ls != 0.0 {
        size.x -= t.ls; // trailing spacing after the last glyph
    }
    let r = anchor.anchor_size(pos, size);
    // Centered wrapped galleys are laid out around x=0.
    let origin = if anchor.x() == egui::Align::Center && wrap.is_finite() { Pos2::new(r.center().x, r.min.y) } else { r.min };
    p.galley(origin, g, t.color);
    r
}

pub fn measure(p: &Painter, s: &str, t: Txt) -> egui::Vec2 {
    let g = p.layout_job(t.job(s, f32::INFINITY));
    let mut v = g.size();
    if t.ls != 0.0 {
        v.x -= t.ls;
    }
    v
}

/// Box: fill + inside border, CSS-style.
pub fn boxed(p: &Painter, r: Rect, radius: f32, fill: Color32, border: f32, border_color: Color32) {
    p.rect_filled(r, radius, fill);
    if border > 0.0 {
        p.rect_stroke(r, radius, Stroke::new(border, border_color), StrokeKind::Inside);
    }
}

/// `:focus-visible` ring (outline: 2px solid #fff; outline-offset: 2px).
pub fn focus_ring(p: &Painter, r: Rect, radius: f32) {
    p.rect_stroke(r.expand(2.0), radius + 2.0, Stroke::new(2.0, Color32::WHITE), StrokeKind::Outside);
}

pub fn fade(c: Color32, opacity: f32) -> Color32 {
    c.gamma_multiply(opacity)
}

/// Truncates `s` with an ellipsis to fit `max_w` (CSS text-overflow: ellipsis).
pub fn ellipsize(p: &Painter, s: &str, t: Txt, max_w: f32) -> String {
    if measure(p, s, t).x <= max_w {
        return s.to_string();
    }
    let chars: Vec<char> = s.chars().collect();
    let (mut lo, mut hi) = (0usize, chars.len());
    while lo < hi {
        let mid = (lo + hi + 1) / 2;
        let cand: String = chars[..mid].iter().collect::<String>() + "…";
        if measure(p, &cand, t).x <= max_w {
            lo = mid;
        } else {
            hi = mid - 1;
        }
    }
    chars[..lo].iter().collect::<String>() + "…"
}
