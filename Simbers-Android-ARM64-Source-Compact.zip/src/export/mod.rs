//! Export: Info.dat (metadata.js), ZIP (zip.js), song.ogg (encode.js / ogg-passthrough.js).

pub mod cover;

use crate::mapgen::beatmaps::Difficulty;
use crate::settings as adv;
use crate::util::{jnum, js_round, json, to_fixed_num};
use serde_json::{Map, Value};

pub fn safe_base_name(name: &str) -> String {
    let stem = match name.rfind('.') {
        Some(i) if i + 1 < name.len() => &name[..i],
        _ => name,
    };
    let mut raw = stem.trim().to_string();
    if raw.is_empty() {
        raw = "Generated Song".into();
    }
    let mut out = String::new();
    let mut in_bad = false;
    for ch in raw.chars() {
        if matches!(ch, '\\' | '/' | ':' | '*' | '?' | '"' | '<' | '>' | '|') {
            if !in_bad {
                out.push('_');
            }
            in_bad = true;
        } else {
            out.push(ch);
            in_bad = false;
        }
    }
    // JS slice(0, 80) counts UTF-16 units.
    let mut units = 0;
    let mut cut = out.len();
    for (i, ch) in out.char_indices() {
        if units + ch.len_utf16() > 80 {
            cut = i;
            break;
        }
        units += ch.len_utf16();
    }
    out[..cut].to_string()
}

pub struct CharacteristicSet {
    pub characteristic: &'static str,
    pub difficulties: Vec<Difficulty>,
}

pub fn make_info(song_name: &str, duration: f64, sets: &[CharacteristicSet]) -> Value {
    let preview_start = 10f64.min(0f64.max(duration * 0.12));
    let mut info = Map::new();
    let mut put = |k: &str, v: Value| {
        info.insert(k.into(), v);
    };
    put("_version", "2.0.0".into());
    put("_songName", song_name.into());
    put("_songSubName", "Multi-Difficulty Signature Flow".into());
    put("_songAuthorName", "Unknown".into());
    put("_levelAuthorName", "Simbers".into());
    put("_beatsPerMinute", 60.into());
    put("_songTimeOffset", 0.into());
    put("_shuffle", 0.into());
    put("_shufflePeriod", 0.into());
    put("_previewStartTime", jnum(to_fixed_num(preview_start, 3)));
    put("_previewDuration", jnum(to_fixed_num(12f64.min(0f64.max(duration - preview_start)), 3)));
    put("_songFilename", "song.ogg".into());
    put("_coverImageFilename", "cover.png".into());
    put("_environmentName", "DefaultEnvironment".into());
    put("_allDirectionsEnvironmentName", "DefaultEnvironment".into());
    put("_customData", serde_json::json!({"_simplifiedSabersCharacteristics": sets.iter().map(|s| s.characteristic).collect::<Vec<_>>()}));
    let bsets: Vec<Value> = sets
        .iter()
        .map(|set| {
            let diffs: Vec<Value> = set
                .difficulties
                .iter()
                .map(|d| {
                    let c = &d.config;
                    let mut cd = Map::new();
                    cd.insert("_minimumEventGapMs".into(), jnum(c.minimum_gap_ms));
                    cd.insert("_flowWeights".into(), serde_json::json!({"easy": jnum(c.weights[0]), "medium": jnum(c.weights[1]), "hard": jnum(c.weights[2])}));
                    cd.insert("_expertPlusIntensityPercent".into(), jnum(c.expert_plus_intensity_percent));
                    cd.insert("_difficultyDensityPercent".into(), jnum(c.difficulty_density_percent));
                    cd.insert("_targetRelativeToExpertPlusDefaultPercent".into(), jnum(c.target_relative_percent));
                    if c.id == "medium" {
                        cd.insert("_difficultyLabel".into(), "Medium".into());
                    }
                    let mut m = Map::new();
                    m.insert("_difficulty".into(), c.difficulty.clone().into());
                    m.insert("_difficultyRank".into(), jnum(c.rank));
                    m.insert("_beatmapFilename".into(), d.filename.clone().into());
                    m.insert("_noteJumpMovementSpeed".into(), jnum(c.note_jump_movement_speed));
                    m.insert("_noteJumpStartBeatOffset".into(), 0.into());
                    m.insert("_customData".into(), Value::Object(cd));
                    Value::Object(m)
                })
                .collect();
            serde_json::json!({"_beatmapCharacteristicName": set.characteristic, "_difficultyBeatmaps": diffs})
        })
        .collect();
    put("_difficultyBeatmapSets", Value::Array(bsets));
    Value::Object(info)
}

pub fn validate_native_charts(diffs: &[&Difficulty]) -> anyhow::Result<()> {
    for d in diffs {
        for w in &d.beatmap.obstacles {
            if w.type_ != 0 && w.type_ != 1 {
                anyhow::bail!("{}: invalid Beat Saber v2 wall type {}.", d.filename, w.type_);
            }
            if !w.time.is_finite() || !w.duration.is_finite() || w.line_index < 0 || w.line_index + w.width > 4 || w.width < 1 {
                anyhow::bail!("{}: invalid v2 wall geometry.", d.filename);
            }
        }
    }
    Ok(())
}

pub fn validate_info(info: &Value, sets: &[CharacteristicSet], expected_count: usize) -> anyhow::Result<Vec<String>> {
    let expected: Vec<&str> = sets.iter().map(|s| s.characteristic).collect();
    let bsets = info["_difficultyBeatmapSets"].as_array().cloned().unwrap_or_default();
    let actual: Vec<String> = bsets.iter().map(|s| s["_beatmapCharacteristicName"].as_str().unwrap_or("").to_string()).collect();
    if actual != expected {
        anyhow::bail!("Info.dat mode manifest mismatch. Expected {}; got {}.", expected.join(", "), if actual.is_empty() { "none".into() } else { actual.join(", ") });
    }
    let mut files = vec![];
    for s in &bsets {
        let d = s["_difficultyBeatmaps"].as_array().cloned().unwrap_or_default();
        if d.len() != expected_count {
            anyhow::bail!("Info.dat {} mode has {} difficulties instead of {}.", s["_beatmapCharacteristicName"].as_str().unwrap_or(""), d.len(), expected_count);
        }
        for x in d {
            match x["_beatmapFilename"].as_str() {
                Some(f) if !f.is_empty() => files.push(f.to_string()),
                _ => anyhow::bail!("Info.dat contains a mode difficulty without a filename."),
            }
        }
    }
    Ok(files)
}

// ---------------------------------------------------------------- Ogg

#[derive(Clone, Debug)]
pub struct OggDetails {
    pub codec: &'static str,
    pub channels: u8,
    pub pages: usize,
}

pub fn identify_reusable_ogg(b: &[u8]) -> Option<OggDetails> {
    if b.len() < 64 {
        return None;
    }
    let cap = |at: usize| at + 4 <= b.len() && &b[at..at + 4] == b"OggS";
    if !cap(0) {
        return None;
    }
    let (mut off, mut serial, mut pages, mut eos) = (0usize, None::<u32>, 0usize, false);
    let (mut codec, mut channels) = (None, 0u8);
    while off < b.len() {
        if off + 27 > b.len() || !cap(off) || b[off + 4] != 0 || eos {
            return None;
        }
        let count = b[off + 26] as usize;
        if off + 27 + count > b.len() {
            return None;
        }
        let stream = u32::from_le_bytes([b[off + 14], b[off + 15], b[off + 16], b[off + 17]]);
        if serial.is_some_and(|s| s != stream) {
            return None;
        }
        serial.get_or_insert(stream);
        let flags = b[off + 5];
        if pages == 0 && flags & 2 == 0 {
            return None;
        }
        let len: usize = b[off + 27..off + 27 + count].iter().map(|&x| x as usize).sum();
        let start = off + 27 + count;
        let end = start + len;
        if end > b.len() {
            return None;
        }
        if pages == 0 {
            let p = &b[start..end];
            if p.len() >= 19 && &p[..8] == b"OpusHead" {
                codec = Some("opus");
                channels = p[9];
            } else if p.len() >= 12 && p[0] == 1 && &p[1..7] == b"vorbis" {
                codec = Some("vorbis");
                channels = p[11];
            } else {
                return None;
            }
        }
        if flags & 4 != 0 {
            eos = true;
        }
        pages += 1;
        off = end;
    }
    if eos && pages >= 3 && (channels == 1 || channels == 2) { Some(OggDetails { codec: codec?, channels, pages }) } else { None }
}

pub fn assert_beat_saber_vorbis(b: &[u8]) -> anyhow::Result<()> {
    if identify_reusable_ogg(b).map(|d| d.codec) != Some("vorbis") {
        anyhow::bail!("Beat Saber export blocked: song.ogg must contain a complete Ogg Vorbis stream (not Opus).");
    }
    Ok(())
}

pub fn reusable_ogg(src: &[u8], source_duration: f64, mapped_duration: f64, channels: usize) -> Option<OggDetails> {
    if !source_duration.is_finite() || !mapped_duration.is_finite() || mapped_duration < source_duration - 0.05 {
        return None;
    }
    let d = identify_reusable_ogg(src)?;
    (d.codec == "vorbis" && d.channels as usize == channels).then_some(d)
}

pub fn selected_bitrate() -> f64 {
    16f64.max(128f64.min(js_round(adv::number("audio.bitrateKbps", 80.0) / 16.0) * 16.0))
}

/// encodeOggVorbis — libvorbis (aoTuV) quality VBR, same quality mapping as the WASM build.
pub fn encode_ogg_vorbis(channels: &[Vec<f32>], sample_rate: f64, check: &dyn Fn() -> anyhow::Result<()>, progress: &mut dyn FnMut(f64)) -> anyhow::Result<Vec<u8>> {
    use std::num::{NonZeroU32, NonZeroU8};
    use vorbis_rs::{VorbisBitrateManagementStrategy, VorbisEncoderBuilder};
    let ch: Vec<&Vec<f32>> = channels.iter().take(2).collect();
    if ch.is_empty() {
        anyhow::bail!("No audio channels to encode.");
    }
    let quality = 0f64.max(6f64.min(js_round((selected_bitrate() - 32.0) / 16.0)));
    let sr = NonZeroU32::new(sample_rate.round() as u32).ok_or_else(|| anyhow::anyhow!("bad sample rate"))?;
    let n = NonZeroU8::new(ch.len() as u8).unwrap();
    let serial = crate::util::hash_string(&format!("{}|{}", ch[0].len(), sample_rate)) as i32;
    let mut b = VorbisEncoderBuilder::new_with_serial(sr, n, Vec::<u8>::new(), serial);
    b.bitrate_management_strategy(VorbisBitrateManagementStrategy::QualityVbr { target_quality: (quality / 10.0) as f32 });
    let mut enc = b.build()?;
    let total = ch[0].len();
    let block = 16384;
    let mut pos = 0;
    while pos < total {
        check()?;
        let end = (pos + block).min(total);
        let slices: Vec<&[f32]> = ch.iter().map(|c| &c[pos..end]).collect();
        enc.encode_audio_block(&slices)?;
        pos = end;
        progress(pos as f64 / total.max(1) as f64);
    }
    let out = enc.finish()?;
    assert_beat_saber_vorbis(&out)?;
    Ok(out)
}

// ---------------------------------------------------------------- ZIP

fn crc_table() -> &'static [u32; 256] {
    static T: std::sync::OnceLock<[u32; 256]> = std::sync::OnceLock::new();
    T.get_or_init(|| {
        let mut t = [0u32; 256];
        for (n, slot) in t.iter_mut().enumerate() {
            let mut c = n as u32;
            for _ in 0..8 {
                c = if c & 1 != 0 { 0xedb88320 ^ (c >> 1) } else { c >> 1 };
            }
            *slot = c;
        }
        t
    })
}

pub fn crc32(data: &[u8]) -> u32 {
    let t = crc_table();
    let mut v = 0xffffffffu32;
    for &b in data {
        v = t[((v ^ b as u32) & 255) as usize] ^ (v >> 8);
    }
    v ^ 0xffffffff
}

pub struct ZipEntry {
    pub name: String,
    pub data: Vec<u8>,
}

/// makeCompressedZip: stored audio/png, raw-deflated text, UTF-8 flag, single-disk EOCD.
pub fn make_zip(entries: &[ZipEntry], check: &dyn Fn() -> anyhow::Result<()>, progress: &mut dyn FnMut(f64)) -> anyhow::Result<Vec<u8>> {
    use rayon::prelude::*;
    let deflate_text = adv::boolean("output.deflateText", true);
    let total = entries.iter().map(|e| e.data.len()).sum::<usize>().max(1) as f64;
    progress(0.0);
    struct P<'a> {
        name: &'a [u8],
        data: &'a [u8],
        packed: Option<Vec<u8>>,
        method: u16,
        crc: u32,
    }
    let prepared: Vec<P> = entries
        .par_iter()
        .map(|e| {
            let lower = e.name.to_lowercase();
            let text = deflate_text && [".dat", ".json", ".txt", ".csv"].iter().any(|x| lower.ends_with(x));
            let mut packed = None;
            let mut method = 0;
            if text && e.data.len() > 256 {
                let d = miniz_oxide::deflate::compress_to_vec(&e.data, 6);
                if d.len() < e.data.len() {
                    packed = Some(d);
                    method = 8;
                }
            }
            P { name: e.name.as_bytes(), data: &e.data, packed, method, crc: crc32(&e.data) }
        })
        .collect();
    check()?;
    progress(0.9);
    let now = chrono_like_now();
    let dos_time = ((now.3 & 31) << 11) | ((now.4 & 63) << 5) | ((now.5 / 2) & 31);
    let dos_date = (((now.0.saturating_sub(1980)) & 127) << 9) | ((now.1 & 15) << 5) | (now.2 & 31);
    let mut out: Vec<u8> = Vec::with_capacity(entries.iter().map(|e| e.data.len() + 80 + e.name.len() * 2).sum::<usize>() + 22);
    let u16w = |o: &mut Vec<u8>, v: u32| o.extend_from_slice(&(v as u16).to_le_bytes());
    let u32w = |o: &mut Vec<u8>, v: u32| o.extend_from_slice(&v.to_le_bytes());
    let mut offsets = vec![];
    let mut copied = 0usize;
    for p in &prepared {
        let packed: &[u8] = p.packed.as_deref().unwrap_or(p.data);
        offsets.push(out.len() as u32);
        u32w(&mut out, 0x04034b50);
        u16w(&mut out, 20);
        u16w(&mut out, 0x0800);
        u16w(&mut out, p.method as u32);
        u16w(&mut out, dos_time);
        u16w(&mut out, dos_date);
        u32w(&mut out, p.crc);
        u32w(&mut out, packed.len() as u32);
        u32w(&mut out, p.data.len() as u32);
        u16w(&mut out, p.name.len() as u32);
        u16w(&mut out, 0);
        out.extend_from_slice(p.name);
        out.extend_from_slice(packed);
        copied += p.data.len();
        check()?;
        progress(0.9 + 0.1 * copied as f64 / total);
    }
    let central = out.len() as u32;
    for (i, p) in prepared.iter().enumerate() {
        let packed_len = p.packed.as_ref().map(|v| v.len()).unwrap_or(p.data.len());
        u32w(&mut out, 0x02014b50);
        u16w(&mut out, 20);
        u16w(&mut out, 20);
        u16w(&mut out, 0x0800);
        u16w(&mut out, p.method as u32);
        u16w(&mut out, dos_time);
        u16w(&mut out, dos_date);
        u32w(&mut out, p.crc);
        u32w(&mut out, packed_len as u32);
        u32w(&mut out, p.data.len() as u32);
        u16w(&mut out, p.name.len() as u32);
        for _ in 0..4 {
            u16w(&mut out, 0);
        }
        u32w(&mut out, 0);
        u32w(&mut out, offsets[i]);
        out.extend_from_slice(p.name);
    }
    let central_len = out.len() as u32 - central;
    u32w(&mut out, 0x06054b50);
    u16w(&mut out, 0);
    u16w(&mut out, 0);
    u16w(&mut out, prepared.len() as u32);
    u16w(&mut out, prepared.len() as u32);
    u32w(&mut out, central_len);
    u32w(&mut out, central);
    u16w(&mut out, 0);
    progress(1.0);
    Ok(out)
}

/// Local time (year, month, day, hour, minute, second) via Win32/libc-free arithmetic on UTC
/// plus the system's current offset (from `date +%z` style env is unavailable, so use Windows API).
fn chrono_like_now() -> (u32, u32, u32, u32, u32, u32) {
    #[cfg(windows)]
    {
        #[repr(C)]
        #[derive(Default)]
        struct SystemTime {
            y: u16,
            m: u16,
            dow: u16,
            d: u16,
            h: u16,
            mi: u16,
            s: u16,
            ms: u16,
        }
        unsafe extern "system" {
            fn GetLocalTime(t: *mut SystemTime);
        }
        let mut t = SystemTime::default();
        unsafe { GetLocalTime(&mut t) };
        (t.y as u32, t.m as u32, t.d as u32, t.h as u32, t.mi as u32, t.s as u32)
    }
    #[cfg(not(windows))]
    {
        let secs = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_secs()).unwrap_or(0);
        let days = secs / 86400;
        let rem = secs % 86400;
        let (y, m, d) = civil_from_days(days as i64);
        (y as u32, m, d, (rem / 3600) as u32, ((rem % 3600) / 60) as u32, (rem % 60) as u32)
    }
}

#[cfg(not(windows))]
fn civil_from_days(z: i64) -> (i64, u32, u32) {
    let z = z + 719468;
    let era = z.div_euclid(146097);
    let doe = z - era * 146097;
    let yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
    let y = yoe + era * 400;
    let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    let mp = (5 * doy + 2) / 153;
    let d = (doy - (153 * mp + 2) / 5 + 1) as u32;
    let m = if mp < 10 { mp + 3 } else { mp - 9 } as u32;
    (if m <= 2 { y + 1 } else { y }, m, d)
}

/// packageFastContext
pub fn package(info: &Value, sets: &[CharacteristicSet], audio: &[u8], cover: &[u8], expected_count: usize, check: &dyn Fn() -> anyhow::Result<()>, progress: &mut dyn FnMut(f64)) -> anyhow::Result<Vec<u8>> {
    assert_beat_saber_vorbis(audio)?;
    let files = validate_info(info, sets, expected_count)?;
    let diffs: Vec<&Difficulty> = sets.iter().flat_map(|s| s.difficulties.iter()).collect();
    validate_native_charts(&diffs)?;
    let mut entries: Vec<ZipEntry> = vec![];
    entries.push(ZipEntry {
        name: "Info.dat".into(),
        data: if adv::boolean("output.prettyInfo", true) { json::stringify_pretty(info) } else { json::stringify(info) }.into_bytes(),
    });
    let beatmaps: Vec<ZipEntry> = {
        use rayon::prelude::*;
        diffs.par_iter().map(|d| ZipEntry { name: d.filename.clone(), data: json::stringify(&d.beatmap.to_json()).into_bytes() }).collect()
    };
    for f in &files {
        if !beatmaps.iter().any(|e| &e.name == f) {
            anyhow::bail!("Info.dat references missing beatmap file: {f}");
        }
    }
    entries.extend(beatmaps);
    entries.push(ZipEntry { name: "song.ogg".into(), data: audio.to_vec() });
    entries.push(ZipEntry { name: "cover.png".into(), data: cover.to_vec() });
    make_zip(&entries, check, progress)
}
