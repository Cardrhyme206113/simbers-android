//! 256×256 cover art (metadata.js createCover), rendered with tiny-skia + Segoe UI.

use ab_glyph::{Font, FontArc, PxScale, ScaleFont};
use tiny_skia::{Color, FillRule, GradientStop, LinearGradient, Paint, PathBuilder, Pixmap, Point, Rect, Shader, SpreadMode, Transform};

fn load_font(files: &[&str]) -> Option<FontArc> {
    let dir = std::env::var("WINDIR").map(|w| format!("{w}\\Fonts")).unwrap_or_else(|_| "C:\\Windows\\Fonts".into());
    for f in files {
        if let Ok(bytes) = std::fs::read(format!("{dir}\\{f}"))
            && let Ok(font) = FontArc::try_from_vec(bytes)
        {
            return Some(font);
        }
    }
    for f in ["/system/fonts/Roboto-Bold.ttf", "/system/fonts/Roboto-Regular.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", "/System/Library/Fonts/SFNS.ttf"] {
        if let Ok(bytes) = std::fs::read(f)
            && let Ok(font) = FontArc::try_from_vec(bytes)
        {
            return Some(font);
        }
    }
    None
}

fn hex(c: &str, a: f32) -> Color {
    let v = u32::from_str_radix(c.trim_start_matches('#'), 16).unwrap_or(0);
    Color::from_rgba8((v >> 16) as u8, (v >> 8) as u8, v as u8, (a * 255.0).round() as u8)
}

fn measure(font: &FontArc, size: f32, text: &str) -> f32 {
    let sf = font.as_scaled(PxScale::from(size));
    let mut w = 0.0;
    let mut prev = None;
    for ch in text.chars() {
        let id = sf.glyph_id(ch);
        if let Some(p) = prev {
            w += sf.kern(p, id);
        }
        w += sf.h_advance(id);
        prev = Some(id);
    }
    w
}

/// Fill `text` centred at (cx, cy) with textBaseline = middle.
fn fill_text(pix: &mut Pixmap, font: &FontArc, size: f32, text: &str, cx: f32, cy: f32, color: [u8; 4]) {
    let sf = font.as_scaled(PxScale::from(size));
    let width = measure(font, size, text);
    // Canvas "middle" baseline = halfway between em ascent/descent.
    let baseline = cy + (sf.ascent() + sf.descent()) / 2.0;
    let mut x = cx - width / 2.0;
    let mut prev = None;
    let (w, h) = (pix.width() as i32, pix.height() as i32);
    let data = pix.data_mut();
    for ch in text.chars() {
        let id = sf.glyph_id(ch);
        if let Some(p) = prev {
            x += sf.kern(p, id);
        }
        let glyph = id.with_scale_and_position(PxScale::from(size), ab_glyph::point(x, baseline));
        if let Some(outlined) = font.outline_glyph(glyph) {
            let b = outlined.px_bounds();
            outlined.draw(|gx, gy, cov| {
                let px = b.min.x as i32 + gx as i32;
                let py = b.min.y as i32 + gy as i32;
                if px < 0 || py < 0 || px >= w || py >= h {
                    return;
                }
                let a = cov.clamp(0.0, 1.0) * color[3] as f32 / 255.0;
                let i = ((py * w + px) * 4) as usize;
                for k in 0..3 {
                    let dst = data[i + k] as f32;
                    data[i + k] = (dst * (1.0 - a) + color[k] as f32 * a).round() as u8;
                }
                data[i + 3] = 255;
            });
        }
        x += sf.h_advance(id);
        prev = Some(id);
    }
}

/// Separable gaussian blur of a premultiplied RGBA buffer.
fn blur(pix: &mut Pixmap, sigma: f32) {
    let r = (sigma * 3.0).ceil() as i32;
    let kernel: Vec<f32> = (-r..=r).map(|i| (-(i * i) as f32 / (2.0 * sigma * sigma)).exp()).collect();
    let sum: f32 = kernel.iter().sum();
    let kernel: Vec<f32> = kernel.iter().map(|k| k / sum).collect();
    let (w, h) = (pix.width() as i32, pix.height() as i32);
    let src: Vec<f32> = pix.data().iter().map(|&v| v as f32).collect();
    let mut tmp = vec![0f32; src.len()];
    for y in 0..h {
        for x in 0..w {
            let mut acc = [0f32; 4];
            for (k, kv) in kernel.iter().enumerate() {
                let sx = x + k as i32 - r;
                if sx < 0 || sx >= w {
                    continue;
                }
                let i = ((y * w + sx) * 4) as usize;
                for c in 0..4 {
                    acc[c] += src[i + c] * kv;
                }
            }
            let o = ((y * w + x) * 4) as usize;
            tmp[o..o + 4].copy_from_slice(&acc);
        }
    }
    let data = pix.data_mut();
    for y in 0..h {
        for x in 0..w {
            let mut acc = [0f32; 4];
            for (k, kv) in kernel.iter().enumerate() {
                let sy = y + k as i32 - r;
                if sy < 0 || sy >= h {
                    continue;
                }
                let i = ((sy * w + x) * 4) as usize;
                for c in 0..4 {
                    acc[c] += tmp[i + c] * kv;
                }
            }
            let o = ((y * w + x) * 4) as usize;
            for c in 0..4 {
                data[o + c] = acc[c].round().clamp(0.0, 255.0) as u8;
            }
        }
    }
}

fn saber(pix: &mut Pixmap, t: Transform, y: f32, glow: &str, fill: &str) {
    let rect = Rect::from_xywh(-70.0, y, 140.0, 18.0).unwrap();
    let path = PathBuilder::from_rect(rect);
    let mut shadow = Pixmap::new(pix.width(), pix.height()).unwrap();
    let mut p = Paint::default();
    p.set_color(hex(glow, 1.0));
    p.anti_alias = true;
    shadow.fill_path(&path, &p, FillRule::Winding, t, None);
    blur(&mut shadow, 11.0);
    pix.draw_pixmap(0, 0, shadow.as_ref(), &tiny_skia::PixmapPaint::default(), Transform::identity(), None);
    p.set_color(hex(fill, 1.0));
    pix.fill_path(&path, &p, FillRule::Winding, t, None);
}

fn wrap(font: &FontArc, text: &str, size: f32, max: f32) -> Vec<String> {
    let mut lines = vec![];
    let mut line = String::new();
    for word in text.split_whitespace() {
        let cand = if line.is_empty() { word.to_string() } else { format!("{line} {word}") };
        if measure(font, size, &cand) <= max {
            line = cand;
            continue;
        }
        if !line.is_empty() {
            lines.push(std::mem::take(&mut line));
        }
        line = word.to_string();
        if measure(font, size, &line) > max {
            let mut chunk = String::new();
            for ch in line.chars() {
                let next = format!("{chunk}{ch}");
                if measure(font, size, &next) > max && !chunk.is_empty() {
                    lines.push(std::mem::replace(&mut chunk, ch.to_string()));
                } else {
                    chunk = next;
                }
            }
            line = chunk;
        }
    }
    if !line.is_empty() {
        lines.push(line);
    }
    lines
}

pub fn create_cover(song_name: &str) -> anyhow::Result<Vec<u8>> {
    let mut pix = Pixmap::new(256, 256).unwrap();
    let grad = LinearGradient::new(
        Point::from_xy(0.0, 0.0),
        Point::from_xy(256.0, 198.0),
        vec![GradientStop::new(0.0, hex("#3a111b", 1.0)), GradientStop::new(0.48, hex("#17151d", 1.0)), GradientStop::new(1.0, hex("#0d2d4d", 1.0))],
        SpreadMode::Pad,
        Transform::identity(),
    )
    .ok_or_else(|| anyhow::anyhow!("gradient"))?;
    let paint = Paint { shader: grad, ..Default::default() };
    pix.fill_rect(Rect::from_xywh(0.0, 0.0, 256.0, 256.0).unwrap(), &paint, Transform::identity(), None);
    let base = Transform::from_translate(128.0, 99.0).pre_rotate((-0.62f32).to_degrees());
    saber(&mut pix, base, -19.0, "#ff3f70", "#ff496f");
    saber(&mut pix, base.pre_rotate(1.24f32.to_degrees()), 1.0, "#47a3ff", "#4e9fff");
    let mut bar = Paint::default();
    bar.set_color(Color::from_rgba(0.0, 0.0, 0.0, 0.42).unwrap());
    pix.fill_rect(Rect::from_xywh(0.0, 198.0, 256.0, 58.0).unwrap(), &bar, Transform::identity(), None);
    let _ = Shader::SolidColor(Color::BLACK);
    let bold = load_font(&["segoeuib.ttf", "arialbd.ttf"]);
    let semi = load_font(&["seguisb.ttf", "segoeuib.ttf", "arialbd.ttf"]);
    if let (Some(bold), Some(semi)) = (bold, semi) {
        let max_w = 224.0;
        let clean = {
            let t = song_name.trim();
            if t.is_empty() { "Untitled".to_string() } else { t.to_string() }
        };
        let mut size = 16.0f32;
        let mut lines = wrap(&bold, &clean, size, max_w);
        while size > 8.0 && (lines.len() > 2 || lines.iter().any(|l| measure(&bold, size, l) > max_w)) {
            size -= 1.0;
            lines = wrap(&bold, &clean, size, max_w);
        }
        if lines.len() > 2 {
            lines.truncate(2);
            let mut last: Vec<char> = lines[1].chars().collect();
            while !last.is_empty() && measure(&bold, size, &format!("{}…", last.iter().collect::<String>())) > max_w {
                last.pop();
            }
            lines[1] = format!("{}…", last.iter().collect::<String>());
        }
        let lh = (size + 1.0).max(10.0);
        let first_y = 202.0 + (34.0 - lines.len() as f32 * lh) / 2.0 + lh / 2.0;
        for (i, l) in lines.iter().enumerate() {
            fill_text(&mut pix, &bold, size, l, 128.0, first_y + i as f32 * lh, [255, 255, 255, 255]);
        }
        fill_text(&mut pix, &semi, 9.0, "SIMBERS", 128.0, 246.0, [255, 255, 255, 179]);
    }
    Ok(pix.encode_png()?)
}
