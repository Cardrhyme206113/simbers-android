//! Attack Lab V2 onset detector (attack-lab.js + quietness.js).

use super::fft::{TablePlan, hann, hypot};
use crate::job::Job;
use crate::util::{clamp, jsm, median, now_ms};
use rayon::prelude::*;
use std::sync::atomic::{AtomicUsize, Ordering};

pub const SR: f64 = 11025.0;
pub const N: usize = 1024;
pub const HOP: usize = 128;
pub const FMIN: f64 = 60.0;
pub const FMAX: f64 = 5000.0;

pub fn bands_count() -> usize {
    (12.0 * jsm::log2(FMAX / FMIN)).ceil() as usize
}

pub struct AttackLabData {
    pub bands: Vec<f32>,
    pub rms: Vec<f32>,
    pub count: usize,
    pub hop: usize,
    pub rate: f64,
    pub parallel_workers: usize,
}

/// Chromium OfflineAudioContext resampling (linear interpolation, f64 index).
pub fn resample_to(samples: &[f32], sample_rate: f64, target: f64) -> Vec<f32> {
    if sample_rate == target {
        return samples.to_vec();
    }
    let length = ((samples.len() as f64 * target) / sample_rate).ceil() as usize;
    let ratio = sample_rate / target;
    let len = samples.len();
    let mut out = vec![0f32; length];
    if len == 0 {
        return out;
    }
    out.par_chunks_mut(8192).enumerate().for_each(|(ci, chunk)| {
        for (k, slot) in chunk.iter_mut().enumerate() {
            let i = ci * 8192 + k;
            let virt = i as f64 * ratio;
            let r1 = virt.floor() as usize;
            if r1 >= len {
                *slot = 0.0;
                continue;
            }
            let r2 = if r1 + 1 < len { r1 + 1 } else { r1 };
            let f = virt - r1 as f64;
            *slot = ((1.0 - f) * samples[r1] as f64 + f * samples[r2] as f64) as f32;
        }
    });
    out
}

struct Tables {
    plan: TablePlan,
    window: Vec<f32>,
    idx: Vec<i16>,
    weight: Vec<f32>,
}

fn tables() -> Tables {
    let b = bands_count() as f64;
    let mut idx = vec![0i16; N / 2 + 1];
    let mut weight = vec![0f32; N / 2 + 1];
    for k in 0..=N / 2 {
        let hz = (k as f64 * SR) / N as f64;
        let val = 12.0 * jsm::log2(hz / FMIN);
        if !val.is_finite() || val < 0.0 || val >= b - 1.0 {
            idx[k] = -1;
            continue;
        }
        idx[k] = val.floor() as i16;
        weight[k] = (val - idx[k] as f64) as f32;
    }
    Tables { plan: TablePlan::new(N), window: hann(N), idx, weight }
}

pub fn prepare(samples: &[f32], sample_rate: f64, job: &Job) -> anyhow::Result<AttackLabData> {
    let t0 = now_ms();
    let pcm = resample_to(samples, sample_rate, SR);
    job.stage("attackResample", now_ms() - t0);
    job.check()?;
    let t1 = now_ms();
    let b_count = bands_count();
    let count = pcm.len().div_ceil(HOP);
    let tb = tables();
    let mut bands = vec![0f32; count * b_count];
    let mut rms = vec![0f32; count];
    let done = AtomicUsize::new(0);
    const BATCH: usize = 384;
    let results: Vec<anyhow::Result<()>> = bands
        .par_chunks_mut(BATCH * b_count)
        .zip(rms.par_chunks_mut(BATCH))
        .enumerate()
        .map(|(ci, (bchunk, rchunk))| {
            job.check()?;
            let mut re = vec![0f32; N];
            let mut im = vec![0f32; N];
            let mut power = vec![0f32; b_count];
            let total = pcm.len() as i64;
            for local in 0..rchunk.len() {
                let t = ci * BATCH + local;
                power.fill(0.0);
                let center = (t * HOP) as i64;
                let mut sumsq = 0.0f64;
                for i in 0..N {
                    let si = center + i as i64 - (N as i64 >> 1);
                    let v = if si >= 0 && si < total { pcm[si as usize] } else { 0.0 } as f64;
                    sumsq += v * v;
                    re[i] = (v * tb.window[i] as f64) as f32;
                    im[i] = 0.0;
                }
                tb.plan.run(&mut re, &mut im);
                for k in 1..N / 2 {
                    let b = tb.idx[k];
                    if b < 0 {
                        continue;
                    }
                    let b = b as usize;
                    let mag = hypot(re[k], im[k]) * (2.0 / N as f64);
                    let w = tb.weight[k] as f64;
                    power[b] = (power[b] as f64 + mag * (1.0 - w)) as f32;
                    power[b + 1] = (power[b + 1] as f64 + mag * w) as f32;
                }
                let base = local * b_count;
                for b in 0..b_count {
                    bchunk[base + b] = jsm::log1p(power[b] as f64 * 40.0) as f32;
                }
                rchunk[local] = (sumsq / N as f64).sqrt() as f32;
            }
            let d = done.fetch_add(rchunk.len(), Ordering::Relaxed) + rchunk.len();
            let avg = d as f64 / count.max(1) as f64;
            job.set_progress(0.79 + 0.035 * avg, format!("V2: parallel note analysis {}%…", crate::util::js_round(100.0 * avg)));
            Ok(())
        })
        .collect();
    for r in results {
        r?;
    }
    job.check()?;
    job.stage("attackFft", now_ms() - t1);
    Ok(AttackLabData { bands, rms, count, hop: HOP, rate: SR, parallel_workers: rayon::current_num_threads().min(count.div_ceil(BATCH)) })
}

fn moving_average(arr: &[f32], radius: usize) -> Vec<f32> {
    let n = arr.len();
    let mut prefix = vec![0f64; n + 1];
    for i in 0..n {
        prefix[i + 1] = prefix[i] + arr[i] as f64;
    }
    (0..n)
        .map(|i| {
            let a = i.saturating_sub(radius);
            let b = (i + radius + 1).min(n);
            ((prefix[b] - prefix[a]) / (b - a) as f64) as f32
        })
        .collect()
}

pub fn quietness_floor(rms: &[f32]) -> f64 {
    let mut sample: Vec<f32> = rms.iter().step_by(4).copied().filter(|v| (*v as f64) > 1e-7).collect();
    if sample.is_empty() {
        return f64::INFINITY;
    }
    sample.sort_by(|a, b| a.partial_cmp(b).unwrap());
    sample[((sample.len() - 1) as f64 * 0.9).floor() as usize] as f64 * 0.09
}

pub fn has_audible_transient(rms: &[f32], frame: usize, floor: f64, frame_seconds: f64) -> bool {
    let prior = crate::util::js_round(0.012 / frame_seconds).max(1.0) as usize;
    let following = crate::util::js_round(0.024 / frame_seconds).max(1.0) as usize;
    let from = frame.saturating_sub(prior);
    let to = (frame + following).min(rms.len() - 1);
    (from..=to).any(|i| rms[i] as f64 >= floor)
}

#[derive(Clone, Debug)]
pub struct IntensityCandidate {
    pub time: f64,
    pub frame: usize,
    pub score: f64,
    pub raw: f64,
    pub confidence: f64,
    pub change_index: f64,
    pub stability_index: f64,
    pub passed_primary_threshold: bool,
    pub default_accepted: bool,
}

#[derive(Clone, Debug, Default)]
pub struct Detection {
    pub times: Vec<f64>,
    pub median_interval: f64,
    pub timing_variation: f64,
    pub confidence: f64,
    pub event_density: f64,
    pub strength: Vec<f64>,
    pub scores: Vec<f64>,
    pub state_change: Vec<f64>,
    pub stability_index: Vec<f64>,
    pub average_state_change: f64,
    pub candidate_count: usize,
    pub reserve_candidate_count: usize,
    pub quiet_rejected_candidate_count: usize,
    pub intensity_candidates: Vec<IntensityCandidate>,
}

/// detectAttackLabV2
pub fn detect(d: &AttackLabData, duration: f64) -> Detection {
    let b_count = bands_count();
    let n = d.count;
    let bands = &d.bands;
    let rms = &d.rms;
    let frame_seconds = d.hop as f64 / d.rate;
    let sensitivity = 60.0;
    let radius = 3usize;
    let gap_ms = 90.0;
    let lag = 2usize;
    let mut raw = vec![0f32; n];
    raw.par_iter_mut().enumerate().skip(lag).for_each(|(t, slot)| {
        let base = t * b_count;
        let old = (t - lag) * b_count;
        let mut flux = 0.0f64;
        for b in 0..b_count {
            let mut maximum = 0f32;
            let lo = b.saturating_sub(radius);
            let hi = (b + radius).min(b_count - 1);
            for k in lo..=hi {
                let v = bands[old + k];
                if v > maximum {
                    maximum = v;
                }
            }
            flux += (bands[base + b] as f64 - maximum as f64).max(0.0);
        }
        let e = (jsm::log1p(rms[t] as f64 * 12.0) - jsm::log1p(rms[t - lag] as f64 * 12.0)).max(0.0);
        *slot = (flux / b_count as f64 + e * 0.18) as f32;
    });
    let mut smoothed = vec![0f32; n];
    if n >= 5 {
        for i in 2..n - 2 {
            smoothed[i] = ((raw[i - 2] as f64 + 2.0 * raw[i - 1] as f64 + 3.0 * raw[i] as f64 + 2.0 * raw[i + 1] as f64 + raw[i + 2] as f64)
                / 9.0) as f32;
        }
    }
    let background = moving_average(&smoothed, ((0.31 / frame_seconds).floor() as usize).max(5));
    let mut prom = vec![0f32; n];
    let mut sorted: Vec<f32> = Vec::with_capacity(n / 2 + 1);
    for t in 0..n {
        prom[t] = (smoothed[t] as f64 - background[t] as f64 * 0.85).max(0.0) as f32;
        if t % 2 == 0 {
            sorted.push(prom[t]);
        }
    }
    sorted.sort_by(|a, b| a.partial_cmp(b).unwrap());
    let quantile = |p: f64| -> f64 {
        if sorted.is_empty() {
            return 0.0;
        }
        let i = ((sorted.len() - 1) as f64 * p).floor() as usize;
        sorted[i.min(sorted.len() - 1)] as f64
    };
    let level = quantile(0.9);
    let peak_level = quantile(0.99);
    let threshold = 0.0012f64.max(level * (0.92 - 0.007 * sensitivity)).max(peak_level * (0.19 - 0.00135 * sensitivity));
    let loudness_floor = quietness_floor(rms);
    let mut quiet_rejected = 0usize;
    let reserve_floor = 0.0006f64.max(threshold * 0.48);
    struct C {
        time: f64,
        strength: f64,
        frame: usize,
    }
    let mut exact: Vec<C> = vec![];
    let mut reserves: Vec<C> = vec![];
    if n > 6 {
        for i in 3..n - 3 {
            if !(prom[i] >= prom[i - 1] && prom[i] > prom[i + 1]) {
                continue;
            }
            let sm = smoothed[i] as f64;
            let bg = background[i] as f64;
            let base_valid = sm > bg * 1.2;
            let v = prom[i] as f64;
            if v > reserve_floor && sm > bg * 1.045 && !has_audible_transient(rms, i, loudness_floor, frame_seconds) {
                quiet_rejected += 1;
                continue;
            }
            if v >= threshold && base_valid {
                exact.push(C { time: i as f64 * frame_seconds, strength: v, frame: i });
            }
            if v > reserve_floor && sm > bg * 1.045 {
                reserves.push(C { time: i as f64 * frame_seconds, strength: v, frame: i });
            }
        }
    }
    let mut selected: Vec<&C> = vec![];
    for c in &exact {
        if let Some(last) = selected.last()
            && c.time - last.time < gap_ms / 1000.0
        {
            if c.strength > last.strength {
                *selected.last_mut().unwrap() = c;
            }
            continue;
        }
        selected.push(c);
    }
    let selected_frames: std::collections::HashSet<usize> = selected.iter().map(|c| c.frame).collect();
    let duration_seconds = duration.max(0.001);
    let times: Vec<f64> = selected.iter().map(|c| c.time).collect();
    let intervals: Vec<f64> = times.windows(2).map(|w| w[1] - w[0]).collect();
    let median_interval = if intervals.is_empty() { 0.5 } else { median(&intervals) };
    let deviations: Vec<f64> = intervals.iter().map(|v| (v - median_interval).abs()).collect();
    let timing_variation = if intervals.is_empty() { 0.0 } else { clamp(median(&deviations) / (median_interval + 1e-6), 0.0, 2.0) };
    let divisor = (peak_level * 1.2).max(0.001);
    let intensity_candidates: Vec<IntensityCandidate> = reserves
        .iter()
        .map(|c| IntensityCandidate {
            time: c.time,
            frame: c.frame,
            score: c.strength,
            raw: c.strength,
            confidence: clamp(c.strength / divisor, 0.0, 1.0),
            change_index: clamp(c.strength / peak_level.max(0.001), 0.0, 1.0),
            stability_index: 1.0,
            passed_primary_threshold: c.strength > threshold && smoothed[c.frame] as f64 > background[c.frame] as f64 * 1.2,
            default_accepted: selected_frames.contains(&c.frame),
        })
        .collect();
    let strength: Vec<f64> = selected.iter().map(|c| clamp(c.strength / peak_level.max(0.001), 0.0, 1.0)).collect();
    let mean_strength = if strength.is_empty() {
        0.0
    } else {
        strength.iter().fold(0.0, |a, b| a + b) / strength.len() as f64
    };
    Detection {
        median_interval,
        timing_variation,
        confidence: mean_strength,
        event_density: times.len() as f64 / duration_seconds,
        scores: selected.iter().map(|c| c.strength).collect(),
        state_change: strength.clone(),
        stability_index: vec![1.0; selected.len()],
        average_state_change: mean_strength,
        candidate_count: exact.len(),
        reserve_candidate_count: intensity_candidates.len(),
        quiet_rejected_candidate_count: quiet_rejected,
        intensity_candidates,
        strength,
        times,
    }
}
