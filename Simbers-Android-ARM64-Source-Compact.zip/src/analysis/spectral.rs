//! Pitch/timbre spectral frontends (unified-worker.js, spectral-worker.js,
//! audio/analysis.js). Worker chunking is replaced with rayon; every chunk
//! recomputes the same warm-up frames, so results do not depend on threading.

use super::fft::{TablePlan, fft_recurrence, hann, hypot};
use crate::job::Job;
use crate::settings as adv;
use crate::util::{clamp, jsm, median_f32, now_ms, sigmoid};
use rayon::prelude::*;
use std::sync::atomic::{AtomicUsize, Ordering};

pub struct SharedSpectral {
    pub n: usize,
    pub hop: usize,
    pub pitch_stride: usize,
    pub min_midi: i32,
    pub max_midi: i32,
    pub p: usize,
    pub pitch_frames: usize,
    pub spectral_frames: usize,
    /// pitch_frames * p, f32 like the Float32Array rows.
    pub salience: Vec<f32>,
    pub state_bands: Vec<Vec<f32>>,
    pub elapsed_ms: f64,
}

struct Harmonics {
    k: Vec<Vec<i32>>,
    frac: Vec<Vec<f32>>,
    weight: Vec<Vec<f32>>,
    weight_sum: Vec<f32>,
    base_bin: Vec<i32>,
}

fn harmonic_tables(p_count: usize, min_midi: i32, harmonics: usize, n: usize, sample_rate: f64) -> Harmonics {
    let half = (n >> 1) as f64;
    let mut h = Harmonics { k: vec![], frac: vec![], weight: vec![], weight_sum: vec![], base_bin: vec![] };
    for p in 0..p_count {
        let f0 = 440.0 * jsm::pow(2.0, ((min_midi + p as i32 - 69) as f64) / 12.0);
        h.base_bin.push(clamp(crate::util::js_round((f0 * n as f64) / sample_rate), 1.0, half - 1.0) as i32);
        let (mut ks, mut fr, mut ws) = (vec![], vec![], vec![]);
        let mut sum = 0.0f64;
        for hh in 1..=harmonics {
            let hz = f0 * hh as f64;
            if hz >= sample_rate / 2.0 {
                break;
            }
            let bin = (hz * n as f64) / sample_rate;
            let k = bin.floor();
            let w = 1.0 / (hh as f64).sqrt();
            ks.push(k as i32);
            fr.push((bin - k) as f32);
            ws.push(w as f32);
            sum += w;
        }
        h.k.push(ks);
        h.frac.push(fr);
        h.weight.push(ws);
        h.weight_sum.push(if sum != 0.0 { sum as f32 } else { 1.0 });
    }
    h
}

fn band_edges(n: usize, sample_rate: f64) -> Vec<usize> {
    let mut edge_hz: Vec<f64> = adv::number_list("spectral.edges", &[38.0, 90.0, 180.0, 360.0, 720.0, 1440.0, 2880.0, 5760.0])
        .into_iter()
        .filter(|f| *f > 0.0 && *f < sample_rate / 2.0)
        .collect();
    edge_hz.sort_by(|a, b| a.partial_cmp(b).unwrap());
    edge_hz.push(sample_rate / 2.0);
    edge_hz
        .iter()
        .map(|f| clamp(crate::util::js_round((f * n as f64) / sample_rate), 1.0, ((n >> 1) - 1) as f64) as usize)
        .collect()
}

/// Scores -> robust z salience (shared by the frontends).
#[inline]
fn salience_row(scores: &[f32], dev: &mut [f32], out: &mut [f32]) {
    let med = median_f32(scores);
    for (d, s) in dev.iter_mut().zip(scores) {
        *d = ((*s as f64) - med).abs() as f32;
    }
    let mad = median_f32(dev) + 1e-4;
    for (o, s) in out.iter_mut().zip(scores) {
        *o = clamp(((*s as f64) - med) / (1.4826 * mad), -2.0, 8.0) as f32;
    }
}

fn worker_count_default() -> usize {
    // PARALLEL_ANALYSIS_WORKERS = min(6, max(2, hc - 2)); Rust uses the full pool.
    rayon::current_num_threads().max(1)
}

/// NORMAL mode unified frontend (N=2048, hop=512, pitchStride=2 at 22.05 kHz).
pub fn compute_unified(samples: &[f32], sample_rate: f64, job: &Job) -> anyhow::Result<Option<SharedSpectral>> {
    job.check()?;
    let n = 2048usize;
    let hop = 512usize;
    let pitch_stride = 2usize;
    if sample_rate != 22050.0 {
        anyhow::bail!("Unified frontend requires 22050 Hz input");
    }
    let min_midi = adv::integer("pitch.minMidi", 36.0).clamp(0, 126) as i32;
    let max_midi = adv::integer("pitch.maxMidi", 96.0).min(127).max(min_midi as i64 + 1) as i32;
    let p_count = (max_midi - min_midi + 1) as usize;
    let spectral_frames = samples.len().div_ceil(hop).max(1);
    let pitch_frames = (spectral_frames - 1) / pitch_stride + 1;
    let edges = band_edges(n, sample_rate);
    let bands = edges.len() - 1;
    let harmonics = adv::integer("pitch.harmonics", 8.0).max(1) as usize;
    let local_onset_weight = adv::number("pitch.localOnsetWeight", 0.1);
    let global_flux_weight = adv::number("pitch.globalFluxWeight", 0.002);
    let magnitude_scale = adv::number("spectral.magnitudeScale", 10.0);
    let tables = harmonic_tables(p_count, min_midi, harmonics, n, sample_rate);
    let window = hann(n);
    let plan = TablePlan::new(n);
    let half = n >> 1;
    let full = samples.len() as i64;
    let started = now_ms();

    let chunks = worker_count_default().min((spectral_frames / 384).max(1)).max(1);
    let done = AtomicUsize::new(0);
    struct ChunkOut {
        start: usize,
        bands: Vec<f32>,
        pitch_first: usize,
        salience: Vec<f32>,
    }
    let outs: Vec<anyhow::Result<ChunkOut>> = (0..chunks)
        .into_par_iter()
        .map(|wi| {
            let unique_start = (wi * spectral_frames) / chunks;
            let unique_end = ((wi + 1) * spectral_frames) / chunks;
            let local_start = unique_start.saturating_sub(2);
            let unique_frames = unique_end - unique_start;
            let pitch_start = unique_start.div_ceil(pitch_stride);
            let pitch_end = unique_end.div_ceil(pitch_stride);
            let pitch_count = pitch_end.saturating_sub(pitch_start);
            let mut state = vec![0f32; unique_frames * bands];
            let mut salience = vec![0f32; pitch_count * p_count];
            let mut re = vec![0f32; n];
            let mut im = vec![0f32; n];
            let mut pitch_mag = vec![0f32; half];
            let mut prev_pitch = vec![0f32; half];
            let mut magnitudes = vec![0f32; half];
            let mut scores = vec![0f32; p_count];
            let mut dev = vec![0f32; p_count];
            for t in local_start..unique_end {
                if (t - local_start) & 255 == 0 {
                    job.check()?;
                }
                let center = (t * hop) as i64;
                for i in 0..n {
                    let pos = center + i as i64 - (n as i64 >> 1);
                    let v = if pos >= 0 && pos < full { samples[pos as usize] } else { 0.0 };
                    re[i] = ((v as f64) * (window[i] as f64)) as f32;
                    im[i] = 0.0;
                }
                plan.run(&mut re, &mut im);
                let mut pitch_flux = 0.0f64;
                let is_pitch_frame = t % pitch_stride == 0;
                let is_pitch_pred = (t + 1) % pitch_stride == 0;
                let needs_pitch = is_pitch_frame || is_pitch_pred;
                for k in 1..half {
                    let magnitude = hypot(re[k], im[k]);
                    magnitudes[k] = magnitude as f32;
                    if needs_pitch {
                        let pv = jsm::log1p(4.0 * magnitude);
                        pitch_mag[k] = pv as f32;
                        if is_pitch_frame {
                            pitch_flux += (pv - prev_pitch[k] as f64).max(0.0);
                        }
                    }
                }
                if t >= unique_start {
                    let u = t - unique_start;
                    for b in 0..bands {
                        let mut total = 0.0f64;
                        let mut count = 0usize;
                        for k in edges[b]..edges[b + 1] {
                            total += jsm::log1p(magnitude_scale * magnitudes[k] as f64);
                            count += 1;
                        }
                        state[b * unique_frames + u] = (total / count.max(1) as f64) as f32;
                    }
                    if is_pitch_frame {
                        let pi = t / pitch_stride - pitch_start;
                        for p in 0..p_count {
                            let mut score = 0.0f64;
                            for h in 0..tables.k[p].len() {
                                let k = tables.k[p][h] as usize;
                                let f = tables.frac[p][h] as f64;
                                score += (pitch_mag[k] as f64 * (1.0 - f) + pitch_mag[k + 1] as f64 * f) * tables.weight[p][h] as f64;
                            }
                            let base = tables.base_bin[p] as usize;
                            let mut local_flux = 0.0f64;
                            for k in base.saturating_sub(2).max(1)..=(base + 2).min(half - 1) {
                                local_flux += (pitch_mag[k] as f64 - prev_pitch[k] as f64).max(0.0);
                            }
                            scores[p] = (score / tables.weight_sum[p] as f64 + local_onset_weight * local_flux + global_flux_weight * pitch_flux) as f32;
                        }
                        salience_row(&scores, &mut dev, &mut salience[pi * p_count..(pi + 1) * p_count]);
                    }
                }
                if is_pitch_pred {
                    prev_pitch.copy_from_slice(&pitch_mag);
                }
                if (t - local_start) & 255 == 0 {
                    let d = done.fetch_add(256, Ordering::Relaxed) + 256;
                    let ratio = (d as f64 / spectral_frames as f64).min(1.0);
                    job.set_progress(0.05 + 0.7 * ratio, format!("Unified FFT / Attack Lab {}%…", crate::util::js_round(100.0 * ratio)));
                }
            }
            Ok(ChunkOut { start: unique_start, bands: state, pitch_first: pitch_start, salience })
        })
        .collect();
    let mut state_bands = vec![vec![0f32; spectral_frames]; bands];
    let mut salience = vec![0f32; pitch_frames * p_count];
    for out in outs {
        let out = out?;
        let unique = out.bands.len() / bands.max(1);
        for b in 0..bands {
            state_bands[b][out.start..out.start + unique].copy_from_slice(&out.bands[b * unique..(b + 1) * unique]);
        }
        let off = out.pitch_first * p_count;
        salience[off..off + out.salience.len()].copy_from_slice(&out.salience);
    }
    job.check()?;
    Ok(Some(SharedSpectral {
        n,
        hop,
        pitch_stride,
        min_midi,
        max_midi,
        p: p_count,
        pitch_frames,
        spectral_frames,
        salience,
        state_bands,
        elapsed_ms: now_ms() - started,
    }))
}

/// HIGH mode shared spectral frontend (spectral-worker.js).
pub fn compute_shared(samples: &[f32], sample_rate: f64, job: &Job) -> anyhow::Result<Option<SharedSpectral>> {
    job.check()?;
    let detector_n = adv::nearest_power_of_two("detector.fftSize", 1024.0);
    let pitch_n = adv::nearest_power_of_two("pitch.fftSize", 4096.0);
    let n = detector_n.max(pitch_n.min(detector_n * 2));
    let hop = adv::integer("detector.hopSize", 256.0).max(1) as usize;
    let requested_pitch_hop = (adv::integer("pitch.hopSize", 1024.0) as usize).max(hop);
    let pitch_stride = (crate::util::js_round(requested_pitch_hop as f64 / hop as f64) as usize).max(1);
    let min_midi = adv::integer("pitch.minMidi", 36.0).clamp(0, 126) as i32;
    let max_midi = adv::integer("pitch.maxMidi", 96.0).min(127).max(min_midi as i64 + 1) as i32;
    let p_count = (max_midi - min_midi + 1) as usize;
    let spectral_frames = if samples.len() >= n { (samples.len() - n) / hop + 1 } else {
        // Math.floor((len - N)/hop) + 1 with negative numerator
        let v = ((samples.len() as f64 - n as f64) / hop as f64).floor() + 1.0;
        v.max(1.0) as usize
    }
    .max(1);
    let pitch_frames = ((spectral_frames - 1) / pitch_stride + 1).max(1);
    if spectral_frames < 128 {
        return Ok(None);
    }
    let edges = band_edges(n, sample_rate);
    let bands = edges.len() - 1;
    let harmonics = adv::integer("pitch.harmonics", 8.0).max(1) as usize;
    let local_onset_weight = adv::number("pitch.localOnsetWeight", 0.1);
    let global_flux_weight = adv::number("pitch.globalFluxWeight", 0.002);
    let magnitude_scale = adv::number("spectral.magnitudeScale", 10.0);
    let tables = harmonic_tables(p_count, min_midi, harmonics, n, sample_rate);
    let window = hann(n);
    let half = n >> 1;
    let started = now_ms();
    let chunks = worker_count_default().min(spectral_frames).max(1);
    let done = AtomicUsize::new(0);
    struct ChunkOut {
        start: usize,
        bands: Vec<f32>,
        first_pitch: usize,
        salience: Vec<f32>,
    }
    let outs: Vec<anyhow::Result<ChunkOut>> = (0..chunks)
        .into_par_iter()
        .map(|wi| {
            let unique_start = (wi * spectral_frames) / chunks;
            let unique_end = ((wi + 1) * spectral_frames) / chunks;
            let local_start = unique_start.saturating_sub(1);
            let unique_frames = unique_end - unique_start;
            let first_pitch = unique_start.div_ceil(pitch_stride);
            let last_pitch = unique_end.div_ceil(pitch_stride);
            let pf = last_pitch.saturating_sub(first_pitch);
            let mut state = vec![0f32; unique_frames * bands];
            let mut salience = vec![0f32; pf * p_count];
            let mut re = vec![0f32; n];
            let mut im = vec![0f32; n];
            let mut pitch_mag = vec![0f32; half];
            let mut prev_pitch = vec![0f32; half];
            let mut det_mag = vec![0f32; half];
            let mut scores = vec![0f32; p_count];
            let mut dev = vec![0f32; p_count];
            for t in local_start..unique_end {
                if (t - local_start) & 127 == 0 {
                    job.check()?;
                }
                let off = t * hop;
                for i in 0..n {
                    let v = samples.get(off + i).copied().unwrap_or(0.0);
                    re[i] = ((v as f64) * (window[i] as f64)) as f32;
                    im[i] = 0.0;
                }
                fft_recurrence(&mut re, &mut im);
                let mut pitch_flux = 0.0f64;
                for k in 1..half {
                    let a = hypot(re[k], im[k]);
                    pitch_mag[k] = jsm::log1p(4.0 * a) as f32;
                    det_mag[k] = jsm::log1p(magnitude_scale * a) as f32;
                    pitch_flux += (pitch_mag[k] as f64 - prev_pitch[k] as f64).max(0.0);
                }
                let in_unique = t >= unique_start && t < unique_end;
                if in_unique {
                    let u = t - unique_start;
                    for b in 0..bands {
                        let mut level = 0.0f64;
                        let mut count = 0usize;
                        for k in edges[b]..edges[b + 1] {
                            level += det_mag[k] as f64;
                            count += 1;
                        }
                        state[b * unique_frames + u] = (level / count.max(1) as f64) as f32;
                    }
                }
                if t % pitch_stride == 0 && in_unique {
                    let pi = t / pitch_stride - first_pitch;
                    for p in 0..p_count {
                        let mut s = 0.0f64;
                        for h in 0..tables.k[p].len() {
                            let k = tables.k[p][h] as usize;
                            let f = tables.frac[p][h] as f64;
                            s += (pitch_mag[k] as f64 * (1.0 - f) + pitch_mag[k + 1] as f64 * f) * tables.weight[p][h] as f64;
                        }
                        let kb = tables.base_bin[p] as usize;
                        let mut local_flux = 0.0f64;
                        for k in kb.saturating_sub(2).max(1)..=(kb + 2).min(half - 1) {
                            local_flux += (pitch_mag[k] as f64 - prev_pitch[k] as f64).max(0.0);
                        }
                        scores[p] = (s / tables.weight_sum[p] as f64 + local_onset_weight * local_flux + global_flux_weight * pitch_flux) as f32;
                    }
                    salience_row(&scores, &mut dev, &mut salience[pi * p_count..(pi + 1) * p_count]);
                }
                prev_pitch.copy_from_slice(&pitch_mag);
                if (t - local_start) & 127 == 0 {
                    let d = done.fetch_add(128, Ordering::Relaxed) + 128;
                    let ratio = (d as f64 / spectral_frames as f64).min(1.0);
                    job.set_progress(0.05 + 0.57 * ratio, format!("Shared spectral analysis {}%…", crate::util::js_round(ratio * 100.0)));
                }
            }
            Ok(ChunkOut { start: unique_start, bands: state, first_pitch, salience })
        })
        .collect();
    let mut state_bands = vec![vec![0f32; spectral_frames]; bands];
    let mut salience = vec![0f32; pitch_frames * p_count];
    for out in outs {
        let out = out?;
        let unique = out.bands.len() / bands.max(1);
        for b in 0..bands {
            state_bands[b][out.start..out.start + unique].copy_from_slice(&out.bands[b * unique..(b + 1) * unique]);
        }
        let rows = out.salience.len() / p_count;
        for r in 0..rows {
            let pi = out.first_pitch + r;
            if pi >= pitch_frames {
                continue;
            }
            salience[pi * p_count..(pi + 1) * p_count].copy_from_slice(&out.salience[r * p_count..(r + 1) * p_count]);
        }
    }
    Ok(Some(SharedSpectral {
        n,
        hop,
        pitch_stride,
        min_midi,
        max_midi,
        p: p_count,
        pitch_frames,
        spectral_frames,
        salience,
        state_bands,
        elapsed_ms: now_ms() - started,
    }))
}

#[derive(Clone, Debug)]
pub struct FrameData {
    pub time: f64,
    pub foreground: Option<i32>,
    pub confidence: f64,
}

#[derive(Clone, Debug)]
pub struct PitchEvent {
    pub midi: i32,
    pub start: f64,
    pub end: f64,
    pub duration: f64,
    pub confidence: f64,
}

#[derive(Clone, Copy, Debug)]
pub struct PitchOpts {
    pub tracks: usize,
    pub confidence: f64,
    pub ambiguity: f64,
    pub stability: f64,
}

#[derive(Default, Clone, Debug)]
pub struct AnalysisPerf {
    pub shared_fft_frontend: f64,
    pub pitch_tracking: f64,
    pub foreground_selection: f64,
    pub legacy_fallback: bool,
    pub shared_fft_size: usize,
    pub shared_fft_hop: usize,
    pub pitch_stride: usize,
    pub pitch_frames: usize,
    pub spectral_frames: usize,
}

pub struct PitchAnalysis {
    pub sample_rate: f64,
    pub frame_size: usize,
    pub hop_size: usize,
    pub min_midi: i32,
    pub max_midi: i32,
    pub duration: f64,
    pub frames: Vec<FrameData>,
    pub layers: Vec<Vec<Option<i32>>>,
    pub events: Vec<PitchEvent>,
    pub coverage: f64,
    pub shared_hop: usize,
    pub state_bands: Option<Vec<Vec<f32>>>,
    pub performance: AnalysisPerf,
}

/// viterbiTrack (melody.js) with Float32Array emulation.
pub fn viterbi_track(s: &[f32], t_count: usize, p_count: usize, stability: f64) -> Vec<i16> {
    let mut prev = vec![0f32; p_count];
    let mut cur = vec![0f32; p_count];
    let mut back = vec![0i16; t_count * p_count];
    let mut penalty = [0f32; 19];
    for (jump, slot) in penalty.iter_mut().enumerate() {
        let j = jump as f64;
        *slot = (stability * (0.075 * j + 0.01 * j * j)) as f32;
    }
    for p in 0..p_count {
        prev[p] = s[p];
        back[p] = p as i16;
    }
    for t in 1..t_count {
        let base = t * p_count;
        for p in 0..p_count {
            let mut best = -1e9f64;
            let mut best_q = p;
            let lo = p.saturating_sub(18);
            let hi = (p + 18).min(p_count - 1);
            for q in lo..=hi {
                let v = prev[q] as f64 - penalty[p.abs_diff(q)] as f64;
                if v > best {
                    best = v;
                    best_q = q;
                }
            }
            cur[p] = (best + s[base + p] as f64) as f32;
            back[base + p] = best_q as i16;
        }
        std::mem::swap(&mut prev, &mut cur);
    }
    let mut state = 0usize;
    for p in 1..p_count {
        if prev[p] > prev[state] {
            state = p;
        }
    }
    let mut path = vec![0i16; t_count];
    for t in (0..t_count).rev() {
        path[t] = state as i16;
        state = back[t * p_count + state] as usize;
    }
    path
}

fn midi_to_hz(m: f64) -> f64 {
    440.0 * jsm::pow(2.0, (m - 69.0) / 12.0)
}

/// consolidateEvents (visualization.js)
fn consolidate_events(frames: &[FrameData], frame_dur: f64) -> Vec<PitchEvent> {
    struct Cur {
        midi: i32,
        start: f64,
        end: f64,
        conf: f64,
        count: usize,
    }
    let mut out: Vec<Cur> = vec![];
    let mut current: Option<Cur> = None;
    for f in frames {
        match f.foreground {
            None => {
                if let Some(mut c) = current.take() {
                    c.end = f.time;
                    out.push(c);
                }
            }
            Some(note) => {
                if current.as_ref().map(|c| c.midi != note).unwrap_or(true) {
                    if let Some(mut c) = current.take() {
                        c.end = f.time;
                        out.push(c);
                    }
                    current = Some(Cur { midi: note, start: f.time, end: f.time + frame_dur, conf: f.confidence, count: 1 });
                } else if let Some(c) = current.as_mut() {
                    c.end = f.time + frame_dur;
                    c.conf += f.confidence;
                    c.count += 1;
                }
            }
        }
    }
    if let Some(c) = current {
        out.push(c);
    }
    use crate::util::to_fixed_num as tf;
    out.into_iter()
        .filter(|e| e.end - e.start >= frame_dur * 1.5)
        .map(|e| PitchEvent {
            midi: e.midi,
            start: tf(e.start, 3),
            end: tf(e.end, 3),
            duration: tf(e.end - e.start, 3),
            confidence: tf(e.conf / e.count as f64, 3),
        })
        .collect()
}

fn track_and_select(
    salience: &[f32],
    pitch_frames: usize,
    p_count: usize,
    min_midi: i32,
    pitch_hop: usize,
    sample_rate: f64,
    opts: &PitchOpts,
    job: &Job,
) -> anyhow::Result<(Vec<Vec<i16>>, Vec<FrameData>, usize, f64, f64)> {
    let t0 = now_ms();
    let mut residual = salience.to_vec();
    let mut layers = vec![];
    let residual_center = adv::number("pitch.residualCenter", 2.8);
    let residual_slope = adv::number("pitch.residualSlope", 0.6);
    for k in 0..opts.tracks {
        let path = viterbi_track(&residual, pitch_frames, p_count, opts.stability);
        for t in 0..pitch_frames {
            let p = path[t] as i64;
            if p >= 0 {
                for d in -2i64..=2 {
                    let q = p + d;
                    if q >= 0 && (q as usize) < p_count {
                        let idx = t * p_count + q as usize;
                        residual[idx] = (residual[idx] as f64 - (residual_center - residual_slope * d.abs() as f64)) as f32;
                    }
                }
            }
        }
        layers.push(path);
        job.set_progress(0.63 + 0.12 * ((k + 1) as f64 / opts.tracks as f64), format!("Tracked layer {}/{}…", k + 1, opts.tracks));
        job.check()?;
    }
    let tracking_ms = now_ms() - t0;
    let f0 = now_ms();
    let mut frames = Vec::with_capacity(pitch_frames);
    let mut foreground_frames = 0;
    for t in 0..pitch_frames {
        let mut cands: Vec<(usize, f64)> = layers
            .iter()
            .filter_map(|l| {
                let p = l[t];
                if p >= 0 { Some((p as usize, salience[t * p_count + p as usize] as f64)) } else { None }
            })
            .collect();
        cands.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal));
        let best = cands.first().copied();
        let second = cands.get(1).copied();
        let activity = best.map(|b| sigmoid((b.1 - 0.35) * 1.3)).unwrap_or(0.0);
        let margin = best.map(|b| b.1 - second.map(|s| s.1).unwrap_or(0.0)).unwrap_or(0.0);
        let clarity = sigmoid((margin - opts.ambiguity) * 3.0);
        let confidence = clamp(activity * clarity, 0.0, 1.0);
        let dominant = best.map(|b| b.1 > 0.1).unwrap_or(false) && confidence >= opts.confidence;
        if dominant {
            foreground_frames += 1;
        }
        frames.push(FrameData {
            time: (t * pitch_hop) as f64 / sample_rate,
            foreground: if dominant { Some(min_midi + best.unwrap().0 as i32) } else { None },
            confidence,
        });
    }
    let _ = midi_to_hz;
    Ok((layers, frames, foreground_frames, tracking_ms, now_ms() - f0))
}

/// analyzeSamples + analyzePitchFallback.
pub fn analyze_samples(
    samples: &[f32],
    sample_rate: f64,
    opts: PitchOpts,
    shared_override: Option<SharedSpectral>,
    job: &Job,
) -> anyhow::Result<PitchAnalysis> {
    job.check()?;
    let shared = match shared_override {
        Some(s) => Some(s),
        None => match compute_shared(samples, sample_rate, job) {
            Ok(s) => s,
            Err(e) => {
                job.check()?;
                log::warn!("Shared FFT frontend unavailable; using pitch-analysis fallback. {e}");
                None
            }
        },
    };
    let Some(shared) = shared else {
        let mut legacy = analyze_pitch_fallback(samples, sample_rate, opts, job)?;
        legacy.performance.legacy_fallback = true;
        return Ok(legacy);
    };
    let pitch_hop = shared.hop * shared.pitch_stride;
    let (layers, frames, fg, tracking_ms, fg_ms) =
        track_and_select(&shared.salience, shared.pitch_frames, shared.p, shared.min_midi, pitch_hop, sample_rate, &opts, job)?;
    let events = consolidate_events(&frames, pitch_hop as f64 / sample_rate);
    let min_midi = shared.min_midi;
    Ok(PitchAnalysis {
        sample_rate,
        frame_size: shared.n,
        hop_size: pitch_hop,
        min_midi,
        max_midi: shared.max_midi,
        duration: samples.len() as f64 / sample_rate,
        coverage: fg as f64 / shared.pitch_frames as f64,
        layers: layers.iter().map(|l| l.iter().map(|&p| if p < 0 { None } else { Some(min_midi + p as i32) }).collect()).collect(),
        frames,
        events,
        shared_hop: shared.hop,
        performance: AnalysisPerf {
            shared_fft_frontend: shared.elapsed_ms,
            pitch_tracking: tracking_ms,
            foreground_selection: fg_ms,
            legacy_fallback: false,
            shared_fft_size: shared.n,
            shared_fft_hop: shared.hop,
            pitch_stride: shared.pitch_stride,
            pitch_frames: shared.pitch_frames,
            spectral_frames: shared.spectral_frames,
        },
        state_bands: Some(shared.state_bands),
    })
}

fn analyze_pitch_fallback(samples: &[f32], sample_rate: f64, opts: PitchOpts, job: &Job) -> anyhow::Result<PitchAnalysis> {
    let n = adv::nearest_power_of_two("pitch.fftSize", 4096.0);
    let hop = adv::integer("pitch.hopSize", 1024.0).max(1) as usize;
    let min_midi = adv::integer("pitch.minMidi", 36.0).clamp(0, 126) as i32;
    let max_midi = adv::integer("pitch.maxMidi", 96.0).min(127).max(min_midi as i64 + 1) as i32;
    let p_count = (max_midi - min_midi + 1) as usize;
    let frames_n = ((((samples.len() as f64) - n as f64) / hop as f64).floor() + 1.0).max(1.0) as usize;
    let harmonics = adv::integer("pitch.harmonics", 8.0).max(1) as usize;
    let low = adv::number("pitch.localOnsetWeight", 0.1);
    let gfw = adv::number("pitch.globalFluxWeight", 0.002);
    let mut salience = vec![0f32; frames_n * p_count];
    let window = hann(n);
    let mut re = vec![0f32; n];
    let mut im = vec![0f32; n];
    let mut mag = vec![0f32; n / 2];
    let mut prev_mag = vec![0f32; n / 2];
    let mut scores = vec![0f32; p_count];
    let mut dev = vec![0f32; p_count];
    let yield_every = adv::integer("pitch.yieldEveryFrames", 24.0).max(1) as usize;
    for t in 0..frames_n {
        let off = t * hop;
        for i in 0..n {
            re[i] = ((samples.get(off + i).copied().unwrap_or(0.0) as f64) * window[i] as f64) as f32;
            im[i] = 0.0;
        }
        fft_recurrence(&mut re, &mut im);
        let mut flux = 0.0f64;
        for k in 1..n / 2 {
            let m = jsm::log1p(4.0 * hypot(re[k], im[k]));
            mag[k] = m as f32;
            flux += (m - prev_mag[k] as f64).max(0.0);
        }
        for p in 0..p_count {
            let f0 = midi_to_hz((min_midi + p as i32) as f64);
            let mut s = 0.0;
            let mut wsum = 0.0;
            for h in 1..=harmonics {
                let f = f0 * h as f64;
                if f >= sample_rate / 2.0 {
                    break;
                }
                let bin = (f * n as f64) / sample_rate;
                let k = bin.floor() as usize;
                let frac = bin - k as f64;
                let v = mag.get(k).copied().unwrap_or(0.0) as f64 * (1.0 - frac) + mag.get(k + 1).copied().unwrap_or(0.0) as f64 * frac;
                let w = 1.0 / (h as f64).sqrt();
                s += v * w;
                wsum += w;
            }
            let kb = crate::util::js_round((f0 * n as f64) / sample_rate) as i64;
            let mut local_flux = 0.0;
            let lo = (kb - 2).max(1);
            let hi = (kb + 2).min(n as i64 / 2 - 1);
            let mut k = lo;
            while k <= hi {
                local_flux += (mag[k as usize] as f64 - prev_mag[k as usize] as f64).max(0.0);
                k += 1;
            }
            scores[p] = (s / if wsum != 0.0 { wsum } else { 1.0 } + low * local_flux + gfw * flux) as f32;
        }
        salience_row(&scores, &mut dev, &mut salience[t * p_count..(t + 1) * p_count]);
        prev_mag.copy_from_slice(&mag);
        if t % yield_every == 0 {
            job.set_progress(0.05 + 0.57 * (t as f64 / frames_n as f64), format!("Analyzing frame {}/{}…", t + 1, frames_n));
            job.check()?;
        }
    }
    job.check()?;
    job.set_progress(0.63, "Tracking stable note layers…");
    let (layers, frames, fg, _, _) = track_and_select(&salience, frames_n, p_count, min_midi, hop, sample_rate, &opts, job)?;
    job.set_progress(0.77, "Choosing dominant foreground vs. no-foreground…");
    let events = consolidate_events(&frames, hop as f64 / sample_rate);
    Ok(PitchAnalysis {
        sample_rate,
        frame_size: n,
        hop_size: hop,
        min_midi,
        max_midi,
        duration: samples.len() as f64 / sample_rate,
        coverage: fg as f64 / frames_n as f64,
        layers: layers.iter().map(|l| l.iter().map(|&p| if p < 0 { None } else { Some(min_midi + p as i32) }).collect()).collect(),
        frames,
        events,
        shared_hop: hop,
        state_bands: None,
        performance: AnalysisPerf::default(),
    })
}
