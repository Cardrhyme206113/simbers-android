//! Beat-synchronous melodic pattern analysis (patterns.js + melody.js).

use super::attack::{AttackLabData, Detection, detect};
use super::spectral::PitchAnalysis;
use crate::job::Job;
use crate::settings as adv;
use crate::util::{clamp, jsm, median, now_ms};
use rayon::prelude::*;
use std::collections::{HashMap, HashSet};
use std::sync::Arc;

pub const BINS: usize = 12;
pub const FP_LEN: usize = BINS * 4 + 1;
pub type Fingerprint = [f32; FP_LEN];

#[derive(Clone, Debug, Default)]
pub struct Segment {
    pub index: usize,
    pub beat_index: usize,
    pub start: f64,
    pub end: f64,
    pub center: f64,
    pub sequence: Arc<Vec<f64>>,
    pub mask: Arc<Vec<f64>>,
    pub rhythm: Arc<Vec<f64>>,
    pub activity: f64,
    pub local_pulse_contrast: f64,
    pub beat_strength: f64,
    pub state_change: f64,
    pub stability_index: f64,
    pub melody_value: f64,
    pub cluster: usize,
    pub group: Option<String>,
    pub repeated: bool,
    pub repeat_score: f64,
    pub nearest: Option<usize>,
    pub candidate_score: f64,
    pub candidate_confidence: f64,
    pub default_accepted: bool,
    pub passed_primary_threshold: bool,
    pub reserve_candidate: bool,
}

#[derive(Clone, Debug)]
pub struct Occurrence {
    pub start: f64,
    pub end: f64,
    pub first_beat: usize,
    pub last_beat: usize,
    pub members: Vec<usize>,
}

#[derive(Clone, Debug)]
pub struct Cluster {
    pub index: usize,
    pub label: String,
    pub coordinate: f64,
    pub repeated: bool,
    pub members: Vec<usize>,
    pub medoid: usize,
    pub occurrences: Vec<Occurrence>,
    pub average_similarity: f64,
}

#[derive(Clone, Debug)]
pub struct ActivityTrack {
    pub step: f64,
    pub bins: usize,
    pub prefix: Vec<f64>,
    pub reference: f64,
    pub power_values: Vec<f32>,
}

#[derive(Clone, Debug)]
pub struct Patterns {
    pub event_times: Vec<f64>,
    pub bpm: f64,
    pub median_beat_interval: f64,
    pub timing_variation: f64,
    pub beat_confidence: f64,
    pub event_density: f64,
    pub average_state_change: f64,
    pub candidate_count: usize,
    pub reserve_candidate_count: usize,
    pub quiet_rejected_candidate_count: usize,
    pub intensity_pool: Vec<Arc<Segment>>,
    pub local_activity_track: Option<ActivityTrack>,
    pub similarity_ms: f64,
    pub compared_pairs: f64,
    pub context_beats: usize,
    pub threshold: f64,
    pub transpose_invariant: bool,
    pub sensitivity: f64,
    pub minimum_gap_ms: f64,
    pub segments: Vec<Arc<Segment>>,
    pub clusters: Vec<Cluster>,
    pub repeated_groups: usize,
}

pub struct PatternOpts {
    pub context_beats: usize,
    pub threshold: f64,
    pub transpose_invariant: bool,
    pub sensitivity: f64,
    pub minimum_gap_ms: f64,
}

fn fill_missing(values: &[Option<f64>]) -> Option<Vec<f64>> {
    let first = values.iter().position(|v| v.is_some())?;
    let mut out: Vec<f64> = values.iter().map(|v| v.unwrap_or(0.0)).collect();
    let fv = out[first];
    for slot in out.iter_mut().take(first) {
        *slot = fv;
    }
    let mut last = first;
    for i in first + 1..out.len() {
        if values[i].is_some() {
            let a = out[last];
            let b = out[i];
            let span = i - last;
            for j in 1..span {
                out[last + j] = a + (b - a) * (j as f64 / span as f64);
            }
            last = i;
        }
    }
    let lv = out[last];
    for slot in out.iter_mut().skip(last + 1) {
        *slot = lv;
    }
    Some(out)
}

fn fill_bins(source: &[f64], out: &mut [f32]) {
    let n = source.len();
    if n == 0 {
        out[..BINS].fill(0.0);
        return;
    }
    for b in 0..BINS {
        let start = (b * n) / BINS;
        let end = (start + 1).max(((b + 1) * n) / BINS);
        let mut sum = 0.0f64;
        let mut count = 0usize;
        for v in &source[start..end.min(n)] {
            sum += if v.is_nan() { 0.0 } else { *v };
            count += 1;
        }
        out[b] = (sum / count.max(1) as f64) as f32;
    }
}

pub fn build_fingerprint(seg: &Segment) -> Fingerprint {
    let mut fp = [0f32; FP_LEN];
    let seq = &seg.sequence;
    let mut contour = vec![0f64; seq.len()];
    for i in 1..seq.len() {
        contour[i] = ((seq[i] - seq[i - 1]) as f32) as f64;
    }
    fill_bins(seq, &mut fp[0..BINS]);
    fill_bins(&contour, &mut fp[BINS..2 * BINS]);
    fill_bins(&seg.mask, &mut fp[2 * BINS..3 * BINS]);
    fill_bins(&seg.rhythm, &mut fp[3 * BINS..4 * BINS]);
    fp[BINS * 4] = seg.activity as f32;
    fp
}

#[inline]
pub fn fp_distance(a: &Fingerprint, b: &Fingerprint) -> f64 {
    let mut aligned_best = f64::INFINITY;
    for shift in -1i32..=1 {
        let (mut pitch, mut contour, mut mask, mut count) = (0.0f64, 0.0f64, 0.0f64, 0usize);
        for i in 0..BINS as i32 {
            let j = i + shift;
            if j < 0 || j >= BINS as i32 {
                continue;
            }
            let (i, j) = (i as usize, j as usize);
            pitch += (a[i] as f64 - b[j] as f64).abs();
            contour += (a[BINS + i] as f64 - b[BINS + j] as f64).abs();
            mask += (a[BINS * 2 + i] as f64 - b[BINS * 2 + j] as f64).abs();
            count += 1;
        }
        let c = count.max(1) as f64;
        let d = pitch / c + (0.35 * contour) / c + (0.18 * mask) / c + 0.018 * shift.abs() as f64;
        if d < aligned_best {
            aligned_best = d;
        }
    }
    let mut rhythm = 0.0f64;
    for i in 0..BINS {
        rhythm += (a[BINS * 3 + i] as f64 - b[BINS * 3 + i] as f64).abs();
    }
    rhythm /= BINS as f64;
    aligned_best + 0.18 * (a[BINS * 4] as f64 - b[BINS * 4] as f64).abs() + 0.24 * rhythm
}

pub fn mds_one_dimension(dm: &[Vec<f64>]) -> Vec<f64> {
    let n = dm.len();
    if n == 0 {
        return vec![];
    }
    if n == 1 {
        return vec![0.5];
    }
    let mut row_mean = vec![0f64; n];
    let mut squared = vec![vec![0f64; n]; n];
    let mut total = 0.0;
    for i in 0..n {
        for j in 0..n {
            let d = dm[i][j];
            let d2 = d * d;
            squared[i][j] = d2;
            row_mean[i] += d2;
            total += d2;
        }
        row_mean[i] /= n as f64;
    }
    total /= (n * n) as f64;
    let mut b = vec![vec![0f64; n]; n];
    for i in 0..n {
        for j in 0..n {
            b[i][j] = -0.5 * (squared[i][j] - row_mean[i] - row_mean[j] + total);
        }
    }
    let mut x: Vec<f64> = (0..n).map(|i| jsm::sin((i + 1) as f64 * 1.713) + jsm::cos((i + 1) as f64 * 0.619)).collect();
    let mut y = vec![0f64; n];
    let mut mean = 0.0;
    for v in &x {
        mean += v;
    }
    mean /= n as f64;
    for v in x.iter_mut() {
        *v -= mean;
    }
    for _ in 0..80 {
        let mut y_mean = 0.0;
        for i in 0..n {
            let mut sum = 0.0;
            let row = &b[i];
            for j in 0..n {
                sum += row[j] * x[j];
            }
            y[i] = sum;
            y_mean += sum;
        }
        y_mean /= n as f64;
        let mut norm = 0.0;
        for v in y.iter_mut() {
            *v -= y_mean;
            norm += *v * *v;
        }
        let mut norm = norm.sqrt();
        if norm == 0.0 || norm.is_nan() {
            norm = 1.0;
        }
        for i in 0..n {
            x[i] = y[i] / norm;
        }
    }
    let mut lo = f64::INFINITY;
    let mut hi = f64::NEG_INFINITY;
    for v in &x {
        lo = lo.min(*v);
        hi = hi.max(*v);
    }
    if hi - lo < 1e-8 {
        return (0..n).map(|i| i as f64 / (n - 1) as f64).collect();
    }
    x.iter().map(|v| (v - lo) / (hi - lo)).collect()
}

pub fn group_label(index: usize) -> String {
    let mut n = index + 1;
    let mut s = Vec::new();
    while n > 0 {
        n -= 1;
        s.push((65 + (n % 26)) as u8 as char);
        n /= 26;
    }
    s.iter().rev().collect()
}

struct Context {
    sequence: Vec<f64>,
    mask: Vec<f64>,
    activity: f64,
    rhythm: Vec<f64>,
}

fn sample_beat_context(a: &PitchAnalysis, event_times: &[f64], event_index: usize, context_events: usize, transpose_invariant: bool, duration: f64) -> Option<Context> {
    let track: Vec<Option<i32>> = match a.layers.first() {
        Some(l) => l.clone(),
        None => a.frames.iter().map(|f| f.foreground).collect(),
    };
    let frame_dur = a.hop_size as f64 / a.sample_rate;
    const PPE: usize = 8;
    let mut raw = Vec::with_capacity(context_events * PPE);
    let mut mask = Vec::with_capacity(context_events * PPE);
    let mut durations = Vec::with_capacity(context_events);
    let first = (event_index + 1).saturating_sub(context_events);
    let available = event_index - first + 1;
    let pad = context_events - available;
    for slot in 0..context_events {
        let event = if slot < pad { first } else { first + (slot - pad) };
        let start = event_times[event];
        let end = event_times.get(event + 1).copied().unwrap_or(duration);
        let ed = (end - start).max(0.045);
        durations.push(ed);
        for p in 0..PPE {
            let time = start + ((p as f64 + 0.5) / PPE as f64) * ed;
            let fi = clamp(crate::util::js_round(time / frame_dur), 0.0, track.len() as f64 - 1.0) as usize;
            let pitch = track[fi];
            let conf = a.frames.get(fi).map(|f| f.confidence).unwrap_or(0.0);
            raw.push(pitch.map(|p| p as f64));
            mask.push(clamp(conf * 1.35, 0.0, 1.0));
        }
    }
    let activity = mask.iter().fold(0.0, |s, v| s + v) / mask.len().max(1) as f64;
    let filled = fill_missing(&raw)?;
    let base = if transpose_invariant { median(&filled) } else { 60.0 };
    let dm = median(&durations);
    let duration_median = if dm == 0.0 || dm.is_nan() { 1.0 } else { dm };
    Some(Context {
        sequence: filled.iter().map(|v| clamp((v - base) / 12.0, -2.5, 2.5)).collect(),
        mask,
        activity,
        rhythm: durations.iter().map(|v| clamp(jsm::log2(v / duration_median), -2.0, 2.0)).collect(),
    })
}

pub fn build_local_activity_track(d: &AttackLabData, duration: f64) -> Option<ActivityTrack> {
    let input = &d.rms;
    if input.is_empty() {
        return None;
    }
    let frame_sec = d.hop as f64 / d.rate.max(1.0);
    let step = 0.25;
    let dur = if duration != 0.0 && !duration.is_nan() { duration } else { input.len() as f64 * frame_sec };
    let bins = ((dur / step).ceil() as usize).max(1);
    let mut power = vec![0f64; bins];
    let mut count = vec![0u32; bins];
    for (i, v) in input.iter().enumerate() {
        let j = (((i as f64 * frame_sec) / step).floor() as usize).min(bins - 1);
        let v = (*v as f64).max(0.0);
        power[j] += v * v;
        count[j] += 1;
    }
    let mut values = vec![0f32; bins];
    let mut positive = vec![];
    let mut prefix = vec![0f64; bins + 1];
    for i in 0..bins {
        values[i] = (power[i] / count[i].max(1) as f64).sqrt() as f32;
        if values[i] as f64 > 1e-7 {
            positive.push(values[i]);
        }
        prefix[i + 1] = prefix[i] + values[i] as f64 * values[i] as f64;
    }
    if positive.is_empty() {
        return None;
    }
    positive.sort_by(|a, b| a.partial_cmp(b).unwrap());
    let reference = positive[((positive.len() - 1) as f64 * 0.82).floor() as usize] as f64;
    Some(ActivityTrack { step, bins, prefix, reference, power_values: values })
}

struct SparseResult {
    clusters: Vec<(Vec<usize>, usize)>,
    coords: Vec<f32>,
    segment_cluster: Vec<usize>,
    best_scores: Vec<f32>,
    nearest: Vec<i32>,
    compared_pairs: f64,
}

fn quant(v: f64, step: f64) -> i64 {
    (v / step).floor() as i64
}

fn sparse_keys(fp: &Fingerprint) -> [String; 4] {
    let f = |i: usize| fp[i] as f64;
    let early = (f(0) + f(1) + f(2) + f(3)) / 4.0;
    let late = (f(8) + f(9) + f(10) + f(11)) / 4.0;
    let contour = (f(BINS + 2) + f(BINS + 5) + f(BINS + 8)) / 3.0;
    let rhythm = (f(BINS * 3 + 2) + f(BINS * 3 + 6) + f(BINS * 3 + 9)) / 3.0;
    let activity = f(BINS * 4);
    [
        format!("p:{}:{}", quant(early, 0.3), quant(late, 0.3)),
        format!("ps:{}:{}", quant(early + 0.15, 0.3), quant(late + 0.15, 0.3)),
        format!("c:{}:{}", quant(contour, 0.22), quant(rhythm, 0.32)),
        format!("a:{}:{}", quant(activity, 0.24), quant(late - early, 0.25)),
    ]
}

fn build_sparse_groups(segments: &[Segment], fps: &[Fingerprint], threshold: f64, scale: f64, context_beats: usize, job: &Job) -> anyhow::Result<SparseResult> {
    let n = fps.len();
    let mut buckets: HashMap<String, Vec<usize>> = HashMap::new();
    let mut seen = vec![0usize; n];
    let mut best_scores = vec![0f32; n];
    let mut nearest = vec![-1i32; n];
    let mut segment_cluster = vec![0usize; n];
    let mut clusters: Vec<(Vec<usize>, usize)> = vec![];
    let mut compared = 0f64;
    let mut last_yield = now_ms();
    for i in 0..n {
        let keys = sparse_keys(&fps[i]);
        let mut best_group: i64 = -1;
        let mut best_group_score = threshold;
        let mut group_checks: HashMap<usize, f64> = HashMap::new();
        let mut candidates: Vec<usize> = vec![];
        for key in &keys {
            let Some(bucket) = buckets.get(key) else { continue };
            let recent_start = bucket.len().saturating_sub(12);
            let spaced = 24.min(recent_start);
            for k in 0..spaced {
                candidates.push(bucket[(((k as f64 + 0.5) * recent_start as f64) / spaced as f64).floor() as usize]);
            }
            candidates.extend_from_slice(&bucket[recent_start..]);
        }
        for j in candidates {
            if j == i || seen[j] == i + 1 {
                continue;
            }
            seen[j] = i + 1;
            compared += 1.0;
            let similarity = jsm::exp(-scale * fp_distance(&fps[i], &fps[j]));
            if segments[i].beat_index.abs_diff(segments[j].beat_index) > context_beats {
                if similarity > best_scores[i] as f64 {
                    best_scores[i] = similarity as f32;
                    nearest[i] = j as i32;
                }
                if similarity > best_scores[j] as f64 {
                    best_scores[j] = similarity as f32;
                    nearest[j] = i as i32;
                }
            }
            if similarity >= threshold {
                let gid = segment_cluster[j];
                let rep_score = match group_checks.get(&gid) {
                    Some(v) => *v,
                    None => {
                        let rep = clusters[gid].1;
                        let v = if rep == j {
                            similarity
                        } else {
                            compared += 1.0;
                            jsm::exp(-scale * fp_distance(&fps[i], &fps[rep]))
                        };
                        group_checks.insert(gid, v);
                        v
                    }
                };
                if rep_score >= threshold && rep_score > best_group_score {
                    best_group = gid as i64;
                    best_group_score = rep_score;
                }
            }
        }
        let bg = if best_group < 0 {
            clusters.push((vec![i], i));
            clusters.len() - 1
        } else {
            clusters[best_group as usize].0.push(i);
            best_group as usize
        };
        segment_cluster[i] = bg;
        for key in keys {
            buckets.entry(key).or_default().push(i);
        }
        if now_ms() - last_yield > 25.0 {
            job.set_progress(0.9 + (0.07 * i as f64) / n.max(1) as f64, format!("Comparing likely musical patterns {}/{}…", i + 1, n));
            job.check()?;
            last_yield = now_ms();
        }
    }
    let count = clusters.len();
    let mut coords = vec![0f32; count];
    let dist = |a: usize, b: usize, compared: &mut f64| {
        *compared += 1.0;
        fp_distance(&fps[a], &fps[b])
    };
    if count == 1 {
        coords[0] = 0.5;
    } else if count > 1 {
        let anchor_count = 32.min(count);
        let anchors: Vec<usize> = (0..anchor_count).map(|i| (count - 1).min((((i as f64 + 0.5) * count as f64) / anchor_count as f64).floor() as usize)).collect();
        let mut distances = vec![vec![0f64; anchor_count]; anchor_count];
        for (ai, &a) in anchors.iter().enumerate() {
            for (aj, &b) in anchors.iter().enumerate() {
                distances[ai][aj] = dist(clusters[a].1, clusters[b].1, &mut compared);
            }
        }
        let positions = mds_one_dimension(&distances);
        // Map: later duplicates overwrite earlier ones (JS new Map semantics).
        let mut anchor_map: HashMap<usize, usize> = HashMap::new();
        for (i, &idx) in anchors.iter().enumerate() {
            anchor_map.insert(idx, i);
        }
        for c in 0..count {
            if let Some(&ai) = anchor_map.get(&c) {
                coords[c] = positions[ai] as f32;
                continue;
            }
            let (mut closest, mut second) = (-1i64, -1i64);
            let (mut d1, mut d2) = (f64::INFINITY, f64::INFINITY);
            for a in 0..anchor_count {
                let d = dist(clusters[c].1, clusters[anchors[a]].1, &mut compared);
                if d < d1 {
                    second = closest;
                    d2 = d1;
                    closest = a as i64;
                    d1 = d;
                } else if d < d2 {
                    second = a as i64;
                    d2 = d;
                }
            }
            if second < 0 {
                coords[c] = positions.get(closest.max(0) as usize).copied().unwrap_or(0.5) as f32;
            } else {
                let w1 = 1.0 / d1.max(0.02);
                let w2 = 1.0 / d2.max(0.02);
                coords[c] = ((positions[closest as usize] * w1 + positions[second as usize] * w2) / (w1 + w2)) as f32;
            }
        }
    }
    Ok(SparseResult { clusters, coords, segment_cluster, best_scores, nearest, compared_pairs: compared })
}

/// analyzeBeatSynchronousPatterns
pub fn analyze(a: &PitchAnalysis, lab: &AttackLabData, opts: PatternOpts, job: &Job) -> anyhow::Result<(Patterns, Detection)> {
    let t0 = now_ms();
    let detector = detect(lab, a.duration);
    job.stage("beatDetection", now_ms() - t0);
    let end_pad = adv::number("patterns.endPaddingSec", 0.03);
    let event_times: Vec<f64> = detector.times.iter().copied().filter(|t| *t >= 0.0 && *t < a.duration - end_pad).collect();
    job.set_progress(
        0.88,
        format!(
            "Detected {} events ({}/s); Attack Lab defaults (60% / ±3 bands / 90ms)…",
            event_times.len(),
            crate::util::to_fixed(detector.event_density, 2)
        ),
    );
    let sig_start = now_ms();
    let min_seg = adv::number("patterns.minimumSegmentSec", 0.035);
    // Contexts are independent per event; build in parallel, keep order.
    let contexts: Vec<Option<Segment>> = (0..event_times.len())
        .into_par_iter()
        .map(|i| {
            let end = event_times.get(i + 1).copied().unwrap_or(a.duration);
            if end - event_times[i] < min_seg {
                return None;
            }
            let c = sample_beat_context(a, &event_times, i, opts.context_beats, opts.transpose_invariant, a.duration)?;
            let pick = |v: &Vec<f64>, dflt: f64| -> f64 {
                if v.is_empty() { dflt } else { v[i.min(v.len() - 1)] }
            };
            Some(Segment {
                beat_index: i,
                start: event_times[i],
                end,
                center: event_times[i],
                sequence: Arc::new(c.sequence),
                mask: Arc::new(c.mask),
                rhythm: Arc::new(c.rhythm),
                activity: c.activity,
                local_pulse_contrast: 0.0,
                beat_strength: pick(&detector.strength, 0.0),
                state_change: pick(&detector.state_change, 0.0),
                stability_index: pick(&detector.stability_index, 1.0),
                ..Default::default()
            })
        })
        .collect();
    let mut segments: Vec<Segment> = contexts.into_iter().flatten().collect();
    for (i, s) in segments.iter_mut().enumerate() {
        s.index = i;
    }
    let n = segments.len();
    let fps: Vec<Fingerprint> = segments.par_iter().map(build_fingerprint).collect();
    job.stage("eventSignatures", now_ms() - sig_start);

    let scale = adv::number("patterns.similarityScale", 4.0);
    let mut similarities: Option<Vec<f32>> = None;
    let mut cl: Vec<(Vec<usize>, usize)> = vec![];
    let coords: Vec<f64>;
    let mut segment_cluster = vec![0usize; n];
    let mut sparse: Option<SparseResult> = None;
    let mut compared_pairs = if n > 1 { (n * (n - 1)) as f64 / 2.0 } else { 0.0 };
    let sim_started = now_ms();
    let similarity_ms;
    let post_start;
    if n <= 1400 {
        let mut sims = vec![0f32; n * n];
        // Upper triangle rows in parallel, then mirror.
        let rows: Vec<Vec<f32>> = (0..n)
            .into_par_iter()
            .map(|i| ((i + 1)..n).map(|j| jsm::exp(-scale * fp_distance(&fps[i], &fps[j])) as f32).collect())
            .collect();
        for i in 0..n {
            sims[i * n + i] = 1.0;
            for (k, v) in rows[i].iter().enumerate() {
                let j = i + 1 + k;
                sims[i * n + j] = *v;
                sims[j * n + i] = *v;
            }
        }
        job.check()?;
        similarity_ms = now_ms() - sim_started;
        post_start = now_ms();
        for i in 0..n {
            let mut best: i64 = -1;
            let mut best_sim = -1.0f64;
            for (c, cluster) in cl.iter().enumerate() {
                let sim = sims[i * n + cluster.1] as f64;
                if sim > best_sim {
                    best_sim = sim;
                    best = c as i64;
                }
            }
            if best >= 0 && best_sim >= opts.threshold {
                cl[best as usize].0.push(i);
            } else {
                cl.push((vec![i], i));
            }
        }
        for cluster in cl.iter_mut() {
            let mut best_member = cluster.0[0];
            let mut best_score = f64::NEG_INFINITY;
            for &cand in &cluster.0 {
                let mut score = 0.0f64;
                for &m in &cluster.0 {
                    score += sims[cand * n + m] as f64;
                }
                if score > best_score {
                    best_score = score;
                    best_member = cand;
                }
            }
            cluster.1 = best_member;
        }
        let cd: Vec<Vec<f64>> = cl.iter().map(|a| cl.iter().map(|b| fp_distance(&fps[a.1], &fps[b.1])).collect()).collect();
        coords = mds_one_dimension(&cd);
        for (c, cluster) in cl.iter().enumerate() {
            for &m in &cluster.0 {
                segment_cluster[m] = c;
            }
        }
        similarities = Some(sims);
    } else {
        let s = build_sparse_groups(&segments, &fps, opts.threshold, scale, opts.context_beats, job)?;
        cl = s.clusters.clone();
        coords = s.coords.iter().map(|v| *v as f64).collect();
        segment_cluster = s.segment_cluster.clone();
        compared_pairs = s.compared_pairs;
        similarity_ms = now_ms() - sim_started;
        post_start = now_ms();
        sparse = Some(s);
    }
    job.stage("similarityAllPairs", similarity_ms);
    job.note("similarityPairs", crate::util::jnum(compared_pairs));

    let mut clusters: Vec<Cluster> = Vec::with_capacity(cl.len());
    for (c, (members, medoid)) in cl.iter().enumerate() {
        let mut sorted = members.clone();
        sorted.sort_by_key(|&m| segments[m].beat_index);
        let mut occ: Vec<Occurrence> = vec![];
        for m in sorted {
            let s = &segments[m];
            if let Some(last) = occ.last_mut()
                && s.beat_index <= last.last_beat + 1
            {
                last.end = s.end;
                last.last_beat = s.beat_index;
                last.members.push(m);
                continue;
            }
            occ.push(Occurrence { start: s.start, end: s.end, first_beat: s.beat_index, last_beat: s.beat_index, members: vec![m] });
        }
        let repeated = occ.len() >= 2;
        clusters.push(Cluster {
            index: c,
            label: group_label(c),
            coordinate: coords.get(c).copied().unwrap_or(0.5),
            repeated,
            members: members.clone(),
            medoid: *medoid,
            occurrences: occ,
            average_similarity: 1.0,
        });
    }
    let sim_of = |i: usize, j: usize| -> f64 {
        match &similarities {
            Some(s) => s[i * n + j] as f64,
            None => jsm::exp(-scale * fp_distance(&fps[i], &fps[j])),
        }
    };
    let jitter = adv::number("patterns.melodyJitter", 0.05);
    for i in 0..n {
        let ci = segment_cluster[i];
        let cluster = &clusters[ci];
        let (mut repeat_score, mut nearest) = (0.0f64, None);
        if let Some(sp) = &sparse {
            repeat_score = sp.best_scores[i] as f64;
            nearest = if sp.nearest[i] < 0 { None } else { Some(sp.nearest[i] as usize) };
        } else if let Some(s) = &similarities {
            for j in 0..n {
                if i == j || segments[i].beat_index.abs_diff(segments[j].beat_index) <= opts.context_beats {
                    continue;
                }
                let v = s[i * n + j] as f64;
                if v > repeat_score {
                    repeat_score = v;
                    nearest = Some(j);
                }
            }
        }
        let stm = sim_of(i, cluster.medoid);
        let sim_to_medoid = if stm == 0.0 || stm.is_nan() { 1.0 } else { stm };
        let sign = if i % 2 == 1 { 1.0 } else { -1.0 };
        let seg = &mut segments[i];
        seg.melody_value = clamp(cluster.coordinate + sign * (1.0 - sim_to_medoid) * jitter, 0.0, 1.0);
        seg.cluster = ci;
        seg.group = if cluster.repeated { Some(cluster.label.clone()) } else { None };
        seg.repeated = cluster.repeated;
        seg.repeat_score = repeat_score;
        seg.nearest = nearest;
    }

    let cands = &detector.intensity_candidates;
    let mut cursor = 0usize;
    for seg in segments.iter_mut() {
        while cursor + 1 < cands.len() && (cands[cursor + 1].time - seg.start).abs() <= (cands[cursor].time - seg.start).abs() {
            cursor += 1;
        }
        match cands.get(cursor) {
            Some(c) if (c.time - seg.start).abs() < 0.035 => {
                seg.candidate_score = c.score;
                seg.candidate_confidence = c.confidence;
            }
            _ => {
                seg.candidate_score = seg.beat_strength;
                seg.candidate_confidence = seg.beat_strength;
            }
        }
        seg.default_accepted = true;
        seg.passed_primary_threshold = true;
    }
    let nearest_default = |time: f64| -> Option<&Segment> {
        if segments.is_empty() {
            return None;
        }
        let (mut lo, mut hi) = (0usize, segments.len());
        while lo < hi {
            let mid = (lo + hi) >> 1;
            if segments[mid].start < time { lo = mid + 1 } else { hi = mid }
        }
        let a = &segments[lo.saturating_sub(1)];
        let b = &segments[lo.min(segments.len() - 1)];
        Some(if (a.start - time).abs() <= (b.start - time).abs() { a } else { b })
    };
    let default_keys: HashSet<i64> = segments.iter().map(|s| crate::util::js_round(s.start * 1000.0) as i64).collect();
    let mut pool = segments.clone();
    for (i, c) in cands.iter().enumerate() {
        if c.default_accepted || c.time < 0.2 || c.time >= a.duration - 0.02 {
            continue;
        }
        if default_keys.contains(&(crate::util::js_round(c.time * 1000.0) as i64)) {
            continue;
        }
        let Some(near) = nearest_default(c.time) else { continue };
        let mut s = near.clone();
        s.index = segments.len() + i;
        s.beat_index = segments.len() + i;
        s.start = c.time;
        s.center = c.time;
        s.end = a.duration.min(c.time + 0.035f64.max(detector.median_interval));
        s.beat_strength = c.confidence;
        s.local_pulse_contrast = 0.0;
        s.state_change = c.change_index;
        s.stability_index = c.stability_index;
        s.candidate_score = c.score;
        s.candidate_confidence = c.confidence;
        s.default_accepted = false;
        s.passed_primary_threshold = c.passed_primary_threshold;
        s.reserve_candidate = true;
        pool.push(s);
    }
    pool.sort_by(|x, y| x.start.partial_cmp(&y.start).unwrap_or(std::cmp::Ordering::Equal));
    for c in clusters.iter_mut() {
        c.average_similarity = if c.members.len() <= 1 {
            1.0
        } else {
            c.members.iter().fold(0.0, |s, &i| s + sim_of(i, c.medoid)) / c.members.len() as f64
        };
    }
    job.stage("similarityPost", now_ms() - post_start);
    let repeated_groups = clusters.iter().filter(|c| c.repeated).count();
    Ok((
        Patterns {
            bpm: 60.0 / detector.median_interval.max(0.001),
            median_beat_interval: detector.median_interval,
            timing_variation: detector.timing_variation,
            beat_confidence: detector.confidence,
            event_density: detector.event_density,
            average_state_change: detector.average_state_change,
            candidate_count: detector.candidate_count,
            reserve_candidate_count: if detector.reserve_candidate_count != 0 { detector.reserve_candidate_count } else { detector.candidate_count },
            quiet_rejected_candidate_count: detector.quiet_rejected_candidate_count,
            intensity_pool: pool.into_iter().map(Arc::new).collect(),
            local_activity_track: build_local_activity_track(lab, a.duration),
            similarity_ms,
            compared_pairs,
            context_beats: opts.context_beats,
            threshold: opts.threshold,
            transpose_invariant: opts.transpose_invariant,
            sensitivity: opts.sensitivity,
            minimum_gap_ms: opts.minimum_gap_ms,
            event_times,
            segments: segments.into_iter().map(Arc::new).collect(),
            clusters,
            repeated_groups,
        },
        detector,
    ))
}
