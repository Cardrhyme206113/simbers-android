package io.simbers.app;

import android.app.NativeActivity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;

/** Thin native-activity bridge for the Android Storage Access Framework. */
public final class SimbersActivity extends NativeActivity {
    private static final int PICK_DOCUMENT = 1101;
    private static final int SAVE_DOCUMENT = 1102;
    private String pendingExport;
    private String pendingName;

    static {
        System.loadLibrary("simbers");
    }

    // These symbols are exported by src/platform.rs.
    private static native void nativeFilePicked(String privatePath);
    private static native void nativeFileMessage(String message);

    /** Called via JNI by the Rust UI. Never blocks the native UI thread. */
    public void pickFile() {
        runOnUiThread(() -> {
            try {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivityForResult(intent, PICK_DOCUMENT);
            } catch (Exception e) {
                nativeFileMessage("Android file picker failed: " + e.getMessage());
            }
        });
    }

    /** Export an app-private temporary file to a user-selected document URI. */
    public void saveFile(String privatePath, String displayName) {
        runOnUiThread(() -> {
            try {
                pendingExport = privatePath;
                pendingName = displayName;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(mimeFor(displayName));
                intent.putExtra(Intent.EXTRA_TITLE, displayName);
                startActivityForResult(intent, SAVE_DOCUMENT);
            } catch (Exception e) {
                nativeFileMessage("Android export picker failed: " + e.getMessage());
            }
        });
    }

    private String mimeFor(String fileName) {
        String lower = fileName.toLowerCase(java.util.Locale.ROOT);
        if (lower.endsWith(".zip")) return "application/zip";
        if (lower.endsWith(".json")) return "application/json";
        return "application/octet-stream";
    }

    private String displayName(Uri uri) {
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) return cursor.getString(idx);
            }
        } catch (Exception ignored) { }
        return "imported-song.bin";
    }

    private static String safeName(String title) {
        if (title == null || title.isEmpty()) return "imported-song.bin";
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < title.length(); i++) {
            char c = title.charAt(i);
            out.append(c < 32 || "/\\:*?\"<>|".indexOf(c) >= 0 ? '_' : c);
        }
        return out.toString();
    }

    private static long copy(InputStream input, OutputStream output) throws Exception {
        byte[] buf = new byte[64 * 1024];
        long size = 0;
        int n;
        while ((n = input.read(buf)) != -1) {
            size += n;
            if (size > 512L * 1024L * 1024L) throw new Exception("File exceeds 512 MiB import limit");
            output.write(buf, 0, n);
        }
        output.flush();
        return size;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == PICK_DOCUMENT) {
            new Thread(() -> {
                File copied = null;
                try {
                    String title = safeName(displayName(uri));
                    // Retain the user-visible extension: Rust selects audio/zip/bsor based on it.
                    File dir = new File(getCacheDir(), "simbers-imports");
                    if (!dir.exists() && !dir.mkdirs()) throw new Exception("Cannot create import directory");
                    File subdir = new File(dir, UUID.randomUUID().toString());
                    if (!subdir.mkdirs()) throw new Exception("Cannot create import folder");
                    copied = new File(subdir, title);
                    try (InputStream input = getContentResolver().openInputStream(uri);
                         OutputStream output = new FileOutputStream(copied)) {
                        if (input == null) throw new Exception("Document provider returned no data");
                        copy(input, output);
                    }
                    nativeFilePicked(copied.getAbsolutePath());
                } catch (Exception e) {
                    if (copied != null) copied.delete();
                    nativeFileMessage("Import failed: " + e.getMessage());
                }
            }, "simbers-document-import").start();
        } else if (requestCode == SAVE_DOCUMENT) {
            String path = pendingExport;
            String title = pendingName;
            pendingExport = null;
            pendingName = null;
            new Thread(() -> {
                try {
                    if (path == null) throw new Exception("No export data pending");
                    try (InputStream input = new FileInputStream(path);
                         OutputStream output = getContentResolver().openOutputStream(uri, "w")) {
                        if (output == null) throw new Exception("Document provider returned no output stream");
                        copy(input, output);
                    }
                    nativeFileMessage("Saved " + title);
                } catch (Exception e) {
                    nativeFileMessage("Export failed: " + e.getMessage());
                } finally {
                    if (path != null) new File(path).delete();
                }
            }, "simbers-document-export").start();
        }
    }
}
