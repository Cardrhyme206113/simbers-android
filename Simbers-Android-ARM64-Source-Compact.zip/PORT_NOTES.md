# Simbers Rust port — working notes

Source: `../Simbers7_8Bot_Late_Prep_Animation.html` (v0.9.7). Extracted modules live in `../ref/`:
- `ref/main_mod/js/**`  — app JS (generation, analysis, export, UI glue)
- `ref/main_mod/css/**` — app CSS (for look & feel)
- `ref/viewer_mod/**`   — viewer iframe (WebGL renderer, replay, BSOR)
- `ref/viewer_env/**`   — nested environment iframe
- `ref/bundled/**`      — wasm vorbis encoder (replaced by libvorbis via vorbis_rs)
- `ref/main.html`       — page markup with huge lines stripped

## Fidelity rules used in the port
- JS numbers are f64; Float32Array storage is emulated with `f32` storage + f64 math.
- `+x.toFixed(n)` → `util::to_fixed_num` (JS tie rule: round half away from zero on exact value).
- JSON output → `util::json::stringify` (JS number formatting, integer-like keys first ascending).
- Array.sort is stable → Rust `sort_by` (stable). Comparators ported literally.
- `hashString` = FNV-1a over UTF-16 code units (`util::hash_string`).
- Chromium OfflineAudioContext resample 22050→11025 = linear interpolation playback
  (rate 2 => exact decimation). Implemented in `analysis::attack::resample_linear`.
- attackLabV2 in pipeline comes from attackLabPrepare (no rawFlux) → localPulseContrast == 0 always.
- Unified frontend's attack (rawFlux/rms) output is unused by the pipeline → skipped in Rust.

## Status
See bottom of file (updated as modules land).

## Status (2026-11-20)
DONE (compiles, release build, verified end-to-end on 2 real songs: ~2 s per song, valid ZIP):
- analysis/: fft, spectral (unified + shared + pitch/Viterbi), attack (Attack Lab V2), patterns
- mapgen/: corpus, grid, choreo (scfPlanChoreographyV2), nps, swing, select (intensity),
  beatmaps (+NoArrows/OneSaber/90/360/Lawless), arcs, bombs, walls, lighting, bot (8-bot pass), guard (physical flow)
- audio/: symphonia decode (+ ffmpeg fallback), resampleUnifiedAudio / high-mode resamplers
- export/: Info.dat, validators, Ogg identify/passthrough, libvorbis encode (quality = WASM mapping), ZIP writer
  (same layout as zip.js), cover.png (tiny-skia + Segoe UI)
- pipeline.rs: runAnalysis → prepareMapBuild → export. CLI: `simbers gen <audio> [out.zip] [intensity%]`

BUILD NOTES:
- Project now lives in `Desktop/card` (renamed from a folder with "ö"). `.cargo/config.toml` still sets
  target-dir = C:/Users/iceti/.simbers-target (harmless; keeps build output out of the project).
- WinLibs GCC must be on PATH (vorbis_rs C code).
- Module is `mapgen` (not `gen`: reserved keyword in edition 2024).
- Decoder rate: browser decodeAudioData resamples to the AudioContext rate (usually 48 kHz); Rust keeps the native
  rate. Small numeric drift vs the browser is expected here.

## Status (2026-11-20, session 2)
DONE:
- tools/js-harness/run.js: runs the ORIGINAL ref/main_mod JS in a Node vm (DOM stubs, same-realm Worker shim,
  OfflineAudioContext = linear resample) on the PCM Rust dumped (`SIMBERS_DUMP_PCM=file`), diffs every .dat.
  RESULT: 4 songs x intensities 40/100/170/200 + a 15-min highlights edit -> all 150 beatmaps byte-identical.
- tools/js-harness/highlights.js (`SIMBERS_DUMP_HIGHLIGHTS=dir`): highlights plan + assembled PCM identical.
- audio/highlights.rs (plan/snap/beat grid/assemble), pipeline LongSongMode {Full, Highlights, Clip},
  RunOptions, Info.dat highlights edits, pre-encoded highlights Ogg export.
- storage/zip_reader.rs (core/zip-reader.js, same limits/errors), payload.rs (ViewerPayload + from_zip =
  pastJobsZipToViewerPayload), storage/history.rs (Past Jobs on disk: <data>/history/<id>/..., MAX 25, prune,
  disk-full eviction, size/duration text, reprocess via materialize_audio).
- youtube/mod.rs: (superseded by the built-in yt-dlp backend, see below) Invidious search/videos, header
  sniff, square 512 cover (falls back to standard cover like the original).
- CLI: `gen <audio> [zip] [intensity] [full|highlights|clip]` (saves to Past Jobs unless SIMBERS_NO_HISTORY),
  `history [delete <id>|clear]`, `inspect <zip>`, `yt "<query|url>" [n]`, `yt-cover <id> <png>`.

Harness usage:
  SIMBERS_DUMP_PCM=m.f32 SIMBERS_NO_HISTORY=1 simbers gen song.mp3 r.zip 100
  node tools/js-harness/run.js song.mp3 m.f32 r.zip 100      (use C:/ paths for filenames with quotes/brackets)

TODO: none open. Steps 3 (native UI) and 4 (wgpu viewer + replay + BSOR) are done; see below.

## Native UI (TODO 3, done 2026-11-20)
`simbers` with no args (or `simbers ui [file]`) opens the eframe/egui window; CLI commands unchanged.
src/ui/: theme.rs (CSS tokens, Segoe UI/Consolas weights from C:/Windows/Fonts, CSS weight matching
550-650→600, 700→700, 750+→900), icons.rs (the page's inline SVGs verbatim, rasterized by resvg),
widgets.rs (absolute-positioned buttons/text fields), main_view.rs (card + inline Past Jobs + viewer
shell + export popover), pages.rs (Settings, YouTube page, long-song dialog, drop overlay), mod.rs
(state, worker threads, message pump). Geometry was measured from the original page in Chromium at
1280×800 (getBoundingClientRect/getComputedStyle), so boxes match pixel for pixel.
Verified in the running app: generation, Past Jobs save/list/pending card, Highlights Edit via the
long-song dialog, Settings, YouTube search + import (see the YouTube backend section).
Test tip: SendKeys drops "i" on the Turkish
layout; use SendInput (real VK) when automating typing.

## YouTube backend: built-in yt-dlp (2026-11-20)
Replaces the Invidious + CORS-proxy path; the page's FREE API / 403 notices were removed once it was verified.
- Why not a Rust-native crate: rustypipe (last release 0.11.4 on 2025-04-23, no code changes since 2025-06),
  tydle (2026-04, 3 stars, challenge solving needs deno_core/V8) and tafas (drops signature-protected formats
  by design) don't handle YouTube's current player JS challenges; yt-dlp >= 2025.11 itself needs an external
  JS runtime for them.
- vendor/yt-dlp/: official one-folder yt-dlp_win.zip 2026.10.26 (0.4 s startup vs ~2 s for the one-file exe)
  + QuickJS-NG 0.18.0 qjs.exe, `include_bytes!` into the exe (+25 MB). Unpacked once to
  %LOCALAPPDATA%\SimplifiedSabers\tools\yt-dlp-<ver> (marker file, temp dir + rename, old versions pruned);
  the unpack starts in the background at app launch. Hashes and update steps: vendor/yt-dlp/README.md.
- youtube/ytdlp.rs: hidden process (CREATE_NO_WINDOW) inside a Job Object (KILL_ON_JOB_CLOSE), so cancel or
  closing the app kills yt-dlp and its JS runtime. --ignore-config, own --cache-dir, extractor/http retries,
  `--js-runtimes node` + bundled quickjs (yt-dlp priority deno > node > quickjs; Node solves the challenge in
  ~1.4 s, QuickJS in ~4.2 s).
- Search: `--flat-playlist -J ytsearch12:<q>` -> first 9 non-live hits (~1.7 s). Import:
  `player_client=visionos,default` (visionos streams need no challenge and no ad wait; tv-client formats carry
  a ~3 s "available_at" wait), `-f ba[ext=m4a]/b[ext=mp4]/ba/b` (AAC first: symphonia decodes it natively,
  Opus would need ffmpeg), `--fixup never`, `--print-to-file` meta JSON + filepath, progress template parsed
  into the status line. Typical import 3-5 s, then decode + map generation as before.
- Network: attempts alternate `--force-ipv4` / dual-stack, because this machine's IPv6 path to Google times
  out or resets TLS ("SSL: INVALID_SESSION_ID"). Thumbnails/covers try IPv4, any family, then img.youtube.com.
- Errors: friendly text for bot check / HTTP 429 / age gate / private / unavailable / no format; transient
  network errors are retried (import 3 attempts, search 2). The failure report is available through
  "Copy report"; "Retry download" replaced "Try yt-dlp fallback". A failed/cancelled import deletes its
  scratch folder (%TEMP%\SimplifiedSabers\youtube\.yt-dlp-<pid>).
- Fixed on the way: result thumbnails never appeared (decode_jpeg returns RGBA, the UI treated it as RGB and
  the worker panicked), and eframe was built without its `clipboard` feature (Ctrl+V into the search box and
  "Copy report" did nothing).
- Verified: CLI `yt` end to end; in the app search -> import -> map for a search hit and a pasted URL,
  cancel (process tree and scratch folder gone), unavailable video (error + report), thumbnails.

## UI port spec (reference)
Design mode: "redesign - preserve". The original CSS is the spec; no restyling.
Tokens (ref/main_mod/css/tokens.css): bg #121212, panel #1e1e1e, text #fff, muted #9a9a9a,
primary #007bff / hover #0067d8, secondary #3f464d / hover #58616a, border #333.
CSS sources: base, layout, settings, status, history, youtube, replay (~4.6k lines total).
Rust building blocks ready for the UI: pipeline::{decode, run_decoded, RunOptions, LongSongMode,
viewer_payload, history_record}, audio::highlights::selected_song_limit (long-song dialog trigger),
storage::history (Past Jobs list/open/download/reprocess/delete/clear), youtube::{search, import,
duration_text, bytes_text, thumb_url, fetch_image, decode_jpeg}, settings (ADV_SETTINGS), job::Job
(progress + cancel + timing profile).
Pre-flight for the UI: keep the original copy, keyboard focus and visible focus rings, AA contrast, one
accent (#007bff), no em-dashes added to copy.

## Viewer (TODO 4, done 2026-11-20)
src/viewer/: map.rs, scene.rs, geom.rs, lighting.rs, env.rs, meshes.rs (map renderer), gpu.rs (wgpu
passes in flush3DFrame order, offscreen MSAA texture shown by egui), audio.rs (cpal, WSOLA speed,
hitsounds), state.rs (map-state/playback/presentation), src/ui/viewer_ui.rs (dock, HUD, timeline).
The original's instanced note program never links in WebGL1 (uEyeX precision mismatch), so it always
uses CPU note triangles + procedural bombs and no planar mirror; `scene::NOTE_INSTANCING = false`.

Replay (default viewer mode, Settings › Viewer mode switches to Map):
- replay_sim.rs = replay-math.js + replay-simulator.js + cyberMapWalls/cyberDodgeWalls. Bit-identical
  to the JS (same score/events/poses on the test map); trig/exp go through `libm` (fdlibm, as V8).
  Model: assets/viewer/replay-model.json.z, inflated once (Model::shared). Runs on a worker thread;
  the stage stays #050609 until the first pose (cyber-await-first-pose); autoplay waits for it.
- replay.rs = poseAt, BeatLeader pose conversion, deck clipping, hilt/blade/glow/headset/trail
  geometry into replay_opaque/replay_transparent, HMD camera (cyberUpdateHmdCamera, 110° long-axis
  FOV, camera 1.40 m behind). POV only in DefaultEnvironment; 90/360 draw sabers + headset instead.
- bsor.rs = packBSOR/parseBSOR + map SHA-1 (Info.dat + listed difficulty files). Output is
  byte-identical to the JS packBSOR. Export Replay (export popover / Settings) switches to Replay,
  waits for the simulated track and saves `<song>_<diff>_CyberStyle_SIMULATED.bsor`. Import BSOR
  (Settings or drop a .bsor) checks the map hash and shows the recorded track.
- The cyber HUD/loader are `display:none` in the original page, so they are not drawn.
Debug: `simbers replay-dump <zip> [eyeY]` prints pose samples, score and the BSOR digest for diffing
against `__CYBER_REPLAY_DEBUG` in Chromium. Visual diff (t=10/t=40 replay POV): mean 2.3-2.6/255.
