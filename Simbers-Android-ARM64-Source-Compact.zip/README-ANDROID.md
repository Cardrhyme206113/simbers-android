# Simbers for Android (ARM64) — experimental native Rust port

This is a source-based port of the original `simbers-rs` workspace, not a WebView. It keeps the existing Rust analysis, full flow corpus, map generation, Ogg encoding, history, egui state, wgpu renderer, and CPAL audio player. Android-specific components are limited to the application entry point, SAF file picker/export bridge, app-private storage, font fallbacks, and a touch-first layout.

**YouTube/yt-dlp is disabled on Android only.** Windows and desktop Rust code is preserved, including its original yt-dlp backend; the Windows-only vendor binaries are omitted from this compact Android upload. FFmpeg executable fallback is unavailable on Android; Symphonia supports common MP3, FLAC, WAV, AAC/M4A formats. The APK is compiled exclusively for `arm64-v8a` (API 26+).

## Build on GitHub (no local Android Studio necessary)

1. Create a **private** GitHub repository named `simbers-android` (this code is your source; avoid the Pages repository).
2. Upload **all contents of this archive to the repository root**, preserving `.github/workflows/android-apk.yml` and the `android/` subdirectory. GitHub web upload may omit dotfiles; double-check `.github/workflows/android-apk.yml` exists.
3. Push to `main` or click **Actions → Android APK (ARM64) → Run workflow**.
4. Once the job succeeds, open its **Artifacts** section and download **Simbers-Android-ARM64-APK**, unzip it, then install `app-debug.apk` on an ARM64 phone. Debug packages are signed using Android's standard debug key by Gradle; no signing secret needed for testing.

For subsequent runs simply edit your repo; each push to `main` triggers the build.

## Android-specific changes

- `src/lib.rs` exports `android_main` as a native shared library and retains all core modules.
- `src/platform.rs` bridges Rust to Java file import/export, using `ACTION_OPEN_DOCUMENT` and `ACTION_CREATE_DOCUMENT`. SAF data is copied into app-private storage and output is written through the selected URI; no broad storage permission is needed.
- `src/ui/mobile.rs` implements a compact responsive view with settings, source import, generation, history, export, and a fullscreen viewer.
- `src/ui/mod.rs` branches at compile time: Android calls the mobile layout; desktop runs the existing pixel-precise interface.
- `src/storage/kv.rs`, `src/ui/theme.rs`, `src/export/cover.rs`, `src/audio/mod.rs` have small Android-aware adaptations.
- Native audio playback uses CPAL's Android backend. GPU rendering is still wgpu/Vulkan.

## Limitations and validation status

**Source-prepared, NOT yet compiled on GitHub Actions or tested on an Android device.** A first CI run is necessary to validate the Rust dependency graph and native codec cross-compilation (`vorbis_rs` and its C libraries), Java/Gradle packaging, and Android runtime behavior. Do not consider this a confirmed working APK until a workflow and device smoke test succeed.

First smoke test on an ARM64 phone:

1. Launch app in portrait, tap **Import audio / ZIP** and select an MP3 or WAV.
2. Tap **Create Map**, verify progress and creation; use **Export ZIP** and confirm the destination chooser writes a valid ZIP.
3. Reopen that ZIP with **Import audio / ZIP**; open the native GPU viewer and try playback.
4. Open a past job, export/reprocess it; verify it persists after app restart.
5. Check `adb logcat -s RustStdoutStderr:* simbers:* AndroidRuntime:E` if startup fails. For a complete log use `adb logcat | grep -Ei 'simbers|libsimbers|AndroidRuntime|FATAL'`.

Potential runtime issues requiring a follow-up patch after CI: wgpu adapter selection/Vulkan availability, Android audio output device permissions, plugin/native C linkage, keyboard IME handling, small landscape viewer toolbar, and permission/intent behavior on vendor-modified Android.

## Build locally (optional)

Requires Rust stable, Android SDK 35, NDK r27c, JDK 17, Gradle 8.11.1, and `cargo-ndk`:

```bash
rustup target add aarch64-linux-android
cargo install cargo-ndk --locked
export ANDROID_NDK_HOME="$ANDROID_HOME/ndk/27.2.12479018"
cargo ndk -t arm64-v8a -o android/app/src/main/jniLibs build --release --lib
cd android && gradle :app:assembleDebug
```

## Compact Android source package

The compact upload ZIP omits the Windows-only `vendor/yt-dlp/yt-dlp_win.zip` and `vendor/yt-dlp/qjs.exe` binaries (approximately 25 MB unpacked). These files are not referenced when compiling for Android. All Rust sources, Android project files, original map corpus and viewer assets, and GitHub Actions workflow are included.

This ZIP is suitable for the **Android build**. To compile the original Windows desktop app with embedded yt-dlp, restore the two Windows-only binaries from the original `card.rar` (`simbers-rs/vendor/yt-dlp/`) before building on Windows.
